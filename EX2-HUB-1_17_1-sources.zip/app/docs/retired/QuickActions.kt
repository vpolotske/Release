package com.ex2hub.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import com.ex2hub.data.SourceMode

object QuickActions {
    fun launch(context: Context, action: QuickAction): String? {
        val intent = when (action) {
            QuickAction.NAV -> Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="))
            QuickAction.MUSIC -> Intent.makeMainSelectorActivity(
                Intent.ACTION_MAIN,
                Intent.CATEGORY_APP_MUSIC
            )
            QuickAction.PHONE -> Intent(Intent.ACTION_DIAL)
            QuickAction.CAMERA -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            QuickAction.BLUETOOTH -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            QuickAction.SYSTEM -> Intent(Settings.ACTION_SETTINGS)
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            null
        } catch (error: ActivityNotFoundException) {
            "Приложение для «${action.title.lowercase()}» не найдено на этом ГУ."
        } catch (error: SecurityException) {
            "Система не разрешила открыть «${action.title.lowercase()}»."
        }
    }

    fun launchSourceSettings(context: Context, mode: SourceMode): String? {
        val intent = when (mode) {
            SourceMode.CAR_API -> Intent(Settings.ACTION_SETTINGS)
            SourceMode.ROOT -> null
            SourceMode.MANUAL -> null
            SourceMode.DEMO -> null
        } ?: return "Настройки этого источника — внутри приложения."
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            null
        } catch (error: ActivityNotFoundException) {
            "Системные настройки недоступны."
        }
    }
}
