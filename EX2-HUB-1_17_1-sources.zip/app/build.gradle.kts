plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ex2hub"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.ex2hub"
        minSdk = 26
        targetSdk = 34
        versionCode = 46
        versionName = "1.17.1"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    // Постоянный ключ для релизов. На машине сборки без постоянного ~/.android/debug.keystore
    // (GitHub Actions, чистый компьютер) debug-ключ каждый раз создаётся заново, и тогда
    // новая сборка не ставится поверх прежней, а встроенное обновление её отклоняет как
    // «подписано другим ключом». Если заданы переменные EX2_KEYSTORE_*, релиз подписывается
    // ими; без них поведение прежнее — подпись debug-ключом.
    val releaseKeystore = System.getenv("EX2_KEYSTORE_FILE")?.takeIf { it.isNotBlank() && file(it).isFile }

    signingConfigs {
        getByName("debug") {
            // AGP включает v1 только при minSdk ниже 24, а у нас minSdk 26 — в 1.8.6–1.13.0
            // JAR-подписи не было вовсе. Включаем вручную: установщик прошивки может читать
            // только её. Причина отказа обновления на ГУ не замерена — это страховка.
            enableV1Signing = true
            enableV2Signing = true
        }
        if (releaseKeystore != null) {
            create("ex2release") {
                storeFile = file(releaseKeystore)
                storePassword = System.getenv("EX2_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("EX2_KEY_ALIAS")
                keyPassword = System.getenv("EX2_KEY_PASSWORD")
                enableV1Signing = true
                enableV2Signing = true
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // Без постоянного ключа — тот же, что у debug-сборок: релиз ставится поверх и
            // сохраняет журнал. С ключом из EX2_KEYSTORE_* подписывается им.
            signingConfig = signingConfigs.findByName("ex2release") ?: signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("com.android.tools.build:apksig:8.5.2")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.2")

    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")

    debugImplementation("androidx.compose.ui:ui-tooling")

    testImplementation("junit:junit:4.13.2")
}
