#!/usr/bin/env bash
# Съёмка интерфейса EX2 HUB с подключённого головного устройства.
# Использование: bash tools/hu-ui-check.sh [серийник|IP:5555] [--apk путь] [--probe]
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ADB="${ADB:-$ROOT/../.toolchain/android-sdk/platform-tools/adb.exe}"
APK="$(ls -1 "$ROOT"/dist/*.apk 2>/dev/null | tail -1)"
OUT="$ROOT/docs/shots/$(date +%Y%m%d-%H%M%S)"
SERIAL=""
PROBE=0

args=("$@")
i=0
while [ $i -lt ${#args[@]} ]; do
  case "${args[$i]}" in
    --apk) i=$((i + 1)); APK="${args[$i]}" ;;
    --out) i=$((i + 1)); OUT="${args[$i]}" ;;
    --probe) PROBE=1 ;;
    *) SERIAL="${args[$i]}" ;;
  esac
  i=$((i + 1))
done

if [ ! -f "$APK" ]; then echo "APK не найден: $APK" >&2; exit 1; fi
if [ ! -x "$ADB" ] && [ ! -f "$ADB" ]; then echo "adb не найден: $ADB" >&2; exit 1; fi

A() { if [ -n "$SERIAL" ]; then "$ADB" -s "$SERIAL" "$@"; else "$ADB" "$@"; fi; }

case "$SERIAL" in
  *:*) A connect "$SERIAL" ;;
esac
if ! A get-state >/dev/null 2>&1; then
  echo "Устройство не подключено. Подключите ГУ и повторите, или передайте IP:5555." >&2
  A devices >&2
  exit 1
fi

mkdir -p "$OUT"
echo "Устройство: $(A shell getprop ro.product.model | tr -d '\r') · Android $(A shell getprop ro.build.version.release | tr -d '\r') · $(A shell wm size | tr -d '\r')"
echo "APK: $APK"
A install -r "$APK"
A shell am force-stop com.ex2hub
A shell am start -n com.ex2hub/.MainActivity >/dev/null
sleep 3

dump_ui() { A shell uiautomator dump /sdcard/ex2hub_ui.xml >/dev/null 2>&1 || true; A pull /sdcard/ex2hub_ui.xml "$OUT/ui.xml" >/dev/null 2>&1 || true; }

# Центр элемента по content-desc или text: uiautomator пишет bounds последним атрибутом.
tap_attr() {
  local attr="$1" value="$2" bounds
  dump_ui
  [ -f "$OUT/ui.xml" ] || { echo "  нет дампа интерфейса: $value" >&2; return 1; }
  bounds=$(grep -o "$attr=\"$value\"[^>]*bounds=\"\\[[0-9]*,[0-9]*\\]\\[[0-9]*,[0-9]*\\]\"" "$OUT/ui.xml" 2>/dev/null | tail -1 || true)
  if [ -z "$bounds" ]; then echo "  не нашёл элемент: $value" >&2; return 1; fi
  local nums x y
  nums=$(echo "$bounds" | grep -o '[0-9]\+')
  x=$(( ( $(echo "$nums" | sed -n 1p) + $(echo "$nums" | sed -n 3p) ) / 2 ))
  y=$(( ( $(echo "$nums" | sed -n 2p) + $(echo "$nums" | sed -n 4p) ) / 2 ))
  A shell input tap "$x" "$y"
  sleep 2
}

capture() { A exec-out screencap -p > "$OUT/$1.png"; echo "  -> $1.png"; }

echo "Экраны:"
for tab in "Рабочий стол:home" "Поездки:trips" "Зарядки:charging" "Настройки:settings"; do
  tap_attr "content-desc" "${tab%%:*}" && capture "${tab##*:}"
done

if [ "$PROBE" = 1 ]; then
  echo "Проба источника:"
  tap_attr "text" "Проверить доступ"
  sleep 25
  capture settings-probe
fi

A shell "run-as com.ex2hub cat /data/data/com.ex2hub/shared_prefs/ex2hub_state.xml" > "$OUT/state.xml" 2>/dev/null || echo "  SharedPreferences недоступны (нужен debug-APK)"
A logcat -d -v brief > "$OUT/logcat.txt" 2>/dev/null
A shell "timeout 20 dumpsys car_service list-properties" > "$OUT/car_service_properties.txt" 2>/dev/null || echo "  car_service не отвечает (обычно так и есть без прав системы)"

echo "Готово: $OUT"
