/* ==========================================================================
   EX2 HUB — инструмент макета.
   app.js отвечает только за предпросмотр и не является частью приложения:
     • переключение экранов (вкладки, рейл, бренд, источник);
     • масштаб разделов 2× / 1.5× / 1× и пороги «широкой» раскладки;
     • вписывание экрана 1920×1080 в окно браузера;
     • направляющие и лёгкие переключатели для проверки внешнего вида.
   ========================================================================== */

(() => {
  const screen = document.getElementById('screen');
  const stage = document.getElementById('stage');
  const scaler = document.getElementById('scaler');
  const toolbar = document.querySelector('.toolbar');
  const scaleTool = document.getElementById('scale-tool');
  const dpReadout = document.getElementById('dp-readout');
  const fitBtn = document.getElementById('fit-btn');
  const oneBtn = document.getElementById('one-btn');
  const guidesBtn = document.getElementById('guides-btn');

  const PAGES = ['home', 'trips', 'charging', 'settings'];
  const BASE_WIDTH = 1920;
  const BASE_HEIGHT = 1080;
  const WORKSPACE_WIDTH = 1768; // 1920 − рейл 152
  const SECTION_PADDING = 36;   // 18 dp с каждой стороны
  const TRIPS_WIDE = 900;
  const SETTINGS_WIDE = 1000;

  const fmtInt = (value) => String(value).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');

  /* ---------- Экраны ------------------------------------------------------ */
  function setPage(page) {
    if (!PAGES.includes(page)) return;
    screen.dataset.page = page;
    document.querySelectorAll('.page').forEach((node) => {
      node.classList.toggle('is-active', node.dataset.page === page);
    });
    document.querySelectorAll('.tab').forEach((node) => {
      node.classList.toggle('is-active', node.dataset.page === page);
    });
    document.querySelectorAll('.rail-item').forEach((node) => {
      node.classList.toggle('is-active', node.dataset.page === page);
    });
  }

  /* ---------- Масштаб разделов ------------------------------------------- */
  function setScale(scale) {
    screen.style.setProperty('--section-scale', scale);
    const logical = Math.round(WORKSPACE_WIDTH / scale - SECTION_PADDING);
    screen.dataset.tripsWide = String(logical >= TRIPS_WIDE);
    screen.dataset.chargingWide = String(logical >= TRIPS_WIDE);
    screen.dataset.settingsWide = String(logical >= SETTINGS_WIDE);

    dpReadout.textContent = `${fmtInt(logical)} dp`;
    dpReadout.title = `Логическая ширина контента раздела: ${fmtInt(logical)} dp`;
    document.querySelectorAll('.js-width').forEach((node) => {
      node.textContent = `${fmtInt(logical)} dp`;
    });
    document.querySelectorAll('.js-scale').forEach((node) => {
      node.textContent = `${scale}×`;
    });
    scaleTool.querySelectorAll('button').forEach((button) => {
      button.classList.toggle('is-active', Number(button.dataset.scale) === scale);
    });
  }

  scaleTool.addEventListener('click', (event) => {
    const button = event.target.closest('button[data-scale]');
    if (button) setScale(Number(button.dataset.scale));
  });

  /* ---------- Вписывание экрана в окно ----------------------------------- */
  let fitMode = true;

  function fitScale() {
    const availableWidth = Math.max(stage.clientWidth - 48, 240);
    const availableHeight = Math.max(window.innerHeight - toolbar.offsetHeight - 48, 160);
    return Math.min(availableWidth / BASE_WIDTH, availableHeight / BASE_HEIGHT, 1);
  }

  function renderMode() {
    if (fitMode) {
      const scale = fitScale();
      scaler.style.width = `${Math.round(BASE_WIDTH * scale)}px`;
      scaler.style.height = `${Math.round(BASE_HEIGHT * scale)}px`;
      scaler.style.overflow = 'hidden';
      screen.style.transform = `scale(${scale})`;
      fitBtn.classList.add('is-on');
      oneBtn.classList.remove('is-on');
    } else {
      scaler.style.width = `${BASE_WIDTH}px`;
      scaler.style.height = `${BASE_HEIGHT}px`;
      scaler.style.overflow = 'visible';
      screen.style.transform = 'none';
      fitBtn.classList.remove('is-on');
      oneBtn.classList.add('is-on');
    }
  }

  fitBtn.addEventListener('click', () => {
    fitMode = true;
    renderMode();
  });
  oneBtn.addEventListener('click', () => {
    fitMode = false;
    renderMode();
  });

  let resizePending = false;
  window.addEventListener('resize', () => {
    if (!fitMode || resizePending) return;
    resizePending = true;
    requestAnimationFrame(() => {
      resizePending = false;
      renderMode();
    });
  });

  /* ---------- Направляющие ------------------------------------------------- */
  guidesBtn.addEventListener('click', () => {
    const enabled = screen.classList.toggle('guides');
    guidesBtn.classList.toggle('is-on', enabled);
  });

  /* ---------- Климат: независимые состояния макета ------------------------ */
  const climate = {
    power: true, ac: true, temp: 22, fan: 3, direction: 0,
    driver: 1, passenger: 1, wheel: false, glass: false, rearGlass: false
  };
  let lastMaxPreset = null;

  function pressed(button, on, className = 'is-on') {
    button.classList.toggle(className, on);
    button.setAttribute('aria-pressed', String(on));
  }

  function renderClimate() {
    const power = document.getElementById('climate-power');
    power.classList.toggle('is-off', !climate.power);
    power.textContent = climate.power ? 'Вкл' : 'Выкл';
    power.setAttribute('aria-pressed', String(climate.power));
    pressed(document.getElementById('climate-ac'), climate.ac);
    document.getElementById('cabin-temp').textContent = String(climate.temp);
    document.getElementById('fan-level').textContent = String(climate.fan);
    document.querySelectorAll('#fan-bars i').forEach((bar, i) => bar.classList.toggle('on', i < climate.fan));
    document.querySelectorAll('.dir2').forEach((button, i) => pressed(button, i === climate.direction, 'is-active'));
    document.querySelectorAll('[data-seat]').forEach((button) => {
      const level = climate[button.dataset.seat];
      const person = button.dataset.seat === 'driver' ? 'водителя' : 'пассажира';
      button.dataset.level = String(level);
      button.classList.toggle('is-on', level > 0);
      button.setAttribute('aria-label', `Подогрев сиденья ${person}: ${level} из 3`);
      button.querySelectorAll('.heat-wave').forEach((wave, i) => wave.classList.toggle('is-on', i < level));
    });
    pressed(document.getElementById('wheel-heat'), climate.wheel);
    document.querySelectorAll('.glass2').forEach((button, i) => pressed(button, i === 0 ? climate.glass : climate.rearGlass));
    document.querySelectorAll('[data-preset]').forEach((button) => {
      const active = lastMaxPreset === button.dataset.preset;
      pressed(button, active, 'is-active');
      button.title = active ? 'Повторное нажатие: выключить пресет' : 'Быстрый режим, вентилятор 6/8';
    });
  }

  function applyPreset(preset) {
    const cool = preset === 'QUICK_COOL';
    if (lastMaxPreset === preset) {
      // Второе нажатие снимает пресет сразу, не дожидаясь ручной правки обогрева.
      climate.ac = false;
      climate.driver = climate.passenger = 0;
      climate.wheel = climate.glass = climate.rearGlass = false;
      lastMaxPreset = null;
      renderClimate();
      return;
    }
    climate.power = true;
    climate.fan = 6;
    climate.ac = cool;
    climate.temp = cool ? 17 : 32;
    climate.direction = cool ? 1 : 3;
    climate.driver = climate.passenger = cool ? 0 : 3;
    climate.wheel = climate.glass = climate.rearGlass = !cool;
    lastMaxPreset = preset;
    renderClimate();
  }

  function changeClimate(change) {
    lastMaxPreset = null;
    change();
    renderClimate();
  }

  /* ---------- Клики ------------------------------------------------------- */
  const NAV_SELECTOR = [
    '.tab[data-page]',
    '.rail-item[data-page]',
    '.brand[data-page]',
    '.source-pill[data-page]',
    '.btn[data-page]',
    '.dock-tile[data-page]'
  ].join(', ');

  function cycleHeat(tile) {
    const dots = Array.from(tile.querySelectorAll('.level-dots i'));
    const current = dots.filter((dot) => dot.classList.contains('on')).length;
    const level = (current + 1) % (dots.length + 1);
    dots.forEach((dot, index) => dot.classList.toggle('on', index < level));
    tile.classList.toggle('is-on', level > 0);
  }

  document.addEventListener('click', (event) => {
    if (!(event.target instanceof Element)) return;

    const nav = event.target.closest(NAV_SELECTOR);
    if (nav) {
      setPage(nav.dataset.page);
      return;
    }

    const seg = event.target.closest('.seg');
    if (seg && seg.parentElement && seg.parentElement.classList.contains('segments')) {
      seg.parentElement.querySelectorAll('.seg').forEach((node) => {
        node.classList.toggle('is-active', node === seg);
      });
      return;
    }

    const modeSeg = event.target.closest('.mode-seg');
    if (modeSeg) {
      modeSeg.parentElement.querySelectorAll('.mode-seg').forEach((node) => {
        node.classList.toggle('is-active', node === modeSeg);
      });
      return;
    }

    const preset = event.target.closest('[data-preset]');
    if (preset) {
      applyPreset(preset.dataset.preset);
      return;
    }

    const direction2 = event.target.closest('.dir2');
    if (direction2) {
      changeClimate(() => { climate.direction = Array.from(direction2.parentElement.children).indexOf(direction2); });
      return;
    }

    const seat = event.target.closest('[data-seat]');
    if (seat) {
      changeClimate(() => { climate[seat.dataset.seat] = (climate[seat.dataset.seat] + 1) % 4; });
      return;
    }

    const wheel = event.target.closest('#wheel-heat');
    if (wheel) {
      changeClimate(() => { climate.wheel = !climate.wheel; });
      return;
    }

    const glass = event.target.closest('.glass2');
    if (glass) {
      const key = glass === document.querySelector('.glass2') ? 'glass' : 'rearGlass';
      changeClimate(() => { climate[key] = !climate[key]; });
      return;
    }

    const tempStep = event.target.closest('.temp-step');
    if (tempStep) {
      changeClimate(() => { climate.temp = Math.min(32, Math.max(17, climate.temp + Number(tempStep.dataset.step))); });
      return;
    }

    const fanStep = event.target.closest('.fan-step');
    if (fanStep) {
      changeClimate(() => { climate.fan = Math.min(8, Math.max(0, climate.fan + Number(fanStep.dataset.step))); });
      return;
    }

    const ac = event.target.closest('#climate-ac');
    if (ac) {
      changeClimate(() => { climate.ac = !climate.ac; });
      return;
    }

    const power = event.target.closest('#climate-power');
    if (power) {
      changeClimate(() => { climate.power = !climate.power; });
      return;
    }

    const direction = event.target.closest('.dir-btn');
    if (direction) {
      direction.parentElement.querySelectorAll('.dir-btn').forEach((node) => {
        node.classList.toggle('is-active', node === direction);
      });
      return;
    }

    const toggle = event.target.closest('.toggle');
    if (toggle) {
      toggle.classList.toggle('is-on');
      return;
    }

    const tile = event.target.closest('.heat-tile');
    if (tile) {
      cycleHeat(tile);
      return;
    }

    const source = event.target.closest('.source-option');
    if (source) {
      source.parentElement.querySelectorAll('.source-option').forEach((node) => {
        node.classList.toggle('is-selected', node === source);
      });
      return;
    }

    const switchNode = event.target.closest('.switch');
    if (switchNode) {
      switchNode.classList.toggle('is-on');
    }
  });

  /* ---------- Клавиатура --------------------------------------------------- */
  window.addEventListener('keydown', (event) => {
    if (event.altKey || event.ctrlKey || event.metaKey) return;
    if (event.target instanceof HTMLElement &&
        /^(input|textarea|select)$/i.test(event.target.tagName)) return;
    const index = Number(event.key) - 1;
    if (index >= 0 && index < PAGES.length) {
      event.preventDefault();
      setPage(PAGES[index]);
    }
  });

  /* ---------- Локальные настройки предпросмотра --------------------------- */
  const storageKey = 'ex2-hub-mockup-settings';
  const settings = { tariff: 0.28, volume: 12, brightness: 70, auto: true };
  try {
    const saved = JSON.parse(localStorage.getItem(storageKey));
    if (saved && typeof saved === 'object') {
      for (const [key, min, max] of [['tariff', 0, 100000], ['volume', 0, 30], ['brightness', 10, 100]]) {
        if (Number.isFinite(saved[key]) && saved[key] >= min && saved[key] <= max) settings[key] = saved[key];
      }
      if (typeof saved.auto === 'boolean') settings.auto = saved.auto;
    }
  } catch (_) { /* Предпросмотр работает и без доступа к localStorage. */ }

  function saveSettings() {
    try {
      localStorage.setItem(storageKey, JSON.stringify(settings));
      return true;
    } catch (_) { return false; }
  }

  const tariffInput = document.getElementById('tariff');
  const tariffStatus = document.getElementById('tariff-status');
  const money = (value) => value.toLocaleString('ru-RU', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  function renderTariff() {
    tariffInput.value = String(settings.tariff).replace('.', ',');
    document.querySelector('.charge-kpis .kpi-card:last-child .kpi-value b').textContent = tariffInput.value;
    document.querySelector('.range-tariff b').textContent = `${tariffInput.value} р.`;
    document.querySelector('.charge-kpis .kpi-card:nth-child(2) .kpi-value b').textContent = money(17.1 * settings.tariff);
    document.querySelector('.trips-summary .summary-row:last-child b').textContent = `${money(30.5 * settings.tariff)} р.`;
    for (const [page, energyIndex] of [['trips', 3], ['charging', 1]]) {
      document.querySelectorAll(`.page[data-page="${page}"] .table-row`).forEach((row) => {
        const cells = row.querySelectorAll('.cell');
        const energy = parseFloat(cells[energyIndex].textContent.replace(',', '.'));
        cells[cells.length - 1].textContent = `${money(energy * settings.tariff)} р.`;
      });
    }
  }
  document.getElementById('tariff-form').addEventListener('submit', (event) => {
    event.preventDefault();
    const raw = tariffInput.value.trim().replace(',', '.');
    const value = Number(raw);
    const valid = /^\d+(\.\d{1,4})?$/.test(raw) && Number.isFinite(value) && value <= 100000;
    tariffInput.setAttribute('aria-invalid', String(!valid));
    if (!valid) {
      tariffStatus.textContent = 'Введите тариф от 0 до 100 000, не более 4 знаков после запятой.';
      return;
    }
    settings.tariff = value;
    renderTariff();
    tariffStatus.textContent = saveSettings() ? 'Тариф сохранён. Стоимость пересчитана.' : 'Тариф применён до закрытия страницы: хранилище недоступно.';
  });

  const volume = document.getElementById('volume');
  const brightness = document.getElementById('brightness');
  const auto = document.getElementById('brightness-auto');
  function renderControls() {
    volume.value = String(settings.volume);
    brightness.value = String(settings.brightness);
    auto.checked = settings.auto;
    document.getElementById('volume-value').textContent = `${settings.volume}/30`;
    document.getElementById('brightness-value').textContent = `${settings.auto ? 'Авто · ' : ''}${settings.brightness}%`;
    screen.style.filter = `brightness(${settings.auto ? 1 : 0.45 + settings.brightness * 0.0055})`;
  }
  function updateControls() {
    renderControls();
    document.getElementById('controls-status').textContent = saveSettings()
      ? 'Сохранено в макете. Звук и яркость ГУ не изменяются.'
      : 'Применено до закрытия страницы: хранилище недоступно.';
  }
  volume.addEventListener('input', () => { settings.volume = Number(volume.value); updateControls(); });
  brightness.addEventListener('input', () => {
    settings.brightness = Number(brightness.value);
    settings.auto = false;
    updateControls();
  });
  auto.addEventListener('change', () => { settings.auto = auto.checked; updateControls(); });

  /* ---------- Стартовое состояние ----------------------------------------- */
  renderClimate();
  renderTariff();
  renderControls();
  // Ссылку можно сохранить вместе с состоянием: ?page=trips&scale=1.5&guides=1&fit=0
  const params = new URLSearchParams(location.search);
  const startPage = params.get('page');
  const startScale = Number(params.get('scale'));

  setPage(PAGES.includes(startPage) ? startPage : (screen.dataset.page || 'home'));
  setScale([2, 1.5, 1].includes(startScale) ? startScale : 1.5);
  if (params.get('guides') === '1') {
    screen.classList.add('guides');
    guidesBtn.classList.add('is-on');
  }
  if (params.get('fit') === '0') fitMode = false;
  renderMode();

  window.addEventListener('load', () => {
    if (fitMode) renderMode();
  });
})();
