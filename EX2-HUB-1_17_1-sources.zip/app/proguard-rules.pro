# R8 shrinks and optimizes; names stay readable for stack traces from the head unit.
-dontobfuscate
