package com.ex2hub.update

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.assertThrows
import org.junit.Test

class VersionNamesTest {
    @Test fun nextReleaseIsNewer() {
        assertTrue(compareVersionNames("1.8.6", "1.8.5") > 0)
        assertEquals(0, compareVersionNames("1.8.5", "1.8.5"))
        assertTrue(compareVersionNames("1.8.4", "1.8.5") < 0)
    }

    @Test fun componentsAreNumericNotLexicographic() {
        assertTrue(compareVersionNames("1.10.0", "1.9.99") > 0)
        assertTrue(compareVersionNames("2.0.0", "1.999.999") > 0)
        assertTrue(compareVersionNames("1.8.100", "1.8.99") > 0)
    }

    @Test fun largeComponentsDoNotOverflow() {
        assertTrue(compareVersionNames("999999999999999999999.0.0", "2147483647.0.0") > 0)
    }

    @Test fun semverPrereleasePrecedence() {
        val versions = listOf(
            "1.0.0-alpha", "1.0.0-alpha.1", "1.0.0-alpha.beta", "1.0.0-beta",
            "1.0.0-beta.2", "1.0.0-beta.11", "1.0.0-rc.1", "1.0.0"
        )
        versions.zipWithNext().forEach { (older, newer) ->
            assertTrue("$newer > $older", compareVersionNames(newer, older) > 0)
        }
    }

    @Test fun buildMetadataDoesNotChangePrecedence() {
        assertEquals(0, compareVersionNames("1.8.6+build.1", "1.8.6+build.02"))
        assertEquals(0, compareVersionNames("1.8.6+abc", "1.8.6"))
    }

    @Test fun rejectsMalformedVersionsOnBothSides() {
        val invalid = listOf(
            "", "1", "1.8", "1.8.6.0", "v1.8.6", "01.8.6", "1.08.6", "1.8.06",
            "-1.8.6", "1.8.6-", "1.8.6-01", "1.8.6-alpha.01", "1.8.6+",
            "1.8.6+build..1", " 1.8.6", "1.8.6\n", "1.8.6/evil", "１.8.6", "9".repeat(129)
        )
        invalid.forEach { value ->
            assertThrows(value, IllegalArgumentException::class.java) { compareVersionNames(value, "1.8.5") }
            assertThrows(value, IllegalArgumentException::class.java) { compareVersionNames("1.8.6", value) }
        }
    }

    @Test fun tagAcceptsPlainOrLowercaseVStableSemverOnly() {
        assertEquals("1.8.6", versionFromTag("v1.8.6"))
        assertEquals("1.8.6", versionFromTag("1.8.6"))
        assertEquals("1.8.6+build.2", versionFromTag("v1.8.6+build.2"))
        listOf("V1.8.6", "vv1.8.6", "v01.8.6", "v1.8.6-rc.1", "v1.8.6/evil").forEach {
            assertThrows(IllegalArgumentException::class.java) { versionFromTag(it) }
        }
    }
}
