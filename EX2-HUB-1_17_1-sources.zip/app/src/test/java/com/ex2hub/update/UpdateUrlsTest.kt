package com.ex2hub.update

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class UpdateUrlsTest {
    private val tag = "v1.8.6"
    private val name = "EX2-HUB-1.8.6.apk"
    private val url = "https://github.com/vpolotske/Release/releases/download/$tag/$name"
    private val release = UpdateRelease("1.8.6", tag, name, url, "sha256:" + "a".repeat(64), 3)

    @Test fun acceptsOnlyExactRepositoryTagAndFile() {
        validateAssetUrl(url, tag, name)
        validateReleaseUrls(
            "https://api.github.com/repos/vpolotske/Release/releases/123",
            "https://github.com/vpolotske/Release/releases/tag/$tag", tag
        )
    }

    @Test fun rejectsWrongAssetOriginAndPath() {
        val invalid = listOf(
            url.replace("https:", "http:"),
            url.replace("github.com", "evil.example"),
            url.replace("github.com", "github.com.evil.example"),
            url.replace("github.com", "github.com@evil.example"),
            url.replace("github.com", "user:secret@github.com"),
            url.replace("github.com", "github.com:444"),
            url.replace("vpolotske", "another-owner"),
            url.replace("/Release/", "/Other/"),
            url.replace(tag, "v1.8.7"),
            url.replace(name, "other.apk"),
            url.replace("/download/", "/download/../download/"),
            url.replace("/Release/", "/Release%2F..%2FOther/"),
            url.replace("github.com", "release-assets.githubusercontent.com"),
            "$url?token=anything", "$url#fragment", "$url/", "file:///tmp/$name", "not a URL"
        )
        invalid.forEach {
            assertThrows(it, IllegalArgumentException::class.java) { validateAssetUrl(it, tag, name) }
        }
        assertThrows(IllegalArgumentException::class.java) { validateAssetUrl(url, tag, "EX2-HUB-1.8.5.apk") }
    }

    @Test fun releaseMetadataMustReferenceSameRepositoryAndTag() {
        val api = "https://api.github.com/repos/vpolotske/Release/releases/123"
        val html = "https://github.com/vpolotske/Release/releases/tag/$tag"
        listOf(
            api.replace("vpolotske", "fork"), api.replace("/Release/", "/Other/"),
            api.replace("api.github.com", "evil.example"), api.replace("https:", "http:"),
            api.replace("123", "latest"), api.replace("123", "-1"), "$api?x=1", "$api#x"
        ).forEach {
            assertThrows(IllegalArgumentException::class.java) { validateReleaseUrls(it, html, tag) }
        }
        listOf(
            html.replace(tag, "v1.8.5"), html.replace("vpolotske", "fork"),
            html.replace("github.com", "evil.example"), "$html?x=1", "$html#x"
        ).forEach {
            assertThrows(IllegalArgumentException::class.java) { validateReleaseUrls(api, it, tag) }
        }
    }

    @Test fun signedCdnRedirectsAndRelativeGitHubRedirectAreAllowed() {
        listOf("release-assets.githubusercontent.com", "objects.githubusercontent.com").forEach { host ->
            val cdn = "https://$host/some/asset.apk?sig=public-signed-value&expires=123"
            assertEquals(cdn, resolveDownloadRedirect(url, cdn, release))
        }
        assertEquals(url, resolveDownloadRedirect(url, "/vpolotske/Release/releases/download/$tag/$name", release))
        validateAssetUrl(url.replace("github.com", "github.com:443"), tag, name)
    }

    @Test fun redirectsCannotDowngradeHttpsLeakCredentialsOrEscapeAllowlist() {
        listOf(
            "http://release-assets.githubusercontent.com/asset",
            "https://evil.example/asset", "//evil.example/asset",
            "https://release-assets.githubusercontent.com.evil.example/asset",
            "https://api.github.com/asset", "https://raw.githubusercontent.com/asset",
            "https://user:secret@objects.githubusercontent.com/asset",
            "https://objects.githubusercontent.com:8443/asset", "https://objects.githubusercontent.com/asset#frag",
            "https://github.com/fork/Release/releases/download/$tag/$name",
            "https://github.com/vpolotske/Release/releases/download/v1.8.5/$name",
            "file:///tmp/asset", "https://objects.githubusercontent.com/" + "x".repeat(16_384)
        ).forEach {
            assertThrows(it, IllegalArgumentException::class.java) { resolveDownloadRedirect(url, it, release) }
        }
    }

    @Test fun missingReleaseInPublicRepositoryIsNotReportedAsPrivateOrCurrent() {
        val message = UpdateHttp.latestReleaseFailure(404, repositoryStatus = 200)
        org.junit.Assert.assertTrue(message.contains("нет опубликованного стабильного релиза"))
        org.junit.Assert.assertFalse(message.contains("закрыт"))
        org.junit.Assert.assertFalse(message.contains("актуальная"))
    }

    @Test fun unavailableRepositoryAndUnknownVisibilityAreDifferent() {
        org.junit.Assert.assertTrue(UpdateHttp.latestReleaseFailure(404, 404).contains("не найден или закрыт"))
        org.junit.Assert.assertTrue(UpdateHttp.latestReleaseFailure(404).contains("Не удалось уточнить"))
        org.junit.Assert.assertTrue(UpdateHttp.latestReleaseFailure(403, rateLimited = true).contains("лимит"))
        org.junit.Assert.assertTrue(UpdateHttp.latestReleaseFailure(429).contains("лимит"))
    }

    @Test fun encodedSemverBuildMetadataStillMatchesExactDecodedPath() {
        validateAssetUrl(
            "https://github.com/vpolotske/Release/releases/download/v1.8.6%2Bbuild.2/EX2-HUB-1.8.6%2Bbuild.2.apk",
            "v1.8.6+build.2", "EX2-HUB-1.8.6+build.2.apk"
        )
    }
}
