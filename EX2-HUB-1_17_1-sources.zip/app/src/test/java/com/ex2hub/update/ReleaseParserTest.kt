package com.ex2hub.update

import java.security.MessageDigest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Test

class ReleaseParserTest {
    private val digest = "sha256:" + "a".repeat(64)

    private fun quote(value: String?): String = value?.let {
        "\"" + it.replace("\\", "\\\\").replace("\"", "\\\"") + "\""
    } ?: "null"

    private fun asset(
        tag: String = "v1.8.6",
        name: String = "EX2-HUB-${tag.removePrefix("v")}.apk",
        state: String = "uploaded",
        size: String = "3",
        hash: String? = digest,
        url: String = "https://github.com/vpolotske/Release/releases/download/$tag/$name"
    ): String = """
        {"name":${quote(name)},"state":${quote(state)},"size":$size,
         "digest":${quote(hash)},"browser_download_url":${quote(url)}}
    """.trimIndent()

    private fun json(
        tag: String = "v1.8.6",
        assets: String = asset(tag),
        draft: String = "false",
        prerelease: String = "false",
        apiUrl: String = "https://api.github.com/repos/vpolotske/Release/releases/123",
        htmlUrl: String = "https://github.com/vpolotske/Release/releases/tag/$tag"
    ): String = """
        {"url":${quote(apiUrl)},"html_url":${quote(htmlUrl)},"tag_name":${quote(tag)},
         "draft":$draft,"prerelease":$prerelease,"assets":[$assets]}
    """.trimIndent()

    private fun parse(json: String): UpdateRelease = parseLatestRelease(json.toByteArray(Charsets.UTF_8))

    private fun rejects(json: String) {
        assertThrows(IllegalArgumentException::class.java) { parse(json) }
    }

    @Test fun selectsExpectedUploadedApkAndNormalizesDigest() {
        val release = parse(json(assets = asset(hash = "sha256:" + "A".repeat(64))))
        assertEquals("1.8.6", release.versionName)
        assertEquals("v1.8.6", release.tag)
        assertEquals("EX2-HUB-1.8.6.apk", release.assetName)
        assertEquals(3L, release.size)
        assertEquals(digest, release.digest)
        assertEquals("https://github.com/vpolotske/Release/releases/download/v1.8.6/EX2-HUB-1.8.6.apk", release.url)
        assertEquals("1.8.6", parse(json(tag = "1.8.6")).versionName)
    }

    @Test fun ignoresUnrelatedAssetsButNeverSelectsWrongVersion() {
        val unrelated = asset(name = "notes.txt", hash = null, size = "0")
        assertEquals("EX2-HUB-1.8.6.apk", parse(json(assets = "$unrelated,${asset()}")).assetName)
        rejects(json(assets = unrelated))
        rejects(json(assets = asset(name = "EX2-HUB-1.8.5.apk")))
        rejects(json(assets = asset(name = "ex2-hub-1.8.6.apk")))
        rejects(json(assets = ""))
    }

    @Test fun duplicateCandidatesAreAmbiguousEvenIfOneIsNotUploaded() {
        rejects(json(assets = "${asset()},${asset()}"))
        rejects(json(assets = "${asset()},${asset(state = "new")}"))
    }

    @Test fun rejectsUnfinishedAssetsDraftsAndPrereleases() {
        rejects(json(assets = asset(state = "new")))
        rejects(json(assets = asset(state = "starter")))
        rejects(json(draft = "true"))
        rejects(json(prerelease = "true"))
        rejects(json(draft = "null"))
        rejects(json(prerelease = "\"false\""))
        rejects(json(tag = "v1.8.6-rc.1"))
    }

    @Test fun digestIsMandatoryAndExactlySha256Hex() {
        listOf(null, "", "sha256:", "sha256:" + "a".repeat(63), "sha256:" + "a".repeat(65),
            "sha256:" + "g".repeat(64), "SHA256:" + "a".repeat(64), "sha512:" + "a".repeat(64),
            "a".repeat(64), " $digest"
        ).forEach { rejects(json(assets = asset(hash = it))) }
        rejects(json().replace("\"digest\":${quote(digest)},", ""))
    }

    @Test fun sizeMustBePositiveIntegerAndAtMost64MiB() {
        assertEquals(MAX_APK_BYTES, parse(json(assets = asset(size = "$MAX_APK_BYTES"))).size)
        listOf("0", "-1", "${MAX_APK_BYTES + 1}", "9223372036854775808", "3.0", "3e0", "03", "\"3\"", "null")
            .forEach { rejects(json(assets = asset(size = it))) }
    }

    @Test fun rejectsWrongRepoTagFileAndHostInApiResponse() {
        rejects(json(apiUrl = "https://api.github.com/repos/fork/Release/releases/123"))
        rejects(json(htmlUrl = "https://github.com/vpolotske/Other/releases/tag/v1.8.6"))
        rejects(json(htmlUrl = "https://github.com/vpolotske/Release/releases/tag/v1.8.5"))
        listOf(
            "http://github.com/vpolotske/Release/releases/download/v1.8.6/EX2-HUB-1.8.6.apk",
            "https://github.com/fork/Release/releases/download/v1.8.6/EX2-HUB-1.8.6.apk",
            "https://github.com/vpolotske/Release/releases/download/v1.8.5/EX2-HUB-1.8.6.apk",
            "https://github.com/vpolotske/Release/releases/download/v1.8.6/wrong.apk",
            "https://evil.example/EX2-HUB-1.8.6.apk"
        ).forEach { rejects(json(assets = asset(url = it))) }
    }

    @Test fun rejectsInvalidVersions() {
        listOf("v1.8", "v01.8.6", "v1.8.6.0", "V1.8.6", "v1.8.6/../evil", "v1.8.6-01")
            .forEach { rejects(json(tag = it)) }
    }

    @Test fun currentOrOlderReleaseIsUpToDateWithoutDemandingAnApk() {
        assertNull(latestUpdateFor(json(tag = "v1.8.5", assets = "").toByteArray(), "1.8.5"))
        assertNull(latestUpdateFor(json(tag = "v1.8.4", assets = "").toByteArray(), "1.8.5"))
        assertEquals("1.8.6", latestUpdateFor(json().toByteArray(), "1.8.5")?.versionName)
        assertThrows(IllegalArgumentException::class.java) {
            latestUpdateFor(json().toByteArray(), "1.8.5-debug-invalid.")
        }
        // Even old metadata must have the trusted repository and valid stable tag.
        assertThrows(IllegalArgumentException::class.java) {
            latestUpdateFor(json(tag = "v1.8.4", apiUrl = "https://evil.example/releases/123").toByteArray(), "1.8.5")
        }
    }

    @Test fun malformedAmbiguousOrTruncatedJsonIsRejected() {
        rejects(json().dropLast(1))
        rejects(json() + " trailing")
        rejects(json().replace("\"draft\":false", "\"draft\":false,\"draft\":false"))
        rejects(json().replace("\"tag_name\":\"v1.8.6\"", "\"tag_name\":\"v1.8.6\",\"\\u0074ag_name\":\"v1.8.6\""))
        rejects(json().replace("\"draft\":false", "\"body\":\"\u0001\",\"draft\":false"))
        rejects(json().replace("\"draft\":false", "\"body\":\"\\u00xx\",\"draft\":false"))
        rejects(json().replace("\"assets\":[", "\"assets\":[null,"))
        rejects(json().dropLast(1) + ",}")
        rejects("[]")
    }

    @Test fun escapedJsonStringsAreDecodedBeforeValidation() {
        val escaped = json().replace("https://", "https:\\/\\/").replace("v1.8.6", "v1.8.\\u0036")
        assertEquals("1.8.6", parse(escaped).versionName)
    }

    @Test fun jsonIsBoundedTo512KiBAndMustBeUtf8() {
        val base = json().dropLast(1) + ",\"body\":\""
        val exactlyBounded = base + "x".repeat(MAX_JSON_BYTES - base.toByteArray().size - 2) + "\"}"
        assertEquals(MAX_JSON_BYTES, exactlyBounded.toByteArray().size)
        assertEquals("1.8.6", parse(exactlyBounded).versionName)
        rejects(exactlyBounded + " ")
        assertThrows(IllegalArgumentException::class.java) { parseLatestRelease(byteArrayOf(0xc3.toByte(), 0x28)) }
    }

    @Test fun excessiveJsonNestingAndNodeCountAreRejected() {
        val nested = "[".repeat(34) + "0" + "]".repeat(34)
        rejects(json().dropLast(1) + ",\"body\":$nested}")
        val nodes = List(32_769) { "0" }.joinToString(",")
        rejects(json().dropLast(1) + ",\"body\":[$nodes]}")
    }

    @Test fun streamedSizeAndDigestMustBothMatchMetadata() {
        val bytes = "apk".toByteArray()
        val sha256 = MessageDigest.getInstance("SHA-256").digest(bytes)
        val release = parse(json(assets = asset(hash = "sha256:${sha256Hex(bytes)}")))
        verifyDownload(release, bytes.size.toLong(), sha256)
        assertThrows(IllegalArgumentException::class.java) { verifyDownload(release, 2, sha256) }
        assertThrows(IllegalArgumentException::class.java) { verifyDownload(release, 4, sha256) }
        assertThrows(IllegalArgumentException::class.java) { verifyDownload(release, 3, ByteArray(32)) }
        assertThrows(IllegalArgumentException::class.java) { verifyDownload(release, 3, sha256.copyOf(31)) }
    }
}
