package com.ex2hub.source

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Держит дешёвый путь опроса: живой поток VHAL рисует только рабочий стол,
 * а климат и кузов читаются только тогда, когда их видно.
 */
class TelemetryLoadContractTest {
    private fun source(relativePath: String): String {
        val path = "src/main/java/com/ex2hub/$relativePath"
        return listOf(File(path), File("app/$path"))
            .first { it.isFile }
            .readText(Charsets.UTF_8)
    }

    private fun String.blockAfter(marker: String): String {
        val markerIndex = indexOf(marker)
        check(markerIndex >= 0) { "Missing marker: $marker" }
        val start = indexOf('{', markerIndex + marker.length)
        check(start >= 0) { "Missing block: $marker" }
        var depth = 1
        var index = start + 1
        while (index < length) {
            when (this[index]) {
                '{' -> depth++
                '}' -> if (--depth == 0) return substring(start + 1, index)
            }
            index++
        }
        error("Unclosed block: $marker")
    }

    @Test
    fun `live car packets repaint the dashboard and only soc on charging`() {
        val controller = source("ui/HubController.kt")
        val event = controller.blockAfter("private fun receiveCarEvent(")

        assertTrue(event.contains("val charging = uiVisible && uiPage == HubPage.CHARGING"))
        assertTrue(event.contains("if (uiVisible && uiPage != HubPage.HOME && !charging) return"))
        assertTrue(event.contains("if (charging) ui.vehicle.withBatteryCarEvent(merged) else merged"))
    }

    @Test
    fun `regular polling reads only the hood from the body`() {
        val api = source("source/CarApiSource.kt")
        val body = api.blockAfter("private fun readBody(")

        assertTrue(body.contains("if (log == null)"))
        assertTrue(body.contains("DOOR_POS HOOD"))
        assertTrue(body.contains("Body(open = mapOf(BodyPart.HOOD to it))"))
    }

    @Test
    fun `independent command groups do not block each other but a probe blocks all`() {
        val controller = source("ui/HubController.kt")

        assertTrue(
            controller.blockAfter("fun onClimateChange(")
                .contains("if (ui.climateBusy || ui.probeRunning) return")
        )
        assertTrue(
            controller.blockAfter("fun onClimatePreset(")
                .contains("if (ui.climateBusy || ui.probeRunning) return")
        )
        assertTrue(
            controller.blockAfter("private fun writeDrive(")
                .contains("if (ui.driveBusy || ui.probeRunning ||")
        )
        assertTrue(
            controller.blockAfter("private fun writeBodyActuator(")
                .contains("if (ui.bodyBusy || ui.probeRunning || writes.isEmpty()) return")
        )
    }

    @Test
    fun `polls outside home skip climate and body reads and keep their last state`() {
        val controller = source("ui/HubController.kt")

        assertTrue(controller.contains("val home = uiVisible && uiPage == HubPage.HOME"))
        assertTrue(controller.contains("val full = home && (lastFullReadAt == 0L || now - lastFullReadAt >= FULL_READ_MS)"))
        assertTrue(controller.contains("reader.read(profile, full)"))
        assertTrue(controller.contains("snapshot.copy("))
        assertTrue(controller.contains("climate = previous.climate"))
        assertTrue(controller.contains("body = previous.body"))
    }

    @Test
    fun `unchanged telemetry is not republished on every poll`() {
        val controller = source("ui/HubController.kt")

        // Метка времени меняется каждым чтением; сравнение без неё не даёт
        // перерисовывать дерево на стоянке, а гейт в 2 с держит свежесть для установки.
        assertTrue(controller.contains("private const val REPUBLISH_MS = 2_000L"))
        assertTrue(controller.contains("next.vehicle.copy(updatedAt = ui.vehicle.updatedAt)"))
        assertTrue(controller.contains("now - lastTelemetryPublishAt >= REPUBLISH_MS"))
    }

    @Test
    fun `telemetry state is stable and list pages receive projections`() {
        val state = source("ui/HubUiState.kt")
        assertTrue(state.contains("@Immutable\ndata class HubUiState"))
        assertTrue(state.contains("@Immutable\ndata class TripsPageState"))
        assertTrue(state.contains("@Immutable\ndata class ChargingPageState"))
        assertTrue(state.contains("fun HubUiState.tripsPage()"))
        assertTrue(state.contains("fun HubUiState.chargingPage()"))

        val controller = source("ui/HubController.kt")
        assertTrue(controller.contains("@Stable\nclass HubController"))

        val trips = source("ui/screens/TripsScreen.kt")
        assertTrue(trips.contains("state: TripsPageState"))
        assertFalse(trips.contains("state: HubUiState"))
        val charging = source("ui/screens/ChargingScreen.kt")
        assertTrue(charging.contains("state: ChargingPageState"))
        assertFalse(charging.contains("state: HubUiState"))
    }

    @Test
    fun `home cards take only their own fields`() {
        val home = source("ui/screens/HomeScreen.kt")
        val canvas = home.substringAfter("private fun HomeCanvas(").substringBefore(") {")
        assertFalse("Canvas no longer takes the whole snapshot", canvas.contains("VehicleSnapshot"))

        listOf("private fun HeroCard(", "private fun <T> SegmentCard(", "private fun ClimatePanel(",
            "private fun FrunkPill(")
            .forEach { marker ->
                val block = home.blockAfter(marker)
                assertFalse("$marker still takes the whole snapshot", block.contains("VehicleSnapshot"))
            }

        // Экран передаёт в макет отдельные поля снимка.
        listOf("rangeKm = vehicle.rangeKm", "soc = vehicle.soc", "usableKwh = vehicle.usableKwh",
            "outsideTempC = vehicle.outsideTempC", "gear = vehicle.gear", "climate = vehicle.climate")
            .forEach { assertTrue("Field not projected: $it", home.contains(it)) }
    }

    @Test
    fun `windshield heat stays usable while the car does not answer its readback`() {
        val controller = source("ui/HubController.kt")
        // Неизвестное состояние считается выключенным: первое нажатие включает.
        assertTrue(controller.contains("current.copy(windshieldHeatOn = !(current.windshieldHeatOn ?: false))"))
        // Опрос не затирает выбор панели, пока автомобиль молчит.
        assertTrue(controller.contains("snapshot.copy(climate = keepWindshieldHeat(snapshot.climate))"))

        val api = source("source/CarApiSource.kt")
        val signature = api.substringAfter("fun writeClimate(").substringBefore("): ClimateWriteResult")
        assertTrue(signature.contains("windshieldHeatTarget: Boolean? = null"))
        val write = api.blockAfter("fun writeClimate(")
        assertTrue(write.contains("Climate(windshieldHeatOn = windshieldHeatTarget)"))
        assertTrue(write.contains("HVAC_FRONT_WINDSHIELD_HEAT: состояние не читается"))
    }

    @Test
    fun `manual and restored drive selections use the same complete write chains`() {
        val controller = source("ui/HubController.kt")
        val write = controller.blockAfter("private fun writeDrive(")
        assertTrue(write.contains("target.mode?.let(GeelyVhal::driveModeWrites)"))
        assertTrue(write.contains("target.regen?.let(GeelyVhal::regenWrites)"))
        assertTrue(write.contains("if (first.isNotEmpty()) delay(DRIVE_REGEN_GAP_MS)"))
        assertTrue(write.split("stopOnFirst = false").size == 3)
        assertFalse(write.contains("stopOnFirst = true"))
        assertTrue(controller.blockAfter("fun onDriveMode(").contains("writeDrive(DriveMemory.Plan(target, regen), requestedRegen = null)"))
        assertTrue(controller.blockAfter("fun onRegen(").contains("writeDrive(DriveMemory.Plan(drive, target), requestedMode = null)"))
        val restore = controller.blockAfter("private fun restoreDrive(")
        assertTrue(restore.contains("writeDrive(target, restoring = true)"))
        assertTrue(restore.contains("plan.mode ?: snapshot.driveMode"))
        assertTrue(restore.contains("plan.regen ?: snapshot.regen"))
        assertFalse(restore.contains("reader.writeChain"))
        assertFalse(restore.contains("scope.launch"))
    }

    @Test
    fun `pending targets stay separate from serialization and clear only in finally`() {
        val controller = source("ui/HubController.kt")
        val state = source("ui/HubUiState.kt")
        listOf("activeClimateChange: ClimateChange?", "activeClimatePreset: ClimatePreset?",
            "activeDriveMode: DriveMode?", "activeRegen: RegenLevel?").forEach {
            assertTrue(state.contains("val $it = null"))
        }
        val change = controller.blockAfter("fun onClimateChange(")
        assertTrue(change.contains("activeClimateChange = change"))
        assertTrue(change.contains("activeClimatePreset = null"))
        assertTrue(change.contains("climatePresetEngaged = null"))
        val preset = controller.blockAfter("fun onClimatePreset(")
        assertTrue(preset.contains("activeClimateChange = null"))
        assertTrue(preset.contains("activeClimatePreset = preset"))
        // Подсветка ставится по успешному результату и снимается повторным нажатием.
        assertTrue(preset.contains("climatePresetEngaged = if (off) null else preset"))
        listOf(change, preset).forEach { command ->
            assertTrue(command.contains("scope.launch(start = CoroutineStart.UNDISPATCHED)"))
            assertTrue(command.contains("catch (error: Exception)"))
            assertTrue(command.contains("if (error is CancellationException) throw error"))
            assertFalse(command.substringBefore("finally").contains("climateBusy = false"))
            val cleanup = command.blockAfter("finally")
            listOf("climateBusy = false", "activeClimateChange = null", "activeClimatePreset = null")
                .forEach { assertTrue(cleanup.contains(it)) }
        }
        assertFalse(controller.blockAfter("private fun applyClimateResult(").contains("climateBusy = false"))
        val drive = controller.blockAfter("private fun writeDrive(")
        assertTrue(drive.contains("activeDriveMode = requestedMode"))
        assertTrue(drive.contains("activeRegen = requestedRegen"))
        val signature = controller.substringAfter("private fun writeDrive(").substringBefore(") {")
        assertTrue(signature.contains("requestedMode: DriveMode? = target.mode"))
        assertTrue(signature.contains("requestedRegen: RegenLevel? = target.regen"))
        assertTrue(drive.contains("scope.launch(start = CoroutineStart.UNDISPATCHED)"))
        assertTrue(drive.contains("if (error is CancellationException) throw error"))
        assertTrue(drive.indexOf("readDriveBack(mode, target)") < drive.indexOf("finally"))
        assertFalse(drive.substringBefore("finally").contains("driveBusy = false"))
        val cleanup = drive.blockAfter("finally")
        listOf("driveBusy = false", "activeDriveMode = null", "activeRegen = null")
            .forEach { assertTrue(cleanup.contains(it)) }
    }

    @Test
    fun `source changes cannot interrupt commands and reset all pending visuals`() {
        val controller = source("ui/HubController.kt")
        listOf("fun setSource(", "fun resetDemoData(").forEach { marker ->
            val change = controller.blockAfter(marker)
            assertTrue(change.substringBefore("return").contains("ui.climateBusy || ui.driveBusy"))
            listOf("activeClimateChange", "activeClimatePreset", "activeDriveMode", "activeRegen")
                .forEach { assertTrue(change.contains("$it = null")) }
        }
        assertTrue(controller.blockAfter("private fun applyClimateResult(")
            .contains("if (ui.profile.source != mode) return"))
    }

    @Test
    fun `callbacks mark the active signal even when optimistic ui already matches`() {
        val event = source("ui/HubController.kt").blockAfter("private fun receiveCarEvent(")
        assertTrue(event.contains("ui.activeClimateChange?.let"))
        assertTrue(event.contains("Climate().withSignalObservation(change, previous.climate)"))
        assertTrue(event.contains("Climate().withSignalObservation(change, event.climate)"))
        assertTrue(event.indexOf("activeClimateObserved = true") < event.indexOf("if (vehicle != ui.vehicle)"))
    }

    @Test
    fun `drive transport failures keep the other half and both readback attempts`() {
        val controller = source("ui/HubController.kt")
        val write = controller.blockAfter("private fun writeDrive(")
        assertTrue(write.split("driveWriteAttempt {").size == 3)
        val attempt = controller.blockAfter("private suspend fun driveWriteAttempt(")
        assertTrue(attempt.contains("write()"))
        val failure = controller.substringAfter("private suspend fun driveWriteAttempt(")
            .substringBefore("private suspend fun readDriveBack(")
        assertTrue(failure.contains("if (error is CancellationException) throw error"))
        assertTrue(failure.contains("commandFailure(error)"))
        val read = controller.blockAfter("private suspend fun readDriveBack(")
        assertTrue(read.contains("for (attempt in 0 until 2)"))
        val readFailure = read.blockAfter("catch (error: Exception)")
        assertTrue(readFailure.contains("if (error is CancellationException) throw error"))
        assertTrue(readFailure.contains("confirmed = false"))
        assertTrue(readFailure.contains("continue"))
        assertFalse(readFailure.contains("ui ="))
        val commandFailure = controller.substringAfter("private fun commandFailure(")
            .substringBefore("private fun keepWindshieldHeat(")
        assertTrue(commandFailure.contains("status = CheckStatus.ERROR"))
        assertFalse(commandFailure.contains("observed ="))
        assertFalse(commandFailure.contains("applied ="))
        assertFalse(commandFailure.contains("confirmed = true"))
    }

    @Test
    fun `a failed half of the drive pair cannot save preferences or acknowledge success`() {
        val write = source("ui/HubController.kt").blockAfter("private fun writeDrive(")
        assertTrue(write.contains("accepted = accepted && result.status == CheckStatus.OK"))
        assertFalse(write.contains("accepted ||"))
        val saved = write.blockAfter("if (accepted && !restoring)")
        assertTrue(saved.contains("profile = target.remember(ui.profile)"))
        assertTrue(saved.contains("persist()"))
        assertTrue(write.contains("if (!restoring && accepted && confirmed) playAck()"))
        assertTrue(write.indexOf("if (mode != SourceMode.CAR_API)") < write.indexOf("scope.launch"))
    }

    @Test
    fun `drive confirmation uses latest raw answers rather than optimistic display`() {
        val read = source("ui/HubController.kt").blockAfter("private suspend fun readDriveBack(")
        assertTrue(read.contains("confirmed = target.matches(drive, regen)"))
        assertTrue(read.contains("driveMode = drive,"))
        assertTrue(read.contains("regen = regen"))
        assertTrue(read.contains("for (attempt in 0 until 2)"))
        assertFalse(read.contains("?: ui.vehicle"))
        assertFalse(read.contains("matches(ui.vehicle)"))
        assertFalse(read.contains("break"))
        assertFalse(read.contains("writeChain"))
    }

    @Test
    fun `drive readback logs raw property replies and bypasses poll backoff`() {
        val api = source("source/CarApiSource.kt")
        assertTrue(api.contains("fun readDrive(): Triple<DriveMode?, RegenLevel?, String> = withFreshReads"))
        val read = api.blockAfter("fun readDrive(")
        assertTrue(read.contains("readDriveMode(log)"))
        assertTrue(read.contains("readRegen(log)"))
        assertTrue(read.contains("readGear(log)"))
        assertFalse(read.contains("flyme.readCode"))
    }

    @Test
    fun `changing one drive preference preserves the other choice after a physical rollback`() {
        val controller = source("ui/HubController.kt")
        assertTrue(controller.blockAfter("fun onDriveMode(").contains("ui.profile.preferredRegen ?: ui.vehicle.regen"))
        assertTrue(controller.blockAfter("fun onRegen(").contains("ui.profile.preferredDriveMode ?: ui.vehicle.driveMode"))
    }

    @Test
    fun `commands reserve priority before IO and interrupted polls discard partial snapshots`() {
        val reader = source("source/TelemetryReader.kt")
        val command = reader.blockAfter("private suspend fun carOnly(")
        assertTrue(reader.contains("carApi.commandPriority.runCommand(mode == SourceMode.CAR_API)"))
        assertTrue(command.contains("withContext(Dispatchers.IO)"))
        val api = source("source/CarApiSource.kt")
        assertTrue(api.contains("catch (_: CarCommandPriority.PollYield)"))
        assertTrue(api.blockAfter("private fun readRawOnce(").contains("if (poll != null) commandPriority.checkPoll(diagnostic = log != null)"))
        assertTrue(api.blockAfter("private fun readBaseline(").contains("poll = null"))
        assertTrue(api.blockAfter("private fun readBaseline(").contains("eventState.discardPoll(token)"))
        assertTrue(source("ui/HubController.kt").contains("if (generation != controlGeneration)"))
    }

    @Test
    fun `setpoint confirmation stops after actual matching readback`() {
        val api = source("source/CarApiSource.kt")
        val readings = api.blockAfter("private fun readSetpointReadings(")
        assertTrue(readings.contains("if (celsius != null && abs(celsius - target) <= 0.25) return readings"))
        assertTrue(readings.contains("if (mirrorC != null && abs(mirrorC - target) <= 0.25) return readings"))
        assertTrue(readings.contains("if (canonicalC != null && abs(canonicalC - target) <= 0.25) return readings"))
        assertTrue(api.contains("readSetpointReadings(target, log)"))
    }

    @Test
    fun `gauges update directly and installed icon cache is bounded`() {
        val charts = source("ui/components/Charts.kt")
        assertFalse(charts.contains("animateFloatAsState"))
        assertFalse(charts.contains("fun SocRing("))
        assertTrue(charts.contains("sweepAngle = 360f * fraction"))
        assertTrue(charts.contains(".fillMaxWidth(fraction)"))
        val apps = source("ui/InstalledApps.kt")
        assertTrue(apps.contains("ICON_PX = 128"))
        assertTrue(apps.contains("LruCache<String, LaunchableApp>(32)"))
    }

    @Test
    fun `system control IO is off main and refresh bursts cannot create unbounded jobs`() {
        val top = source("ui/components/TopBar.kt")
        val refresh = top.blockAfter("fun refresh()")
        assertTrue(refresh.contains("if (refreshRunning || committing) return"))
        assertTrue(refresh.contains("while (active && refreshDirty && !committing)"))
        assertTrue(refresh.contains("withContext(Dispatchers.IO) { readSnapshot() }"))
        assertTrue(refresh.contains("isCurrent(lifecycle) && writes == writeVersion && !committing"))
        val volume = top.blockAfter("fun finishVolume()")
        val volumeIo = volume.blockAfter("withContext(Dispatchers.IO)")
        assertTrue(volumeIo.contains("audio.setStreamVolume"))
        assertTrue(volumeIo.contains("readVolume()"))
        assertTrue(volume.contains("if (!isCurrent(lifecycle)) return@launch"))
        val brightness = top.blockAfter("fun finishBrightness()")
        assertTrue(brightness.contains("withContext(Dispatchers.IO) { commitSystemBrightness(requested) }"))
        assertTrue(brightness.contains("if (!isCurrent(lifecycle)) return@launch"))
        assertFalse(brightness.blockAfter("withContext(Dispatchers.IO)").contains("window.attributes"))
        val observing = top.blockAfter("private fun rememberHomeControls(")
        assertTrue(observing.contains("withContext(NonCancellable + Dispatchers.IO)"))
        assertTrue(observing.contains("resolver.unregisterContentObserver(observer)"))
        assertTrue(observing.contains("isHomeControlsSettingsUri(uri)"))
        assertTrue(top.contains("!volumeCommitting"))
        assertTrue(top.contains("!brightnessCommitting"))
    }

    @Test
    fun `slider release cancellation and accessibility authorization stay distinct`() {
        val top = source("ui/components/TopBar.kt")
        val tap = top.blockAfter("private fun Modifier.sliderTapRelease(")
        assertTrue(tap.contains("onStart()"))
        assertTrue(tap.contains("waitForUpOrCancellation(PointerEventPass.Initial) != null"))
        assertTrue(tap.indexOf("awaitPointerEvent(PointerEventPass.Final)") < tap.indexOf("onRelease()"))
        assertTrue(top.blockAfter("private fun Modifier.sliderKeyRelease(").contains("KeyEventType.KeyUp"))
        listOf("Volume" to "volume", "Brightness" to "brightness").forEach { (name, field) ->
            val control = top.blockAfter("private fun ${name}Control(")
            assertTrue(control.contains("onValueChangeFinished = {}"))
            assertTrue(control.blockAfter("is DragInteraction.Stop ->").contains("controls.finish$name()"))
            val cancel = control.blockAfter("is DragInteraction.Cancel ->")
            assertTrue(cancel.contains("controls.cancel${name}Preview()"))
            assertFalse(cancel.contains("controls.finish$name()"))
            val accessible = control.blockAfter("setProgress")
            assertTrue(accessible.contains("!controls.${field}Enabled || !requested.isFinite()"))
            assertTrue(accessible.contains("controls.preview$name(requested.coerceIn("))
            assertTrue(accessible.contains("controls.finish$name()"))
        }
    }

    @Test
    fun `navigation rail takes only the page instead of the snapshot`() {
        val top = source("ui/components/TopBar.kt")
        val signature = top.substringAfter("fun HubNavRail(").substringBefore(") {")

        assertTrue(signature.contains("page: HubPage,"))
        assertFalse(signature.contains("VehicleSnapshot"))
        assertFalse("Часы наружной температуры в рейле больше нет", signature.contains("outsideTempC"))
    }
}
