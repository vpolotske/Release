package com.ex2hub.source

import java.io.File
import kotlin.math.roundToInt
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HomeLayoutContractTest {
    private fun source(relativePath: String): String {
        val path = "src/main/java/com/ex2hub/ui/$relativePath"
        return listOf(File(path), File("app/$path"))
            .first { it.isFile }
            .readText(Charsets.UTF_8)
    }

    /** Balanced blocks keep nested Rows/Columns in scope rather than matching one flat regex. */
    private fun String.blockAfter(marker: String): String {
        val markerIndex = indexOf(marker)
        check(markerIndex >= 0) { "Missing marker: $marker" }
        val start = indexOf('{', markerIndex + marker.length)
        check(start >= 0) { "Missing block: $marker" }
        var depth = 1
        var index = start + 1
        while (index < length) {
            when (this[index]) {
                '{' -> depth++
                '}' -> if (--depth == 0) return substring(start + 1, index)
            }
            index++
        }
        error("Unclosed block: $marker")
    }

    @Test
    fun `home is one design canvas scaled as a whole and widened to the workspace`() {
        val top = source("components/TopBar.kt")
        assertTrue(top.contains("BoxWithConstraints"))
        assertFalse("BoxWithConstraints cannot answer intrinsic measurements", top.contains("IntrinsicSize"))

        val home = source("screens/HomeScreen.kt")
        // 1768 — это 1920 без рейла 152 dp: минимальная ширина холста, а не фиксированная.
        assertTrue(home.contains("private val DesignWidth = 1768.dp"))
        assertTrue(home.contains("private val DesignHeight = 1080.dp"))
        assertTrue(home.contains("maxWidth.value / DesignWidth.value"))
        assertTrue(home.contains("maxHeight.value / DesignHeight.value"))
        // Ширина холста растёт вместе с рабочим столом, масштаб остаётся единым по высоте.
        assertTrue(home.contains("val canvasWidth = maxWidth / scale"))
        assertTrue(home.contains("val shellWidth = maxWidth"))
        assertTrue(home.contains(".requiredSize(canvasWidth, DesignHeight)"))
        assertTrue(home.contains("transformOrigin = TransformOrigin.Center"))
        // Дизайн не ветвится: на любом экране та же композиция, уменьшенная целиком.
        listOf("if (wide)", "if (medium)", "IntrinsicSize", "verticalScroll", "maxWidth >=",
            "StatusChip", "animateFloatAsState")
            .forEach { assertFalse("Responsive or decorative leftover: $it", home.contains(it)) }
        assertEquals("No pair derives its height from intrinsics", 0,
            Regex("""\.height\(IntrinsicSize\.Min\)""").findAll(home).count())
    }

    @Test
    fun `scaled canvas fills the workspace width and stays centred vertically`() {
        val home = source("screens/HomeScreen.kt")
        val screen = home.blockAfter("fun HomeScreen(")
        assertTrue(screen.contains("Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center)"))
        assertTrue(Regex("""Box\(\s*Modifier\.size\(shellWidth, DesignHeight \* scale\),\s*contentAlignment = Alignment\.Center\s*\)""")
            .containsMatchIn(screen))
        assertTrue(screen.contains("transformOrigin = TransformOrigin.Center"))
        val designWidth = Regex("private val DesignWidth = ([0-9]+)\\.dp")
            .find(home)!!.groupValues[1].toFloat()
        val designHeight = Regex("private val DesignHeight = ([0-9]+)\\.dp")
            .find(home)!!.groupValues[1].toFloat()

        listOf(1768 to 1080, 1768 to 984, 1608 to 984, 1608 to 784,
            1248 to 720, 928 to 360, 320 to 480, 2560 to 1440).forEach { (width, height) ->
            listOf(1f, 1.3f, 2.75f).forEach { density ->
                val viewport = "${width}x$height density=$density"
                val maxWidthDp = width / density
                val maxHeightDp = height / density
                val scale = minOf(maxWidthDp / designWidth, maxHeightDp / designHeight)
                val canvasWidthDp = maxWidthDp / scale
                val canvasWidth = (canvasWidthDp * density * scale).roundToInt()
                val canvasHeight = (designHeight * density * scale).roundToInt()
                val frameHeight = (designHeight * scale * density).roundToInt()
                val left = 0
                val top = ((height - frameHeight) / 2f).roundToInt()
                val right = left + canvasWidth
                val bottom = top + canvasHeight

                assertEquals("Canvas must span the whole workspace at $viewport",
                    width.toDouble(), canvasWidth.toDouble(), 3.0)
                assertEquals("Vertical centring at $viewport", top.toDouble(),
                    ((height - frameHeight) / 2f).toDouble(), 1.0)
                assertTrue("Canvas overlaps the rail at $viewport", left >= -1f)
                assertTrue("Canvas extends above the workspace at $viewport", top >= -1f)
                assertTrue("Canvas extends past the right edge at $viewport", right <= width + 3f)
                assertTrue("Canvas extends below the workspace at $viewport", bottom <= height + 1f)
                assertEquals("Height keeps the design ratio at $viewport",
                    frameHeight.toDouble(), canvasHeight.toDouble(), 1.0)
            }
        }
    }

    @Test
    fun `hero reads range battery energy and outside temperature from the car`() {
        val home = source("screens/HomeScreen.kt")
        val hero = home.blockAfter("private fun HeroCard(")
        listOf("rangeKm", "soc", "usableKwh", "outsideTempC").forEach {
            assertTrue("Hero readback lost: $it", hero.contains(it))
        }
        assertTrue(hero.contains("Fmt.int(rangeKm)"))
        assertTrue(hero.contains("Fmt.percent(soc)"))
        assertTrue(hero.contains("Fmt.kwh(usableKwh)"))
        assertTrue(hero.contains(".fillMaxWidth(soc / 100f)"))
        assertTrue(hero.contains("outsideText(outsideTempC)"))
        assertTrue(home.contains("\"Наружный воздух: —\""))
        assertTrue(home.contains("Fmt.temp(tempC)"))
        // Единственный кадр автомобиля декодируется вне UI и растягивается за край карточки.
        val cache = home.blockAfter("private object CarFrameCache")
        assertTrue(cache.contains("private var image: ImageBitmap? = null"))
        assertTrue(cache.contains("BitmapFactory.decodeResource(resources, R.drawable.car_base)"))
        assertTrue(hero.contains("withContext(Dispatchers.Default) { CarFrameCache.load(resources) }"))
        assertTrue(hero.contains("filterQuality = FilterQuality.Medium"))
        listOf("Crossfade", "car_lights", "frameFor", "HIGHLIGHT_REGIONS", "DoorHighlights")
            .forEach { assertFalse("Non-static car content: $it", home.contains(it)) }
    }

    @Test
    fun `frunk stays user triggered in P with busy and readback guards`() {
        val home = source("screens/HomeScreen.kt")
        val pill = home.blockAfter("private fun FrunkPill(")
        // Кузовные сигналы на этом ГУ не отвечают, поэтому готовность кнопки
        // зависит только от передачи: открывать передний багажник можно на стоянке.
        assertEquals("Ready state comes only from the gear", 1,
            Regex("""gear == Gear\.P""").findAll(home).count())
        assertTrue(home.substringAfter("private fun FrunkPill(").substringBefore(") {")
            .contains("ready: Boolean"))
        assertTrue(pill.contains("val enabled = ready && !busy"))
        assertTrue(pill.contains(".clickable("))
        assertTrue(pill.contains("enabled = enabled"))
        assertTrue(pill.contains("onClick = onClick"))
        // Открытое состояние читается из кузова, а не запоминается в приложении.
        assertTrue(home.contains("body?.openParts?.contains(BodyPart.HOOD) == true"))
        assertTrue(pill.contains("\"Передний багажник открыт\""))
        // Заднего багажника в меню ГУ нет: ни кнопки, ни параметра, ни готовности.
        listOf("onTrunkOpen", "BodyPart.TAILGATE", "AppIcons.Trunk", "openParts =")
            .forEach { assertFalse("Trunk surface invented: $it", home.contains(it)) }
    }

    @Test
    fun `drive and regen cards select only firmware known values and show unknown readback`() {
        val home = source("screens/HomeScreen.kt")
        val canvas = home.blockAfter("private fun HomeCanvas(")

        assertTrue(canvas.contains("options = driveOptions"))
        assertTrue(canvas.contains("options = regenOptions"))
        assertTrue(canvas.contains("selectable = GeelyVhal.SELECTABLE_DRIVE_MODES"))
        assertTrue(canvas.contains("selectable = GeelyVhal.SELECTABLE_REGEN"))
        // Неизвестное чтение показывается активным, но не предлагается к записи.
        assertTrue(canvas.contains("if (driveMode != null && driveMode !in base) base + driveMode else base"))
        assertTrue(canvas.contains("if (regen != null && regen !in base) base + regen else base"))
        // Занятость и список записи проверяются в момент нажатия, а не параметром кнопки.
        assertTrue(canvas.contains("busyDrive.value && mode in GeelyVhal.SELECTABLE_DRIVE_MODES) onDriveMode(mode)"))
        assertTrue(canvas.contains("busyDrive.value && level in GeelyVhal.SELECTABLE_REGEN) onRegen(level)"))
        assertTrue(canvas.indexOf("title = \"Режим движения\"") < canvas.indexOf("title = \"Рекуперация\""))
        assertTrue(canvas.contains("horizontalArrangement = Arrangement.spacedBy(HeroRowGap)"))
        assertTrue(canvas.contains(".height(HeroRowHeight)"))
        // Блоки рабочего стола пропорциональны друг другу: левая колонка и панель климата.
        assertTrue(canvas.contains("Column(Modifier.weight(736f).fillMaxHeight())"))
        assertTrue(canvas.contains("modifier = Modifier.weight(467f).fillMaxHeight()"))
        assertEquals("Both segment cards split the row equally", 2,
            Regex("""Modifier\.weight\(1f\)\.fillMaxHeight\(\)""").findAll(canvas).count())

        val card = home.blockAfter("private fun <T> SegmentCard(")
        assertTrue(card.contains("active = option == selected"))
        assertTrue(card.contains("selectable = option in selectable"))
        assertTrue(card.contains("waiting = option == pending"))
        assertTrue(card.contains("onClick = { onSelect(option) }"))
        assertFalse("Card must not dim as a whole while one button works", card.contains("busy"))

        val button = home.blockAfter("private fun SegmentButton(")
        assertTrue(button.contains(".clickable(enabled = selectable, onClick = onClick)"))
        assertTrue(button.contains("alpha = if (selectable) 1f else 0.45f"))

        val icons = home.substringAfter("private fun modeIcon(").substringBefore("private fun String.capitalized")
        listOf("DepthIcons.Leaf", "DepthIcons.Comfort", "DepthIcons.Sport").forEach {
            assertTrue("Drive mode icon lost: $it", icons.contains(it))
        }
        listOf("DepthIcons.RegenLow", "DepthIcons.RegenMid", "DepthIcons.RegenHigh").forEach {
            assertTrue("Regen icon lost: $it", icons.contains(it))
        }
    }

    @Test
    fun `climate panel keeps every control with honest silence states`() {
        val home = source("screens/HomeScreen.kt")
        val panel = home.blockAfter("private fun ClimatePanel(")
        listOf("ClimateChange.POWER", "ClimateChange.DRIVER_DOWN", "ClimateChange.DRIVER_UP",
            "ClimateChange.FAN_DOWN", "ClimateChange.FAN_UP", "ClimateChange.AC",
            "ClimateChange.SEAT_DRIVER", "ClimateChange.SEAT_PASSENGER", "ClimateChange.WHEEL_HEAT",
            "ClimateChange.WINDSHIELD_HEAT", "ClimateChange.REAR_DEFROST",
            "ClimatePreset.QUICK_COOL", "ClimatePreset.QUICK_HEAT").forEach {
            assertTrue("Climate control missing: $it", panel.contains(it))
        }
        // Пресет горит, только когда приложение его включало: совпадение с обычной
        // летней настройкой (17 °C, кондиционер, «в лицо») кнопку не подсвечивает.
        assertTrue(panel.contains("engagedPreset == ClimatePreset.QUICK_COOL"))
        assertTrue(panel.contains("engagedPreset == ClimatePreset.QUICK_HEAT"))
        val directions = home.blockAfter("private enum class DirectionData(")
        listOf("ClimateChange.DIRECTION_GLASS", "ClimateChange.DIRECTION_FACE",
            "ClimateChange.DIRECTION_FEET", "ClimateChange.DIRECTION_GLASS_FEET").forEach {
            assertTrue("Direction control missing: $it", directions.contains(it))
        }

        // Молчащий сигнал показывается прочерком, а не выдуманным нулём.
        val temp = home.blockAfter("private fun TempRow(")
        assertTrue(temp.contains("setpointText(it)"))
        assertTrue(temp.contains("?: \"—\""))
        assertTrue(temp.contains("enabled = setpoint != null"))
        val fan = home.blockAfter("private fun FanRow(")
        assertTrue(fan.contains("if (level == null)"))
        assertTrue(fan.contains("GeelyVhal.FAN_MAX"))
        assertTrue(fan.contains("enabled = level != null"))
        // Уменьшение обдува — маленький вентилятор, увеличение — большой.
        assertTrue(fan.indexOf("iconSize = 31.dp") < fan.indexOf("iconSize = 47.8.dp"))

        // Обогрев лобового не читается на этом ГУ, но остаётся нажимаемым.
        val glassRow = home.blockAfter("private fun GlassRow(")
        assertTrue(glassRow.contains("reachable = true"))
        assertTrue(glassRow.contains("reachable = rear != null"))
        val glass = home.blockAfter("private fun GlassTile(")
        assertTrue(glass.contains(".clickable(enabled = reachable, onClick = onClick)"))
        val presets = home.blockAfter("private fun PresetsRow(")
        assertTrue(presets.contains("reachable = reachable"))
        // A/C — отдельная кнопка между быстрым охлаждением и быстрым обогревом.
        assertTrue(presets.indexOf("label = \"Быстрое охлаждение\"") < presets.indexOf("AcTile("))
        assertTrue(presets.indexOf("AcTile(") < presets.indexOf("label = \"Быстрый обогрев\""))
        val ac = home.blockAfter("private fun AcTile(")
        assertTrue(ac.contains(".clickable(enabled = on != null"))
        assertTrue(ac.contains("if (on == null) \"—\" else \"A/C\""))

        val power = home.blockAfter("private fun PowerPill(")
        listOf("true -> \"Вкл\"", "false -> \"Выкл\"", "null -> \"—\"").forEach {
            assertTrue("Power state lost: $it", power.contains(it))
        }
        // Индикатор ожидания принадлежит строке, а не всей панели: POWER маппит заголовок.
        assertTrue(panel.contains("waiting = pendingChange == ClimateChange.POWER"))
        val head = home.blockAfter("private fun ClimateHead(")
        assertTrue(head.contains("PowerPill(power, waiting, onPower)"))
        assertTrue(power.contains(".clickable(enabled = state != null"))

        val heat = home.blockAfter("private fun HeatTile(")
        assertTrue(heat.contains("val active = level != null && level > 0"))
        assertTrue(heat.contains(".clickable(enabled = level != null"))
        // Ступени обогрева: волн ровно столько, сколько supportует сигнал.
        assertTrue(heat.contains("if (levels > 1)"))
        assertTrue(heat.contains("DepthIcons.HeatWave"))
        // Волны узкие и стоят плотно — размер и промежутки заданы вместе.
        assertTrue(heat.contains("width = 15.4.dp"))
        assertTrue(heat.contains("size = 60.9.dp"))
        assertTrue(heat.contains("Arrangement.spacedBy(5.dp)"))
        val seats = home.blockAfter("private fun SeatsRow(")
        assertTrue(seats.contains("levels = GeelyVhal.HEAT_MAX_LEVEL"))
        // У руля одна ступень: волн нет, значок стоит один по центру.
        assertTrue(seats.contains("levels = 1"))
        // Пассажирское сиденье зеркальное: спинка смотрит в другую сторону.
        assertTrue(seats.contains("icon = DepthIcons.SeatPassenger"))
        // Высота уставки и обдува не обрезается: кнопки и плитки заданы по макету.
        assertTrue(home.contains("RoundButton("))
        assertTrue(home.contains("HeatTile("))
        assertTrue(home.contains(".size(84.3.dp)"))
        assertTrue(power.contains(".height(64.7.dp)"))
    }

    @Test
    fun `climate glyphs are redrawn in one line family with shared parts`() {
        val icons = source("DepthIcons.kt")
        // Один стиль значка: только контур, цвет приходит тонированием из темы.
        assertFalse("Залитых фигур больше нет", icons.contains("fill = "))
        assertFalse(icons.contains("paint("))
        assertTrue(icons.contains("tintColor = Color.Unspecified"))
        // Стекло и заднее окно — свои формы с закруглёнными углами и нитями обогрева.
        assertTrue(icons.contains("M7.6 4.3h8.8c.84 0 1.48.75 1.38 1.58l-.62 5.2"))
        assertTrue(icons.contains("M5.6 3.9h12.8c.85 0 1.5.74 1.4 1.58l-1 8.2"))
        // Сиденья зеркальные: у водителя спинка слева, у пассажира — справа.
        assertTrue(icons.contains("M9.8 3.3H7.9a2.8 2.8 0 0 0-2.8 2.8"))
        assertTrue(icons.contains("M14.2 3.3h1.9a2.8 2.8 0 0 1 2.8 2.8"))
        // Рекуперация — одна общая заготовка: кольцо, стрелка и три набора ступеней.
        assertTrue(icons.contains("line(REGEN_RING, 1.5f)"))
        assertTrue(icons.contains("line(REGEN_ARROW, 1.5f)"))
        assertEquals(3, Regex("""regen\("Regen(Low|Mid|High)"""").findAll(icons).count())
        // Полоса обогрева держит узкий viewBox макета 6.4×36.
        assertTrue(icons.contains("vector(\"HeatWave\", 6.4f, 36f)"))
    }

    @Test
    fun `home buttons share one flat surface and the rail stays visible`() {
        val home = source("screens/HomeScreen.kt")
        // Все прямоугольные органы: одна поверхность, одна рамка, один радиус 12 dp.
        listOf(
            "private fun SegmentButton(",
            "private fun DockTile(",
            "private fun DirectionTile(",
            "private fun PresetTile(",
            "private fun HeatTile(",
            "private fun GlassTile(",
            "private fun AcTile(",
            "private fun PowerPill(",
            "private fun FrunkPill("
        ).forEach { marker ->
            val block = home.blockAfter(marker)
            assertTrue("$marker keeps the 12 dp control radius",
                block.contains("RoundedCornerShape(12.dp)"))
            assertTrue("$marker uses the shared surface",
                block.contains("c.control") || block.contains("c.frunk"))
            assertFalse("$marker must not paint its own gradient", block.contains("Brush."))
        }
        // Свечения кнопок больше нет: подсветка осталась только у кадра автомобиля.
        assertFalse(home.contains("private fun Modifier.glow("))

        // Фон рабочего стола обрезается по своим границам и не закрашивает рейл.
        assertTrue(home.contains(".clipToBounds()"))

        val top = source("components/TopBar.kt")
        val item = top.blockAfter("private fun RailItem(")
        // Панель рейла отделена от рабочего стола, активная плитка — сплошная заливка.
        assertTrue(item.contains("HubColors.RailActiveBg"))
        assertTrue(item.contains("HubColors.RailActiveBorder"))
        assertFalse(item.contains("Brush."))
        assertFalse(item.contains("shadow("))
        assertFalse(item.contains("glow("))

        val palette = source("theme/Palette.kt")
        val blue = palette.blockAfter("val Blue: HubPalette")
        // Оформление одно — синее: акцент, фон рейла и активная плитка из макета.
        assertTrue(blue.contains("accent = Color(0xFF3D8BFF)"))
        assertTrue(blue.contains("bg = Color(0xFF05101F)"))
        assertTrue(blue.contains("activeBg = Color(0xFF2E7DFF)"))
        // Светлой и графитовой темы больше нет: палитра объявлена одна.
        assertEquals(1, Regex("""val \w+: HubPalette""").findAll(palette).count())
    }

    @Test
    fun `climate rows take single values so one change redraws only its row`() {
        val home = source("screens/HomeScreen.kt")
        val panel = home.blockAfter("private fun ClimatePanel(")
        // Панель не получает флаг занятости: иначе команда гасла бы весь блок.
        val signature = home.substringAfter("private fun ClimatePanel(").substringBefore(") {")
        assertFalse(signature.contains("Busy"))
        assertFalse(panel.contains("busy"))
        assertFalse(panel.contains("Busy"))
        // Каждому блоку передаётся только его значение и его ожидание ответа.
        listOf(
            "private fun ClimateHead(" to "power: Boolean?",
            "private fun TempRow(" to "setpoint: Double?",
            "private fun FanRow(" to "level: Int?",
            "private fun DirectionRow(" to "direction: Int?",
            "private fun PresetsRow(" to "acOn: Boolean?",
            "private fun SeatsRow(" to "driver: Int?",
            "private fun GlassRow(" to "rear: Boolean?"
        ).forEach { (marker, parameter) ->
            val blockSignature = home.substringAfter(marker).substringBefore(") {")
            assertTrue("$marker must read only $parameter", blockSignature.contains(parameter))
            assertFalse("$marker still takes the whole climate object", blockSignature.contains("climate:"))
        }
        // Индикатор ожидания остаётся локальным: он относится к нажатой кнопке.
        assertTrue(panel.contains("waiting = pendingChange == ClimateChange.POWER"))
        assertTrue(panel.contains("lowering = pendingChange == ClimateChange.DRIVER_DOWN"))
        assertTrue(panel.contains("raising = pendingChange == ClimateChange.DRIVER_UP"))
        assertTrue(panel.contains("waiting = pendingChange?.isDirection()"))
        assertTrue(panel.contains("acWaiting = pendingChange == ClimateChange.AC"))
    }

    @Test
    fun `dock keeps mockup tile size and centres sparse rows`() {
        val home = source("screens/HomeScreen.kt")
        val dock = home.blockAfter("private fun AppDock(")
        val tile = home.blockAfter("private fun DockTile(")

        assertTrue(home.contains("private val DockTileWidth = 195.65.dp"))
        assertTrue(home.contains("private val DockHeight = 119.5.dp"))
        assertTrue(home.contains("private val DockGap = 14.06.dp"))
        assertTrue(tile.contains(".width(DockTileWidth)"))
        assertTrue(tile.contains(".height(DockHeight)"))
        assertTrue(dock.contains("horizontalScroll(rememberScrollState())"))
        assertTrue(dock.contains("val side = ((maxWidth - total) / 2).coerceAtLeast(0.dp)"))
        assertTrue(dock.contains(".padding(horizontal = side)"))
        // Пустой список не заполняется поддельными ярлыками: «Все приложения» и настройка.
        assertTrue(dock.contains("DockTile(label = \"Все приложения\""))
        assertTrue(dock.contains("if (apps.isEmpty())"))
        assertTrue(dock.contains("DockTile(label = \"Добавить ярлыки\""))
        assertTrue(tile.contains("TextOverflow.Ellipsis"))
        // Настоящий значок приложения рисуется растром, линейный — только запасной.
        assertTrue(dock.contains("if (icon != null)"))
        assertTrue(dock.contains("bitmap = icon"))
        assertTrue(dock.contains("dockGlyph("))
    }

    @Test
    fun `home controls keep comfortable touch targets at the design scale`() {
        val home = source("screens/HomeScreen.kt")
        val segment = home.blockAfter("private fun SegmentButton(")
        val round = home.blockAfter("private fun RoundButton(")
        val direction = home.blockAfter("private fun DirectionTile(")
        val preset = home.blockAfter("private fun PresetTile(")
        val heat = home.blockAfter("private fun HeatTile(")
        val glass = home.blockAfter("private fun GlassTile(")

        assertTrue(segment.contains(".height(87.1.dp)"))
        assertTrue(round.contains(".size(84.3.dp)"))
        assertTrue(direction.contains(".height(70.3.dp)"))
        assertTrue(preset.contains(".height(70.3.dp)"))
        assertTrue(heat.contains(".height(118.1.dp)"))
        assertTrue(glass.contains(".height(75.9.dp)"))
        // Значки помещаются внутри плиток: смещение и размер больше кнопки её срезают.
        assertTrue(direction.contains("53.4.dp"))
        assertFalse(direction.contains("Modifier.offset("))
        assertTrue(glass.contains("50.6.dp"))
        assertTrue(preset.contains("38.0.dp"))
        val depth = home.blockAfter("private fun DepthIcon(")
        assertTrue(depth.contains("modifier.requiredSize(size)"))
        assertTrue(depth.contains("box.requiredWidth(width)"))
        val ac = home.blockAfter("private fun AcTile(")
        assertTrue(ac.contains(".size(width = 90.dp, height = 70.3.dp)"))
    }

    @Test
    fun `drive memory toggle lives in settings rather than the dashboard`() {
        val home = source("screens/HomeScreen.kt")
        assertFalse(home.contains("onRestoreDrive"))
        assertFalse(home.contains("Запоминать выбор"))

        val settings = source("screens/SettingsScreen.kt")
        assertTrue(settings.contains("onRestoreDrive: (Boolean) -> Unit,"))
        assertTrue(settings.contains("DriveMemoryCard(profile.restoreDrive, onRestoreDrive)"))
        val card = settings.blockAfter("private fun DriveMemoryCard(")
        assertTrue(card.contains(".clickable { onChange(!restore) }"))
        assertTrue(card.contains("SwitchPill(restore)"))
        assertTrue(card.contains("Запоминать выбор после выключения"))
        val pill = settings.blockAfter("private fun SwitchPill(")
        assertTrue(pill.contains(".size(width = 42.dp, height = 24.dp)"))

        val hub = source("HubScreen.kt")
        assertTrue(hub.contains("onRestoreDrive = vm::setRestoreDrive,"))
    }

    @Test
    fun `rail shows the clock and labelled sections and no top bar exists`() {
        val top = source("components/TopBar.kt")
        val rail = top.blockAfter("fun HubNavRail(")
        val signature = top.substringAfter("fun HubNavRail(").substringBefore(") {")
        val item = top.blockAfter("private fun RailItem(")
        val clock = top.blockAfter("private fun Clock(")
        val system = top.blockAfter("fun SystemSettingsCard(")

        // Рейл получает только страницу: телеметрия в нём не читается.
        assertTrue(signature.contains("page: HubPage,"))
        assertTrue(signature.contains("onNavigate: (HubPage) -> Unit,"))
        assertFalse(signature.contains("VehicleSnapshot"))
        // Панель 152 dp: 1920 − 1768 dp рабочей области макета.
        assertTrue(rail.contains(".width(152.dp)"))
        assertTrue(rail.contains(".padding(start = 12.dp, end = 12.dp, top = 30.dp, bottom = 18.dp)"))
        assertTrue(rail.indexOf("Clock(") < rail.indexOf("HubPage.entries"))
        assertFalse("Погода в рейле не осталась", rail.contains("Weather("))
        assertTrue(clock.contains("fontSize = 40.sp"))
        assertTrue(clock.contains("fontSize = 17.sp"))
        // Плитка активного раздела шире обычной на 10 %: 98 × 1,1 = 107,8 dp.
        assertTrue(item.contains(".width(if (selected) 107.8.dp else 98.dp)"))
        assertTrue(item.contains(".height(132.dp)"))
        assertTrue(item.contains("Modifier.size(42.dp)"))
        assertTrue(item.contains("fontSize = 19.sp"))
        assertTrue(item.contains("contentDescription = page.label"))
        // Верхней панели больше нет: часы живут в рейле, экран и звук — в настройках.
        assertFalse("Top bar was removed from the layout", top.contains("fun HubTopBar("))
        assertFalse("Brand block was removed with the top bar", top.contains("private fun Brand("))
        assertFalse(top.contains("SourcePill"))
        assertTrue(system.contains("CardHead(title = \"Экран и звук\")"))
        assertTrue(system.contains("HomeSystemControls(controls"))

        val hub = source("HubScreen.kt")
        assertFalse("HubScreen must not compose a top bar", hub.contains("HubTopBar("))
    }

    @Test
    fun `brightness supports system access or an activity window without blocking on permission`() {
        val top = source("components/TopBar.kt")
        val controls = top.substringAfter("private class HomeControls(").substringBefore("private fun rememberHomeControls(")
        val access = top.blockAfter("private fun readBrightnessAccess()")
        val apply = top.blockAfter("private fun applyBrightness(")
        val finish = top.blockAfter("fun finishBrightness()")
        val system = top.blockAfter("private fun commitSystemBrightness(")
        val window = finish.substringAfter("} else {").substringBefore("} catch")
        val label = top.blockAfter("private fun BrightnessControl(")
        val enabled = controls.substringAfter("val brightnessEnabled:").substringBefore("private fun brightnessAccessIntent")

        assertTrue(enabled.contains("active && !brightnessCommitting && brightness != null"))
        assertTrue(enabled.contains("canWriteBrightness || context.findActivity() != null"))
        assertTrue(access.contains("Settings.System.canWrite(context)"))
        assertTrue(apply.contains("activity.window.attributes.screenBrightness"))
        assertTrue(apply.contains("systemBrightness?.current ?: 128"))
        assertTrue(apply.contains("windowBrightnessInherited"))
        assertTrue(system.contains("Settings.System.putInt(resolver, Settings.System.SCREEN_BRIGHTNESS, requested)"))
        assertTrue(system.contains("Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL"))
        assertTrue(system.contains("it.current == requested && !it.automatic"))
        assertTrue(finish.contains("withContext(Dispatchers.IO) { commitSystemBrightness(requested) }"))
        assertTrue(finish.contains("WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE"))
        assertTrue(window.contains("context.findActivity() ?: error("))
        assertTrue(window.contains("attributes.screenBrightness = requested / 255f"))
        assertTrue(window.contains("window.attributes = attributes"))
        assertTrue(window.contains("check((window.attributes.screenBrightness * 255f).roundToInt() == requested)"))
        assertFalse(window.contains("Settings.System.putInt"))
        assertTrue(label.contains("\"Яркость EX2 HUB\""))
        assertTrue(label.contains("windowBrightnessInherited -> \"По системе\""))
        assertTrue(label.contains("enabled = controls.brightnessEnabled"))
    }

    @Test
    fun `brightness writes occur only on explicit slider release never on startup or observer reads`() {
        val top = source("components/TopBar.kt")
        val finish = top.blockAfter("fun finishBrightness()")
        val preview = top.blockAfter("fun previewBrightness(")
        val refresh = top.blockAfter("fun refresh()")
        val observing = top.blockAfter("private fun rememberHomeControls(")
        val label = top.blockAfter("private fun BrightnessControl(")

        assertTrue(finish.contains("val draft = brightnessDraft ?: return"))
        assertTrue(finish.contains("if (!active || brightnessCommitting) return"))
        assertTrue(preview.contains("brightnessDraft = value"))
        val passiveReads = listOf("private fun readVolume()", "private fun readBrightnessAccess()",
            "private fun readSystemBrightness()", "private fun readSnapshot()", "private fun applyBrightness(")
            .map { top.blockAfter(it) }
        (listOf(preview, refresh, observing) + passiveReads).forEach { passive ->
            assertFalse(passive.contains("Settings.System.putInt"))
            assertFalse(passive.contains("screenBrightness ="))
            assertFalse(passive.contains("window.attributes ="))
            assertFalse(passive.contains("finishBrightness()"))
        }
        assertTrue(label.contains("onValueChange = controls::previewBrightness"))
        assertTrue(label.contains("onValueChangeFinished = {}"))
        assertTrue(label.contains(".sliderTapRelease(controls::cancelBrightnessPreview, controls::finishBrightness)"))
        assertTrue(label.blockAfter("is DragInteraction.Stop ->").contains("controls.finishBrightness()"))
        assertTrue(label.blockAfter("is DragInteraction.Cancel ->").contains("controls.cancelBrightnessPreview()"))
        assertFalse(label.blockAfter("is DragInteraction.Cancel ->").contains("controls.finishBrightness()"))
        assertFalse(top.substringBefore("fun finishBrightness()").contains("window.attributes ="))
        assertFalse(top.substringAfter("fun requestBrightnessAccess()").contains("window.attributes ="))
        assertFalse(observing.contains("LocalContext.current.applicationContext"))
        val unwrap = top.blockAfter("private fun Context.findActivity()")
        assertTrue(unwrap.contains("current is Activity"))
        assertTrue(unwrap.contains("current as? ContextWrapper"))
        assertTrue(unwrap.contains("visited.add(current)"))
        assertTrue(unwrap.contains("it.isFinishing || it.isDestroyed"))
        listOf("WRITE_SECURE_SETTINGS", "GeelyVhal", "Class.forName", "getDeclaredField", "Runtime.getRuntime")
            .forEach { assertFalse("Unsupported platform bypass: $it", top.contains(it)) }
    }

    @Test
    fun `brightness access is offered only when the system intent resolves and is not required`() {
        val top = source("components/TopBar.kt")
        val resolve = top.blockAfter("private fun brightnessAccessResolvable()")
        val request = top.blockAfter("fun requestBrightnessAccess()")
        val snapshot = top.blockAfter("private fun readSnapshot()")
        val control = top.blockAfter("private fun BrightnessControl(")
        assertTrue(resolve.contains("resolveActivity(context.packageManager) != null"))
        assertTrue(snapshot.contains("canOfferBrightnessAccess = !systemMode && brightnessAccessResolvable()"))
        assertTrue(request.contains("if (!active || accessRequestPending) return"))
        assertTrue(request.contains("withContext(Dispatchers.IO) { brightnessAccessResolvable() }"))
        assertTrue(request.contains("if (!isCurrent(lifecycle)) return@launch"))
        assertTrue(request.contains("if (!resolvable)"))
        assertTrue(request.contains("canOfferBrightnessAccess = false"))
        assertTrue(control.contains("if (controls.canOfferBrightnessAccess)"))
        assertTrue(control.contains("enabled = controls.brightnessEnabled"))
        assertTrue(control.contains(".heightIn(min = 48.dp).widthIn(min = 48.dp)"))
        assertFalse(request.contains("brightnessDraft ="))
        assertFalse(request.contains("screenBrightness ="))
    }

    @Test
    fun `home controls use the lifecycle local provided by compose ui`() {
        val source = source("components/TopBar.kt")
        assertTrue(source.contains("import androidx.compose.ui.platform.LocalLifecycleOwner"))
        assertFalse(source.contains("import androidx.lifecycle.compose.LocalLifecycleOwner"))
    }

    @Test
    fun `home uses its own canvas density while journal sections double`() {
        val screen = source("HubScreen.kt")
        assertTrue(screen.contains("val sectionDensity = if (page == HubPage.HOME) {"))
        // Масштаб шрифта из настроек ГУ закреплён на 1: макет в фиксированных dp/sp.
        assertTrue(screen.contains("Density(density.density * 1.5f, 1f)"))
        assertTrue(screen.contains("Density(density.density, 1f)"))
        assertFalse(screen.contains("density.fontScale"))
        assertTrue(screen.contains("CompositionLocalProvider("))
        assertTrue(screen.contains("LocalDensity provides sectionDensity,"))
        assertTrue(screen.contains("LocalHubText provides sectionText"))
        assertTrue(screen.indexOf("HubNavRail(") < screen.indexOf("LocalDensity provides sectionDensity"))
        // У рабочего стола своя шапка внутри макета: верхней панели нет нигде.
        assertFalse(screen.contains("HubTopBar("))
        assertEquals("Only the journal sections are doubled", 1,
            Regex("""density\.density \* 1\.5f""").findAll(screen).count())
        assertFalse(screen.contains("Density(density.density * 1.05f, 1f)"))
    }

    @Test
    fun `ack is a short futuristic chirp created off the UI thread`() {
        val controller = source("HubController.kt")
        val ack = controller.blockAfter("private fun playAck()")
        assertFalse(controller.contains("ToneGenerator"))
        assertTrue(ack.contains("scope.launch(Dispatchers.Default)"))
        assertTrue(ack.contains("ackMutex.withLock"))
        assertTrue(ack.contains("AudioTrack.MODE_STATIC"))
        assertTrue(ack.contains("rate * 72 / 1_000"))
        assertTrue(ack.contains("740.0 + 880.0 * progress * progress"))
        assertTrue(ack.contains("tone * 2.0"))
        assertTrue(ack.contains("track.reloadStaticData()"))
    }
}
