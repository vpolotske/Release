package com.ex2hub.source

import com.ex2hub.data.Body
import com.ex2hub.data.BodyPart
import com.ex2hub.data.CheckStatus
import com.ex2hub.data.Climate
import com.ex2hub.data.ClimateChange
import com.ex2hub.data.ClimateWriteResult
import com.ex2hub.data.DriveMode
import com.ex2hub.data.Gear
import com.ex2hub.data.SourceMode
import com.ex2hub.data.VehicleSnapshot
import com.ex2hub.ui.mergeClimateCommandResult
import com.ex2hub.ui.withBatteryCarEvent
import com.ex2hub.ui.withCarEvent
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CarEventMergeTest {
    private fun baseline() = VehicleSnapshot(source = SourceMode.CAR_API, soc = 60, speedKmh = 4,
        gear = Gear.P, driveMode = DriveMode.ECO, climate = Climate(acOn = false, fanSpeed = 2), updatedAt = 1000L)

    @Test
    fun `speed event does not roll back later command readback`() {
        val previous = baseline()
        val current = previous.copy(climate = Climate(acOn = true, fanSpeed = 6), driveMode = DriveMode.SPORT)
        assertEquals(current.copy(speedKmh = 0), current.withCarEvent(previous, previous.copy(speedKmh = 0)))
    }

    @Test
    fun `climate event changes only its actual signal including unavailable`() {
        val previous = baseline()
        val current = previous.copy(climate = Climate(acOn = true, fanSpeed = 6, driverTempC = 24.0))
        val event = previous.copy(climate = Climate(acOn = false, fanSpeed = 0))
        assertEquals(current.copy(climate = current.climate!!.copy(fanSpeed = 0)), current.withCarEvent(previous, event))
        val unavailable = event.copy(climate = Climate(acOn = false))
        assertEquals(null, current.withCarEvent(event, unavailable).climate!!.fanSpeed)
    }

    @Test
    fun `failed command rolls back only its signal over unrelated newer events`() {
        val previous = Climate(acOn = false, fanSpeed = 2, driverTempC = 20.0)
        val requested = previous.copy(acOn = true)
        val current = requested.copy(fanSpeed = 6, driverTempC = 24.0, wheelHeat = 1)
        val result = ClimateWriteResult(CheckStatus.ERROR, "write failed")
        assertEquals(current.copy(acOn = false), mergeClimateCommandResult(
            current, result, ClimateChange.AC, requested, previous
        ))
        assertEquals(null, result.observed)
        assertFalse(result.confirmed)
    }

    @Test
    fun `fresh failure observation replaces only commanded signal including unknown`() {
        val previous = Climate(fanSpeed = 2, acOn = false)
        val requested = previous.copy(fanSpeed = 3)
        val current = requested.copy(acOn = true, driverTempC = 24.0)
        val failed = ClimateWriteResult(CheckStatus.ERROR, "write failed", observed = Climate(fanSpeed = 5))
        assertEquals(current.copy(fanSpeed = 5), mergeClimateCommandResult(
            current, failed, ClimateChange.FAN_UP, requested, previous, signalObservedSinceRequest = true
        ))
        assertEquals(current.copy(fanSpeed = null), mergeClimateCommandResult(
            current, failed.copy(observed = Climate()), ClimateChange.FAN_UP, requested, previous
        ))
    }

    @Test
    fun `failure without readback preserves same signal callbacks including matching request`() {
        val previous = Climate(fanSpeed = 2, acOn = false)
        val requested = previous.copy(fanSpeed = 3)
        val failed = ClimateWriteResult(CheckStatus.ERROR, "result unknown")
        listOf(3, 5, null).forEach { observed ->
            val current = requested.copy(fanSpeed = observed, acOn = true)
            assertEquals(current, mergeClimateCommandResult(
                current, failed, ClimateChange.FAN_UP, requested, previous, signalObservedSinceRequest = true
            ))
        }
        // A callback that changed away and back to the request is still newer.
        val current = requested.copy(acOn = true)
        assertEquals(current, mergeClimateCommandResult(
            current, failed, ClimateChange.FAN_UP, requested, previous, signalObservedSinceRequest = true
        ))
        assertEquals(null, mergeClimateCommandResult(
            null, failed, ClimateChange.FAN_UP, requested, previous, signalObservedSinceRequest = true
        ))
    }

    @Test
    fun `failure also preserves a newer signal from a non callback update`() {
        val previous = Climate(driverTempC = 20.0, fanSpeed = 2)
        val requested = previous.copy(driverTempC = 21.0)
        val current = requested.copy(driverTempC = 25.0, fanSpeed = 6)
        assertEquals(current, mergeClimateCommandResult(
            current, ClimateWriteResult(CheckStatus.ERROR, "failed"), ClimateChange.DRIVER_UP, requested, previous
        ))
    }

    @Test
    fun `unconfirmed acceptance retains request but never replaces a newer callback`() {
        val previous = Climate(windshieldHeatOn = null, fanSpeed = 2)
        val requested = previous.copy(windshieldHeatOn = true)
        val current = previous.copy(fanSpeed = 6)
        val accepted = ClimateWriteResult(CheckStatus.OK, "accepted, not confirmed")
        assertEquals(current.copy(windshieldHeatOn = true), mergeClimateCommandResult(
            current, accepted, ClimateChange.WINDSHIELD_HEAT, requested, previous
        ))
        val callback = current.copy(windshieldHeatOn = false)
        assertEquals(callback, mergeClimateCommandResult(
            callback, accepted, ClimateChange.WINDSHIELD_HEAT, requested, previous, signalObservedSinceRequest = true
        ))
        assertFalse(accepted.confirmed)
        assertEquals(null, accepted.observed)
    }

    @Test
    fun `confirmed readback merges only the signal and preset failure keeps live state`() {
        val current = Climate(acOn = true, fanSpeed = 6, driverTempC = 24.0)
        val confirmed = ClimateWriteResult(CheckStatus.OK, "confirmed", observed = Climate(acOn = false), confirmed = true)
        assertEquals(current.copy(acOn = false), mergeClimateCommandResult(current, confirmed, ClimateChange.AC))
        assertEquals(current, mergeClimateCommandResult(current, ClimateWriteResult(CheckStatus.ERROR, "preset failed")))
        assertEquals(null, mergeClimateCommandResult(null, ClimateWriteResult(CheckStatus.ERROR, "preset failed")))
    }

    @Test
    fun `events never refresh unrelated fields or revive a stale snapshot`() {
        val previous = baseline()
        val current = previous.copy(stale = true, updatedAt = 500L, note = "Нет связи", batteryKwh = 40.0,
            rangeKm = 120, isCharging = false)
        val event = previous.copy(soc = 0, speedKmh = 0, gear = null, rangeKm = 250, isCharging = true,
            updatedAt = 2000L, note = "Car API")
        assertEquals(current.copy(soc = 0, speedKmh = 0, gear = null), current.withCarEvent(previous, event))
    }

    @Test
    fun `charging page applies only soc and outside temperature from a car event`() {
        val previous = baseline()
        val current = previous.copy(
            gear = Gear.D, speedKmh = 30, climate = Climate(acOn = true),
            rangeKm = 250, chargePowerKw = 6.0
        )
        val event = previous.copy(
            soc = 55, rangeKm = 240, isCharging = true, chargePowerKw = 7.2,
            gear = Gear.P, speedKmh = 0, climate = Climate(acOn = false), outsideTempC = 12
        )
        val battery = current.withBatteryCarEvent(current.withCarEvent(previous, event))
        assertEquals(55, battery.soc)
        assertEquals(12, battery.outsideTempC)
        assertEquals(250, battery.rangeKm)
        assertEquals(6.0, battery.chargePowerKw!!, 0.001)
        assertEquals(Gear.D, battery.gear)
        assertEquals(30, battery.speedKmh)
        assertEquals(true, battery.climate!!.acOn)
    }

    @Test
    fun `body observation can remove a signal without writing an actuator`() {
        val previous = baseline().copy(body = Body(open = mapOf(BodyPart.TAILGATE to true)))
        assertEquals(null, previous.withCarEvent(previous, previous.copy(body = null)).body)
    }

    @Test
    fun `installer uses fresh direct parking reads instead of cached event values`() {
        val root = listOf(File("src/main/java/com/ex2hub"), File("app/src/main/java/com/ex2hub")).first { it.isDirectory }
        val source = File(root, "source/CarApiSource.kt").readText(Charsets.UTF_8)
            .substringAfter("fun isParkedForUpdate()").substringBefore("fun close()")
        assertTrue(source.contains("withFreshReads"))
        assertTrue(source.contains(
            "PropertyHolder.read(manager, PropertyAddress(GeelyVhal.PROP_PERF_VEHICLE_SPEED), requireExact = true)"
        ))
        assertTrue(source.contains("PropertyHolder.read(manager, PropertyAddress(id, area), requireExact = true)"))
        assertTrue(source.contains("speed.recent(nowNanos) && gear.recent(nowNanos)"))
        assertTrue(source.contains("GeelyVhal.gear(integer(gear.value)) == Gear.P"))
        assertTrue(source.contains("!eventState.superseded(speed, speedOrder) && !eventState.superseded(gear, gearOrder)"))
        val screen = File(root, "ui/HubScreen.kt").readText(Charsets.UTF_8)
        assertTrue(screen.contains("System.currentTimeMillis() - vehicle.updatedAt !in 0L..5_000L"))
        assertTrue(screen.indexOf("vm.canInstallUpdate()") < screen.indexOf("updater.installerIntent()"))
    }

    @Test
    fun `heat confirmation keeps AC off and reports an already matching climate as done`() {
        val path = "src/main/java/com/ex2hub/source/CarApiSource.kt"
        val source = listOf(File(path), File("app/$path")).first { it.isFile }.readText(Charsets.UTF_8)
        assertTrue(source.contains("if (remaining.isEmpty() && attempted == 0)"))
        assertTrue(source.contains("GeelyVhal.climateWrites(ClimateChange.AC, Climate(acOn = false))"))
        assertTrue(source.contains("confirmClimate(result, log, settleMs = 120L) { it.confirms(target) && failed.isEmpty() }"))
    }

    @Test
    fun `controller owns collector lifetime and shows events during polling`() {
        val path = "src/main/java/com/ex2hub/ui/HubController.kt"
        val source = listOf(File(path), File("app/$path")).first { it.isFile }.readText(Charsets.UTF_8)
        // Подписка живёт вместе с циклом опроса: в фоне события обновляют снимок,
        // а не только при видимом экране.
        assertTrue(source.contains("if (mode == SourceMode.CAR_API) {"))
        assertFalse(source.contains("if (mode == SourceMode.CAR_API && uiVisible)"))
        assertTrue(source.contains("launch { reader.carUpdates.collect { receiveCarEvent(it) } }"))
        assertTrue(source.contains("reader.eventsActive"))
        val receive = source.substringAfter("private fun receiveCarEvent(").substringBefore("private fun seedCarEvents(")
        assertFalse(receive.contains("reading ||"))
        assertTrue(receive.contains("ui.probeRunning || previous == null || event.updatedAt > previous.updatedAt"))
        assertTrue(receive.contains("event.updatedAt < previous.updatedAt"))
        assertTrue(receive.contains("ui.vehicle.withCarEvent(previous, event)"))
        assertFalse(receive.contains("journal.observe"))
        assertFalse(receive.contains("restoreDrive("))
        assertFalse(receive.contains("playAck("))
    }
}
