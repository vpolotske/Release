package com.ex2hub.source

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertSame
import org.junit.Assert.assertThrows
import org.junit.Test

class CarCommandPriorityTest {
    @Test fun `idle polls continue normally`() {
        CarCommandPriority().checkPoll()
    }

    @Test fun `priority is reserved before the command suspends`() = runBlocking {
        val priority = CarCommandPriority()
        val release = CompletableDeferred<Unit>()
        val command = launch(start = CoroutineStart.UNDISPATCHED) {
            priority.runCommand { release.await() }
        }
        assertThrows(CarCommandPriority.PollYield::class.java) { priority.checkPoll() }
        priority.checkPoll(diagnostic = true)
        release.complete(Unit)
        command.join()
        priority.checkPoll()
    }

    @Test fun `cancellation releases a queued command priority`() = runBlocking {
        val priority = CarCommandPriority()
        val command = launch(start = CoroutineStart.UNDISPATCHED) {
            priority.runCommand { CompletableDeferred<Unit>().await() }
        }
        assertThrows(CarCommandPriority.PollYield::class.java) { priority.checkPoll() }
        command.cancelAndJoin()
        priority.checkPoll()
    }

    @Test fun `a failed command cannot block later polling`() = runBlocking {
        val priority = CarCommandPriority()
        val error = IllegalStateException("setter failed")
        assertSame(error, runCatching { priority.runCommand { throw error } }.exceptionOrNull())
        priority.checkPoll()
    }

    @Test fun `priority survives another command completing`() = runBlocking {
        val priority = CarCommandPriority()
        val release = CompletableDeferred<Unit>()
        val command = launch(start = CoroutineStart.UNDISPATCHED) {
            priority.runCommand { release.await() }
        }
        assertEquals(42, priority.runCommand { 42 })
        assertThrows(CarCommandPriority.PollYield::class.java) { priority.checkPoll() }
        release.complete(Unit)
        command.join()
        priority.checkPoll()
    }

    @Test fun `non car operations do not interrupt car reads`() = runBlocking {
        val priority = CarCommandPriority()
        assertEquals(42, priority.runCommand(enabled = false) {
            priority.checkPoll()
            42
        })
    }

    @Test fun `interruption has no expensive throwable stack`() = runBlocking {
        val priority = CarCommandPriority()
        priority.runCommand {
            val interruption = assertThrows(CarCommandPriority.PollYield::class.java) { priority.checkPoll() }
            assertEquals(0, interruption.stackTrace.size)
        }
    }
}
