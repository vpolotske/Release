package com.ex2hub.source

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Выгрузка журнала касается файлов и подтверждений, а это в JVM-тестах не исполняется:
 * здесь закреплены договорённости — приватный каталог без новых разрешений, CSV с BOM,
 * копия без якорей и восстановление только по подтверждению.
 */
class JournalExportContractTest {

    private fun source(relativePath: String): String {
        val path = "src/main/java/com/ex2hub/$relativePath.kt"
        return listOf(File(path), File("app/$path")).first { it.isFile }.readText(Charsets.UTF_8)
    }

    @Test
    fun `files land in the app external directory without a storage permission`() {
        val files = source("data/JournalFiles")
        assertTrue(files.contains("context.getExternalFilesDir(null) ?: context.filesDir"))
        assertFalse(files.contains("getExternalStorageDirectory"))
        assertFalse(files.contains("Environment."))
        val manifest = File(
            listOf("src/main/AndroidManifest.xml", "app/src/main/AndroidManifest.xml")
                .first { File(it).isFile }
        ).readText(Charsets.UTF_8)
        assertFalse(manifest.contains("WRITE_EXTERNAL_STORAGE"))
        assertTrue(files.contains("0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()"))
    }

    @Test
    fun `csv and backup have fixed names the settings screen can point at`() {
        val files = source("data/JournalFiles")
        assertTrue(files.contains("TRIPS_FILE = \"EX2-trips.csv\""))
        assertTrue(files.contains("CHARGES_FILE = \"EX2-charges.csv\""))
        assertTrue(files.contains("BACKUP_FILE = \"EX2-backup.json\""))
        assertTrue(files.contains("fun backupText(): String?"))
    }

    @Test
    fun `backup drops anchors but keeps version and export time`() {
        val store = source("data/Store")
        assertTrue(store.contains("toJson(state.copy(tripAnchor = null, chargeAnchor = null))"))
        assertTrue(store.contains("root.put(\"exportedAt\", exportedAt)"))
        assertTrue(store.contains("root.put(\"appVersion\", appVersion)"))
        assertTrue(store.contains("if (!root.has(\"trips\") && !root.has(\"sessions\"))"))
        assertTrue(store.contains("fun parseBackup(json: String): PersistedState?"))
    }

    @Test
    fun `journal writing leaves the main thread and refuses silent loss`() {
        val controller = source("ui/HubController")
        val export = controller.between("fun exportJournal()", "fun restoreJournal()")
        val restore = controller.between("fun restoreJournal()", "fun resetDemoData()")
        assertTrue(export.contains("withContext(Dispatchers.IO)"))
        assertTrue(restore.contains("withContext(Dispatchers.IO)"))
        assertTrue(restore.contains("?: error(\"нет файла \${JournalFiles.BACKUP_FILE}"))
        assertTrue(restore.contains("файл не похож на копию журнала"))
        assertTrue(restore.contains("В копии нет записей — журнал оставлен без изменений"))
        assertTrue(export.contains("if (ui.exportBusy) return"))
        assertTrue(restore.contains("profile = ui.profile.copy(tariffPerKwh = state.profile.tariffPerKwh)"))
    }

    @Test
    fun `settings shows both actions and asks before replacing the journal`() {
        val settings = source("ui/screens/SettingsScreen")
        assertTrue(settings.contains("text = \"Выгрузить CSV и копию\""))
        assertTrue(settings.contains("text = \"Восстановить из копии\""))
        assertTrue(settings.contains("SectionNote(\"Файлы лежат в \$path\")"))
        assertTrue(settings.contains("title = \"Восстановить журнал из копии?\""))
        assertTrue(settings.contains("busy = ui.exportBusy"))
        assertTrue(settings.contains("path = ui.exportPath"))
        assertTrue(settings.contains("enabled = records > 0 && !busy"))
    }

    @Test
    fun `both journal pages reach the controller actions`() {
        val hub = source("ui/HubScreen")
        assertTrue(hub.contains("onExportJournal = vm::exportJournal"))
        assertTrue(hub.contains("onRestoreJournal = vm::restoreJournal"))
        val state = source("ui/HubUiState")
        assertTrue(state.contains("val exportBusy: Boolean = false"))
        assertTrue(state.contains("val exportPath: String = \"\""))
    }

    @Test
    fun `csv writer has no android imports`() {
        val export = source("data/JournalExport")
        assertFalse(export.contains("import android."))
        assertTrue(export.contains("LINE_END = \"\\r\\n\""))
        assertTrue(export.contains("separator = \";\""))
    }

    /** Только тело метода: проверка не должна проходить за его пределы. */
    private fun String.between(start: String, end: String): String {
        val from = indexOf(start)
        val to = indexOf(end)
        assertTrue("нет блока $start", from >= 0 && to > from)
        return substring(from, to)
    }
}
