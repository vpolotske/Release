package com.ex2hub.source

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Уведомления о зарядке — Android-сторона, которая в JVM не исполняется. Здесь закреплено
 * главное: события берутся только из прочитанного, канал отдельный от строки сервиса,
 * и ни один новый класс не пытается что-либо писать автомобилю.
 */
class ChargeAlertContractTest {

    private fun source(relativePath: String): String {
        val path = "src/main/java/com/ex2hub/$relativePath.kt"
        return listOf(File(path), File("app/$path")).first { it.isFile }.readText(Charsets.UTF_8)
    }

    @Test
    fun `charge events use their own channel and respect the permission`() {
        val notifier = source("service/ChargeNotifier")
        assertTrue(notifier.contains("NotificationChannelCompat.Builder(CHANNEL_ID"))
        assertTrue(notifier.contains("CHANNEL_ID = \"charge\""))
        assertTrue(notifier.contains("NotificationManagerCompat.IMPORTANCE_DEFAULT"))
        assertTrue(notifier.contains("manager.areNotificationsEnabled()"))
        assertTrue(notifier.contains("Manifest.permission.POST_NOTIFICATIONS"))
        assertTrue(notifier.contains("catch (error: SecurityException)"))
        assertTrue(notifier.contains("manager.notify(alert.kind.notificationId"))
        // Постоянная строка сервиса живёт под id 1: события не должны её затирать.
        assertFalse(notifier.contains("NOTIFICATION_ID"))
        assertFalse(notifier.contains("setOngoing(true)"))
    }

    @Test
    fun `alerts read telemetry only and never write to the car`() {
        listOf(source("service/ChargeNotifier"), source("data/ChargeAlerts")).forEach { text ->
            assertFalse(text.contains("setProperty"))
            assertFalse(text.contains("CarPropertyManager"))
            assertFalse(text.contains("Runtime.getRuntime"))
            assertFalse(text.contains("GeelyVhal."))
        }
    }

    @Test
    fun `controller reports only the car answer and stores the choice`() {
        val controller = source("ui/HubController")
        assertTrue(controller.contains("notifyCharge(nextVehicle, profile, update.sessions)"))
        val body = controller.between("private fun notifyCharge(", "private fun polls(")
        assertTrue(body.contains("!vehicle.isFallback && profile.chargeAlertSoc > 0"))
        assertTrue(body.contains("charging = vehicle.isCharging == true"))
        assertTrue(body.contains("closed.maxByOrNull { it.startedAt }"))
        assertTrue(body.contains("profile.chargeDoneAlert"))
        assertTrue(controller.contains("ui.profile.copy(chargeAlertSoc = value)"))
        assertTrue(controller.contains("ui.profile.copy(chargeDoneAlert = enabled)"))
    }

    @Test
    fun `settings expose the threshold stepper and the finish switch`() {
        val settings = source("ui/screens/SettingsScreen")
        assertTrue(settings.contains("CardHead(title = \"Уведомления о зарядке\", eyebrow = \"Зарядка\")"))
        assertTrue(settings.contains("contentDescription = \"Поднять порог заряда\""))
        assertTrue(settings.contains("contentDescription = \"Снизить порог заряда\""))
        assertTrue(settings.contains("SwitchPill(done)"))
        assertEquals(2, Regex("ChargeAlertCard\\(").findAll(settings).count() - 1)
        assertTrue(settings.contains("percent = profile.chargeAlertSoc"))
        assertTrue(settings.contains("onPercentChange = onChargeAlertChange"))
        val hub = source("ui/HubScreen")
        assertTrue(hub.contains("onChargeAlertChange = vm::setChargeAlert"))
        assertTrue(hub.contains("onChargeDoneChange = vm::setChargeDoneAlert"))
    }

    @Test
    fun `both alert settings survive a restart`() {
        val store = source("data/Store")
        assertTrue(store.contains("profile.put(\"chargeAlertSoc\", chargeAlertSoc)"))
        assertTrue(store.contains("profile.put(\"chargeDoneAlert\", chargeDoneAlert)"))
        assertTrue(store.contains("json.optInt(\"chargeAlertSoc\", 0).coerceIn(0, 100)"))
        assertTrue(store.contains("json.optBoolean(\"chargeDoneAlert\", true)"))
    }

    private fun String.between(start: String, end: String): String {
        val from = indexOf(start)
        val to = indexOf(end)
        assertTrue("нет блока $start", from >= 0 && to > from)
        return substring(from, to)
    }
}
