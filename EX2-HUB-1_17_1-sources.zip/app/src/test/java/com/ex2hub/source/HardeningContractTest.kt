package com.ex2hub.source

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Правки 1.17.1: закрытие дыр и разгрузка ГУ. Поведение на устройстве в JVM-тестах не
 * исполняется, поэтому закреплены сами договорённости в исходниках, как в соседних
 * контрактных тестах.
 */
class HardeningContractTest {

    private fun text(path: String): String =
        listOf(File(path), File("app/$path")).first { it.isFile }.readText(Charsets.UTF_8)

    private fun source(relativePath: String): String = text("src/main/java/com/ex2hub/$relativePath.kt")

    private val manifest: String by lazy { text("src/main/AndroidManifest.xml") }

    @Test
    fun `journal and root commands never leave the device through backup`() {
        assertTrue(manifest.contains("android:allowBackup=\"false\""))
        assertFalse(manifest.contains("android:allowBackup=\"true\""))
    }

    @Test
    fun `configuration changes do not recreate the activity`() {
        val config = Regex("android:configChanges=\"([^\"]+)\"").find(manifest)?.groupValues?.get(1)
            ?: error("у активности нет configChanges")
        val flags = config.split('|').toSet()
        listOf("orientation", "screenSize", "uiMode", "density", "fontScale", "locale", "layoutDirection")
            .forEach { assertTrue("нет $it", it in flags) }
        assertTrue(manifest.contains("android:name=\".Ex2App\""))
    }

    @Test
    fun `a damaged state document is kept aside instead of being overwritten silently`() {
        val store = source("data/Store")
        assertTrue(store.contains("keepCorrupt(raw)"))
        assertTrue(store.contains("CORRUPT_FILE = \"state_json.corrupt\""))
        assertFalse(store.contains("getOrElse { PersistedState() }"))
    }

    @Test
    fun `numbers from a restored file are finite before they reach the statistics`() {
        val store = source("data/Store")
        assertTrue(store.contains("private fun JSONObject.finiteDouble("))
        assertFalse(store.contains("json.optDouble(\"distanceKm\", 0.0)"))
        assertFalse(store.contains("json.optDouble(\"energyKwh\", 0.0)"))
    }

    @Test
    fun `serialized journal arrays are reused while the list is the same object`() {
        val store = source("data/Store")
        assertTrue(store.contains("it.source === list"))
        assertTrue(store.contains("tripsCache = CachedArray(list, trips)"))
        assertTrue(store.contains("sessionsCache = CachedArray(list, sessions)"))
    }

    @Test
    fun `trip progress is not written every poll but boundaries are written at once`() {
        val controller = source("ui/HubController")
        assertTrue(controller.contains("private const val ANCHOR_PERSIST_MS = 30_000L"))
        assertTrue(controller.contains("val anchorBoundary = (previousTrip == null) != (journal.trip == null)"))
        assertTrue(controller.contains("anchorProgress && now - lastPersistAt >= ANCHOR_PERSIST_MS"))
        assertTrue(controller.contains("lastPersistAt = System.currentTimeMillis()"))
    }

    @Test
    fun `export files are replaced atomically and a restore file has a size limit`() {
        val files = source("data/JournalFiles")
        assertTrue(files.contains("private fun writeAtomically("))
        assertTrue(files.contains("MAX_BACKUP_BYTES"))
        assertTrue(files.contains("require(file.length() <= MAX_BACKUP_BYTES)"))
        assertFalse(files.contains("File(dir, BACKUP_FILE).writeText("))
    }

    @Test
    fun `root command output is bounded and read off the shared pool`() {
        val root = source("source/RootSource")
        assertFalse(root.contains("CompletableFuture"))
        assertTrue(root.contains("OUTPUT_LIMIT = 64 * 1024"))
        assertTrue(root.contains("EX2Hub-su-output"))
        assertTrue(root.contains("process.destroyForcibly()"))
    }

    @Test
    fun `home callbacks are stable references and the font scale is pinned`() {
        val screen = source("ui/HubScreen")
        listOf("onClimateChange", "onClimatePreset", "onDriveMode", "onRegen", "onFrunkOpen").forEach {
            assertTrue("нет remember(vm) для $it", screen.contains("remember(vm) { vm::$it }"))
        }
        assertFalse(screen.contains("onClimate = vm::onClimateChange"))
        assertFalse(screen.contains("density.fontScale"))
        assertTrue(screen.contains("LocalDensity provides fixedDensity"))
    }

    @Test
    fun `number formats are not shared between threads`() {
        val fmt = source("data/Fmt")
        assertTrue(fmt.contains("ThreadLocal.withInitial { DecimalFormat(pattern, symbols) }"))
        assertFalse(fmt.contains("DecimalFormat(\"0.0\", symbols)"))
        assertTrue(fmt.contains("decimal1.get().format(it)"))
    }

    @Test
    fun `release can be signed with a permanent key from the environment`() {
        val gradle = text("build.gradle.kts")
        assertTrue(gradle.contains("EX2_KEYSTORE_FILE"))
        assertTrue(gradle.contains("signingConfigs.findByName(\"ex2release\") ?: signingConfigs.getByName(\"debug\")"))
    }
}
