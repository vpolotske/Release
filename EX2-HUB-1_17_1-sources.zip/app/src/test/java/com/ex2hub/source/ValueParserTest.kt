package com.ex2hub.source

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ValueParserTest {
    @Test
    fun `reads first number from command output`() {
        assertEquals(68.0, ValueParser.firstNumber("68")!!, 0.0001)
        assertEquals(68.5, ValueParser.firstNumber("SOC: 68.5 %")!!, 0.0001)
    }

    @Test
    fun `accepts comma as decimal separator`() {
        assertEquals(12.7, ValueParser.firstNumber("12,7\n")!!, 0.0001)
    }

    @Test
    fun `accepts negative values`() {
        assertEquals(-8.5, ValueParser.firstNumber("-8.5 C")!!, 0.0001)
    }

    @Test
    fun `returns null when output has no number`() {
        assertNull(ValueParser.firstNumber("error: not found"))
        assertNull(ValueParser.firstNumber(""))
    }

    @Test
    fun `range guard rejects values outside bounds`() {
        assertEquals(68.0, ValueParser.parseInRange("68", 0.0, 100.0)!!, 0.0001)
        assertNull(ValueParser.parseInRange("128", 0.0, 100.0))
        assertNull(ValueParser.parseInRange("n/a", 0.0, 100.0))
    }
}
