package com.ex2hub.source

import com.ex2hub.data.BodyPart
import com.ex2hub.data.Climate
import com.ex2hub.data.DriveMode
import com.ex2hub.data.Gear
import com.ex2hub.data.RegenLevel
import com.ex2hub.data.SourceMode
import com.ex2hub.data.VehicleSnapshot
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class CarPropertyEventsTest {
    class FakeHolder(
        private val property: Int,
        private val area: Int,
        private val status: Int,
        private val value: Any?,
        private val timestamp: Long = 100L
    ) {
        fun getPropertyId(): Int = property
        fun getAreaId(): Int = area
        fun getStatus(): Int = status
        fun getValue(): Any? {
            check(status == 0) { "unavailable getValue must not be called" }
            return value
        }
        fun getTimestamp(): Long = timestamp
    }

    class FakeManager(var holder: Any?) {
        var holderCalls = 0
        var typedCalls = 0
        @Suppress("UNUSED_PARAMETER")
        fun getProperty(property: Int, area: Int): Any? { holderCalls++; return holder }
        @Suppress("UNUSED_PARAMETER")
        fun getIntProperty(property: Int, area: Int): Int { typedCalls++; return 0 }
        @Suppress("UNUSED_PARAMETER")
        fun getFloatProperty(property: Int, area: Int): Float { typedCalls++; return 0f }
        @Suppress("UNUSED_PARAMETER")
        fun getBooleanProperty(property: Int, area: Int): Boolean { typedCalls++; return false }
    }
    class IncompleteHolder {
        fun getPropertyId(): Int = 7
        fun getAreaId(): Int = 0
        fun getValue(): Int = 0
    }
    class HolderWithoutTimestamp(private val value: Float) {
        fun getPropertyId(): Int = GeelyVhal.PROP_PERF_VEHICLE_SPEED
        fun getAreaId(): Int = 0
        fun getStatus(): Int = 0
        fun getValue(): Float = value
    }
    class UnavailableHolderWithoutValue {
        fun getPropertyId(): Int = GeelyVhal.PROP_PERF_VEHICLE_SPEED
        fun getAreaId(): Int = 0
        fun getStatus(): Int = 3
    }
    class TypedTemperatureManager(val integer: Int?, val floating: Float?) {
        internal val calls = mutableListOf<Pair<String, PropertyAddress>>()
        fun getIntProperty(property: Int, area: Int): Int {
            calls += "int" to PropertyAddress(property, area)
            return checkNotNull(integer) { "integer unavailable" }
        }
        fun getFloatProperty(property: Int, area: Int): Float {
            calls += "float" to PropertyAddress(property, area)
            return checkNotNull(floating) { "float unavailable" }
        }
    }
    interface Listener {
        fun onChangeEvent(holder: Any)
        fun onErrorEvent(property: Int, area: Int)
    }

    private val speed = PropertyAddress(GeelyVhal.PROP_PERF_VEHICLE_SPEED)
    private val soc = PropertyAddress(GeelyVhal.PROP_SOC_PERCENT)
    private val ac = PropertyAddress(GeelyVhal.PROP_HVAC_AC_ON, GeelyVhal.AREA_HVAC_DA)
    private fun holder(address: PropertyAddress, value: Any?, timestamp: Long = 100L, status: Int = 0) =
        PropertyHolder(address, status, value, timestamp)
    private fun baseline() = VehicleSnapshot(source = SourceMode.CAR_API, soc = 60, speedKmh = 4,
        batteryKwh = 39.6, updatedAt = 1000L)
    private fun seeded(state: CarPropertyEvents, vararg holders: PropertyHolder): VehicleSnapshot {
        val poll = state.beginPoll()
        holders.forEach { state.observe(poll, it, state.reserve()) }
        return state.seed(baseline(), poll)!!
    }

    @Test fun `missing holder cannot become a typed default`() {
        val manager = FakeManager(null)
        assertThrows(IllegalArgumentException::class.java) { PropertyHolder.read(manager, speed) }
        assertEquals(1, manager.holderCalls)
        assertEquals(0, manager.typedCalls)
    }

    @Test fun `available zeros and false retain their actual holder types`() {
        for (value in listOf<Any>(false, 0, 0f, 0.0, 22.5f, 32f)) {
            val manager = FakeManager(FakeHolder(speed.propertyId, speed.areaId, 0, value))
            val result = PropertyHolder.read(manager, speed)
            assertTrue(result.available)
            assertSame(value, result.value)
            assertEquals(value.javaClass, result.value!!.javaClass)
            assertEquals(0, manager.typedCalls)
        }
    }

    @Test fun `unavailable and error status never unwrap a primitive value`() {
        for (status in listOf(1, 2, -1)) {
            val manager = FakeManager(FakeHolder(ac.propertyId, ac.areaId, status, false))
            val result = PropertyHolder.read(manager, ac)
            assertFalse(result.available)
            assertEquals(status, result.status)
            assertNull(result.value)
            assertEquals(0, manager.typedCalls)
        }
        assertFalse(PropertyHolder.read(FakeManager(FakeHolder(ac.propertyId, ac.areaId, 0, null)), ac).available)
    }

    @Test fun `exact reads reject canonical wrapper answers that plain reads accept`() {
        // Обёртка ECARX отвечает каноническими address; отказ от такого ответа ломал
        // чтение SOC, уставки и климата. Точная сверка нужна только проверке парковки.
        val canonical = FakeHolder(speed.propertyId + 1, 9, 0, 0)
        assertThrows(IllegalArgumentException::class.java) {
            PropertyHolder.read(FakeManager(canonical), speed, requireExact = true)
        }
        val accepted = PropertyHolder.read(FakeManager(canonical), speed)
        assertTrue(accepted.available)
        assertEquals(PropertyAddress(speed.propertyId + 1, 9), accepted.address)
        assertThrows(NoSuchMethodException::class.java) { PropertyHolder.decode(IncompleteHolder()) }
    }

    @Test fun `cached methods read each current holder instead of caching values`() {
        val manager = FakeManager(FakeHolder(speed.propertyId, 0, 0, 4f, 100L))
        assertEquals(4f, PropertyHolder.read(manager, speed).value)
        manager.holder = FakeHolder(speed.propertyId, 0, 0, 0f, 200L)
        val stopped = PropertyHolder.read(manager, speed)
        assertEquals(0f, stopped.value)
        assertEquals(200L, stopped.timestamp)
        manager.holder = FakeHolder(speed.propertyId, 0, 3, 99f, 300L)
        assertNull(PropertyHolder.read(manager, speed).value)
        assertEquals(3, manager.holderCalls)
    }

    @Test fun `cached optional timestamp cannot fabricate parking freshness`() {
        repeat(2) {
            val decoded = PropertyHolder.decode(HolderWithoutTimestamp(it.toFloat()))
            assertEquals(it.toFloat(), decoded.value)
            assertEquals(0L, decoded.timestamp)
            assertFalse(decoded.recent(1L))
        }
    }

    @Test fun `unavailable holder needs no value getter even with cached accessors`() {
        repeat(2) {
            val decoded = PropertyHolder.decode(UnavailableHolderWithoutValue())
            assertFalse(decoded.available)
            assertNull(decoded.value)
        }
    }

    @Test fun `listener Object methods use identity and never dispatch`() {
        val calls = mutableListOf<String>()
        val listener = propertyCallback(Listener::class.java) { name, _ -> calls += name } as Listener
        val other = propertyCallback(Listener::class.java) { _, _ -> } as Listener
        assertTrue(listener == listener)
        assertFalse(listener == other)
        assertFalse(listener.equals(null))
        assertEquals(System.identityHashCode(listener), listener.hashCode())
        assertTrue(listener.toString().startsWith("EX2HubPropertyCallback@"))
        assertTrue(calls.isEmpty())
        listener.onChangeEvent(Any())
        listener.onErrorEvent(1, 0)
        assertEquals(listOf("onChangeEvent", "onErrorEvent"), calls)
    }

    @Test fun `events cannot fabricate a snapshot before a successful baseline`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        assertNull(state.event(generation, holder(speed, 0f)))
        assertNull(state.seed(null, state.beginPoll()))
        val poll = state.beginPoll()
        val actual = state.seed(baseline(), poll)!!
        assertEquals(0, actual.speedKmh)
        assertEquals(60, actual.soc)
        assertNull(actual.climate)
        assertNull(actual.gear)
    }

    @Test fun `callback patches zero speed without making unrelated fields fresh`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        seeded(state, holder(speed, 4f), holder(soc, 60))
        val event = state.event(generation, holder(speed, 0f, 200L))!!
        assertEquals(0, event.speedKmh)
        assertEquals(60, event.soc)
        assertEquals(1000L, event.updatedAt)
        assertNull(state.event(generation, holder(speed, 0f, 201L))) // no changed snapshot
    }

    @Test fun `unavailable AC clears instead of switching off and ignores wrong area`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        seeded(state, holder(ac, true))
        assertNull(state.event(generation, holder(ac.copy(areaId = 74), false, 200L)))
        val unavailable = state.event(generation, holder(ac, false, 200L, status = 1))!!
        assertNull(unavailable.climate?.acOn)
        val off = state.event(generation, holder(ac, false, 300L))!!
        assertEquals(false, off.climate?.acOn)
        assertNull(state.event(generation, holder(PropertyAddress(1234), 0, 500L)))
    }

    @Test fun `newer event wins an older full poll with positive timestamps`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        seeded(state, holder(speed, 4f))
        val poll = state.beginPoll()
        val reservation = state.reserve()
        assertEquals(31, state.event(generation, holder(speed, 30f, 300L))!!.speedKmh)
        state.observe(poll, holder(speed, 5f, 200L), reservation)
        val merged = state.seed(baseline().copy(speedKmh = 5, updatedAt = 2000L), poll)!!
        assertEquals(31, merged.speedKmh)
        assertEquals(2000L, merged.updatedAt)
        assertNull(state.event(generation, holder(speed, 10f, 250L)))
    }

    @Test fun `equal timestamp duplicates cannot roll back or resurrect a field`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        seeded(state, holder(speed, 4f))
        assertNotNull(state.event(generation, holder(speed, 20f, 200L)))
        assertNull(state.event(generation, holder(speed, 0f, 200L)))
        assertNull(state.event(generation, holder(speed, 0f, 200L, status = 1))!!.speedKmh)
        assertNull(state.event(generation, holder(speed, 20f, 200L)))
        assertEquals(0, state.event(generation, holder(speed, 0f, 300L))!!.speedKmh)
    }

    @Test fun `discarded poll cannot consume a later matching callback`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        seeded(state, holder(speed, 4f))
        val poll = state.beginPoll()
        state.observe(poll, holder(speed, 0f, 200L), state.reserve())
        state.discardPoll(poll)
        assertEquals(0, state.event(generation, holder(speed, 0f, 200L))!!.speedKmh)
    }

    @Test fun `matching callback during unfinished poll is delivered only once`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        seeded(state, holder(speed, 4f))
        val poll = state.beginPoll()
        state.observe(poll, holder(speed, 0f, 200L), state.reserve())
        assertEquals(0, state.event(generation, holder(speed, 0f, 200L))!!.speedKmh)
        state.discardPoll(poll)
        assertNull(state.event(generation, holder(speed, 0f, 200L)))
        assertEquals(0, state.event(generation, holder(soc, 61, 300L))!!.speedKmh)
    }

    @Test fun `discarding a poll never rolls back a newer unavailable event`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        seeded(state, holder(ac, true))
        val poll = state.beginPoll()
        state.observe(poll, holder(ac, false, 200L), state.reserve())
        assertNull(state.event(generation, holder(ac, null, 300L, status = 3))!!.climate?.acOn)
        state.discardPoll(poll)
        assertNull(state.event(generation, holder(ac, false, 200L)))
        assertNull(state.event(generation, holder(soc, 61, 400L))!!.climate?.acOn)
    }

    @Test fun `unavailable callback matching an unfinished poll clears the baseline`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        seeded(state, holder(ac, true))
        val poll = state.beginPoll()
        val unavailable = holder(ac, null, 200L, status = 3)
        state.observe(poll, unavailable, state.reserve())
        assertNull(state.event(generation, unavailable)!!.climate?.acOn)
        state.discardPoll(poll)
        assertNull(state.event(generation, holder(ac, true, 200L)))
    }

    @Test fun `unfinished newer read cannot swallow invalidation of committed baseline`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        seeded(state, holder(ac, true, 100L))
        val poll = state.beginPoll()
        state.observe(poll, holder(ac, true, 300L), state.reserve())
        assertNull(state.event(generation, holder(ac, null, 200L, status = 3))!!.climate?.acOn)
        state.discardPoll(poll)
        assertNull(state.event(generation, holder(ac, true, 200L)))
        assertNull(state.event(generation, holder(soc, 61, 400L))!!.climate?.acOn)
    }

    @Test fun `successful poll publishes its newer read after an intermediate invalidation`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        seeded(state, holder(ac, true, 100L))
        val poll = state.beginPoll()
        state.observe(poll, holder(ac, true, 300L), state.reserve())
        assertNull(state.event(generation, holder(ac, null, 200L, status = 3))!!.climate?.acOn)
        assertEquals(true, state.seed(baseline(), poll)!!.climate?.acOn)
        assertNull(state.event(generation, holder(ac, null, 200L, status = 3)))
    }

    @Test fun `completed poll still rejects equal timestamp conflicting callbacks`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        val poll = state.beginPoll()
        state.observe(poll, holder(speed, 0f, 200L), state.reserve())
        assertEquals(0, state.seed(baseline(), poll)!!.speedKmh)
        state.discardPoll(poll)
        assertNull(state.event(generation, holder(speed, 4f, 200L)))
        assertNull(state.event(generation, holder(speed, 0f, 200L)))
    }

    @Test fun `missing timestamps use reservation order not Binder completion order`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        seeded(state, holder(speed, 4f, 0L))
        val poll = state.beginPoll()
        val reservation = state.reserve()
        state.event(generation, holder(speed, 20f, 0L))
        state.observe(poll, holder(speed, 0f, 0L), reservation)
        assertEquals(21, state.seed(baseline().copy(speedKmh = 0), poll)!!.speedKmh)
    }

    @Test fun `unavailable event wins older poll and old event cannot restore it`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        seeded(state, holder(ac, false))
        val poll = state.beginPoll()
        val reservation = state.reserve()
        state.event(generation, holder(ac, false, 300L, status = 1))
        state.observe(poll, holder(ac, false, 200L), reservation)
        val merged = state.seed(baseline().copy(climate = Climate(acOn = false)), poll)!!
        assertNull(merged.climate?.acOn)
        assertNull(state.event(generation, holder(ac, false, 200L)))
    }

    @Test fun `events received before poll start still reject older holder timestamps`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        seeded(state, holder(speed, 4f), holder(ac, false))
        state.event(generation, holder(speed, 20f, 300L))
        state.event(generation, holder(ac, false, 300L, status = 1))
        val poll = state.beginPoll()
        state.observe(poll, holder(speed, 0f, 200L), state.reserve())
        state.observe(poll, holder(ac, false, 200L), state.reserve())
        val merged = state.seed(baseline().copy(climate = Climate(acOn = false)), poll)!!
        assertEquals(21, merged.speedKmh)
        assertNull(merged.climate?.acOn)
    }

    @Test fun `preferred source wins while available and a fallback takes over after invalidation`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        seeded(state, holder(soc, 60))
        val fallback = PropertyAddress(GeelyVhal.PROP_BATTERY_LEVEL)
        assertNull(state.event(generation, holder(fallback, 39_600f, 200L)))
        assertEquals(0, state.event(generation, holder(soc, 0, 300L))!!.soc)
        assertNull(state.event(generation, holder(fallback, 30f, 400L)))
        assertNull(state.event(generation, holder(soc, 0, 500L, status = 1))!!.soc)
        // Инвалидация предпочтительного адреса разрешает резерв: иначе мёртвый
        // SOC_PERCENT оставлял бы заряд пустым навсегда, хотя ёмкость читается.
        assertEquals(50, state.event(generation, holder(fallback, 19_800f, 600L))!!.soc)
        assertEquals(2, state.event(generation, holder(soc, 2, 700L))!!.soc)
        assertNull(state.event(generation, holder(fallback, 39_600f, 800L)))
    }

    @Test fun `snapshot uses latest profile and existing GeelyVhal decoders`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        val poll = state.beginPoll()
        state.observe(poll, holder(PropertyAddress(GeelyVhal.PROP_BATTERY_LEVEL), 20_000f), state.reserve())
        assertEquals(50, state.seed(baseline().copy(batteryKwh = 40.0), poll)!!.soc)
        assertEquals(25, state.event(generation,
            holder(PropertyAddress(GeelyVhal.PROP_BATTERY_LEVEL), 10_000f, 200L))!!.soc)
        assertEquals(DriveMode.COMFORT, state.event(generation,
            holder(PropertyAddress(GeelyVhal.PROP_DRIVE_MODE), 0x22010102, 200L))!!.driveMode)
        assertEquals(RegenLevel.MID, state.event(generation,
            holder(PropertyAddress(GeelyVhal.PROP_REGEN_LEVEL, 1), 2, 200L))!!.regen)
        assertEquals(Gear.D, state.event(generation,
            holder(PropertyAddress(GeelyVhal.PROP_CURRENT_GEAR, 0), 8, 200L))!!.gear)
        assertEquals(0, state.event(generation,
            holder(PropertyAddress(GeelyVhal.PROP_AC_AMBIENT_TEMP), 80, 200L))!!.outsideTempC)
        assertEquals(5432.5, state.event(generation,
            holder(PropertyAddress(GeelyVhal.PROP_PERF_ODOMETER), 5432.5f, 200L))!!.odometerKm!!, 0.0)
        val temp = PropertyAddress(GeelyVhal.PROP_HVAC_TEMPERATURE_ADJUST, GeelyVhal.AREA_SEAT_LEFT)
        assertEquals(22.5, state.event(generation, holder(temp, 22.5f, 200L))!!.climate!!.driverTempC!!, 0.0)
        assertEquals(0, state.event(generation,
            holder(PropertyAddress(GeelyVhal.PROP_HVAC_FAN_SPEED, 1), 0, 200L))!!.climate?.fanSpeed)
    }

    @Test fun `integer setpoint zone neither masks a float zone nor clears the value`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        val poll = state.beginPoll()
        state.observe(poll, holder(speed, 4), state.reserve())
        assertEquals(20.0, state.seed(baseline().copy(climate = Climate(driverTempC = 20.0)), poll)!!
            .climate!!.driverTempC!!, 0.0)
        val set = { area: Int -> PropertyAddress(GeelyVhal.PROP_HVAC_TEMPERATURE_SET, area) }
        // Журнал 2026-10-28: зона 1 отдаёт Int 4 — это шаг, а не градусы.
        assertNull(state.event(generation, holder(set(GeelyVhal.AREA_SEAT_LEFT), 4, 200L)))
        // Float из зоны 4 становится источником, даже если зона 1 ответила раньше.
        assertEquals(20.5, state.event(generation,
            holder(set(GeelyVhal.AREA_SEAT_RIGHT), 20.5f, 300L))!!.climate!!.driverTempC!!, 0.0)
        // Повторный Int зоны 1 не сбрасывает показание и не переключает источник.
        assertNull(state.event(generation, holder(set(GeelyVhal.AREA_SEAT_LEFT), 4, 400L)))
        // Целый шаг 0x15200503 уступает любому float-каналу.
        assertNull(state.event(generation,
            holder(PropertyAddress(GeelyVhal.PROP_HVAC_TEMPERATURE_SET_INT, GeelyVhal.AREA_SEAT_LEFT), 4, 500L)))
        // Когда float-зона замолчала, показ берётся из целого шага.
        assertNull(state.event(generation,
            holder(set(GeelyVhal.AREA_SEAT_RIGHT), null, 600L, status = 3)))
        assertEquals(20.0, state.event(generation,
            holder(PropertyAddress(GeelyVhal.PROP_HVAC_TEMPERATURE_SET_INT, GeelyVhal.AREA_SEAT_LEFT), 4, 700L))!!
            .climate!!.driverTempC!!, 0.0)
    }

    @Test fun `outside temperature reads ENV zones in tenths and takes the preferred zone back`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        val ambient = PropertyAddress(GeelyVhal.PROP_AC_AMBIENT_TEMP)
        val envLeft = PropertyAddress(GeelyVhal.PROP_ENV_OUTSIDE_TEMP, GeelyVhal.AREA_SEAT_LEFT)
        val envRight = PropertyAddress(GeelyVhal.PROP_ENV_OUTSIDE_TEMP, GeelyVhal.AREA_SEAT_RIGHT)
        // Зона сиденья водителя молчит, поэтому базу даёт Flyme: (106 − 80) / 2.
        assertEquals(13, seeded(state, holder(ambient, 106)).outsideTempC)
        assertNull(state.event(generation, holder(envLeft, 120, 200L, status = 3))!!.outsideTempC)
        assertEquals(23, state.event(generation, holder(ambient, 126, 210L))!!.outsideTempC)
        // Ответившая ENV-зона опережает резерв, даже если приходит позже.
        assertEquals(14, state.event(generation, holder(envRight, 140, 220L))!!.outsideTempC)
        assertNull(state.event(generation, holder(ambient, 120, 230L)))
        assertNull(state.event(generation, holder(envRight, 141, 240L, status = 1))!!.outsideTempC)
        assertEquals(20, state.event(generation, holder(ambient, 120, 250L))!!.outsideTempC)
        assertEquals(13, state.event(generation, holder(envLeft, 130, 260L))!!.outsideTempC)
    }

    @Test fun `outside temperature baseline prefers ENV zones over Flyme ambient`() {
        val state = CarPropertyEvents()
        state.open()
        val ambient = holder(PropertyAddress(GeelyVhal.PROP_AC_AMBIENT_TEMP), 106)
        val env = holder(PropertyAddress(GeelyVhal.PROP_ENV_OUTSIDE_TEMP, GeelyVhal.AREA_SEAT_RIGHT), 125)
        assertEquals(13, seeded(state, ambient, env).outsideTempC)
        val state2 = CarPropertyEvents()
        state2.open()
        assertEquals(13, seeded(state2, env, ambient).outsideTempC)
    }

    @Test fun `typed ENV preserves integer tenths and floating degrees`() {
        val address = PropertyAddress(GeelyVhal.PROP_ENV_OUTSIDE_TEMP, 4)
        for ((raw, expected) in listOf(200 to 20, -90 to -9, 0 to 0)) {
            val manager = TypedTemperatureManager(raw, null)
            assertEquals(expected, readTypedTemperature(manager, address, true, GeelyVhal::outsideCelsius))
            assertEquals(listOf("float" to address, "int" to address), manager.calls)
        }
        val manager = TypedTemperatureManager(200, 9.0f)
        assertEquals(9, readTypedTemperature(manager, address, true, GeelyVhal::outsideCelsius))
        assertEquals(listOf("float" to address), manager.calls)
    }

    @Test fun `invalid typed float tries integer instead of hiding valid temperature`() {
        val address = PropertyAddress(GeelyVhal.PROP_ENV_OUTSIDE_TEMP)
        for (raw in listOf(Float.NaN, Float.POSITIVE_INFINITY, 200f)) {
            val manager = TypedTemperatureManager(125, raw)
            assertEquals(13, readTypedTemperature(manager, address, true, GeelyVhal::outsideCelsius))
            assertEquals(2, manager.calls.size)
        }
    }

    @Test fun `typed ambient rejects raw zero and tries next getter`() {
        val address = PropertyAddress(GeelyVhal.PROP_AC_AMBIENT_TEMP)
        val decode = { raw: Any? -> GeelyVhal.tempC(GeelyVhal.flymeTemp((raw as? Number)?.toDouble())) }
        for (raw in listOf<Int?>(0, 1000, null)) {
            val manager = TypedTemperatureManager(raw, 106f)
            assertEquals(13, readTypedTemperature(manager, address, false, decode))
            assertEquals(listOf("int" to address, "float" to address), manager.calls)
        }
        assertEquals(0, readTypedTemperature(TypedTemperatureManager(80, null), address, false, decode))
        assertNull(readTypedTemperature(TypedTemperatureManager(0, 0f), address, false, decode))
        assertNull(readTypedTemperature(TypedTemperatureManager(null, null), address, false, decode))
    }

    @Test fun `unavailable holder poll does not erase independent typed temperature`() {
        val state = CarPropertyEvents()
        state.open()
        val poll = state.beginPoll()
        for (address in GeelyVhal.OUTSIDE_TEMP_AREAS.map { PropertyAddress(GeelyVhal.PROP_ENV_OUTSIDE_TEMP, it) } +
            GeelyVhal.OUTSIDE_AMBIENT_AREAS.map { PropertyAddress(GeelyVhal.PROP_AC_AMBIENT_TEMP, it) } +
            PropertyAddress(GeelyVhal.PROP_ENV_OUTSIDE_TEMPERATURE)) {
            state.observe(poll, holder(address, null, status = 3), state.reserve())
        }
        val address = PropertyAddress(GeelyVhal.PROP_AC_AMBIENT_TEMP)
        val typed = readTypedTemperature(TypedTemperatureManager(106, null), address, false, decode = { raw ->
            GeelyVhal.tempC(GeelyVhal.flymeTemp((raw as? Number)?.toDouble()))
        })
        state.observeOutsideTemperature(poll, typed!!, state.reserve())
        assertEquals(13, state.seed(baseline().copy(outsideTempC = typed), poll)!!.outsideTempC)
        val nextPoll = state.beginPoll()
        state.observe(nextPoll, holder(address, null, 200L, status = 3), state.reserve())
        assertNull(state.seed(baseline(), nextPoll)!!.outsideTempC)
    }

    @Test fun `unavailable event during poll cannot erase independently read temperature`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        seeded(state)
        val poll = state.beginPoll()
        val address = PropertyAddress(GeelyVhal.PROP_ENV_OUTSIDE_TEMP, 1)
        assertNull(state.event(generation, holder(address, null, 200L, status = 3)))
        state.observeOutsideTemperature(poll, 13, state.reserve())
        assertEquals(13, state.seed(baseline().copy(outsideTempC = 13), poll)!!.outsideTempC)
        val nextPoll = state.beginPoll()
        assertNull(state.seed(baseline(), nextPoll)!!.outsideTempC)
    }

    @Test fun `valid outside event during poll still wins independent baseline`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        seeded(state)
        val poll = state.beginPoll()
        state.observeOutsideTemperature(poll, 13, state.reserve())
        assertEquals(14, state.event(generation,
            holder(PropertyAddress(GeelyVhal.PROP_ENV_OUTSIDE_TEMP, 4), 140, 200L))!!.outsideTempC)
        assertEquals(14, state.seed(baseline().copy(outsideTempC = 13), poll)!!.outsideTempC)
    }

    @Test fun `old outside event cannot override fresh typed reading when holders are skipped`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        seeded(state)
        assertEquals(14, state.event(generation,
            holder(PropertyAddress(GeelyVhal.PROP_ENV_OUTSIDE_TEMP, 4), 140, 200L))!!.outsideTempC)
        val poll = state.beginPoll()
        state.observeOutsideTemperature(poll, 13, state.reserve())
        assertEquals(13, state.seed(baseline().copy(outsideTempC = 13), poll)!!.outsideTempC)
        assertEquals(13, state.event(generation, holder(speed, 0f, 300L))!!.outsideTempC)
    }

    @Test fun `newer unavailable outside event wins a typed reply reserved before Binder`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        val outside = PropertyAddress(GeelyVhal.PROP_ENV_OUTSIDE_TEMP, 4)
        seeded(state, holder(outside, 140))
        val poll = state.beginPoll()
        val reservation = state.reserve()
        assertNull(state.event(generation, holder(outside, null, 200L, status = 3))!!.outsideTempC)
        state.observeOutsideTemperature(poll, 13, reservation)
        assertNull(state.seed(baseline().copy(outsideTempC = 13), poll)!!.outsideTempC)
    }

    @Test fun `newer unavailable outside event still clears holder derived baseline`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        val outside = PropertyAddress(GeelyVhal.PROP_ENV_OUTSIDE_TEMP, 4)
        seeded(state, holder(outside, 140))
        val poll = state.beginPoll()
        state.observe(poll, holder(outside, 130, 200L), state.reserve())
        assertNull(state.event(generation, holder(outside, null, 300L, status = 3))!!.outsideTempC)
        assertNull(state.seed(baseline().copy(outsideTempC = 13), poll)!!.outsideTempC)
    }

    @Test fun `newer drive and regen invalidations still clear holder derived baseline`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        val drive = PropertyAddress(GeelyVhal.PROP_DRIVE_MODE)
        val regen = PropertyAddress(GeelyVhal.PROP_REGEN_LEVEL, 1)
        seeded(state, holder(drive, 0x22010102), holder(regen, 2))
        val poll = state.beginPoll()
        state.observe(poll, holder(drive, 0x22010102, 200L), state.reserve())
        state.observe(poll, holder(regen, 2, 200L), state.reserve())
        assertNull(state.event(generation, holder(drive, null, 300L, status = 1))!!.driveMode)
        assertNull(state.event(generation, holder(regen, null, 300L, status = 1))!!.regen)
        val merged = state.seed(baseline().copy(driveMode = DriveMode.COMFORT, regen = RegenLevel.MID), poll)!!
        assertNull(merged.driveMode)
        assertNull(merged.regen)
    }

    @Test fun `outside ambient subscriptions cover every polled zone`() {
        for (area in GeelyVhal.OUTSIDE_AMBIENT_AREAS) {
            val state = CarPropertyEvents()
            val generation = state.open()
            seeded(state)
            val address = PropertyAddress(GeelyVhal.PROP_AC_AMBIENT_TEMP, area)
            assertTrue(state.knows(address))
            assertEquals(13, state.event(generation, holder(address, 106, 200L))!!.outsideTempC)
        }
    }

    @Test fun `boolean and unknown codes do not fabricate gear or drive values`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        seeded(state)
        assertNull(state.event(generation, holder(PropertyAddress(GeelyVhal.PROP_CURRENT_GEAR, 0), true)))
        assertNull(state.event(generation, holder(PropertyAddress(GeelyVhal.PROP_DRIVE_MODE), true)))
        assertNull(state.event(generation, holder(PropertyAddress(GeelyVhal.PROP_DRIVE_MODE), 999, 200L)))
        assertEquals(Gear.D, state.event(generation,
            holder(PropertyAddress(GeelyVhal.PROP_CURRENT_GEAR, 0), 8, 200L))!!.gear)
        assertNull(state.event(generation,
            holder(PropertyAddress(GeelyVhal.PROP_CURRENT_GEAR, 0), 0, 300L))!!.gear)
    }

    @Test fun `only the hood is subscribed and unavailable removes its map entry`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        seeded(state)
        val hood = PropertyAddress(GeelyVhal.PROP_DOOR_POS, GeelyVhal.DOOR_AREAS.getValue(BodyPart.HOOD))
        assertEquals(true, state.event(generation, holder(hood, 1))!!.body?.isOpen(BodyPart.HOOD))
        assertNull(state.event(generation, holder(hood, 0, 200L, status = 2))!!.body?.isOpen(BodyPart.HOOD))

        val door = PropertyAddress(GeelyVhal.PROP_DOOR_POS, GeelyVhal.AREA_DOOR_ROW_1_LEFT)
        assertFalse(state.knows(door))
        assertFalse(state.knows(PropertyAddress(GeelyVhal.PROP_DOOR_LOCK, GeelyVhal.AREA_DOOR_ROW_1_LEFT)))
        assertFalse(state.knows(PropertyAddress(GeelyVhal.PROP_WINDOW_POS, GeelyVhal.AREA_WINDOW_ROW_1_LEFT)))
        for (id in listOf(GeelyVhal.PROP_FRONT_TRUNK_SWT, GeelyVhal.PROP_HOOD_LOCK)) {
            assertFalse(id in state.propertyIds)
        }
    }

    @Test fun `partial poll keeps actual climate and omitted event fields`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        seeded(state, holder(ac, false))
        state.event(generation, holder(speed, 20f, 200L))
        val poll = state.beginPoll() // speed suppressed/omitted, not a zero reply
        val merged = state.seed(baseline().copy(speedKmh = null), poll, full = false)!!
        assertEquals(false, merged.climate?.acOn)
        assertEquals(21, merged.speedKmh)
    }

    @Test fun `error callback without a holder invalidates the exact address`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        seeded(state, holder(ac, true))
        assertNull(state.event(generation, holder(ac, null, 0L, status = -1))!!.climate?.acOn)
        assertNull(state.event(generation, holder(ac.copy(areaId = 74), false, 0L, status = -1)))
    }

    @Test fun `actual command observations reconcile the cache without setter values`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        seeded(state, holder(ac, false), holder(speed, 4f))
        assertEquals(true, state.observation(generation, holder(ac, true, 200L), state.reserve())!!.climate?.acOn)
        assertEquals(true, state.event(generation, holder(speed, 0f, 300L))!!.climate?.acOn)
        assertEquals(false, state.event(generation, holder(ac, false, 400L))!!.climate?.acOn)
        val oldReadOrder = state.reserve()
        state.event(generation, holder(ac, true, 0L))
        assertNull(state.observation(generation, holder(ac, false, 0L), oldReadOrder))
    }

    @Test fun `preferred poll recovery wins a fallback event during the same poll`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        val fallback = PropertyAddress(GeelyVhal.PROP_HVAC_AC_ON_ALT, 1)
        seeded(state, holder(ac, null, 100L, status = 1), holder(fallback, true))
        val poll = state.beginPoll()
        state.observe(poll, holder(ac, true, 200L), state.reserve())
        state.event(generation, holder(fallback, false, 300L))
        assertEquals(true, state.seed(baseline().copy(climate = Climate(acOn = true)), poll)!!.climate?.acOn)
        assertNull(state.event(generation, holder(fallback, false, 400L)))
    }

    @Test fun `opposite newer callback supersedes a command readback but duplicates do not`() {
        val state = CarPropertyEvents()
        val generation = state.open()
        seeded(state, holder(ac, true))
        val order = state.reserve()
        state.event(generation, holder(ac, false, 300L))
        assertTrue(state.superseded(holder(ac, true, 200L), order))
        assertTrue(state.superseded(holder(ac, true, 300L), order))
        assertFalse(state.superseded(holder(ac, false, 300L), order))
        assertFalse(state.superseded(holder(ac, true, 400L), order))
        val noTimestampOrder = state.reserve()
        state.event(generation, holder(ac, true, 0L))
        assertTrue(state.superseded(holder(ac, false, 0L), noTimestampOrder))
        assertFalse(state.superseded(holder(ac, true, 0L), noTimestampOrder))
    }

    @Test fun `fresh zero speed cannot authorize a stale missing future or unavailable P`() {
        val now = 10_000_000_000L
        val speedHolder = holder(speed, 0f, now)
        val gear = PropertyAddress(GeelyVhal.PROP_CURRENT_GEAR)
        for (gearHolder in listOf(holder(gear, 4, 0L), holder(gear, 4, now - 5_000_000_001L),
            holder(gear, 4, now + 1L), holder(gear, 4, now, status = 1))) {
            assertFalse(speedHolder.recent(now) && gearHolder.recent(now))
        }
        assertTrue(speedHolder.recent(now) && holder(gear, 4, now).recent(now))
    }

    @Test fun `continuous speed freshness rejects absent old future and unavailable timestamps`() {
        val now = 10_000_000_000L
        assertTrue(holder(speed, 0f, now).recent(now))
        assertTrue(holder(speed, 0f, now - 5_000_000_000L).recent(now))
        assertFalse(holder(speed, 0f, now - 5_000_000_001L).recent(now))
        assertFalse(holder(speed, 0f, now + 1L).recent(now))
        assertFalse(holder(speed, 0f, 0L).recent(now))
        assertFalse(holder(speed, 0f, now, status = 1).recent(now))
    }

    @Test fun `close and reconnect invalidate callbacks pending polls and cache`() {
        val state = CarPropertyEvents()
        val oldGeneration = state.open()
        seeded(state, holder(speed, 4f))
        val pending = state.beginPoll()
        state.reset()
        assertNull(state.event(oldGeneration, holder(speed, 100f, 900L)))
        assertNull(state.seed(baseline(), pending))
        val currentGeneration = state.open()
        assertNull(state.event(oldGeneration, holder(speed, 100f, 900L)))
        assertNull(state.event(currentGeneration, holder(speed, 0f, 1000L)))
        assertNotNull(state.seed(baseline(), state.beginPoll()))
        assertEquals(6, state.event(currentGeneration, holder(speed, 6f, 1100L))!!.speedKmh)
    }
}
