package com.ex2hub.source

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Карточка «Неделя и месяц»: колонки помещаются в ширину карточки, подписи читаются. */
class PeriodSummaryContractTest {
    /** Та же рабочая область раздела, что у списков журнала. */
    private val tableBudget = 1117

    private fun source(relativePath: String): String {
        val path = "src/main/java/com/ex2hub/$relativePath.kt"
        return listOf(File(path), File("app/$path")).first { it.isFile }.readText(Charsets.UTF_8)
    }

    private fun columns(screen: String): List<Pair<String, Int>> =
        Regex("""PeriodColumn\("([^"]*)", (\d+)\.dp\)""")
            .findAll(source("ui/screens/$screen"))
            .map { it.groupValues[1] to it.groupValues[2].toInt() }
            .toList()

    @Test
    fun `trips summary columns fit the card and price a hundred kilometres`() {
        val trips = source("ui/screens/TripsScreen")
        val captions = columns("TripsScreen")
        assertTrue("Cost per hundred kilometres must be in the summary",
            captions.any { it.first == "На 100 км, р." })
        assertFits(captions)
        assertTrue(trips.contains("Stats.monthStats(trips"))
        assertTrue(trips.contains("val month = rememberJournalCalculation"))
        assertTrue(trips.contains("key = \"trips:period\""))
        assertTrue(trips.contains("wide = wide"))
    }

    @Test
    fun `charging summary columns fit the card and keep the month`() {
        val charging = source("ui/screens/ChargingScreen")
        val captions = columns("ChargingScreen")
        assertTrue("Month energy must be in the summary",
            captions.any { it.first == "Получено, кВт·ч" })
        assertFits(captions)
        assertTrue(charging.contains("Stats.chargeSummary(sessions"))
        assertTrue(charging.contains("key = \"charges:period\""))
        assertTrue(charging.contains("wide = wide"))
    }

    @Test
    fun `period card reads at the section size and never scrolls sideways`() {
        val card = source("ui/components/PeriodSummary")
        assertFalse(card.contains("horizontalScroll"))
        val sizes = Regex("""fontSize = ([\d.]+)\.sp""")
            .findAll(card).map { it.groupValues[1].toDouble() }.toList()
        assertTrue("Every caption must stay readable: $sizes", sizes.all { it >= 18.0 })
        assertTrue("Values use the section size 21 sp", sizes.contains(21.0))
        assertTrue(card.contains("Arrangement.spacedBy(12.dp)"))
    }

    @Test
    fun `month aggregation is calendar based and prices the distance`() {
        val stats = source("data/Stats")
        assertTrue(stats.contains("fun monthStats("))
        assertTrue(stats.contains("YearMonth.from(dateOf(it.startedAt, zone)) == month"))
        assertEquals(2, Regex("""val costPer100Km: Double\?""").findAll(stats).count())
        assertTrue(stats.contains("private fun Double.per100(distanceKm: Double): Double?"))
    }

    private fun assertFits(captions: List<Pair<String, Int>>) {
        // Первая колонка — подпись периода на весе: она получает остаток ширины карточки.
        val gaps = 12 * (captions.size + 1)
        val free = tableBudget - captions.sumOf { it.second } - gaps
        assertTrue("Period caption needs room: $free", free >= 200)
    }
}
