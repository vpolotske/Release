package com.ex2hub.source

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Поездка открывается маршрутом в Яндекс.Картах: формат ссылки и правила для точек без GPS. */
class MapRouteContractTest {
    private val mapRoute = source("ui/MapRoute")
    private val trips = source("ui/screens/TripsScreen")
    private val hub = source("ui/HubScreen")

    @Test
    fun `route uses the confirmed rtext format with one separator`() {
        assertTrue(mapRoute.contains("rtext=\$rtext&rtt=auto"))
        assertTrue(mapRoute.contains("\"\$from~\$to\""))
        assertTrue("Both ends are taken as coordinates together", mapRoute.contains("lat != null && lon != null"))
        assertTrue("Decimal separator must not follow the device locale", mapRoute.contains("Locale.US"))
    }

    @Test
    fun `route tries the maps app first and the web link as fallback`() {
        val app = mapRoute.indexOf("yandexmaps://")
        val web = mapRoute.indexOf("https://yandex.ru/maps/")
        assertTrue("Both targets must exist", app >= 0 && web >= 0)
        assertTrue("The installed maps app gets the first attempt", app < web)
        assertFalse(
            "Visibility rules filter resolveActivity — launch the intent and catch instead",
            mapRoute.contains("resolveActivity")
        )
        assertTrue(mapRoute.contains("ActivityNotFoundException"))
        assertTrue(mapRoute.contains("FLAG_ACTIVITY_NEW_TASK"))
    }

    @Test
    fun `placeholder names and half-unknown points never build a route`() {
        assertTrue(mapRoute.contains("setOf(\"Старт\", \"Финиш\", \"GPS-трек\")"))
        assertTrue(mapRoute.contains("it !in placeholders"))
        assertEquals("Missing end means no route at all", 2, Regex("""\?: return null""").findAll(mapRoute).count())
        assertTrue(mapRoute.contains("fun available(trip: Trip): Boolean = query(trip) != null"))
    }

    @Test
    fun `journal row asks the route helper before it lights the button`() {
        val row = trips.blockAfter("private fun TripTableRow(")
        assertTrue(row.contains("enabled = MapRoute.available(trip)"))
        assertTrue(row.contains("onClick = { onOpenRoute(trip) }"))
        assertTrue(hub.contains("onOpenRoute = ::openTripRoute"))
        assertTrue(hub.contains("MapRoute.open(context, trip)"))
        assertTrue(hub.contains("Карты не открылись"))
    }

    private fun source(path: String): String {
        val file = "src/main/java/com/ex2hub/$path.kt"
        return listOf(File(file), File("app/$file")).first { it.isFile }.readText(Charsets.UTF_8)
    }

    private fun String.blockAfter(marker: String): String {
        val markerIndex = indexOf(marker)
        check(markerIndex >= 0) { "Missing marker: $marker" }
        val start = indexOf('{', markerIndex + marker.length)
        check(start >= 0) { "Missing block: $marker" }
        var depth = 1
        var index = start + 1
        while (index < length) {
            when (this[index]) {
                '{' -> depth++
                '}' -> if (--depth == 0) return substring(start + 1, index)
            }
            index++
        }
        error("Unclosed block: $marker")
    }
}
