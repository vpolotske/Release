package com.ex2hub.source

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Манифест — часть факта о прошивке, поэтому он тоже закреплён тестом.
 *
 * CentralEXAuto, который на этом гу реально пишет климат, объявляет
 * `android.car.permission.CAR_HVAC` (разобран `manifest.txt` референсной сборки),
 * а doc-разбор штатного HVAC Flyme для тех же записей называет
 * `CONTROL_CAR_CLIMATE`. Приложение не выбирает между ними наугад: объявлены оба,
 * и право записи в журнале пробы ищется по обоим именам.
 */
class ManifestPermissionsTest {

    private val manifest: String by lazy {
        val candidates = listOf(
            File("src/main/AndroidManifest.xml"),
            File("app/src/main/AndroidManifest.xml")
        )
        val file = candidates.firstOrNull { it.isFile }
            ?: error("AndroidManifest.xml не найден: ${System.getProperty("user.dir")}")
        file.readText()
    }

    @Test
    fun `both climate write permissions are declared`() {
        assertTrue(manifest.contains("android.car.permission.CAR_HVAC"))
        assertTrue(manifest.contains("android.car.permission.CONTROL_CAR_CLIMATE"))
    }

    @Test
    fun `every permission the probe checks is declared`() {
        val checkedByProbe = listOf(
            "android.car.permission.CAR_ENERGY",
            "android.car.permission.CAR_ENERGY_PORTS",
            "android.car.permission.CAR_INFO",
            "android.car.permission.CAR_MILEAGE",
            "android.car.permission.CAR_MILEAGE_3P",
            "android.car.permission.CAR_SPEED",
            "android.car.permission.CAR_POWERTRAIN",
            "android.car.permission.CAR_EXTERIOR_ENVIRONMENT",
            "android.car.permission.CAR_VENDOR_EXTENSION",
            "android.car.permission.CAR_PROPERTY_ACCESS",
            "android.car.permission.CAR_HVAC",
            "android.car.permission.CONTROL_CAR_CLIMATE"
        )
        val missing = checkedByProbe.filterNot { manifest.contains(it) }
        assertTrue("в манифесте нет $missing", missing.isEmpty())
    }

    @Test
    fun `the activity can be picked as the home screen`() {
        val home = Regex(
            "<intent-filter>(?:(?!</intent-filter>).)*category\\.HOME(?:(?!</intent-filter>).)*</intent-filter>",
            RegexOption.DOT_MATCHES_ALL
        ).find(manifest)?.value
        assertTrue("нет фильтра HOME", home != null)
        assertTrue(home!!.contains("android.intent.action.MAIN"))
        assertTrue(home.contains("android.intent.category.DEFAULT"))
        assertTrue(manifest.contains("android.intent.category.LAUNCHER"))
        assertTrue(manifest.contains("android:launchMode=\"singleTask\""))
    }

    @Test
    fun `background work runs in a declared foreground service`() {
        val service = Regex("<service(?:(?!</service>).)*</service>", RegexOption.DOT_MATCHES_ALL)
            .find(manifest)?.value
        assertTrue("нет сервиса", service != null)
        assertTrue(service!!.contains(".service.HubService"))
        assertTrue(service.contains("android:exported=\"false\""))
        assertTrue(service.contains("android:foregroundServiceType=\"specialUse|location\""))
        assertTrue(service.contains("PROPERTY_SPECIAL_USE_FGS_SUBTYPE"))
        assertTrue(manifest.contains(".service.BootReceiver"))
        assertTrue(manifest.contains("android.intent.action.BOOT_COMPLETED"))
    }

    @Test
    fun `home controls declare only normal audio and user approved settings rights`() {
        val declared = Regex("uses-permission[^>]*android:name=\"([^\"]+)\"")
            .findAll(manifest)
            .map { it.groupValues[1] }
            .toSet()
        assertTrue("android.permission.MODIFY_AUDIO_SETTINGS" in declared)
        assertTrue("android.permission.WRITE_SETTINGS" in declared)
        assertTrue("android.permission.WRITE_SECURE_SETTINGS" !in declared)
        assertTrue("android.permission.MODIFY_AUDIO_ROUTING" !in declared)
    }

    @Test
    fun `the app asks only for car home location and explicit APK update rights`() {
        assertTrue(manifest.contains("uses-library") && manifest.contains("android.car"))
        val declared = Regex("uses-permission[^>]*android:name=\"([^\"]+)\"")
            .findAll(manifest)
            .map { it.groupValues[1] }
            .toSet()
        assertTrue(declared.isNotEmpty())
        assertTrue("android.permission.INTERNET" in declared)
        assertTrue("android.permission.REQUEST_INSTALL_PACKAGES" in declared)
        val allowed = setOf(
            "android.permission.INTERNET",
            "android.permission.REQUEST_INSTALL_PACKAGES",
            "android.permission.ACCESS_FINE_LOCATION",
            "android.permission.ACCESS_COARSE_LOCATION",
            "android.permission.MODIFY_AUDIO_SETTINGS",
            "android.permission.WRITE_SETTINGS",
            "android.permission.FOREGROUND_SERVICE",
            "android.permission.FOREGROUND_SERVICE_SPECIAL_USE",
            "android.permission.FOREGROUND_SERVICE_LOCATION",
            "android.permission.RECEIVE_BOOT_COMPLETED",
            "android.permission.POST_NOTIFICATIONS"
        )
        val carRights = declared.filter {
            it.startsWith("android.car.permission.") || it.startsWith("com.flyme.auto.")
        }.toSet()
        val extra = declared - allowed - carRights
        assertTrue("неожиданные разрешения: $extra", extra.isEmpty())
        assertTrue(carRights.isNotEmpty())
    }

    @Test
    fun `update provider is private and exposes only its cache directory`() {
        val provider = Regex("<provider(?:(?!</provider>).)*</provider>", RegexOption.DOT_MATCHES_ALL)
            .find(manifest)?.value ?: error("нет FileProvider")
        assertTrue(provider.contains("androidx.core.content.FileProvider"))
        assertTrue(provider.contains("android:exported=\"false\""))
        assertTrue(provider.contains("android:grantUriPermissions=\"true\""))
        assertTrue(provider.contains("\${applicationId}.updates"))
        assertTrue(provider.contains("@xml/update_paths"))
        assertTrue(manifest.contains("android:usesCleartextTraffic=\"false\""))
        val pathFile = listOf(File("src/main/res/xml/update_paths.xml"), File("app/src/main/res/xml/update_paths.xml"))
            .first { it.isFile }
        val paths = pathFile.readText()
        assertTrue(paths.contains("<cache-path"))
        assertTrue(paths.contains("path=\"updates/\""))
        assertTrue(!paths.contains("<root-path") && !paths.contains("<external-path"))
        assertTrue(Regex("<[^!?/][^>]*-path\\b").findAll(paths).count() == 1)
    }

    @Test
    fun `APK content signature is verified before reading signer metadata`() {
        val path = "src/main/java/com/ex2hub/update/ApkVerifier.kt"
        val source = listOf(File(path), File("app/$path")).first { it.isFile }.readText()
        assertTrue(source.contains("com.android.apksig.ApkVerifier.Builder(apk)"))
        assertTrue(source.contains("require(verified.isVerified)"))
        assertTrue(source.contains("verified.signerCertificates"))
        assertTrue(source.indexOf(".verify()") < source.indexOf("getPackageArchiveInfo("))
    }
}
