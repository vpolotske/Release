package com.ex2hub.source

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Списки журналов: таблица целиком помещается в карточку, без горизонтальной прокрутки. */
class JournalTableLayoutContractTest {
    /** Ширина таблицы в единицах макета: рабочая область раздела минус поля страницы и карточки. */
    private val tableBudget = 1117

    private fun source(screen: String): String {
        val path = "src/main/java/com/ex2hub/ui/screens/$screen.kt"
        return listOf(File(path), File("app/$path"))
            .first { it.isFile }
            .readText(Charsets.UTF_8)
    }

    private fun String.blockAfter(marker: String): String {
        val markerIndex = indexOf(marker)
        check(markerIndex >= 0) { "Missing marker: $marker" }
        val start = indexOf('{', markerIndex + marker.length)
        check(start >= 0) { "Missing block: $marker" }
        var depth = 1
        var index = start + 1
        while (index < length) {
            when (this[index]) {
                '{' -> depth++
                '}' -> if (--depth == 0) return substring(start + 1, index)
            }
            index++
        }
        error("Unclosed block: $marker")
    }

    private fun assertTable(
        screen: String,
        header: String,
        row: String,
        delete: String,
        label: String,
        fixedWidths: List<Int>
    ) {
        val source = source(screen)
        // Строка умещается в карточку: горизонтальная прокрутка запрещена.
        assertFalse("No horizontal scrolling in the journal", source.contains("horizontalScroll"))
        assertFalse(source.contains("tableScroll"))
        assertFalse(source.contains("tableWidth"))
        assertFalse(source.contains("IntrinsicSize"))

        // Список ленивый: строки считаются по мере появления, а не собираются все сразу.
        assertTrue(source.contains("LazyColumn("))
        assertTrue(source.contains("itemsIndexed(day"))
        assertTrue(source.contains("import androidx.compose.foundation.lazy.LazyColumn"))
        assertTrue(source.contains("import androidx.compose.foundation.lazy.itemsIndexed"))
        assertFalse("LazyColumn owns the vertical scroll",
            source.contains(".verticalScroll(rememberScrollState())"))

        val headerBody = source.blockAfter("private fun $header(")
        val rowBody = source.blockAfter("private fun $row(")
        listOf(headerBody, rowBody).forEach {
            assertTrue(it.contains("Modifier.fillMaxWidth().padding(vertical ="))
            assertTrue("Columns share one gap", it.contains("Arrangement.spacedBy(12.dp)"))
        }
        assertTrue(headerBody.contains("TableLabel(\"$label\", Modifier.weight(1f)"))
        assertTrue(rowBody.contains("Column(Modifier.weight(1f).padding(end = 8.dp))"))
        assertTrue(rowBody.contains(delete))
        // Колонка источника данных из списков убрана.
        assertFalse("Source column must be gone", headerBody.contains("Источник"))

        val widths = Regex("""\.width\((\d+)\.dp\)""")
        val headerWidths = widths.findAll(headerBody).map { it.groupValues[1].toInt() }.toList()
        val weightedContent = rowBody.blockAfter("Column(Modifier.weight(1f).padding(end = 8.dp))")
        val rowWidths = widths.findAll(rowBody.replace(weightedContent, ""))
            .map { it.groupValues[1].toInt() }.toList()
        assertEquals("Header and rows must keep aligned fixed columns", headerWidths, rowWidths)
        assertEquals("Fixed columns are the widest caption of each column", fixedWidths, headerWidths)

        // На весовой ячейке остаётся запас: именованные колонки не выталкивают данные за карточку.
        val gaps = 12 * (headerWidths.size + 1)
        assertTrue("Weighted cell needs room: ${tableBudget - headerWidths.sum() - gaps}",
            tableBudget - headerWidths.sum() - gaps >= 280)

        // Шрифт раздела: 21 для значений, 18 для подписей колонок.
        val rowText = Regex("""fontSize = ([\d.]+)\.sp""").findAll(rowBody).map {
            it.groupValues[1].toDouble()
        }.toList()
        assertTrue("Row text must be at least 18 sp: $rowText", rowText.all { it >= 18.0 })
        assertTrue("Main row cells use the section size 21 sp", rowText.contains(21.0))
        val labelSize = Regex("""fontSize = ([\d.]+)\.sp""")
            .find(source.blockAfter("private fun TableLabel("))!!.groupValues[1].toDouble()
        assertTrue("Column captions must not stay tiny: $labelSize", labelSize >= 18.0)
        val cellSize = Regex("""fontSize = ([\d.]+)\.sp""")
            .find(source.blockAfter("private fun TableCell("))!!.groupValues[1].toDouble()
        assertTrue("Value cells must match the section size: $cellSize", cellSize >= 21.0)
    }

    @Test
    fun `trips fit the card width and drop the source column`() {
        assertTable(
            screen = "TripsScreen", header = "TripsTableHeader", row = "TripTableRow",
            delete = "onClick = { onDeleteTrip(trip.id) }", label = "Маршрут",
            fixedWidths = listOf(88, 103, 122, 66, 110, 100, 40, 40)
        )
        val trips = source("TripsScreen").blockAfter("private fun TripTableRow(")
        assertFalse("Source badge must be gone from the row", trips.contains("trip.source.title()"))
        assertFalse(trips.contains("StateDot(trip.source"))
        assertTrue("Every row keeps its route button", trips.contains("onClick = { onOpenRoute(trip) }"))
    }

    @Test
    fun `charging fits the card width and keeps the charge type`() {
        assertTable(
            screen = "ChargingScreen", header = "SessionsTableHeader", row = "SessionTableRow",
            delete = "onClick = onDelete", label = "Место",
            fixedWidths = listOf(88, 146, 106, 110, 122, 126, 40)
        )
        val row = source("ChargingScreen").blockAfter("private fun SessionTableRow(")
        assertTrue("Charge type must stay readable", row.contains("session.type.title()"))
    }
}
