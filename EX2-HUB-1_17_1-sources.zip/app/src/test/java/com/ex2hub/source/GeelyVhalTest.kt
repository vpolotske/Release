package com.ex2hub.source

import com.ex2hub.data.Body
import com.ex2hub.data.BodyPart
import com.ex2hub.data.ChargeFlow
import com.ex2hub.data.ChargeType
import com.ex2hub.data.Climate
import com.ex2hub.data.ClimateChange
import com.ex2hub.data.ClimatePreset
import com.ex2hub.data.DriveMode
import com.ex2hub.data.Gear
import com.ex2hub.data.IgnitionState
import com.ex2hub.data.RegenLevel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class GeelyVhalTest {

    /** Десятиличные константы должны совпадать с hex-адресами из справочников. */
    @Test
    fun `property ids match their documented hex`() {
        assertEquals(0x2140A6ED, GeelyVhal.PROP_SOC_PERCENT)
        assertEquals(0x11600309, GeelyVhal.PROP_BATTERY_LEVEL)
        assertEquals(0x11400308, GeelyVhal.PROP_RANGE_REMAINING_KM)
        assertEquals(0x11400204, GeelyVhal.PROP_ODOMETER)
        assertEquals(0x11600204, GeelyVhal.PROP_PERF_ODOMETER)
        assertEquals(0x2140A6AC, GeelyVhal.PROP_RANGE_MIRROR)
        assertEquals(0x11600207, GeelyVhal.PROP_PERF_VEHICLE_SPEED)
        assertEquals(0x2140737E, GeelyVhal.PROP_CHARGING_STATE)
        assertEquals(0x21407289, GeelyVhal.PROP_CHARGING_PLUG)
        assertEquals(0x24205C00, GeelyVhal.CHARGING_STATE_LOGICAL)
        assertEquals(0x24130200, GeelyVhal.CHARGING_PLUG_LOGICAL)
        assertEquals(0x2140A201, GeelyVhal.PROP_REGEN_LEVEL_VENDOR)
        assertEquals(0x2140A377, GeelyVhal.PROP_AC_AMBIENT_TEMP)
        assertEquals(0x22010100, GeelyVhal.PROP_DRIVE_MODE)
        assertEquals(0x20020500, GeelyVhal.PROP_REGEN_LEVEL)
        assertEquals(0x11400401, GeelyVhal.PROP_CURRENT_GEAR)
        assertEquals(0x11400400, GeelyVhal.PROP_GEAR_SELECTION)
        assertEquals(0x2140A331, GeelyVhal.PROP_PEPS_POWER_MODE)
        assertEquals(0x2140A822, GeelyVhal.PROP_PEPS_USAGE_MODE)
        assertEquals(0x200100, GeelyVhal.IGNITION_SENSOR_LOGICAL)
        assertEquals(0x201300, GeelyVhal.USAGE_SENSOR_LOGICAL)
    }

    @Test
    fun `soc prefers vendor percent and reads tenths above one hundred`() {
        assertEquals(68, GeelyVhal.socPercent(68.0, 26_400.0, 39_600.0))
        assertEquals(68, GeelyVhal.socPercent(684.0, null, null))
        assertEquals(100, GeelyVhal.socPercent(100.0, null, null))
    }

    @Test
    fun `soc falls back to battery level and decides percent by magnitude`() {
        assertEquals(45, GeelyVhal.socPercent(null, 45.0, 39_600.0))
        assertEquals(50, GeelyVhal.socPercent(null, 19_800.0, 39_600.0))
        assertNull(GeelyVhal.socPercent(null, 19_800.0, null))
        assertNull(GeelyVhal.socPercent(null, null, 39_600.0))
        // Вендорское число вне диапазона процентов не отдаётся запасному пути вслепую.
        assertNull(GeelyVhal.socPercent(4_000.0, null, null))
    }

    @Test
    fun `flyme ambient temperature decodes as raw minus eighty over two`() {
        assertEquals(0.0, GeelyVhal.flymeTempC(80.0), 0.001)
        assertEquals(9.0, GeelyVhal.flymeTempC(98.0), 0.001)
        assertEquals(-9.0, GeelyVhal.flymeTempC(62.0), 0.001)
    }

    @Test
    fun `flyme raw zero is no answer, not minus forty degrees`() {
        assertNull(GeelyVhal.flymeTemp(0.0))
        assertNull(GeelyVhal.flymeTemp(null))
        assertEquals(9.0, GeelyVhal.flymeTemp(98.0)!!, 0.001)
        assertNull(GeelyVhal.tempC(GeelyVhal.flymeTemp(0.0)))
    }

    @Test
    fun `temperature is accepted only inside the physical range`() {
        assertEquals(9, GeelyVhal.tempC(9.4))
        assertEquals(-50, GeelyVhal.tempC(-50.0))
        assertEquals(85, GeelyVhal.tempC(85.0))
        assertNull(GeelyVhal.tempC(-60.0))
        assertNull(GeelyVhal.tempC(120.0))
        assertNull(GeelyVhal.tempC(Double.NaN))
        assertNull(GeelyVhal.tempC(null))
    }

    @Test
    fun `speed is already km per hour and gets the cluster correction`() {
        assertEquals(0, GeelyVhal.speedKmh(0.0))
        assertEquals(5, GeelyVhal.speedKmh(5.4))
        assertEquals(11, GeelyVhal.speedKmh(10.0))
        assertEquals(140, GeelyVhal.speedKmh(139.6))
        assertEquals(140, GeelyVhal.speedKmh(300.0))
        assertEquals(30, GeelyVhal.speedKmh(-29.0))
        assertNull(GeelyVhal.speedKmh(null))
    }

    @Test
    fun `drive mode decodes full function codes and short counters`() {
        assertEquals(DriveMode.ECO, GeelyVhal.driveMode(0x22010101))
        assertEquals(DriveMode.COMFORT, GeelyVhal.driveMode(0x22010102))
        assertEquals(DriveMode.SPORT, GeelyVhal.driveMode(0x22010103))
        assertEquals(DriveMode.XC, GeelyVhal.driveMode(0x22010104))
        assertEquals(DriveMode.PURE, GeelyVhal.driveMode(0x22010106))
        assertEquals(DriveMode.HYBRID, GeelyVhal.driveMode(0x22010107))
        // «Снег» на этой машине не существует: код 0x22010109 остаётся нерасшифрованным.
        assertNull(GeelyVhal.driveMode(0x22010109))
        assertEquals(DriveMode.ADAPTIVE, GeelyVhal.driveMode(0x22010116))
        assertEquals(DriveMode.COMFORT, GeelyVhal.driveMode(1))
        assertEquals(DriveMode.ECO, GeelyVhal.driveMode(2))
        assertEquals(DriveMode.SPORT, GeelyVhal.driveMode(3))
        assertNull(GeelyVhal.driveMode(0))
        assertNull(GeelyVhal.driveMode(0x22010100))
        assertNull(GeelyVhal.driveMode(null))
    }

    @Test
    fun `regen level decodes function codes and short counters`() {
        assertEquals(RegenLevel.LOW, GeelyVhal.regenLevel(0x20020501))
        assertEquals(RegenLevel.MID, GeelyVhal.regenLevel(0x20020502))
        assertEquals(RegenLevel.HIGH, GeelyVhal.regenLevel(0x20020503))
        assertEquals(RegenLevel.AUTO, GeelyVhal.regenLevel(0x20020504))
        assertEquals(RegenLevel.LOW, GeelyVhal.regenLevel(1))
        assertEquals(RegenLevel.HIGH, GeelyVhal.regenLevel(3))
        assertNull(GeelyVhal.regenLevel(0x20020500))
        assertNull(GeelyVhal.regenLevel(9))
    }

    @Test
    fun `charge flow prefers the coded state and falls back to the plug`() {
        assertEquals(ChargeFlow.AC, GeelyVhal.chargeFlow(GeelyVhal.STATE_AC_CHARGING, null))
        assertEquals(ChargeFlow.DC, GeelyVhal.chargeFlow(GeelyVhal.STATE_DC_CHARGING, null))
        assertEquals(ChargeFlow.HEATING, GeelyVhal.chargeFlow(GeelyVhal.STATE_HEATING, null))
        assertEquals(ChargeFlow.FINISHED, GeelyVhal.chargeFlow(GeelyVhal.STATE_CHARGING_COMPLETE, null))
        assertEquals(ChargeFlow.SUSPENDED, GeelyVhal.chargeFlow(GeelyVhal.STATE_AC_SUSPEND, null))
        assertEquals(ChargeFlow.IDLE, GeelyVhal.chargeFlow(GeelyVhal.STATE_NO_CHARGING, null))
        assertEquals(ChargeFlow.PLUGGED, GeelyVhal.chargeFlow(null, GeelyVhal.PLUG_AC_CONNECTED))
        assertEquals(ChargeFlow.DISCHARGING, GeelyVhal.chargeFlow(null, GeelyVhal.PLUG_DISCHARGE_CONNECTED))
        assertEquals(ChargeFlow.IDLE, GeelyVhal.chargeFlow(null, GeelyVhal.PLUG_NONE))
        assertNull(GeelyVhal.chargeFlow(null, null))
        // Короткие enum-ы сырого свойства без обёртки не расшифровываются.
        assertNull(GeelyVhal.chargeFlow(1, null))
        // Живое ГУ (проба 2026-10-25) отвечает состоянием 2 вне таблицы, а разъём —
        // полным кодом: решение остаётся за разъёмом, а не уходит в null.
        assertEquals(ChargeFlow.IDLE, GeelyVhal.chargeFlow(2, GeelyVhal.PLUG_NONE))
        assertEquals(ChargeFlow.PLUGGED, GeelyVhal.chargeFlow(2, GeelyVhal.PLUG_AC_CONNECTED))
        // Известное состояние сильнее разъёма.
        assertEquals(
            ChargeFlow.FINISHED,
            GeelyVhal.chargeFlow(GeelyVhal.STATE_CHARGING_COMPLETE, GeelyVhal.PLUG_AC_CONNECTED)
        )
    }

    @Test
    fun `charge power follows the plug and rejects the idle side of a known state`() {
        // Ни состояния, ни разъёма: DC-счётчик держит залипшие киловатты после AC-сессии
        // (наблюдение 2026-10-28 — 12,5 кВт при зарядке от сети), поэтому без потока
        // мощность не называем.
        assertNull(GeelyVhal.chargePowerKw(null, 7.4, 50.0))
        assertEquals(50.0, GeelyVhal.chargePowerKw(null, 7.4, 50.0, GeelyVhal.PLUG_DC_CONNECTED)!!, 0.001)
        assertEquals(7.4, GeelyVhal.chargePowerKw(null, 7.4, 50.0, GeelyVhal.PLUG_AC_CONNECTED)!!, 0.001)
        // Измеренная AC-сессия: 1,0 кВт на стороне AC, на DC — чужие 12,5 кВт.
        assertEquals(1.0, GeelyVhal.chargePowerKw(GeelyVhal.STATE_AC_CHARGING, 1.0, 12.5)!!, 0.001)
        assertEquals(50.0, GeelyVhal.chargePowerKw(GeelyVhal.STATE_DC_CHARGING, 11.0, 50.0)!!, 0.001)
        assertNull(GeelyVhal.chargePowerKw(GeelyVhal.STATE_NO_CHARGING, 0.1, 0.0))
        assertNull(GeelyVhal.chargePowerKw(null, null, null))
    }

    @Test
    fun `dc plug is read through the connector type only`() {
        assertEquals(ChargeType.DC, GeelyVhal.connectorType(GeelyVhal.PLUG_DC_CONNECTED))
        assertEquals(ChargeType.AC, GeelyVhal.connectorType(GeelyVhal.PLUG_AC_CONNECTED))
        assertNull("Короткое число без обёртки — не разъём", GeelyVhal.connectorType(2))
        assertNull(GeelyVhal.connectorType(null))
    }

    @Test
    fun `charge type follows the flow and stays unknown when the car is silent`() {
        assertEquals(ChargeType.DC, GeelyVhal.chargeType(GeelyVhal.STATE_DC_CHARGING, null))
        assertEquals(ChargeType.AC, GeelyVhal.chargeType(GeelyVhal.STATE_AC_CHARGING, null))
        // Обогрев идёт от сети: сессия с подогревом остаётся AC, а не «не определено».
        assertEquals(ChargeType.AC, GeelyVhal.chargeType(GeelyVhal.STATE_HEATING, null))
        // Молчание автомобиля — UNKNOWN, а не null: тип всегда назван, просто честно.
        assertEquals(ChargeType.UNKNOWN, GeelyVhal.chargeType(GeelyVhal.STATE_NO_CHARGING, GeelyVhal.PLUG_NONE))
        assertEquals(ChargeType.UNKNOWN, GeelyVhal.chargeType(null, null))
        // Кабель без состояния: разъём решает, поэтому домашняя сессия не теряет тип.
        assertEquals(ChargeType.AC, GeelyVhal.chargeType(null, GeelyVhal.PLUG_AC_CONNECTED))
        assertEquals(ChargeType.DC, GeelyVhal.chargeType(null, GeelyVhal.PLUG_DC_CONNECTED))
        // Поток и разъём спорят — ни один канал не выигрывает.
        assertEquals(ChargeType.UNKNOWN, GeelyVhal.chargeType(GeelyVhal.STATE_AC_CHARGING, GeelyVhal.PLUG_DC_CONNECTED))
    }

    @Test
    fun `hvac ids match their documented hex`() {
        assertEquals(0x15200510, GeelyVhal.PROP_HVAC_POWER_ON)
        assertEquals(0x15200505, GeelyVhal.PROP_HVAC_AC_ON)
        assertEquals(0x21401020, GeelyVhal.PROP_HVAC_FAN_DIRECTION_VENDOR)
        assertEquals(0x15200508, GeelyVhal.PROP_HVAC_RECIRC_ON)
        assertEquals(0x15200511, GeelyVhal.PROP_HVAC_MAX_DEFROST)
        assertEquals(0x15200514, GeelyVhal.PROP_HVAC_REAR_DEFROST)
        assertEquals(0x15400500, GeelyVhal.PROP_HVAC_FAN_SPEED)
        assertEquals(0x15600503, GeelyVhal.PROP_HVAC_TEMPERATURE_SET)
        assertEquals(0x1540050B, GeelyVhal.PROP_HVAC_SEAT_HEAT)
        assertEquals(0x1140050D, GeelyVhal.PROP_HVAC_WHEEL_HEAT)
        assertEquals(0x15600502, GeelyVhal.PROP_HVAC_TEMPERATURE_CURRENT)
        assertEquals(0x15400501, GeelyVhal.PROP_HVAC_FAN_DIRECTION)

        // Адреса климата и зеркал из справочников; SET_INT не используется для записи.
        assertEquals(0x25401036, GeelyVhal.PROP_HVAC_TEMPERATURE_ADJUST)
        assertEquals(0x15200503, GeelyVhal.PROP_HVAC_TEMPERATURE_SET_INT)
        assertEquals(0x2140A6DC, GeelyVhal.PROP_HVAC_TEMPERATURE_SET_VENDOR)
        assertEquals(0x15600099, GeelyVhal.PROP_HVAC_AC_ON_ALT)
        assertEquals(0x2140A625, GeelyVhal.PROP_HVAC_POWER_VENDOR)
        assertEquals(0x2140A417, GeelyVhal.PROP_HVAC_FAN_VENDOR)
        assertEquals(0x21401026, GeelyVhal.PROP_HVAC_RECIRC_VENDOR)
        assertEquals(0x2740A679, GeelyVhal.PROP_TRIP_KM)
        assertEquals(0x2140B085, GeelyVhal.PROP_PORT_CONNECTED)
        assertEquals(0x11400703, GeelyVhal.PROP_ENV_OUTSIDE_TEMPERATURE)
        assertEquals(0x2140A6F8, GeelyVhal.PROP_AVG_ENERGY_CONSUMPTION)
        assertEquals(0x15200507, GeelyVhal.PROP_HVAC_MAX_DEFROST_DA)
        assertEquals(557885148, GeelyVhal.PROP_HVAC_TEMPERATURE_SET_VENDOR)
        assertEquals(624955446, GeelyVhal.PROP_HVAC_TEMPERATURE_ADJUST)
    }

    @Test
    fun `hvac zones match the documented table`() {
        assertEquals(0, GeelyVhal.AREA_GLOBAL)
        assertEquals(1, GeelyVhal.AREA_SEAT_LEFT)
        assertEquals(4, GeelyVhal.AREA_SEAT_RIGHT)
        assertEquals(5, GeelyVhal.AREA_ROW_1_ALL)
        assertEquals(117, GeelyVhal.AREA_HVAC_ALL)
        assertEquals(49, GeelyVhal.AREA_ROW_1_2)
        assertEquals(listOf(1, 49, 5, 0), GeelyVhal.HVAC_AREAS.toList())
    }

    @Test
    fun `requested temperatures write only direct Celsius floats inside the adjusted range`() {
        val requests = listOf(
            15.5 to 16.0, 16.0 to 16.0, 17.0 to 17.0, 22.5 to 22.5,
            24.5 to 24.5, 30.0 to 30.0, 32.0 to 32.0, 33.0 to 32.0, 21.4 to 21.5
        )
        for (change in listOf(ClimateChange.DRIVER_UP, ClimateChange.DRIVER_DOWN)) {
            for ((requested, expected) in requests) {
                val writes = GeelyVhal.climateWrites(change, Climate(driverTempC = requested))
                // Первым — 0x15600503 float в зону, которая ответила Float; затем
                // канонический ответ 0x24120300, зеркало и 0x25401036 как резервы.
                assertEquals(
                    listOf(
                        GeelyVhal.PROP_HVAC_TEMPERATURE_SET,
                        GeelyVhal.PROP_HVAC_TEMPERATURE_SET_CANONICAL,
                        GeelyVhal.PROP_HVAC_TEMPERATURE_SET_VENDOR,
                        GeelyVhal.PROP_HVAC_TEMPERATURE_ADJUST
                    ),
                    writes.map { it.propertyId }
                )
                assertEquals(
                    listOf(
                        "HVAC_TEMPERATURE_SET °C",
                        "HVAC_TEMPERATURE_SET канон. °C",
                        "V_HVAC_TEMP_SET °C (зеркало)",
                        "HVAC_TEMPERATURE_ADJUST °C (резерв)"
                    ),
                    writes.map { it.label }
                )
                assertEquals(
                    listOf(GeelyVhal.AREA_SEAT_LEFT, GeelyVhal.AREA_GLOBAL,
                        GeelyVhal.AREA_SEAT_LEFT, GeelyVhal.AREA_SEAT_LEFT),
                    writes.map { it.areaId }
                )
                for (write in writes) {
                    assertEquals(expected, write.floatC!!, 0.001)
                    assertNull(write.int)
                    assertNull(write.bool)
                }
            }
            for (invalid in listOf(null, 0.0, 9.0, 15.2, 33.3, 40.0, Double.NaN, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY)) {
                assertTrue(GeelyVhal.climateWrites(change, Climate(driverTempC = invalid)).isEmpty())
            }
        }
    }

    @Test
    fun `setpoint reads float Celsius only and scans the Central EX Auto areas`() {
        // Перебор Central EX Auto: {1, 4, 0, 7}; на этом ГУ зона 1 отдаёт целое.
        assertEquals(listOf(1, 4, 0, 7), GeelyVhal.SETPOINT_AREAS.toList())
        assertEquals(0x24120300, GeelyVhal.PROP_HVAC_TEMPERATURE_SET_CANONICAL)
        assertEquals(605_160_192, GeelyVhal.PROP_HVAC_TEMPERATURE_SET_CANONICAL)

        // Журнал 2026-10-28: 0x15600503 в зоне 1 — Int 4, зеркало — Float 20,000.
        assertNull(GeelyVhal.setpointFloatCelsius(4))
        assertNull(GeelyVhal.setpointFloatCelsius(4.0f))
        assertEquals(20.0, GeelyVhal.setpointFloatCelsius(20.0f)!!, 0.001)
        assertEquals(21.5, GeelyVhal.setpointFloatCelsius(21.5)!!, 0.001)
        assertNull(GeelyVhal.setpointFloatCelsius(null))

        // Целая шкала осталась только показом: шаг 4 при 20 °C — это °C − 16.
        assertEquals(20.0, GeelyVhal.setpointFromRaw(4.0)!!, 0.001)
        assertEquals(17.0, GeelyVhal.setpointFromRaw(1.0)!!, 0.001)
        assertNull(GeelyVhal.setpointFromRaw(-1.0))
        assertNull(GeelyVhal.setpointFromRaw(null))

        // Найденная зона уходит в первую запись; остальные каналы фиксированы.
        val writes = GeelyVhal.climateWrites(ClimateChange.DRIVER_UP, Climate(driverTempC = 21.0),
            GeelyVhal.AREA_SEAT_RIGHT)
        assertEquals(
            listOf(GeelyVhal.AREA_SEAT_RIGHT, GeelyVhal.AREA_GLOBAL,
                GeelyVhal.AREA_SEAT_LEFT, GeelyVhal.AREA_SEAT_LEFT),
            writes.map { it.areaId }
        )
        assertTrue(writes.all { it.floatC == 21.0 && it.int == null && it.bool == null })

        val heat = GeelyVhal.presetSteps(
            ClimatePreset.QUICK_HEAT,
            Climate(hvacOn = true, acOn = false, driverTempC = 20.0, fanSpeed = 2),
            setpointArea = GeelyVhal.AREA_GLOBAL
        ).first { it.title == "уставка" }
        assertEquals(GeelyVhal.PROP_HVAC_TEMPERATURE_SET, heat.writes.first().propertyId)
        assertEquals(GeelyVhal.AREA_GLOBAL, heat.writes.first().areaId)
        assertEquals(32.0, heat.writes.first().floatC!!, 0.001)
    }

    @Test
    fun `only the vendor range goes into the adjust property`() {
        assertEquals(22.5, GeelyVhal.adjustTempC(22.5)!!, 0.001)
        assertEquals(16.0, GeelyVhal.adjustTempC(15.5)!!, 0.001)
        assertEquals(32.0, GeelyVhal.adjustTempC(33.0)!!, 0.001)
        assertNull(GeelyVhal.adjustTempC(9.0))
        assertNull(GeelyVhal.adjustTempC(Double.NaN))
        assertNull(GeelyVhal.adjustTempC(Double.POSITIVE_INFINITY))
        assertNull(GeelyVhal.adjustTempC(null))
    }

    @Test
    fun `float setpoint values are already Celsius`() {
        assertEquals(32.0, GeelyVhal.climateTempC(32.0)!!, 0.001)
        assertEquals(30.0, GeelyVhal.climateTempC(30.0)!!, 0.001)
        assertEquals(22.5, GeelyVhal.climateTempC(22.5)!!, 0.001)
        assertEquals(17.0, GeelyVhal.climateTempC(17.0)!!, 0.001)
        assertEquals(15.5, GeelyVhal.climateTempC(15.5)!!, 0.001)
        assertNull(GeelyVhal.climateTempC(0.0))
        assertNull(GeelyVhal.climateTempC(11.0))
        assertNull(GeelyVhal.climateTempC(300.0))
        assertNull(GeelyVhal.climateTempC(Double.NaN))
        assertNull(GeelyVhal.climateTempC(Double.POSITIVE_INFINITY))
        assertNull(GeelyVhal.climateTempC(null))
    }

    @Test
    fun `consumption and the plug code keep to their ranges`() {
        assertEquals(14.3, GeelyVhal.avgConsumption(1430.0)!!, 0.001)
        assertEquals(0.0, GeelyVhal.avgConsumption(0.0)!!, 0.001)
        assertNull(GeelyVhal.avgConsumption(9_000.0))
        assertEquals(true, GeelyVhal.portConnected(3))
        assertEquals(false, GeelyVhal.portConnected(0))
        assertNull(GeelyVhal.portConnected(1))
        assertNull(GeelyVhal.portConnected(null))
    }

    @Test
    fun `climate flags read one as on, zero and two as off, anything else as unknown`() {
        assertEquals(true, GeelyVhal.flag(1.0))
        assertEquals(false, GeelyVhal.flag(0.0))
        // Сырое 2 у 0x15200510 — выключенный климат (Drive Assist, живой IHU629G).
        assertEquals(false, GeelyVhal.flag(2.0))
        assertNull(GeelyVhal.flag(3.0))
        assertNull(GeelyVhal.flag(Double.NaN))
        assertNull(GeelyVhal.flag(null))
    }

    @Test
    fun `climate setpoint is quantized to halves inside the controller range`() {
        assertEquals(22.0, GeelyVhal.climateTempC(22.0)!!, 0.001)
        assertEquals(21.5, GeelyVhal.climateTempC(21.4)!!, 0.001)
        assertEquals(33.0, GeelyVhal.climateTempC(33.2)!!, 0.001)
        assertNull(GeelyVhal.climateTempC(15.2))
        assertNull(GeelyVhal.climateTempC(40.0))
        assertNull(GeelyVhal.climateTempC(-40.0))
        assertNull(GeelyVhal.climateTempC(Double.NaN))
        assertNull(GeelyVhal.climateTempC(null))
    }

    @Test
    fun `fan level accepts zero to eight and heat accepts zero to three`() {
        assertEquals(0, GeelyVhal.fanSpeed(0.0))
        assertEquals(1, GeelyVhal.fanSpeed(1.0))
        assertEquals(3, GeelyVhal.fanSpeed(3.4))
        assertEquals(8, GeelyVhal.fanSpeed(8.0))
        assertNull(GeelyVhal.fanSpeed(9.0))
        // Ноль — честный ответ «выключен»: без него шагом вниз до нуля не дойти.
        assertNull(GeelyVhal.fanSpeed(9.6))
        assertNull(GeelyVhal.fanSpeed(null))
        assertEquals(0, GeelyVhal.heatLevel(0.0))
        assertEquals(3, GeelyVhal.heatLevel(2.6))
        assertNull(GeelyVhal.heatLevel(4.0))
        assertNull(GeelyVhal.heatLevel(null))
    }

    @Test
    fun `climate next only touches signals the car answered`() {
        assertNull(GeelyVhal.climateNext(ClimateChange.POWER, Climate()))
        assertNull(
            GeelyVhal.climateNext(
                ClimateChange.DRIVER_UP,
                Climate(hvacOn = true)
            )
        )
        assertEquals(
            true,
            GeelyVhal.climateNext(ClimateChange.POWER, Climate(hvacOn = false))?.hvacOn
        )
        assertEquals(
            false,
            GeelyVhal.climateNext(ClimateChange.RECIRC, Climate(recircOn = true))?.recircOn
        )
    }

    @Test
    fun `climate next steps fan and setpoints inside their limits`() {
        assertEquals(4, GeelyVhal.climateNext(ClimateChange.FAN_UP, Climate(fanSpeed = 3))?.fanSpeed)
        assertEquals(8, GeelyVhal.climateNext(ClimateChange.FAN_UP, Climate(fanSpeed = 8))?.fanSpeed)
        assertEquals(1, GeelyVhal.climateNext(ClimateChange.FAN_UP, Climate(fanSpeed = 0))?.fanSpeed)
        // Минус с первой ступени гасит вентилятор: ноль теперь «выкл», а не отказ.
        assertEquals(0, GeelyVhal.climateNext(ClimateChange.FAN_DOWN, Climate(fanSpeed = 1))?.fanSpeed)
        assertEquals(0, GeelyVhal.climateNext(ClimateChange.FAN_DOWN, Climate(fanSpeed = 0))?.fanSpeed)

        fun next(change: ClimateChange, from: Double) =
            GeelyVhal.climateNext(change, Climate(driverTempC = from))!!.driverTempC!!

        assertEquals(23.0, next(ClimateChange.DRIVER_UP, 22.0), 0.001)
        assertEquals(21.0, next(ClimateChange.DRIVER_DOWN, 22.0), 0.001)
        assertEquals(23.0, next(ClimateChange.DRIVER_UP, 22.5), 0.001)
        assertEquals(22.0, next(ClimateChange.DRIVER_DOWN, 22.5), 0.001)
        assertEquals(17.0, next(ClimateChange.DRIVER_DOWN, 17.0), 0.001)
        assertEquals(17.0, next(ClimateChange.DRIVER_DOWN, 15.5), 0.001)
        assertEquals(32.0, next(ClimateChange.DRIVER_UP, 32.0), 0.001)
        assertEquals(32.0, next(ClimateChange.DRIVER_UP, 33.0), 0.001)
    }

    @Test
    fun `fan direction keeps only the masks the car accepts`() {
        assertEquals(1, GeelyVhal.fanDirection(1.0))
        assertEquals(2, GeelyVhal.fanDirection(2.0))
        assertEquals(3, GeelyVhal.fanDirection(3.0))
        assertEquals(4, GeelyVhal.fanDirection(4.0))
        assertEquals(6, GeelyVhal.fanDirection(6.0))
        assertNull(GeelyVhal.fanDirection(5.0))
        assertNull(GeelyVhal.fanDirection(0.0))
        assertNull(GeelyVhal.fanDirection(Double.NaN))
        assertNull(GeelyVhal.fanDirection(null))
    }

    @Test
    fun `direction write goes to the vendor property first`() {
        assertNull(GeelyVhal.climateNext(ClimateChange.DIRECTION_FEET, Climate()))
        val next = GeelyVhal.climateNext(ClimateChange.DIRECTION_GLASS_FEET, Climate(fanDirection = 1))!!
        assertEquals(GeelyVhal.DIRECTION_GLASS_FEET, next.fanDirection)

        val writes = GeelyVhal.climateWrites(ClimateChange.DIRECTION_GLASS_FEET, next)
        assertEquals(GeelyVhal.PROP_HVAC_FAN_DIRECTION_VENDOR, writes.first().propertyId)
        assertEquals(GeelyVhal.AREA_GLOBAL, writes.first().areaId)
        assertTrue(writes.all { it.int == 6 })
        assertEquals(GeelyVhal.PROP_HVAC_FAN_DIRECTION, writes.last().propertyId)
    }

    @Test
    fun `drive mode covers the modehelper zones and regen keeps two`() {
        // Зоны DRIVE_AREAS modehelper: 0, 1 и 16_777_216 (0x01000000).
        val sport = GeelyVhal.driveModeWrites(DriveMode.SPORT)
        assertEquals(listOf(0, 1, 16_777_216), sport.map { it.areaId })
        assertTrue(sport.all { it.propertyId == GeelyVhal.PROP_DRIVE_MODE && it.int == 0x22010103 })
        assertEquals(0x22010101, GeelyVhal.driveModeWrites(DriveMode.ECO).first().int)
        assertEquals(0x22010102, GeelyVhal.driveModeWrites(DriveMode.COMFORT).first().int)

        val high = GeelyVhal.regenWrites(RegenLevel.HIGH)
        assertEquals(listOf(0, 1), high.map { it.areaId })
        assertTrue(high.all { it.propertyId == GeelyVhal.PROP_REGEN_LEVEL && it.int == 0x20020503 })
        assertEquals(0x20020501, GeelyVhal.regenWrites(RegenLevel.LOW).first().int)
        assertEquals(0x20020502, GeelyVhal.regenWrites(RegenLevel.MID).first().int)
        assertTrue(GeelyVhal.regenWrites(RegenLevel.AUTO).isEmpty())

        // То, что записано, читается обратно тем же значением.
        assertEquals(DriveMode.SPORT, GeelyVhal.driveMode(sport.first().int))
        assertEquals(RegenLevel.HIGH, GeelyVhal.regenLevel(high.first().int))
    }

    @Test
    fun `quick cool sets minimum, fan six and the compressor`() {
        val current = Climate(hvacOn = true, acOn = false, driverTempC = 24.0, fanSpeed = 2, fanDirection = 2)
        val steps = GeelyVhal.presetSteps(ClimatePreset.QUICK_COOL, current)
        assertEquals(listOf("уставка", "обдув", "вентилятор", "кондиционер"), steps.map { it.title })
        assertTrue(steps.first().writes.all { it.floatC == 17.0 && it.int == null })
        val after = steps.fold(current) { state, step -> step.after(state) }
        assertEquals(17.0, after.driverTempC!!, 0.001)
        assertEquals(6, after.fanSpeed)
        assertEquals(true, after.acOn)
        assertEquals(GeelyVhal.DIRECTION_FACE, after.fanDirection)
    }

    @Test
    fun `quick heat sets maximum, glass and feet, fan six, AC off and electric heaters`() {
        val current = Climate(
            hvacOn = false,
            acOn = true,
            driverTempC = 20.0,
            fanSpeed = 6,
            fanDirection = 1,
            seatHeatDriver = 0,
            seatHeatPassenger = 3,
            wheelHeat = 0,
            rearDefrostOn = false,
            frontDefrostOn = false,
            windshieldHeatOn = false
        )
        val steps = GeelyVhal.presetSteps(ClimatePreset.QUICK_HEAT, current)
        assertEquals(
            listOf(
                "климат", "уставка", "обдув", "кондиционер",
                "сиденье водителя", "руль", "заднее стекло", "лобовое стекло"
            ),
            steps.map { it.title }
        )
        assertTrue(steps.first { it.title == "уставка" }.writes.all { it.floatC == 32.0 && it.int == null })
        assertEquals(false, steps.first { it.title == "кондиционер" }.writes.first().bool)
        val after = steps.fold(current) { state, step -> step.after(state) }
        assertEquals(true, after.hvacOn)
        assertEquals(false, after.acOn)
        assertEquals(32.0, after.driverTempC!!, 0.001)
        assertEquals(6, after.fanSpeed)
        assertEquals(GeelyVhal.DIRECTION_GLASS_FEET, after.fanDirection)
        assertEquals(3, after.seatHeatDriver)
        assertEquals(3, after.seatHeatPassenger)
        assertEquals(1, after.wheelHeat)
        assertEquals(true, after.rearDefrostOn)
        assertEquals(false, after.frontDefrostOn)
        assertEquals(true, after.windshieldHeatOn)
        assertTrue(steps.all { it.writes.isNotEmpty() })
        assertFalse(steps.flatMap { it.writes }.any {
            it.propertyId == GeelyVhal.PROP_HVAC_MAX_DEFROST_DA ||
                it.propertyId == GeelyVhal.PROP_HVAC_MAX_DEFROST
        })
    }

    @Test
    fun `a preset is held only by the properties that identify its scenario`() {
        val cool = Climate(
            hvacOn = true, acOn = true, frontDefrostOn = false, windshieldHeatOn = false,
            rearDefrostOn = false, fanSpeed = 6, driverTempC = 17.0, seatHeatDriver = 0,
            seatHeatPassenger = 0, wheelHeat = 0, fanDirection = GeelyVhal.DIRECTION_FACE
        )
        assertTrue(GeelyVhal.presetHeld(ClimatePreset.QUICK_COOL, cool))
        // Молчание автомобиля сценарий не подтверждает.
        assertFalse(GeelyVhal.presetHeld(ClimatePreset.QUICK_COOL, Climate()))
        assertFalse(GeelyVhal.presetHeld(ClimatePreset.QUICK_COOL, cool.copy(hvacOn = false)))
        assertFalse(GeelyVhal.presetHeld(ClimatePreset.QUICK_COOL, cool.copy(acOn = false)))
        assertFalse(GeelyVhal.presetHeld(ClimatePreset.QUICK_COOL, cool.copy(driverTempC = 18.0)))
        assertFalse(
            GeelyVhal.presetHeld(
                ClimatePreset.QUICK_COOL,
                cool.copy(fanDirection = GeelyVhal.DIRECTION_FEET)
            )
        )
        // Повторное нажатие снимает пресет, но чужая ручная правка сценарий не удерживает.
        assertTrue(GeelyVhal.presetHeld(ClimatePreset.QUICK_COOL, cool.copy(seatHeatDriver = 2)))
        val heat = Climate(
            hvacOn = true, acOn = false, frontDefrostOn = false, windshieldHeatOn = true,
            rearDefrostOn = true, fanSpeed = 6, driverTempC = 32.0, seatHeatDriver = 3,
            seatHeatPassenger = 3, wheelHeat = 1, fanDirection = GeelyVhal.DIRECTION_GLASS_FEET
        )
        assertTrue(GeelyVhal.presetHeld(ClimatePreset.QUICK_HEAT, heat))
        assertFalse(GeelyVhal.presetHeld(ClimatePreset.QUICK_HEAT, heat.copy(hvacOn = false)))
        assertFalse(GeelyVhal.presetHeld(ClimatePreset.QUICK_HEAT, heat.copy(driverTempC = 24.0)))
        assertFalse(
            GeelyVhal.presetHeld(
                ClimatePreset.QUICK_HEAT,
                heat.copy(fanDirection = GeelyVhal.DIRECTION_FACE)
            )
        )
    }

    @Test
    fun `a preset never writes a signal the car did not answer`() {
        for (preset in listOf(ClimatePreset.QUICK_HEAT, ClimatePreset.QUICK_COOL)) {
            for (off in listOf(false, true)) {
                assertTrue(GeelyVhal.presetSteps(preset, Climate(), off = off).isEmpty())
                val current = Climate(recircOn = true)
                val steps = GeelyVhal.presetSteps(preset, current, off = off)
                assertTrue(steps.isEmpty())
                assertEquals(current, steps.fold(current) { state, step -> step.after(state) })
            }
        }
    }

    @Test
    fun `repeated cool press drops the fan to two and switches the compressor off`() {
        val atMax = Climate(
            hvacOn = true,
            acOn = true,
            driverTempC = 17.0,
            fanSpeed = 6,
            fanDirection = GeelyVhal.DIRECTION_FACE
        )
        val steps = GeelyVhal.presetSteps(ClimatePreset.QUICK_COOL, atMax, off = true)
        assertEquals(listOf("вентилятор", "кондиционер"), steps.map { it.title })
        assertFalse(steps.flatMap { it.writes }.any { it.floatC != null })
        val after = steps.fold(atMax) { state, step -> step.after(state) }
        assertEquals(17.0, after.driverTempC!!, 0.001)
        assertEquals(GeelyVhal.PRESET_FAN_REPEAT, after.fanSpeed)
        assertEquals(false, after.acOn)
        assertEquals(GeelyVhal.DIRECTION_FACE, after.fanDirection)
        // Пресет снят: повторный запуск снова включает охлаждение и шестую ступень.
        val back = GeelyVhal.presetSteps(ClimatePreset.QUICK_COOL, after, off = false)
            .fold(after) { state, step -> step.after(state) }
        assertEquals(true, back.acOn)
        assertEquals(GeelyVhal.PRESET_FAN, back.fanSpeed)
    }

    @Test
    fun `repeated heat press leaves 27 degrees and the second fan step`() {
        val atMax = Climate(
            hvacOn = true,
            acOn = false,
            driverTempC = 32.0,
            fanSpeed = 6,
            fanDirection = GeelyVhal.DIRECTION_GLASS_FEET,
            seatHeatDriver = 3,
            seatHeatPassenger = 3,
            wheelHeat = 1,
            rearDefrostOn = true,
            windshieldHeatOn = true,
            frontDefrostOn = false
        )
        val steps = GeelyVhal.presetSteps(ClimatePreset.QUICK_HEAT, atMax, off = true)
        assertEquals(
            listOf(
                "уставка", "вентилятор", "сиденье водителя", "сиденье пассажира",
                "руль", "заднее стекло", "лобовое стекло"
            ),
            steps.map { it.title }
        )
        val after = steps.fold(atMax) { state, step -> step.after(state) }
        // Снятие оставляет 27 °C и вторую ступень, обдув не трогает.
        assertEquals(27.0, after.driverTempC!!, 0.001)
        assertEquals(GeelyVhal.PRESET_FAN_REPEAT, after.fanSpeed)
        assertEquals(GeelyVhal.DIRECTION_GLASS_FEET, after.fanDirection)
        assertEquals(0, after.seatHeatDriver)
        assertEquals(0, after.seatHeatPassenger)
        assertEquals(0, after.wheelHeat)
        assertEquals(false, after.rearDefrostOn)
        assertEquals(false, after.windshieldHeatOn)
        // Кондиционер уже выключен — лишнего нажатия нет.
        assertFalse(steps.any { it.title == "кондиционер" })
        val back = GeelyVhal.presetSteps(ClimatePreset.QUICK_HEAT, after, off = false)
            .fold(after) { state, step -> step.after(state) }
        assertEquals(atMax, back)
    }

    @Test
    fun `quick cool disables MAX first and switches every electric heater off`() {
        val current = Climate(
            hvacOn = true,
            acOn = true,
            driverTempC = 24.0,
            fanSpeed = 2,
            fanDirection = 2,
            seatHeatDriver = 2,
            seatHeatPassenger = 1,
            wheelHeat = 1,
            rearDefrostOn = true,
            frontDefrostOn = true,
            windshieldHeatOn = true
        )
        val steps = GeelyVhal.presetSteps(ClimatePreset.QUICK_COOL, current)
        assertEquals(
            listOf(
                "максимальный обдув", "уставка", "обдув", "вентилятор",
                "сиденье водителя", "сиденье пассажира", "руль", "заднее стекло", "лобовое стекло"
            ),
            steps.map { it.title }
        )
        assertEquals(
            GeelyVhal.climateWrites(ClimateChange.FRONT_DEFROST, Climate(frontDefrostOn = false)),
            steps.first().writes
        )
        val after = steps.fold(current) { state, step -> step.after(state) }
        assertEquals(17.0, after.driverTempC!!, 0.001)
        assertEquals(GeelyVhal.DIRECTION_FACE, after.fanDirection)
        assertEquals(6, after.fanSpeed)
        assertEquals(true, after.acOn)
        assertEquals(0, after.seatHeatDriver)
        assertEquals(0, after.seatHeatPassenger)
        assertEquals(0, after.wheelHeat)
        assertEquals(false, after.rearDefrostOn)
        assertEquals(false, after.frontDefrostOn)
        assertEquals(false, after.windshieldHeatOn)
    }

    @Test
    fun `a climate that already matches writes nothing`() {
        for (preset in listOf(ClimatePreset.QUICK_COOL, ClimatePreset.QUICK_HEAT)) {
            val heat = preset == ClimatePreset.QUICK_HEAT
            val current = Climate(
                hvacOn = true,
                acOn = !heat,
                driverTempC = if (heat) 32.0 else 17.0,
                fanSpeed = 6,
                fanDirection = if (heat) GeelyVhal.DIRECTION_GLASS_FEET else GeelyVhal.DIRECTION_FACE,
                seatHeatDriver = if (heat) 3 else 0,
                seatHeatPassenger = if (heat) 3 else 0,
                wheelHeat = if (heat) 1 else 0,
                rearDefrostOn = heat,
                frontDefrostOn = false,
                windshieldHeatOn = heat
            )
            assertTrue(
                "лишняя запись при совпадении: $preset",
                GeelyVhal.presetSteps(preset, current).isEmpty()
            )
            val off = current.copy(
                acOn = false,
                driverTempC = if (heat) GeelyVhal.PRESET_HEAT_TEMP_REPEAT_C else current.driverTempC,
                fanSpeed = GeelyVhal.PRESET_FAN_REPEAT,
                seatHeatDriver = 0,
                seatHeatPassenger = 0,
                wheelHeat = 0,
                rearDefrostOn = false,
                windshieldHeatOn = false
            )
            assertTrue(
                "лишняя запись при снятии: $preset",
                GeelyVhal.presetSteps(preset, off, off = true).isEmpty()
            )
        }
    }

    @Test
    fun `off keeps the direction, drops the fan to two and moves heat to 27`() {
        val current = Climate(acOn = true, driverTempC = 20.0, fanSpeed = 1, fanDirection = GeelyVhal.DIRECTION_FEET)
        for (preset in listOf(ClimatePreset.QUICK_COOL, ClimatePreset.QUICK_HEAT)) {
            val steps = GeelyVhal.presetSteps(preset, current, off = true)
            val after = steps.fold(current) { state, step -> step.after(state) }
            val heat = preset == ClimatePreset.QUICK_HEAT
            assertEquals(if (heat) 27.0 else 20.0, after.driverTempC!!, 0.001)
            assertEquals(GeelyVhal.PRESET_FAN_REPEAT, after.fanSpeed)
            assertEquals(false, after.acOn)
            // Снятие не переставляет обдув: он остаётся с первого нажатия.
            assertEquals(GeelyVhal.DIRECTION_FEET, after.fanDirection)
            assertFalse(steps.any { it.title == "обдув" })
            assertEquals(heat, steps.any { it.title == "уставка" })
            assertEquals(true, steps.any { it.title == "вентилятор" })
            assertNull(after.hvacOn)
            assertNull(after.frontDefrostOn)
        }
    }

    @Test
    fun `MAX off and power come before the rest of the plan`() {
        val current = Climate(
            hvacOn = false,
            frontDefrostOn = true,
            acOn = true,
            driverTempC = 20.0,
            fanSpeed = 1,
            fanDirection = GeelyVhal.DIRECTION_FEET
        )
        val cool = GeelyVhal.presetSteps(ClimatePreset.QUICK_COOL, current)
        assertEquals(
            listOf("максимальный обдув", "климат", "уставка", "обдув", "вентилятор"),
            cool.map { it.title }
        )
        val heat = GeelyVhal.presetSteps(ClimatePreset.QUICK_HEAT, current)
        assertEquals(
            listOf("максимальный обдув", "климат", "уставка", "обдув", "вентилятор", "кондиционер"),
            heat.map { it.title }
        )

        val maxIds = listOf(GeelyVhal.PROP_HVAC_MAX_DEFROST_DA, GeelyVhal.PROP_HVAC_MAX_DEFROST)
        for (steps in listOf(cool, heat)) {
            assertEquals(maxIds, steps.first().writes.map { it.propertyId })
            assertTrue(steps.first().writes.all { it.bool == false })
            assertEquals(1, steps.count { step -> step.writes.any { it.propertyId in maxIds } })
            assertTrue(steps[1].writes.all {
                it.propertyId == GeelyVhal.PROP_HVAC_POWER_ON && it.bool == true
            })
        }
        val cooled = cool.fold(current) { state, step -> step.after(state) }
        assertEquals(false, cooled.frontDefrostOn)
        assertEquals(true, cooled.hvacOn)
        assertEquals(17.0, cooled.driverTempC!!, 0.001)
        assertEquals(GeelyVhal.DIRECTION_FACE, cooled.fanDirection)
        assertEquals(6, cooled.fanSpeed)
        assertEquals(true, cooled.acOn)
    }

    @Test
    fun `heat never enables MAX and leaves unknown controls unwritten`() {
        for (off in listOf(false, true)) {
            for (front in listOf(null, false, true)) {
                val current = Climate(frontDefrostOn = front)
                val steps = GeelyVhal.presetSteps(ClimatePreset.QUICK_HEAT, current, off = off)
                if (front == true) {
                    assertEquals("максимальный обдув", steps.single().title)
                    assertTrue(steps.single().writes.all { it.bool == false })
                    assertEquals(Climate(frontDefrostOn = false), steps.single().after(current))
                } else {
                    assertTrue(steps.isEmpty())
                }
            }
        }
    }

    @Test
    fun `presets write only each individually known control`() {
        val cases = listOf(
            Climate(hvacOn = false) to Climate(hvacOn = true),
            Climate(acOn = true) to Climate(acOn = false),
            Climate(driverTempC = 20.0) to Climate(driverTempC = 32.0),
            Climate(fanDirection = GeelyVhal.DIRECTION_FACE) to Climate(fanDirection = GeelyVhal.DIRECTION_GLASS_FEET),
            Climate(fanSpeed = 1) to Climate(fanSpeed = 6),
            Climate(seatHeatDriver = 0) to Climate(seatHeatDriver = 3),
            Climate(seatHeatPassenger = 0) to Climate(seatHeatPassenger = 3),
            Climate(wheelHeat = 0) to Climate(wheelHeat = 1),
            Climate(rearDefrostOn = false) to Climate(rearDefrostOn = true)
        )
        for ((current, expected) in cases) {
            val step = GeelyVhal.presetSteps(ClimatePreset.QUICK_HEAT, current).single()
            assertTrue(step.writes.isNotEmpty())
            assertEquals(expected, step.after(current))
        }
    }

    @Test
    fun `seat heat cycles the level while the wheel only switches on and off`() {
        assertEquals(1, GeelyVhal.climateNext(ClimateChange.SEAT_DRIVER, Climate(seatHeatDriver = 0))?.seatHeatDriver)
        assertEquals(3, GeelyVhal.climateNext(ClimateChange.SEAT_PASSENGER, Climate(seatHeatPassenger = 2))?.seatHeatPassenger)
        assertEquals(0, GeelyVhal.climateNext(ClimateChange.SEAT_DRIVER, Climate(seatHeatDriver = 3))?.seatHeatDriver)
        assertEquals(1, GeelyVhal.climateNext(ClimateChange.WHEEL_HEAT, Climate(wheelHeat = 0))?.wheelHeat)
        assertEquals(0, GeelyVhal.climateNext(ClimateChange.WHEEL_HEAT, Climate(wheelHeat = 1))?.wheelHeat)
        assertEquals(0, GeelyVhal.climateNext(ClimateChange.WHEEL_HEAT, Climate(wheelHeat = 3))?.wheelHeat)
    }

    @Test
    fun `climate write maps every command to its property and zone`() {
        val power = GeelyVhal.climateWrites(ClimateChange.POWER, Climate(hvacOn = true)).single()
        assertEquals(GeelyVhal.PROP_HVAC_POWER_ON, power.propertyId)
        assertEquals(GeelyVhal.AREA_ROW_1_ALL, power.areaId)
        assertEquals(true, power.bool)
        assertEquals("вкл", power.valueText())

        // Компрессор: первым — 0x15200505 в канонической зоне 117 из живого лога,
        // затем зона 75; 0x15600099 остаётся запасом — прошивка принимает её вхолостую.
        val ac = GeelyVhal.climateWrites(ClimateChange.AC, Climate(acOn = false))
        assertEquals(GeelyVhal.PROP_HVAC_AC_ON, ac.first().propertyId)
        assertEquals(GeelyVhal.AREA_HVAC_ALL, ac.first().areaId)
        assertEquals(false, ac.first().bool)
        assertEquals(GeelyVhal.AREA_HVAC_DA, ac[1].areaId)
        assertEquals(GeelyVhal.PROP_HVAC_AC_ON_ALT, ac[2].propertyId)
        assertEquals(false, ac[2].bool)
        assertEquals(
            "HVAC_AC_ON int",
            ac[2 + GeelyVhal.HVAC_AREAS.size].label
        )
        assertEquals(0, ac[2 + GeelyVhal.HVAC_AREAS.size].int)
        assertEquals(GeelyVhal.PROP_HVAC_AC_ON_ALT, ac.last().propertyId)

        assertEquals(
            GeelyVhal.AREA_HVAC_ALL,
            GeelyVhal.climateWrites(ClimateChange.RECIRC, Climate(recircOn = true)).single().areaId
        )
        val front = GeelyVhal.climateWrites(ClimateChange.FRONT_DEFROST, Climate(frontDefrostOn = true))
        // Первым — адрес с подтверждённым откликом на живом IHU629G, 0x15200511 — запасной.
        assertEquals(GeelyVhal.PROP_HVAC_MAX_DEFROST_DA, front.first().propertyId)
        assertEquals(GeelyVhal.AREA_HVAC_DA, front.first().areaId)
        assertEquals(GeelyVhal.PROP_HVAC_MAX_DEFROST, front.last().propertyId)
        assertEquals(GeelyVhal.AREA_ROW_1_ALL, front.last().areaId)
        val rear = GeelyVhal.climateWrites(ClimateChange.REAR_DEFROST, Climate(rearDefrostOn = false))
        assertEquals(2, rear.size)
        assertEquals(GeelyVhal.AREA_REAR_DEFROST_DA, rear.first().areaId)
        assertEquals(GeelyVhal.AREA_GLOBAL, rear.last().areaId)

        val fan = GeelyVhal.climateWrites(ClimateChange.FAN_UP, Climate(fanSpeed = 4))
        assertEquals(GeelyVhal.HVAC_AREAS.size, fan.size)
        assertEquals(GeelyVhal.PROP_HVAC_FAN_SPEED, fan.first().propertyId)
        assertEquals(GeelyVhal.AREA_ROW_1_ALL, fan.first().areaId)
        assertEquals(4, fan.first().int)
        assertEquals("4", fan.first().valueText())
        assertEquals(GeelyVhal.HVAC_AREAS.toSet(), fan.map { it.areaId }.toSet())

        // Контроллер шагает через climateNext: 22,5 вверх дают 23 °C.
        // Уставка уходит float-записью 0x15600503, как в Central EX Auto.
        val driverNext = GeelyVhal.climateNext(ClimateChange.DRIVER_UP, Climate(driverTempC = 22.5))!!
        assertEquals(23.0, driverNext.driverTempC!!, 0.001)
        val driver = GeelyVhal.climateWrites(ClimateChange.DRIVER_UP, driverNext)
        assertEquals(4, driver.size)
        assertEquals(GeelyVhal.PROP_HVAC_TEMPERATURE_SET, driver.first().propertyId)
        assertEquals(GeelyVhal.AREA_SEAT_LEFT, driver.first().areaId)
        assertEquals(23.0, driver.first().floatC!!, 0.001)
        assertEquals("23.0", driver.first().valueText())
        assertEquals(GeelyVhal.PROP_HVAC_TEMPERATURE_SET_CANONICAL, driver[1].propertyId)
        assertEquals(GeelyVhal.PROP_HVAC_TEMPERATURE_SET_VENDOR, driver[2].propertyId)
        assertTrue(driver.all { it.int == null && it.bool == null })

        val seat = GeelyVhal.climateWrites(ClimateChange.SEAT_DRIVER, Climate(seatHeatDriver = 2)).single()
        assertEquals(GeelyVhal.PROP_HVAC_SEAT_HEAT, seat.propertyId)
        assertEquals(2, seat.int)
        assertEquals(
            GeelyVhal.AREA_SEAT_RIGHT,
            GeelyVhal.climateWrites(ClimateChange.SEAT_PASSENGER, Climate(seatHeatPassenger = 1)).single().areaId
        )
        val wheel = GeelyVhal.climateWrites(ClimateChange.WHEEL_HEAT, Climate(wheelHeat = 3))
        assertEquals(2, wheel.size)
        assertEquals(GeelyVhal.PROP_HVAC_WHEEL_HEAT, wheel.first().propertyId)
        assertEquals(GeelyVhal.AREA_SEAT_LEFT, wheel.first().areaId)
        assertEquals(GeelyVhal.AREA_GLOBAL, wheel.last().areaId)
        assertTrue(wheel.all { it.int == 3 })
    }

    @Test
    fun `climate write needs the read state before it sends anything`() {
        assertTrue(GeelyVhal.climateWrites(ClimateChange.POWER, Climate()).isEmpty())
        assertTrue(GeelyVhal.climateWrites(ClimateChange.FAN_UP, Climate(hvacOn = true)).isEmpty())
        assertTrue(GeelyVhal.climateWrites(ClimateChange.WHEEL_HEAT, Climate(fanSpeed = 3)).isEmpty())
        assertTrue(GeelyVhal.climateWrites(ClimateChange.DRIVER_UP, Climate(driverTempC = null)).isEmpty())
    }

    @Test
    fun `setpoint steps are clamped to seventeen and thirty-two and written in Celsius`() {
        // 15,5 вниз шагает до нижнего предела панели 17 °C.
        val lowNext = GeelyVhal.climateNext(ClimateChange.DRIVER_DOWN, Climate(driverTempC = 15.5))!!
        assertEquals(17.0, lowNext.driverTempC!!, 0.001)
        val low = GeelyVhal.climateWrites(ClimateChange.DRIVER_DOWN, lowNext)
        assertEquals(4, low.size)
        assertEquals(GeelyVhal.PROP_HVAC_TEMPERATURE_SET, low.first().propertyId)
        assertEquals(GeelyVhal.AREA_SEAT_LEFT, low.first().areaId)
        assertEquals(GeelyVhal.PROP_HVAC_TEMPERATURE_ADJUST, low.last().propertyId)
        assertTrue(low.all { it.floatC == 17.0 && it.int == null && it.bool == null })

        // 33 вверх шагает до верхнего предела 32 °C.
        val highNext = GeelyVhal.climateNext(ClimateChange.DRIVER_UP, Climate(driverTempC = 33.0))!!
        assertEquals(32.0, highNext.driverTempC!!, 0.001)
        val high = GeelyVhal.climateWrites(ClimateChange.DRIVER_UP, highNext)
        assertEquals(4, high.size)
        assertEquals(GeelyVhal.PROP_HVAC_TEMPERATURE_SET, high.first().propertyId)
        assertEquals(GeelyVhal.PROP_HVAC_TEMPERATURE_SET_CANONICAL, high[1].propertyId)
        assertEquals(GeelyVhal.PROP_HVAC_TEMPERATURE_ADJUST, high.last().propertyId)
        assertTrue(high.all { it.floatC == 32.0 && it.int == null && it.bool == null })
    }

    @Test
    fun `a write carries exactly one typed value`() {
        assertThrows(IllegalArgumentException::class.java) {
            GeelyVhal.VhalWrite(
                propertyId = GeelyVhal.PROP_HVAC_FAN_SPEED,
                areaId = GeelyVhal.AREA_ROW_1_ALL,
                bool = true,
                int = 3,
                label = "HVAC_FAN_SPEED"
            )
        }
        assertThrows(IllegalArgumentException::class.java) {
            GeelyVhal.VhalWrite(
                propertyId = GeelyVhal.PROP_HVAC_FAN_SPEED,
                areaId = GeelyVhal.AREA_ROW_1_ALL,
                label = "HVAC_FAN_SPEED"
            )
        }
    }

    @Test
    fun `gear accepts exactly one bit of the mask`() {
        assertEquals(Gear.P, GeelyVhal.gear(GeelyVhal.GEAR_PARK))
        assertEquals(Gear.R, GeelyVhal.gear(GeelyVhal.GEAR_REVERSE))
        assertEquals(Gear.N, GeelyVhal.gear(GeelyVhal.GEAR_NEUTRAL))
        assertEquals(Gear.D, GeelyVhal.gear(GeelyVhal.GEAR_DRIVE))
        // Старшие биты состояния отбрасываются — так же, как в Capy.
        assertEquals(Gear.D, GeelyVhal.gear(0x18))
        // Две передачи одновременно — это не ответ, а шум, и приоритет не выбирается.
        assertNull(GeelyVhal.gear(GeelyVhal.GEAR_PARK or GeelyVhal.GEAR_DRIVE))
        assertNull(GeelyVhal.gear(0))
        assertNull(GeelyVhal.gear(0xF))
        assertNull(GeelyVhal.gear(null))
    }

    @Test
    fun `gear areas try the wildcard before the global one`() {
        assertEquals(-1, GeelyVhal.GEAR_AREAS[0])
        assertEquals(0, GeelyVhal.GEAR_AREAS[1])
    }

    @Test
    fun `ignition accepts only the adapted sensor constants`() {
        assertEquals(IgnitionState.LOCK, GeelyVhal.ignition(0x200102))
        assertEquals(IgnitionState.OFF, GeelyVhal.ignition(0x200103))
        assertEquals(IgnitionState.ACC, GeelyVhal.ignition(0x200104))
        assertEquals(IgnitionState.ON, GeelyVhal.ignition(0x200105))
        assertEquals(IgnitionState.START, GeelyVhal.ignition(0x200106))
        assertEquals(IgnitionState.DRIVING, GeelyVhal.ignition(0x200107))
        // UNDEFINED — это «не определено», а короткое число сырого PEPS неоднозначно.
        assertNull(GeelyVhal.ignition(0x200101))
        assertNull(GeelyVhal.ignition(1))
        assertNull(GeelyVhal.ignition(null))
    }

    @Test
    fun `usage mode names only the states that speak about the key`() {
        assertTrue(GeelyVhal.keyInCabin(0x201304)!!)
        assertTrue(GeelyVhal.keyInCabin(0x201305)!!)
        assertFalse(GeelyVhal.keyInCabin(0x201301)!!)
        assertFalse(GeelyVhal.keyInCabin(0x201302)!!)
        assertNull(GeelyVhal.keyInCabin(0x201303))
        assertNull(GeelyVhal.keyInCabin(null))
    }

    @Test
    fun `body ids match their documented hex`() {
        assertEquals(0x16400B00, GeelyVhal.PROP_DOOR_POS)
        assertEquals(0x264020AA, GeelyVhal.PROP_DOOR_LOCK)
        assertEquals(0x13400BC0, GeelyVhal.PROP_WINDOW_POS)
        assertEquals(0x11400E00, GeelyVhal.PROP_HEADLIGHTS_STATE)
        assertEquals(0x264020A9, GeelyVhal.PROP_DOOR_POS_VENDOR)
        assertEquals(0x234020AB, GeelyVhal.PROP_WINDOW_POS_VENDOR)
        assertEquals(0x2040FC00, GeelyVhal.PROP_CENTRAL_LOCK)
        assertEquals(0x2140801E, GeelyVhal.PROP_HOOD_STATUS_VENDOR)
        assertEquals(0x21402013, GeelyVhal.PROP_TRUNK_POS_VENDOR)
        assertEquals(0x214020BE, GeelyVhal.PROP_BODY_LIGHT_STATUS)
        assertEquals(0x214020A3, GeelyVhal.PROP_HEADLIGHTS_SWITCH)
        assertEquals(0x11400E01, GeelyVhal.PROP_HIGH_BEAM_STATE)
        assertEquals(0x11400E02, GeelyVhal.PROP_FOG_LIGHTS_STATE)
        assertEquals(0x11400E03, GeelyVhal.PROP_HAZARD_LIGHTS_STATE)
        assertEquals(0x11400408, GeelyVhal.PROP_TURN_SIGNAL_STATE)
        assertEquals(0x2140B00B, GeelyVhal.PROP_CHARGE_MAX_SOC)
        assertEquals(0x2140B048, GeelyVhal.PROP_FRONT_TRUNK_SWT)
        assertEquals(0x2140A552, GeelyVhal.PROP_HOOD_LOCK)
    }

    @Test
    fun `frunk keeps its existing candidates and never touches the rear trunk`() {
        val frunk = GeelyVhal.frunkOpenWrites()
        assertEquals("FRONT_TRUNK_SWT", frunk.first().label)
        assertEquals(GeelyVhal.PROP_FRONT_TRUNK_SWT, frunk.first().propertyId)
        assertEquals(true, frunk.first().bool)
        assertTrue(frunk.any { it.propertyId == GeelyVhal.PROP_HOOD_LOCK })
        assertTrue(frunk.all { it.areaId == GeelyVhal.AREA_GLOBAL })
        // Заднего багажника в меню этого ГУ нет: адреса LOCK_TRUNK и SET_REQ убраны
        // целиком, чтобы кнопка не отправляла запрос в неизвестное свойство.
        val tailgate = setOf(0x2140A818, 0x2140A240)
        assertTrue(frunk.none { it.propertyId in tailgate })
    }

    @Test
    fun `door position uses the head unit encoding not the aosp one`() {
        assertEquals(true, GeelyVhal.doorOpen(1))
        assertEquals(false, GeelyVhal.doorOpen(2))
        assertNull(GeelyVhal.doorOpen(0))
        assertNull(GeelyVhal.doorOpen(null))
        assertEquals(true, GeelyVhal.doorLocked(1))
        assertEquals(false, GeelyVhal.doorLocked(0))
        assertNull(GeelyVhal.doorLocked(2))
        assertEquals(0, GeelyVhal.windowPercent(0))
        assertEquals(100, GeelyVhal.windowPercent(100))
        assertNull(GeelyVhal.windowPercent(101))
        assertNull(GeelyVhal.windowPercent(-1))
    }

    @Test
    fun `headlights burn only when state and switch agree`() {
        // Один STATE на живом ГУ показывал 1 при потушенных фарах — верим только свёрке.
        assertEquals(true, GeelyVhal.headlightsOn(state = 1, switch = 1))
        assertEquals(false, GeelyVhal.headlightsOn(state = 1, switch = 0))
        assertEquals(false, GeelyVhal.headlightsOn(state = 0, switch = 1))
        assertEquals(false, GeelyVhal.headlightsOn(state = 0, switch = null))
        assertNull(GeelyVhal.headlightsOn(state = 2, switch = 1))
        assertNull(GeelyVhal.headlightsOn(state = null, switch = 1))
        assertNull(GeelyVhal.headlightsOn(null, null))
    }

    @Test
    fun `body lock is known only when every door answered or one is unlocked`() {
        val all = Body(locked = Body.DOORS.associateWith { true })
        assertEquals(true, all.allLocked)
        assertNull(Body(locked = mapOf(BodyPart.DOOR_FL to true)).allLocked)
        assertEquals(false, Body(locked = mapOf(BodyPart.DOOR_RR to false)).allLocked)
        val open = Body(open = mapOf(BodyPart.TAILGATE to true, BodyPart.DOOR_RL to true, BodyPart.HOOD to false))
        assertEquals(listOf(BodyPart.DOOR_RL, BodyPart.TAILGATE), open.openParts)
    }

    /**
     * Адреса статистики выписаны из дампа свойств EX2 и разборов Capy. Десятичные
     * константы должны совпадать с hex: опечатка в числе — это чтение чужого
     * свойства, а не ошибка компиляции.
     */
    @Test
    fun `statistics ids match their documented hex`() {
        assertEquals(0x24205500, GeelyVhal.PROP_CHARGE_WORK_TIME_MIN)
        assertEquals(0x2140A6D8, GeelyVhal.PROP_AC_CURRENT_SET_A)
        assertEquals(0x2140A6D9, GeelyVhal.PROP_AC_CURRENT_MAX_A)
        assertEquals(0x2140A6DA, GeelyVhal.PROP_AC_CURRENT_MIN_A)
        assertEquals(0x2160A6E9, GeelyVhal.PROP_ED_DRIVING_ENERGY_FLOW)
        assertEquals(0x2160A6EA, GeelyVhal.PROP_ED_CLIMATE_ENERGY_FLOW)
        assertEquals(0x2160A6EB, GeelyVhal.PROP_ED_BATTERY_ENERGY_FLOW)
        assertEquals(0x2160A6EC, GeelyVhal.PROP_ED_OTHER_ENERGY_FLOW)
        assertEquals(0x216074E9, GeelyVhal.PROP_ED_DRIVING_ENERGY_FLOW_TRIP)
        assertEquals(0x24804100, GeelyVhal.LOGICAL_TRIP_ED_DRIVING_ENERGY_FLOW)
        assertEquals(0x21407173, GeelyVhal.PROP_HYBRID_POWER_FLOW)
        assertEquals(0x21402006, GeelyVhal.PROP_DRIVE_POWER_OUTPUT)
        assertEquals(0x2140A6AA, GeelyVhal.PROP_IPK_AVERAGE_POWER_CONSUMPTION)
        assertEquals(0x2140A836, GeelyVhal.PROP_BMSH_BAT_CURRENT)
        assertEquals(0x2140A837, GeelyVhal.PROP_BMSH_PACK_VOLT)
        assertEquals(0x2140B014, GeelyVhal.PROP_BMSH_BUS_VOLT)
        assertEquals(0x2140A82B, GeelyVhal.PROP_BMSH_BAT_SOE)
        assertEquals(0x2140A307, GeelyVhal.PROP_IC_HR_TRIP)
        assertEquals(64, GeelyVhal.AC_CURRENT_MAX_A)
        assertEquals(1440, GeelyVhal.CHARGE_MINUTES_MAX)
        // Пробег остаётся дробным в километрах; ноль неготового адреса и заглушка
        // за пределом не превращаются в пробег, чтобы цепочка шла к резерву.
        assertEquals(18_452.4, GeelyVhal.odometerKm(18_452.4)!!, 0.0)
        assertNull(GeelyVhal.odometerKm(0.0))
        assertNull(GeelyVhal.odometerKm(4_294_967_295.0))
        assertNull(GeelyVhal.odometerKm(Double.NaN))
        assertNull(GeelyVhal.odometerKm(null))
    }

    @Test
    fun `charge minutes drop the zero and everything longer than a day`() {
        assertEquals(42, GeelyVhal.minutes(42.4))
        assertEquals(1, GeelyVhal.minutes(1.0))
        assertEquals(1440, GeelyVhal.minutes(1440.0))
        // Ноль — это «не отвечено», а не «ноль минут», и 1441 мин не бывает.
        assertNull(GeelyVhal.minutes(0.0))
        assertNull(GeelyVhal.minutes(-5.0))
        assertNull(GeelyVhal.minutes(1441.0))
        assertNull(GeelyVhal.minutes(Double.NaN))
        assertNull(GeelyVhal.minutes(null))
    }

    @Test
    fun `work time is trusted only while the car is charging`() {
        assertEquals(42, GeelyVhal.chargeWorkMinutes(42.0, ChargeFlow.AC))
        assertEquals(42, GeelyVhal.chargeWorkMinutes(42.0, ChargeFlow.DC))
        assertEquals(42, GeelyVhal.chargeWorkMinutes(42.0, ChargeFlow.HEATING))
        // После остановки заряда прошивка держит последние числа: залипшее «42 мин»
        // нарисовало бы сессию, которой уже нет.
        assertNull(GeelyVhal.chargeWorkMinutes(42.0, ChargeFlow.FINISHED))
        assertNull(GeelyVhal.chargeWorkMinutes(42.0, ChargeFlow.PLUGGED))
        assertNull(GeelyVhal.chargeWorkMinutes(42.0, ChargeFlow.IDLE))
        assertNull(GeelyVhal.chargeWorkMinutes(42.0, null))
        assertNull(GeelyVhal.chargeWorkMinutes(0.0, ChargeFlow.DC))
    }

    @Test
    fun `allowed ac current keeps only what the car declared`() {
        val measured = GeelyVhal.acCurrentBounds(setA = 5, minA = 5, maxA = 32)
        assertEquals(5, measured.setA)
        assertEquals(5, measured.minA)
        assertEquals(32, measured.maxA)
        assertTrue(measured.hasRange)

        // Только заданный ток: диапазона нет, и рисовать 5…32 A из головы нельзя.
        val onlySet = GeelyVhal.acCurrentBounds(setA = 7, minA = null, maxA = null)
        assertEquals(7, onlySet.setA)
        assertFalse(onlySet.hasRange)

        // Ноль у этих свойств означает «ответа нет».
        val silent = GeelyVhal.acCurrentBounds(setA = 0, minA = 0, maxA = 0)
        assertNull(silent.setA)
        assertFalse(silent.hasRange)

        // Число выше 64 A — не ответ автомобиля, а шум (Capy: интерфейс, придумавший 48 A).
        val nonsense = GeelyVhal.acCurrentBounds(setA = 80, minA = 5, maxA = 100)
        assertNull(nonsense.setA)
        assertFalse(nonsense.hasRange)

        // Границы принимаются только упорядоченной парой.
        val reversed = GeelyVhal.acCurrentBounds(setA = 20, minA = 32, maxA = 5)
        assertEquals(32, reversed.minA)
        assertNull(reversed.maxA)
        assertFalse(reversed.hasRange)

        val single = GeelyVhal.acCurrentBounds(setA = null, minA = 5, maxA = 5)
        assertTrue(single.hasRange)
    }

    @Test
    fun `wall power is derived only while the charge is running`() {
        // Измеренная сессия: 211 В / 6,8 А на стороне несущей сети.
        assertEquals(1.4348, GeelyVhal.derivedChargePowerKw(211.0, 6.8, ChargeFlow.AC)!!, 0.0001)
        // Для DC эти же свойства описывают высоковольтную шину, а не сеть: там есть
        // собственный счётчик мощности, и B×A его не заменяет.
        assertNull(GeelyVhal.derivedChargePowerKw(230.0, -7.0, ChargeFlow.DC))
        assertEquals(0.44, GeelyVhal.derivedChargePowerKw(220.0, 2.0, ChargeFlow.HEATING)!!, 0.001)
        assertNull(GeelyVhal.derivedChargePowerKw(211.0, 6.8, ChargeFlow.FINISHED))
        assertNull(GeelyVhal.derivedChargePowerKw(211.0, 6.8, null))
        assertNull(GeelyVhal.derivedChargePowerKw(null, 6.8, ChargeFlow.AC))
        assertNull(GeelyVhal.derivedChargePowerKw(211.0, null, ChargeFlow.AC))
        assertNull(GeelyVhal.derivedChargePowerKw(0.0, 6.8, ChargeFlow.AC))
        assertNull(GeelyVhal.derivedChargePowerKw(211.0, Double.NaN, ChargeFlow.AC))
        // Ниже порога шума — это дежурка, а не заряд.
        assertNull(GeelyVhal.derivedChargePowerKw(200.0, 0.05, ChargeFlow.AC))
    }
}
