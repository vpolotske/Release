package com.ex2hub.source

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Пульсация полосы заряда — Compose-сторона, которая в JVM не исполняется. Закреплено то,
 * зачем она вообще точечная: дышит только полоса, только по-настоящему растущий заряд,
 * только на видимом экране и без бесконечной анимации, которая будила бы весь рабочий стол.
 */
class ChargePulseContractTest {

    private fun source(relativePath: String): String {
        val path = "src/main/java/com/ex2hub/$relativePath.kt"
        return listOf(File(path), File("app/$path")).first { it.isFile }.readText(Charsets.UTF_8)
    }

    private fun String.blockAfter(marker: String): String {
        val from = indexOf(marker)
        assertTrue("нет блока $marker", from >= 0)
        return substring(from)
    }

    @Test
    fun `pulse reaches the hero card as its own field`() {
        val home = source("ui/screens/HomeScreen")
        val screen = home.blockAfter("fun HomeScreen(")
        assertTrue(screen.contains("socRising = ui.socRising,"))
        assertTrue(home.contains("socRising: Boolean,"))
        assertTrue(home.contains("pulse = socRising,"))
        val canvas = home.blockAfter("private fun HomeCanvas(").substringBefore(") {")
        assertFalse("Canvas still gets the whole snapshot", canvas.contains("VehicleSnapshot"))
    }

    @Test
    fun `only the charge bar breathes and the loop stops with the flag`() {
        val home = source("ui/screens/HomeScreen")
        val hero = home.blockAfter("private fun HeroCard(")
        assertTrue(hero.contains("val fillAlpha = remember { Animatable(1f) }"))
        assertTrue(hero.contains("LaunchedEffect(pulse) {"))
        assertTrue(hero.contains("if (pulse) {"))
        assertTrue(hero.contains("while (true) {"))
        // Мягкое дыхание: полоса темнеет до 0,55, а не гаснет, и всегда возвращается к 1.
        assertTrue(hero.contains("fillAlpha.animateTo(0.55f, tween(1200, easing = FastOutSlowInEasing))"))
        assertTrue(hero.contains("fillAlpha.animateTo(1f, tween(1200, easing = FastOutSlowInEasing))"))
        assertTrue(hero.contains("fillAlpha.animateTo(1f, tween(300))"))
        assertTrue(hero.contains(".graphicsLayer { alpha = fillAlpha.value }"))
        assertEquals("Alpha is read for drawing only", 1, Regex("""fillAlpha\.value""").findAll(hero).count())
        // Дыхание висит на полосе заряда, а не на карточке с кадром автомобиля.
        val fill = hero.indexOf(".fillMaxWidth(soc / 100f)")
        val alpha = hero.indexOf("alpha = fillAlpha.value")
        assertTrue("Layer must belong to the progress fill", fill in 0 until alpha && alpha - fill < 400)
        assertFalse(home.contains("rememberInfiniteTransition"))
        assertFalse(home.contains("animateFloatAsState"))
    }

    @Test
    fun `growth comes from telemetry and dies with the visible screen`() {
        val controller = source("ui/HubController")
        assertTrue(controller.contains("private val socRise = SocRising()"))
        val block = controller.between("val socRising = socRise.update(", "val next = ui.copy(")
        assertTrue(block.contains("soc = nextVehicle.soc.takeIf { !nextVehicle.isFallback }"))
        assertTrue(block.contains("charging = nextVehicle.isCharging == true"))
        assertTrue(block.contains("visible = uiVisible"))
        assertTrue(controller.contains("socRising = socRising,"))
        // Скрытый экран гасит пульсацию сразу: иначе она крутилась бы в фоне.
        val stopped = controller.blockAfter("fun onUiStopped() {").substringBefore("\n    }")
        assertTrue(stopped.contains("if (ui.socRising) ui = ui.copy(socRising = false)"))
        assertTrue(source("ui/HubUiState").contains("val socRising: Boolean = false,"))
    }

    @Test
    fun `the growth rule is plain kotlin and never touches the car`() {
        val rise = source("data/SocRising")
        assertFalse(rise.contains("import android"))
        assertFalse(rise.contains("GeelyVhal."))
        assertFalse(rise.contains("setProperty"))
    }

    private fun String.between(start: String, end: String): String {
        val from = indexOf(start)
        val to = indexOf(end)
        assertTrue("нет блока $start", from >= 0 && to > from)
        return substring(from, to)
    }
}
