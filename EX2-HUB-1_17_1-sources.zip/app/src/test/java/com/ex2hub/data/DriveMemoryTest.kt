package com.ex2hub.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DriveMemoryTest {

    private val wanted = Profile(
        preferredDriveMode = DriveMode.SPORT,
        preferredRegen = RegenLevel.HIGH,
        restoreDrive = true
    )

    private fun car(
        gear: Gear? = Gear.P,
        ignition: IgnitionState? = IgnitionState.ON,
        mode: DriveMode? = DriveMode.COMFORT,
        regen: RegenLevel? = RegenLevel.MID
    ) = VehicleSnapshot(gear = gear, ignition = ignition, driveMode = mode, regen = regen)

    @Test
    fun `a drive or reverse gear is remembered until the car is switched off`() {
        val memory = DriveMemory()
        memory.observe(car(gear = Gear.D), Profile(), 0)
        assertTrue(memory.seenDriveGear)
        memory.observe(car(gear = Gear.P), Profile(), 1)
        assertTrue(memory.seenDriveGear)
        memory.observe(car(ignition = IgnitionState.LOCK), Profile(), 2)
        assertFalse(memory.seenDriveGear)
        memory.observe(car(gear = Gear.R), Profile(), 3)
        assertTrue(memory.seenDriveGear)
    }

    @Test
    fun `nothing is restored unless the owner allowed it`() {
        val memory = DriveMemory()
        assertNull(memory.observe(car(), wanted.copy(restoreDrive = false), 0))
    }

    @Test
    fun `restore happens only in park and only for what differs`() {
        val memory = DriveMemory()
        assertNull(memory.observe(car(gear = Gear.D), wanted, 0))
        assertEquals(DriveMemory.Plan(DriveMode.SPORT, null), memory.observe(car(regen = RegenLevel.HIGH), wanted, 1))
    }

    @Test
    fun `an unread signal is never restored blindly`() {
        val memory = DriveMemory()
        assertEquals(DriveMemory.Plan(null, RegenLevel.HIGH), memory.observe(car(mode = null), wanted, 0))
    }

    @Test
    fun `the mode is written once per power cycle even if the car drops it again`() {
        val memory = DriveMemory()
        assertNotNull(memory.observe(car(), wanted, 0))
        // Прошивка на стоянке снова отдаёт свой режим: повторной записи и мигания
        // кнопок больше нет — журнал 2026-10-28 показал десятки таких повторов.
        assertNull(memory.observe(car(), wanted, 1_000))
        assertNull(memory.observe(car(), wanted, 60_000))
        assertNull(memory.observe(car(), wanted, 10 * 60_000))
    }

    @Test
    fun `a car already in the wanted state leaves restore available`() {
        val memory = DriveMemory()
        assertNull(memory.observe(car(mode = DriveMode.SPORT, regen = RegenLevel.HIGH), wanted, 0))
        assertNotNull(memory.observe(car(), wanted, 1_000))
    }

    @Test
    fun `a new power cycle starts restore again`() {
        val memory = DriveMemory()
        assertNotNull(memory.observe(car(), wanted, 0))
        assertNull(memory.observe(car(ignition = IgnitionState.OFF), wanted, 1))
        assertNotNull(memory.observe(car(), wanted, 2))
    }

    @Test
    fun `a pair is confirmed only by both actual values`() {
        val target = DriveMemory.Plan(DriveMode.ECO, RegenLevel.LOW)
        assertTrue(target.matches(DriveMode.ECO, RegenLevel.LOW))
        assertFalse(target.matches(DriveMode.COMFORT, RegenLevel.LOW))
        assertFalse(target.matches(DriveMode.ECO, RegenLevel.MID))
    }

    @Test
    fun `an unavailable response never confirms a requested pair`() {
        val target = DriveMemory.Plan(DriveMode.ECO, RegenLevel.LOW)
        assertFalse(target.matches(null, null))
        assertFalse(target.matches(DriveMode.ECO, null))
        assertFalse(target.matches(null, RegenLevel.LOW))
    }

    @Test
    fun `a later rollback invalidates an earlier matching response`() {
        val target = DriveMemory.Plan(DriveMode.SPORT, RegenLevel.HIGH)
        assertTrue(target.matches(DriveMode.SPORT, RegenLevel.HIGH))
        assertFalse(target.matches(DriveMode.COMFORT, RegenLevel.MID))
        assertFalse(target.matches(null, null))
    }

    @Test
    fun `a single target requires only its own actual response`() {
        assertTrue(DriveMemory.Plan(DriveMode.ECO, null).matches(DriveMode.ECO, null))
        assertFalse(DriveMemory.Plan(DriveMode.ECO, null).matches(null, RegenLevel.HIGH))
        assertTrue(DriveMemory.Plan(null, RegenLevel.LOW).matches(null, RegenLevel.LOW))
        assertFalse(DriveMemory.Plan(null, RegenLevel.LOW).matches(DriveMode.ECO, null))
    }

    @Test
    fun `an empty command cannot be confirmed`() {
        assertFalse(DriveMemory.Plan(null, null).matches(null, null))
        assertFalse(DriveMemory.Plan(null, null).matches(DriveMode.ECO, RegenLevel.LOW))
    }

    @Test
    fun `remembering a pair replaces both old preferences without enabling restore`() {
        val target = DriveMemory.Plan(DriveMode.ECO, RegenLevel.LOW)
        val saved = target.remember(wanted.copy(restoreDrive = false))
        assertEquals(DriveMode.ECO, saved.preferredDriveMode)
        assertEquals(RegenLevel.LOW, saved.preferredRegen)
        assertFalse(saved.restoreDrive)
        assertEquals(wanted.copy(
            preferredDriveMode = DriveMode.ECO,
            preferredRegen = RegenLevel.LOW,
            restoreDrive = false
        ), saved)
    }

    @Test
    fun `remembering a single target leaves the other preference unchanged`() {
        val mode = DriveMemory.Plan(DriveMode.ECO, null).remember(wanted)
        assertEquals(DriveMode.ECO, mode.preferredDriveMode)
        assertEquals(RegenLevel.HIGH, mode.preferredRegen)
        val regen = DriveMemory.Plan(null, RegenLevel.LOW).remember(wanted)
        assertEquals(DriveMode.SPORT, regen.preferredDriveMode)
        assertEquals(RegenLevel.LOW, regen.preferredRegen)
        assertTrue(regen.restoreDrive)
    }

    @Test
    fun `a manual choice settles the memory until the next power cycle`() {
        val memory = DriveMemory()
        memory.settle()
        assertNull(memory.observe(car(), wanted, 0))
        assertNull(memory.observe(car(), wanted, 60_000))
        memory.observe(car(ignition = IgnitionState.LOCK), wanted, 61_000)
        assertNotNull(memory.observe(car(), wanted, 62_000))
    }
}
