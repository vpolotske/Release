package com.ex2hub.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth
import java.time.ZoneId

class StatsTest {
    private val zone: ZoneId = ZoneId.of("Europe/Minsk")
    private val today = LocalDate.of(2026, 10, 24)

    private fun at(date: LocalDate, time: String): Long =
        date.atTime(LocalTime.parse(time)).atZone(zone).toInstant().toEpochMilli()

    private fun trip(
        id: String,
        date: LocalDate,
        time: String = "09:00",
        km: Double = 10.0,
        minutes: Int = 20,
        kwh: Double = 1.5
    ) = Trip(
        id = id,
        startedAt = at(date, time),
        from = "A",
        to = "B",
        distanceKm = km,
        durationMin = minutes,
        energyKwh = kwh
    )

    @Test
    fun `today trips are filtered and sorted by start`() {
        val trips = listOf(
            trip("late", today, "18:00"),
            trip("early", today, "08:00"),
            trip("yesterday", today.minusDays(1), "12:00")
        )
        val result = Stats.todayTrips(trips, at(today, "23:00"), zone)
        assertEquals(listOf("early", "late"), result.map { it.id })
    }

    @Test
    fun `week stats aggregate distances energy and cost`() {
        val trips = listOf(
            trip("a", today, km = 20.0, minutes = 30, kwh = 3.0),
            trip("b", today.minusDays(1), km = 10.0, minutes = 15, kwh = 1.2),
            trip("old", today.minusDays(8), km = 50.0, minutes = 60, kwh = 7.5)
        )
        val week = Stats.weekStats(trips, at(today, "23:00"), zone, tariffPerKwh = 0.3)

        assertEquals(30.0, week.distanceKm, 0.001)
        assertEquals(4.2, week.energyKwh, 0.001)
        assertEquals(45, week.minutes)
        assertEquals(2, week.trips)
        assertEquals(14.0, week.consumption!!, 0.001)
        assertEquals(1.26, week.cost, 0.001)
        assertEquals(7, week.days.size)
        assertEquals(today, week.days.last().date)
        assertEquals(today.minusDays(6), week.days.first().date)
    }

    @Test
    fun `an earlier week shifts the whole window back by seven days`() {
        val trips = listOf(
            trip("now", today, km = 20.0),
            trip("last-week", today.minusDays(8), km = 50.0),
            trip("two-weeks", today.minusDays(14), km = 5.0)
        )
        val week = Stats.weekStats(trips, at(today, "23:00"), zone, weeksBack = 1)

        assertEquals(today.minusDays(7), week.days.last().date)
        assertEquals(today.minusDays(13), week.days.first().date)
        assertEquals(1, week.trips)
        assertEquals(50.0, week.distanceKm, 0.001)
    }

    @Test
    fun `best efficiency day ignores empty days`() {
        val trips = listOf(
            trip("a", today, km = 10.0, kwh = 2.0),
            trip("b", today.minusDays(2), km = 10.0, kwh = 1.0)
        )
        val week = Stats.weekStats(trips, at(today, "23:00"), zone)
        assertEquals(today.minusDays(2), week.bestEfficiencyDay?.date)
    }

    @Test
    fun `week cost per hundred falls back to nothing when the window has no distance`() {
        val trips = listOf(trip("a", today, km = 20.0, minutes = 30, kwh = 3.0))
        val week = Stats.weekStats(trips, at(today, "23:00"), zone, tariffPerKwh = 0.3)
        assertEquals(4.5, week.costPer100Km!!, 0.001)
        assertNull(Stats.weekStats(emptyList(), at(today, "23:00"), zone).costPer100Km)
    }

    @Test
    fun `month stats keep the calendar month instead of a rolling window`() {
        val trips = listOf(
            trip("a", today, km = 20.0, minutes = 30, kwh = 3.0),
            trip("same-month", today.minusDays(20), km = 10.0, minutes = 15, kwh = 1.2),
            trip("previous-month", today.minusMonths(1), km = 50.0, minutes = 60, kwh = 7.5)
        )
        val month = Stats.monthStats(trips, at(today, "23:00"), zone, tariffPerKwh = 0.3)

        assertEquals(YearMonth.of(2026, 10), month.month)
        assertEquals(30.0, month.distanceKm, 0.001)
        assertEquals(4.2, month.energyKwh, 0.001)
        assertEquals(45, month.minutes)
        assertEquals(2, month.trips)
        assertEquals(2, month.days)
        assertEquals(14.0, month.consumption!!, 0.001)
        assertEquals(1.26, month.cost, 0.001)
        assertEquals(4.2, month.costPer100Km!!, 0.001)
        val empty = Stats.monthStats(emptyList(), at(today, "23:00"), zone)
        assertNull(empty.costPer100Km)
        assertEquals(0, empty.days)
    }

    @Test
    fun `charge summary keeps only current month and splits ac dc`() {
        val sessions = listOf(
            ChargeSession(
                id = "ac",
                startedAt = at(today, "20:00"),
                place = "Дом",
                addedPercent = 40,
                energyKwh = 16.0,
                durationMin = 120,
                type = ChargeType.AC
            ),
            ChargeSession(
                id = "dc",
                startedAt = at(today.minusDays(3), "12:00"),
                place = "Станция",
                addedPercent = 30,
                energyKwh = 12.0,
                durationMin = 30,
                type = ChargeType.DC
            ),
            ChargeSession(
                id = "previous-month",
                startedAt = at(today.minusMonths(1), "12:00"),
                place = "Станция",
                addedPercent = 20,
                energyKwh = 8.0,
                durationMin = 20,
                type = ChargeType.DC
            )
        )
        val summary = Stats.chargeSummary(
            sessions,
            at(today, "23:00"),
            zone,
            tariffPerKwh = 0.5
        )

        assertEquals(2, summary.count)
        assertEquals(YearMonth.of(2026, 10), summary.month)
        assertEquals(150, summary.minutes)
        assertEquals(28.0, summary.kwh, 0.001)
        assertEquals(14.0, summary.cost, 0.001)
        assertEquals(16.0, summary.acKwh, 0.001)
        assertEquals(12.0, summary.dcKwh, 0.001)
        assertEquals(11.2, summary.averagePowerKw, 0.001)
        assertEquals(listOf("ac", "dc"), summary.sessions.map { it.id })
    }

    @Test
    fun `charge week stats mirror the trips window and count the cost`() {
        val sessions = listOf(
            session("ac", today, "20:00", kwh = 16.0, minutes = 120),
            session("dc", today.minusDays(1), "12:00", kwh = 12.0, minutes = 30, type = ChargeType.DC),
            session("old", today.minusDays(8), "21:00", kwh = 8.0, minutes = 90)
        )
        val week = Stats.chargeWeekStats(sessions, at(today, "23:00"), zone, tariffPerKwh = 0.5)

        assertEquals(28.0, week.kwh, 0.001)
        assertEquals(150, week.minutes)
        assertEquals(2, week.sessions)
        assertEquals(14.0, week.cost, 0.001)
        assertEquals(16.0, week.acKwh, 0.001)
        assertEquals(12.0, week.dcKwh, 0.001)
        assertEquals(11.2, week.averagePowerKw, 0.001)
        assertEquals(7, week.days.size)
        assertEquals(today, week.days.last().date)
        assertEquals(today.minusDays(6), week.days.first().date)
        assertEquals(16.0, week.days.last().kwh, 0.001)
        assertEquals(1, week.days.last().sessions)
        assertEquals(120, week.days.last().minutes)

        val earlier = Stats.chargeWeekStats(sessions, at(today, "23:00"), zone, weeksBack = 1)
        assertEquals(today.minusDays(7), earlier.days.last().date)
        // today-8 попадает в окно прошлой недели: 8 кВт·ч уезжают из текущей в архивную.
        assertEquals(8.0, earlier.kwh, 0.001)
        assertEquals(1, earlier.sessions)
        assertEquals(90, earlier.minutes)
    }

    private fun session(
        id: String,
        date: LocalDate,
        time: String,
        kwh: Double,
        minutes: Int,
        type: ChargeType = ChargeType.AC
    ) = ChargeSession(
        id = id,
        startedAt = at(date, time),
        place = "Дом",
        addedPercent = 40,
        energyKwh = kwh,
        durationMin = minutes,
        type = type
    )

    @Test
    fun `average consumption and estimates use trip history`() {
        val trips = listOf(
            trip("a", today, km = 50.0, kwh = 7.0),
            trip("b", today.minusDays(1), km = 50.0, kwh = 6.0)
        )
        assertEquals(13.0, Stats.averageConsumption(trips)!!, 0.001)
        assertEquals(2.6, Stats.estimateEnergy(20.0, trips), 0.001)
        assertEquals(100.0, Stats.potentialRangeKm(13.0, trips)!!, 0.001)
        assertNull(Stats.potentialRangeKm(13.0, emptyList()))
    }

    @Test
    fun `estimate without history uses fallback rate`() {
        assertEquals(2.7, Stats.estimateEnergy(20.0, emptyList()), 0.001)
    }

    @Test
    fun `rounded soc accepts percent or watt hours and clamps`() {
        assertEquals(50, Stats.roundedSoc(50.0, null))
        assertEquals(50, Stats.roundedSoc(20000.0, 40000.0))
        assertEquals(100, Stats.roundedSoc(120.0, null))
        assertEquals(0, Stats.roundedSoc(-5.0, null))
        assertNull(Stats.roundedSoc(null, 40000.0))
        assertTrue(Stats.roundedSoc(19999.0, 40000.0) == 50)
    }

    @Test
    fun `drive mode breakdown groups by mode and skips trips without a code`() {
        val trips = listOf(
            trip("a", today, km = 20.0, kwh = 3.0).copy(driveMode = DriveMode.COMFORT),
            trip("b", today.minusDays(1), km = 10.0, kwh = 2.0).copy(driveMode = DriveMode.COMFORT),
            trip("c", today.minusDays(2), km = 20.0, kwh = 2.0).copy(driveMode = DriveMode.ECO),
            trip("d", today.minusDays(3), km = 5.0, kwh = 1.0)
        )
        val modes = Stats.byDriveMode(trips)

        assertEquals(listOf(DriveMode.COMFORT, DriveMode.ECO), modes.map { it.mode })
        assertEquals(2, modes.first().trips)
        assertEquals(30.0, modes.first().distanceKm, 0.001)
        assertEquals(5.0, modes.first().energyKwh, 0.001)
        assertEquals(16.666, modes.first().consumption!!, 0.01)
        assertEquals(10.0, modes.last().consumption!!, 0.001)
        assertTrue(Stats.byDriveMode(emptyList()).isEmpty())
    }

    @Test
    fun `drive mode breakdown leaves consumption null for a zero distance`() {
        val modes = Stats.byDriveMode(listOf(trip("a", today, km = 0.0, kwh = 0.0)
            .copy(driveMode = DriveMode.SPORT)))
        assertEquals(1, modes.size)
        assertNull(modes.first().consumption)
    }
}
