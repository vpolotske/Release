package com.ex2hub.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ChargeAlertsTest {

    @Test
    fun `threshold speaks once per charging session`() {
        val alerts = ChargeAlerts()
        assertNull(alerts.thresholdReached(soc = 40, charging = true, limitPercent = 80))
        assertEquals(81, alerts.thresholdReached(soc = 81, charging = true, limitPercent = 80))
        assertNull(alerts.thresholdReached(soc = 92, charging = true, limitPercent = 80))
        assertNull(alerts.thresholdReached(soc = 20, charging = false, limitPercent = 80))
        assertEquals(80, alerts.thresholdReached(soc = 80, charging = true, limitPercent = 80))
    }

    @Test
    fun `threshold stays silent without a limit or without the car`() {
        val alerts = ChargeAlerts()
        assertNull(alerts.thresholdReached(soc = 99, charging = true, limitPercent = 0))
        assertNull(alerts.thresholdReached(soc = null, charging = true, limitPercent = 80))
        assertNull(alerts.thresholdReached(soc = 85, charging = false, limitPercent = 80))
    }

    @Test
    fun `threshold text shows the real charge and the remaining range`() {
        val alert = ChargeAlerts.threshold(limitPercent = 80, soc = 84, rangeKm = 210)
        assertEquals(ChargeAlertKind.THRESHOLD, alert.kind)
        assertEquals("Заряд достиг 80%", alert.title)
        assertEquals("сейчас 84% · запас хода 210 км", alert.text)
        assertEquals("сейчас 84%", ChargeAlerts.threshold(80, 84, null).text)
    }

    @Test
    fun `finished text summarizes the closed session`() {
        val session = ChargeSession(
            id = "c1",
            startedAt = 1_760_000_000_000L,
            place = "Дом",
            addedPercent = 38,
            energyKwh = 20.0,
            durationMin = 80,
            type = ChargeType.AC,
            source = RecordSource.CAR
        )
        val alert = ChargeAlerts.finished(session, tariffPerKwh = 5.0)
        assertEquals(ChargeAlertKind.FINISHED, alert.kind)
        assertEquals("Зарядка завершена", alert.title)
        assertEquals("Дом · +38% · 20,0 кВт·ч · 1 ч 20 мин · 100,00 р.", alert.text)
    }

    @Test
    fun `finished text drops the cost and the place when they are absent`() {
        val session = ChargeSession(
            id = "c2",
            startedAt = 1_760_000_000_000L,
            place = "",
            addedPercent = 12,
            energyKwh = 6.0,
            durationMin = 30,
            type = ChargeType.UNKNOWN,
            source = RecordSource.MANUAL
        )
        assertEquals("+12% · 6,0 кВт·ч · 30 мин", ChargeAlerts.finished(session, 0.0).text)
    }

    @Test
    fun `alert ids are distinct and above the service notification`() {
        assertEquals(2, ChargeAlertKind.THRESHOLD.notificationId)
        assertEquals(3, ChargeAlertKind.FINISHED.notificationId)
    }
}
