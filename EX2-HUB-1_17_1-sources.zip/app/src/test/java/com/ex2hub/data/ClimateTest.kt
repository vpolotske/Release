package com.ex2hub.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ClimateTest {

    @Test
    fun `an unanswered climate is empty and gives nothing to control`() {
        assertTrue(Climate().isEmpty)
        assertEquals(0, Climate().readableSignals)
        assertFalse(Climate().controllable)
    }

    @Test
    fun `the counter covers every signal the panel can show`() {
        val one = Climate(fanSpeed = 3)
        assertFalse(one.isEmpty)
        assertEquals(1, one.readableSignals)
        assertTrue(one.controllable)

        val full = Climate(
            hvacOn = true,
            acOn = true,
            recircOn = false,
            frontDefrostOn = false,
            windshieldHeatOn = false,
            rearDefrostOn = true,
            fanSpeed = 3,
            driverTempC = 22.0,
            seatHeatDriver = 0,
            seatHeatPassenger = 1,
            wheelHeat = 0,
            fanDirection = 6
        )
        assertEquals(12, full.readableSignals)
        assertEquals(full.totalSignals, full.readableSignals)
    }

    @Test
    fun `a zero level is an answered signal, not a missing one`() {
        assertEquals(
            3,
            Climate(seatHeatDriver = 0, seatHeatPassenger = 0, wheelHeat = 0).readableSignals
        )
        assertTrue(Climate(hvacOn = false).controllable)
    }

    @Test
    fun `readback must answer every requested signal`() {
        val target = Climate(driverTempC = 24.5, fanSpeed = 2, acOn = false)
        assertTrue(Climate(driverTempC = 24.5, fanSpeed = 2, acOn = false, recircOn = true).confirms(target))
        assertFalse(Climate(driverTempC = 24.5, fanSpeed = 6, acOn = false).confirms(target))
        assertFalse(Climate(driverTempC = 24.5, fanSpeed = 2).confirms(target))
        assertFalse(Climate(driverTempC = 17.0, fanSpeed = 2, acOn = false).confirms(target))
    }

    @Test
    fun `readback temperature allows only a quarter degree tolerance`() {
        val target = Climate(driverTempC = 24.5)
        assertTrue(Climate(driverTempC = 24.25).confirms(target))
        assertFalse(Climate(driverTempC = 24.0).confirms(target))
        assertFalse(Climate(driverTempC = Double.NaN).confirms(target))
        assertFalse(Climate(driverTempC = 33.0).confirms(Climate(driverTempC = 32.0)))
        assertFalse(Climate(hvacOn = false, driverTempC = 24.5).confirms(Climate(hvacOn = true, driverTempC = 24.5)))
    }

    @Test
    fun `an accepted request alone is not confirmation`() {
        val result = ClimateWriteResult(CheckStatus.OK, "принято", applied = Climate(fanSpeed = 2))
        assertFalse(result.confirmed)
        assertEquals(null, result.observed)
    }

    @Test
    fun `single signal observation keeps every unrelated climate reading`() {
        val current = Climate(hvacOn = true, acOn = true, recircOn = false, frontDefrostOn = false,
            rearDefrostOn = true, fanSpeed = 6, driverTempC = 23.0, seatHeatDriver = 3,
            seatHeatPassenger = 2, wheelHeat = 1, fanDirection = 6)
        assertEquals(current.copy(acOn = false), current.withSignalObservation(ClimateChange.AC, Climate(acOn = false)))
        assertEquals(current.copy(fanSpeed = 0), current.withSignalObservation(ClimateChange.FAN_DOWN, Climate(fanSpeed = 0)))
        assertEquals(current.copy(driverTempC = 24.0), current.withSignalObservation(ClimateChange.DRIVER_UP, Climate(driverTempC = 24.0)))
        assertEquals(current.copy(fanDirection = 1), current.withSignalObservation(ClimateChange.DIRECTION_FACE, Climate(fanDirection = 1)))
        assertEquals(current.copy(windshieldHeatOn = true), current.withSignalObservation(ClimateChange.WINDSHIELD_HEAT, Climate(windshieldHeatOn = true)))
    }

    @Test
    fun `missing single signal readback clears only that signal`() {
        val current = Climate(hvacOn = true, acOn = true, fanSpeed = 6, driverTempC = 23.0)
        assertEquals(current.copy(acOn = null), current.withSignalObservation(ClimateChange.AC, null))
        assertEquals(current.copy(fanSpeed = null), current.withSignalObservation(ClimateChange.FAN_UP, Climate()))
    }
}
