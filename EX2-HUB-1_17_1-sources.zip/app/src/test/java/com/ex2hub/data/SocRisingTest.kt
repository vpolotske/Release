package com.ex2hub.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SocRisingTest {

    @Test
    fun `growth keeps the pulse alive between slow reads`() {
        val rise = SocRising()
        assertFalse(rise.update(soc = 50, charging = true, visible = true, now = 0L))
        assertTrue(rise.update(soc = 51, charging = true, visible = true, now = 10_000L))
        // Следующее чтение того же процента — не рост, но полоса ещё дышит.
        assertTrue(rise.update(soc = 51, charging = true, visible = true, now = 100_000L))
        assertFalse(rise.update(soc = 51, charging = true, visible = true, now = 200_000L))
    }

    @Test
    fun `hidden screen only hides the pulse and the growth is shown at once on return`() {
        val rise = SocRising()
        rise.update(soc = 50, charging = true, visible = true, now = 0L)
        assertFalse(rise.update(soc = 51, charging = true, visible = false, now = 10_000L))
        // Экран вернулся в окне удержания: рост не должен ждать нового чтения.
        assertTrue(rise.update(soc = 51, charging = true, visible = true, now = 40_000L))
    }

    @Test
    fun `charging stop clears the held growth`() {
        val rise = SocRising()
        rise.update(soc = 50, charging = true, visible = true, now = 0L)
        assertTrue(rise.update(soc = 51, charging = true, visible = true, now = 10_000L))
        assertFalse(rise.update(soc = 51, charging = false, visible = true, now = 20_000L))
        assertFalse(rise.update(soc = 51, charging = true, visible = true, now = 30_000L))
        assertTrue(rise.update(soc = 52, charging = true, visible = true, now = 40_000L))
    }

    @Test
    fun `a lost read is not mistaken for growth`() {
        val rise = SocRising()
        assertFalse(rise.update(soc = 60, charging = true, visible = true, now = 0L))
        assertFalse(rise.update(soc = 59, charging = true, visible = true, now = 10_000L))
        assertFalse(rise.update(soc = null, charging = true, visible = true, now = 20_000L))
        assertFalse(rise.update(soc = 70, charging = true, visible = true, now = 30_000L))
    }

    @Test
    fun `hold window covers the gap between telemetry reads`() {
        assertEquals(180_000L, SocRising.HOLD_MS)
    }
}
