package com.ex2hub.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.ArrayDeque
import java.util.concurrent.CyclicBarrier
import java.util.concurrent.Executor
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.TimeUnit

class CoalescingStoreWriterTest {
    @Test
    fun `a thousand pending snapshots schedule one drain and only write the newest`() {
        val executor = ManualExecutor()
        val written = mutableListOf<Int?>()
        val queue = CoalescingStoreWriter<Int>(executor) { written.add(it) }

        for (snapshot in 1..1000) queue.submit(snapshot)

        assertEquals(1, executor.submissions)
        assertEquals(1, executor.pendingCount)
        assertTrue(written.isEmpty())
        executor.runNext()
        assertEquals(listOf(1000), written)
        assertEquals(0, executor.pendingCount)

        queue.submit(1001)
        assertEquals(2, executor.submissions)
        executor.runNext()
        assertEquals(listOf(1000, 1001), written)
    }

    @Test
    fun `submissions during consumption share the drain and retain only the newest`() {
        val executor = ManualExecutor()
        val written = mutableListOf<Int?>()
        lateinit var queue: CoalescingStoreWriter<Int>
        queue = CoalescingStoreWriter(executor) { snapshot ->
            written.add(snapshot)
            if (snapshot == 0) {
                for (next in 1..1000) queue.submit(next)
                assertEquals(1, executor.submissions)
                assertEquals(0, executor.pendingCount)
            }
        }

        queue.submit(0)
        executor.runNext()

        assertEquals(listOf(0, 1000), written)
        assertEquals(1, executor.submissions)
        assertEquals(0, executor.pendingCount)
    }

    @Test
    fun `clear supersedes all older pending snapshots`() {
        val executor = ManualExecutor()
        val written = mutableListOf<Int?>()
        val queue = CoalescingStoreWriter<Int>(executor) { written.add(it) }

        for (snapshot in 1..1000) queue.submit(snapshot)
        queue.clear()
        executor.runNext()

        assertEquals(listOf<Int?>(null), written)
        assertEquals(1, executor.submissions)
    }

    @Test
    fun `a pending clear runs before the newest later save`() {
        val executor = ManualExecutor()
        val written = mutableListOf<Int?>()
        val queue = CoalescingStoreWriter<Int>(executor) { written.add(it) }

        queue.submit(-1)
        queue.clear()
        for (snapshot in 1..1000) queue.submit(snapshot)
        executor.runNext()

        assertEquals(listOf(null, 1000), written)
        assertEquals(1, executor.submissions)

        queue.clear()
        queue.submit(1001)
        queue.clear()
        queue.clear()
        executor.runNext()
        assertEquals(listOf(null, 1000, null), written)
    }

    @Test
    fun `clear during an in flight save drops old pending state but preserves later saves`() {
        val executor = ManualExecutor()
        val written = mutableListOf<Int?>()
        lateinit var queue: CoalescingStoreWriter<Int>
        queue = CoalescingStoreWriter(executor) { snapshot ->
            written.add(snapshot)
            if (snapshot == 0) {
                queue.submit(1)
                queue.clear()
                queue.submit(2)
                queue.submit(3)
            }
        }

        queue.submit(0)
        executor.runNext()

        assertEquals(listOf(0, null, 3), written)
        assertEquals(1, executor.submissions)
        assertEquals(0, executor.pendingCount)
    }

    @Test
    fun `a consumer failure is surfaced and pending work is rescheduled`() {
        val executor = ManualExecutor()
        val written = mutableListOf<Int?>()
        val failure = IllegalStateException("write failed")
        lateinit var queue: CoalescingStoreWriter<Int>
        queue = CoalescingStoreWriter(executor) { snapshot ->
            written.add(snapshot)
            if (snapshot == 0) {
                queue.submit(1)
                queue.submit(2)
                throw failure
            }
        }

        queue.submit(0)
        assertSame(failure, runCatching { executor.runNext() }.exceptionOrNull())
        assertEquals(1, executor.pendingCount)
        assertEquals(2, executor.submissions)
        queue.submit(3)
        executor.runNext()
        assertEquals(listOf(0, 3), written)
        assertEquals(0, executor.pendingCount)

        queue.submit(4)
        executor.runNext()
        assertEquals(listOf(0, 3, 4), written)
    }

    @Test
    fun `a clear failure remains visible without wedging a later save`() {
        val executor = ManualExecutor()
        val written = mutableListOf<Int?>()
        val failure = IllegalStateException("clear failed")
        lateinit var queue: CoalescingStoreWriter<Int>
        queue = CoalescingStoreWriter(executor) { snapshot ->
            written.add(snapshot)
            if (snapshot == null) {
                queue.submit(42)
                throw failure
            }
        }

        queue.clear()
        assertSame(failure, runCatching { executor.runNext() }.exceptionOrNull())
        assertEquals(1, executor.pendingCount)
        executor.runNext()
        assertEquals(listOf(null, 42), written)
        assertEquals(0, executor.pendingCount)
    }

    @Test
    fun `rejected scheduling is visible and does not prevent a new submission`() {
        val executor = ManualExecutor()
        val rejection = RejectedExecutionException("rejected")
        var reject = true
        val written = mutableListOf<Int?>()
        val queue = CoalescingStoreWriter<Int>(Executor { task ->
            if (reject) throw rejection
            executor.execute(task)
        }) { written.add(it) }

        assertSame(rejection, runCatching { queue.submit(1) }.exceptionOrNull())
        reject = false
        queue.submit(2)
        executor.runNext()
        assertEquals(listOf(2), written)
        assertEquals(0, executor.pendingCount)
    }

    @Test
    fun `failed recovery scheduling does not hide the original consumer failure`() {
        val executor = ManualExecutor()
        val failure = IllegalStateException("write failed")
        val rejection = RejectedExecutionException("recovery rejected")
        var reject = false
        val written = mutableListOf<Int?>()
        lateinit var queue: CoalescingStoreWriter<Int>
        queue = CoalescingStoreWriter(Executor { task ->
            if (reject) throw rejection
            executor.execute(task)
        }) { snapshot ->
            written.add(snapshot)
            if (snapshot == 0) {
                queue.submit(1)
                reject = true
                throw failure
            }
        }

        queue.submit(0)
        assertSame(failure, runCatching { executor.runNext() }.exceptionOrNull())
        assertEquals(1, failure.suppressed.size)
        assertSame(rejection, failure.suppressed.single())
        reject = false
        queue.submit(2)
        executor.runNext()
        assertEquals(listOf(0, 2), written)
    }

    @Test
    fun `submissions racing the drain idle handoff never lose the final state`() {
        val executor = Executors.newSingleThreadExecutor()
        val handoff = CyclicBarrier(2)
        val written = LinkedBlockingQueue<Int>()
        val queue = CoalescingStoreWriter<Int>(executor) { snapshot ->
            val value = requireNotNull(snapshot)
            written.add(value)
            if (value % 2 == 0) handoff.await(5, TimeUnit.SECONDS)
        }

        try {
            repeat(1000) { iteration ->
                val first = iteration * 2
                queue.submit(first)
                assertEquals(first, written.poll(5, TimeUnit.SECONDS))
                // Release the consumer and submit as its drain returns to the empty check.
                handoff.await(5, TimeUnit.SECONDS)
                queue.submit(first + 1)
                assertEquals(first + 1, written.poll(5, TimeUnit.SECONDS))
            }
        } finally {
            executor.shutdownNow()
            assertTrue(executor.awaitTermination(5, TimeUnit.SECONDS))
        }
    }

    private class ManualExecutor : Executor {
        private val tasks = ArrayDeque<Runnable>()
        var submissions = 0
            private set
        val pendingCount: Int get() = tasks.size

        override fun execute(command: Runnable) {
            submissions++
            tasks.addLast(command)
        }

        fun runNext() {
            tasks.removeFirst().run()
        }
    }
}
