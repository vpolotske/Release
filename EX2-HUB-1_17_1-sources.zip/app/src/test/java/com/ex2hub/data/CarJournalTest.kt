package com.ex2hub.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Журнал растёт из тех же сигналов, что и у Capy (`telemetry/TripSessionDetector.kt`,
 * `telemetry/ChargeSessionDetector.kt`), поэтому тесты гоняют конечный автомат на
 * фиксированном времени. Важно не только то, что запись появилась, но и когда именно
 * она закрылась и какие числа в неё попали: поездку нельзя записать «на глаз».
 */
class CarJournalTest {

    private val minute = 60_000L
    private val profile = Profile(batteryKwh = 40.0)

    private fun car(
        odometer: Double? = 100.0,
        speed: Int? = 0,
        gear: Gear? = null,
        soc: Int? = 80,
        flow: ChargeFlow? = ChargeFlow.IDLE,
        powerKw: Double? = null,
        workMin: Int? = null,
        connector: ChargeType? = null,
        powerSource: ChargePowerSource? = null,
        source: SourceMode = SourceMode.CAR_API,
        fallback: Boolean = false,
        stale: Boolean = false
    ) = VehicleSnapshot(
        source = source,
        odometerKm = odometer,
        speedKmh = speed,
        gear = gear,
        soc = soc,
        chargeFlow = flow,
        chargePowerKw = powerKw,
        isCharging = when (flow) {
            ChargeFlow.AC, ChargeFlow.DC, ChargeFlow.HEATING -> true
            ChargeFlow.PLUGGED -> powerKw != null && powerKw >= 0.2
            else -> false
        },
        chargeWorkMin = workMin,
        chargeConnectorType = connector,
        chargePowerSource = powerSource,
        isFallback = fallback,
        stale = stale
    )

    private fun trip(startedAt: Long = 0L) = Trip(
        id = "old",
        startedAt = startedAt,
        from = "дом",
        to = "работа",
        distanceKm = 10.0,
        durationMin = 20,
        energyKwh = 1.5,
        source = RecordSource.MANUAL
    )

    private fun journal() = CarJournal(idFactory = { "id" })

    // --- Поездки ---------------------------------------------------------------

    @Test
    fun `trip is armed by drive gear and written after half a minute of park`() {
        val journal = journal()
        assertTrue(journal.observe(car(), profile, emptyList(), 0L).trips.isEmpty())
        assertNull(journal.trip)

        journal.observe(car(odometer = 101.0, speed = 40, gear = Gear.D), profile, emptyList(), minute)
        assertNotNull(journal.trip)

        journal.observe(car(odometer = 103.0, speed = 0, gear = Gear.P), profile, emptyList(), 2 * minute)
        assertNotNull(journal.trip)

        // P только что появилась: Capy подтверждает передачу тридцатью секундами тишины.
        val tooEarly = journal.observe(
            car(odometer = 103.0, speed = 0, gear = Gear.P, soc = 78),
            profile, emptyList(), 3 * minute
        )
        assertTrue(tooEarly.trips.isEmpty())

        val update = journal.observe(
            car(odometer = 103.0, speed = 0, gear = Gear.P, soc = 78),
            profile, emptyList(), 3 * minute + 40_000L
        )
        val written = update.trips.single()
        assertEquals(3.0, written.distanceKm, 0.001)
        // Поездка закрыта на подтверждении P, а не на момент записи: 3 − 1 минута.
        assertEquals(2, written.durationMin)
        assertEquals(0.8, written.energyKwh, 0.001)
        assertEquals(Fmt.time(minute), written.from)
        assertEquals(Fmt.time(3 * minute), written.to)
        assertFalse("Route labels must not read as mileage", written.from.contains("км"))
        assertEquals(RecordSource.CAR, written.source)
        assertTrue(written.energyEstimated)
        assertTrue(written.note.contains("ΔSOC 2%"))
        assertNull(journal.trip)
        assertTrue(update.notes.any { it.contains("поездка записана") })
    }

    @Test
    fun `trip distance comes from the odometer only and never from a second counter`() {
        val journal = journal()
        // Во время поездки одометр пропал, а затем вернулся меньшим числом — так
        // выглядел резерв 0x2140A6AC (запас хода 61 км рядом с одометром 5528,1).
        journal.observe(
            car(odometer = 5528.1, speed = 40, gear = Gear.D),
            profile, emptyList(), minute
        )
        assertNotNull(journal.trip)
        journal.observe(
            car(odometer = 5529.1, speed = 40, gear = Gear.D),
            profile, emptyList(), 2 * minute
        )
        // Пропуск чтения и меньшее число не превращаются в тысячи километров.
        journal.observe(
            car(odometer = null, speed = 40, gear = Gear.D),
            profile, emptyList(), 3 * minute
        )
        journal.observe(
            car(odometer = 5530.0, speed = 0, gear = Gear.P),
            profile, emptyList(), 4 * minute
        )
        // Стоянка подтверждается 30 с: первый P только запускает отсчёт.
        journal.observe(
            car(odometer = 5530.0, speed = 0, gear = Gear.P),
            profile, emptyList(), 4 * minute + 40_000L
        )
        val update = journal.observe(
            car(odometer = 5530.0, speed = 0, gear = Gear.P),
            profile, emptyList(), 5 * minute + 20_000L
        )
        assertEquals(1.9, update.trips.single().distanceKm, 0.001)
    }

    @Test
    fun `an odometer that drops back rebases instead of booking a negative-odd trip`() {
        val journal = journal()
        journal.observe(car(), profile, emptyList(), 0L)
        journal.observe(
            car(odometer = 61.0, speed = 40, gear = Gear.D),
            profile, emptyList(), minute
        )
        val anchor = journal.trip
        assertNotNull(anchor)
        assertEquals(61.0, anchor!!.startOdometerKm!!, 0.001)
        journal.observe(
            car(odometer = 63.5, speed = 0, gear = Gear.P),
            profile, emptyList(), 2 * minute
        )
        journal.observe(
            car(odometer = 63.5, speed = 0, gear = Gear.P),
            profile, emptyList(), 2 * minute + 40_000L
        )
        val update = journal.observe(
            car(odometer = 63.5, speed = 0, gear = Gear.P),
            profile, emptyList(), 3 * minute + 20_000L
        )
        assertEquals(2.5, update.trips.single().distanceKm, 0.001)
    }

    @Test
    fun `trip that did not spend any charge is estimated and labelled`() {
        val journal = journal()
        journal.observe(car(odometer = 100.0, speed = 40, gear = Gear.D), profile, emptyList(), 0L)
        journal.observe(car(odometer = 103.0, speed = 0, gear = Gear.P), profile, emptyList(), minute)
        journal.observe(car(odometer = 103.0, speed = 0, gear = Gear.P), profile, emptyList(), 2 * minute)
        val update = journal.observe(
            car(odometer = 103.0, speed = 0, gear = Gear.P),
            profile, emptyList(), 2 * minute + 40_000L
        )
        val written = update.trips.single()
        // Три километра по запасному среднему расходу приложения: 3 · 13,5 / 100.
        assertEquals(0.4, written.energyKwh, 0.001)
        assertTrue(written.note.contains("заряд не упал"))
        assertNull(journal.trip)
    }

    @Test
    fun `odometer growth alone starts a trip even without gear or speed`() {
        val journal = journal()
        journal.observe(car(odometer = 100.0, speed = null, gear = null), profile, emptyList(), 0L)
        assertNull(journal.trip)

        journal.observe(car(odometer = 100.6, speed = null, gear = null), profile, emptyList(), minute)
        assertNotNull(journal.trip)

        // Следующий ответ уже показывает рост пробега: поездка продолжилась.
        journal.observe(car(odometer = 100.6, speed = null, gear = null), profile, emptyList(), 2 * minute)
        assertNotNull(journal.trip)

        // Дальше десять минут тишины без P от прошивки — наше правило конца поездки.
        val update = journal.observe(
            car(odometer = 100.6, speed = null, gear = null),
            profile, emptyList(), 12 * minute
        )
        val written = update.trips.single()
        assertEquals(0.6, written.distanceKm, 0.001)
        assertEquals(1, written.durationMin)
        assertNull(journal.trip)
    }

    @Test
    fun `trip shorter than the odometer threshold is dropped with a note`() {
        val journal = journal()
        journal.observe(car(odometer = 100.0, speed = 40, gear = Gear.D), profile, emptyList(), 0L)
        journal.observe(car(odometer = 100.1, speed = 0, gear = Gear.P), profile, emptyList(), minute)
        journal.observe(car(odometer = 100.1, speed = 0, gear = Gear.P), profile, emptyList(), 2 * minute)
        val update = journal.observe(
            car(odometer = 100.1, speed = 0, gear = Gear.P),
            profile, emptyList(), 2 * minute + 40_000L
        )
        assertTrue(update.trips.isEmpty())
        assertTrue(update.notes.any { it.contains("короче порога") })
        assertNull(journal.trip)
    }

    @Test
    fun `plugging into a charger closes the trip that is running`() {
        val journal = journal()
        journal.observe(car(odometer = 100.0, speed = 40, gear = Gear.D), profile, emptyList(), 0L)
        val update = journal.observe(
            car(odometer = 103.0, speed = 0, gear = Gear.N, flow = ChargeFlow.AC),
            profile, emptyList(), minute
        )
        assertEquals(3.0, update.trips.single().distanceKm, 0.001)
        assertNull(journal.trip)
        assertNotNull(journal.charge)
    }

    @Test
    fun `a trip that never moved is closed by the charger without a record`() {
        val journal = journal()
        journal.observe(car(odometer = 100.0, speed = 40, gear = Gear.D), profile, emptyList(), 0L)
        val update = journal.observe(
            car(odometer = 100.0, flow = ChargeFlow.AC, soc = 20),
            profile, emptyList(), minute
        )
        // TripEndReason.CHARGING_STARTED закрыл поездку, но писать нечего: пробег не вёлся.
        assertNull(journal.trip)
        assertTrue(update.trips.isEmpty())
        assertTrue(update.notes.none { it.contains("поездка записана") })
    }

    @Test
    fun `a trip already in the journal is not written a second time`() {
        val journal = journal()
        journal.observe(car(odometer = 100.0, speed = 40, gear = Gear.D), profile, emptyList(), 0L)
        journal.observe(car(odometer = 103.0, speed = 0, gear = Gear.P), profile, emptyList(), minute)
        journal.observe(car(odometer = 103.0, speed = 0, gear = Gear.P), profile, emptyList(), 2 * minute)
        val update = journal.observe(
            car(odometer = 103.0, speed = 0, gear = Gear.P),
            profile, listOf(trip(startedAt = 0L)), 2 * minute + 40_000L
        )
        assertTrue(update.trips.isEmpty())
        assertTrue(update.notes.any { it.contains("уже в журнале") })
        assertNull(journal.trip)
    }

    @Test
    fun `an anchor older than a day is discarded instead of written`() {
        val journal = journal()
        journal.observe(car(odometer = 100.0, speed = 40, gear = Gear.D), profile, emptyList(), 0L)
        val update = journal.observe(car(odometer = 103.0, speed = 0), profile, emptyList(), 25 * 60 * minute)
        assertTrue(update.trips.isEmpty())
        assertNull(journal.trip)
        assertTrue(update.notes.any { it.contains("якорь сброшен") })
    }

    @Test
    fun `trip restored after a restart keeps the distance it already knew`() {
        val anchor = TripAnchor(
            startedAt = 0L,
            startOdometerKm = 100.0,
            startSoc = 80,
            lastMovingAt = minute,
            distanceKm = 3.0
        )
        val journal = CarJournal(restoredTrip = anchor, idFactory = { "id" })
        journal.observe(car(odometer = 103.0, speed = 0, gear = Gear.P), profile, emptyList(), 2 * minute)
        val update = journal.observe(
            car(odometer = 103.0, speed = 0, gear = Gear.P, soc = 79),
            profile, emptyList(), 2 * minute + 40_000L
        )
        val written = update.trips.single()
        assertEquals(3.0, written.distanceKm, 0.001)
        assertEquals(0L, written.startedAt)
        // Один процент на батарее 40 кВт·ч — те же 0,4 кВт·ч, но уже по ΔSOC.
        assertEquals(0.4, written.energyKwh, 0.001)
        assertTrue(written.note.contains("ΔSOC 1%"))
    }

    @Test
    fun `journal stays shut for sources that cannot name a trip`() {
        listOf(
            car(odometer = 105.0, speed = 60, gear = Gear.D, source = SourceMode.DEMO),
            car(odometer = 105.0, speed = 60, gear = Gear.D, fallback = true),
            car(odometer = 105.0, speed = 60, gear = Gear.D, stale = true),
            car(odometer = 105.0, speed = 60, gear = Gear.D, source = SourceMode.ROOT)
        ).forEach { snapshot ->
            val journal = journal()
            val update = journal.observe(snapshot, profile, emptyList(), 0L)
            assertTrue(update.trips.isEmpty())
            assertTrue(update.sessions.isEmpty())
            assertNull(journal.trip)
            assertNull(journal.charge)
        }
    }

    // --- Зарядки ---------------------------------------------------------------

    @Test
    fun `charge is written after ten quiet minutes with the car clock`() {
        val journal = journal()
        assertTrue(
            journal.observe(car(flow = ChargeFlow.IDLE, soc = 20), profile, emptyList(), 0L)
                .sessions.isEmpty()
        )

        journal.observe(car(flow = ChargeFlow.AC, soc = 20), profile, emptyList(), minute)
        assertNotNull(journal.charge)

        journal.observe(
            car(flow = ChargeFlow.AC, soc = 25, workMin = 9),
            profile, emptyList(), 10 * minute
        )
        journal.observe(car(flow = ChargeFlow.FINISHED, soc = 25), profile, emptyList(), 20 * minute)
        assertNotNull(journal.charge?.stoppedSince)

        val update = journal.observe(
            car(flow = ChargeFlow.FINISHED, soc = 25),
            profile, emptyList(), 31 * minute
        )
        val session = update.sessions.single()
        assertEquals(5, session.addedPercent)
        assertEquals(2.0, session.energyKwh, 0.001)
        // Длительность взята из CHARGING_WORK_TIME, а не из часов приложения (19 мин).
        assertEquals(9, session.durationMin)
        assertEquals(ChargeType.AC, session.type)
        assertEquals(RecordSource.CAR, session.source)
        assertTrue("Энергия по шагу SOC — оценка", session.energyEstimated)
        assertEquals("Автомобиль · время машины", session.place)
        assertNull(journal.charge)
        assertTrue(update.notes.any { it.contains("по часам автомобиля") })
    }

    @Test
    fun `plugged cable with measured power is a session, without it is not`() {
        // Так отвечает живое ГУ (проба 2026-10-25): состояние заряда приходит коротким
        // числом вне таблицы, поэтому сессию держат разъём с измеренной мощностью.
        val waiting = journal()
        waiting.observe(car(flow = ChargeFlow.PLUGGED, soc = 20), profile, emptyList(), 0L)
        assertNull(waiting.charge)

        val journal = journal()
        journal.observe(
            car(flow = ChargeFlow.PLUGGED, soc = 20, powerKw = 1.0),
            profile, emptyList(), 0L
        )
        assertNotNull(journal.charge)
        // Времени машины нет: CHARGING_WORK_TIME берут только из расшифрованных состояний.
        assertNull(journal.charge?.carMinutes)

        journal.observe(
            car(flow = ChargeFlow.PLUGGED, soc = 26, powerKw = 1.0),
            profile, emptyList(), 5 * minute
        )
        journal.observe(car(flow = ChargeFlow.IDLE, soc = 26), profile, emptyList(), 10 * minute)
        val update = journal.observe(
            car(flow = ChargeFlow.IDLE, soc = 26), profile, emptyList(), 21 * minute
        )
        val session = update.sessions.single()
        assertEquals(6, session.addedPercent)
        assertEquals(2.4, session.energyKwh, 0.001)
        assertEquals(10, session.durationMin)
        assertEquals("Автомобиль", session.place)
        assertTrue(update.notes.any { it.contains("по часам приложения") })
    }

    @Test
    fun `a pause inside the quiet window stays one session`() {
        val journal = journal()
        journal.observe(car(flow = ChargeFlow.AC, soc = 20), profile, emptyList(), 0L)
        journal.observe(car(flow = ChargeFlow.FINISHED, soc = 22), profile, emptyList(), 10 * minute)
        val resume = journal.observe(
            car(flow = ChargeFlow.AC, soc = 30, workMin = 24),
            profile, emptyList(), 15 * minute
        )
        assertTrue(resume.sessions.isEmpty())
        assertNotNull(journal.charge)
        assertNull(journal.charge?.stoppedSince)

        val stop = journal.observe(
            car(flow = ChargeFlow.FINISHED, soc = 30),
            profile, emptyList(), 25 * minute
        )
        assertTrue(stop.sessions.isEmpty())
        assertNotNull(journal.charge)
        // Сессия всё ещё одна и та же: её начало не сдвинулось после паузы.
        assertEquals(0L, journal.charge?.startedAt)
    }

    @Test
    fun `charge that added nothing is not written`() {
        val journal = journal()
        journal.observe(car(flow = ChargeFlow.AC, soc = 20), profile, emptyList(), 0L)
        journal.observe(car(flow = ChargeFlow.AC, soc = 20), profile, emptyList(), 5 * minute)
        journal.observe(car(flow = ChargeFlow.SUSPENDED, soc = 20), profile, emptyList(), 10 * minute)
        val update = journal.observe(
            car(flow = ChargeFlow.SUSPENDED, soc = 20),
            profile, emptyList(), 21 * minute
        )
        assertTrue(update.sessions.isEmpty())
        assertTrue(update.notes.any { it.contains("не добавила процентов") })
        assertNull(journal.charge)
    }

    @Test
    fun `charge without a soc reading has nothing to record`() {
        val journal = journal()
        journal.observe(car(flow = ChargeFlow.AC, soc = null), profile, emptyList(), 0L)
        journal.observe(car(flow = ChargeFlow.FINISHED, soc = null), profile, emptyList(), 10 * minute)
        val update = journal.observe(
            car(flow = ChargeFlow.FINISHED, soc = null),
            profile, emptyList(), 21 * minute
        )
        assertTrue(update.sessions.isEmpty())
        assertTrue(update.notes.any { it.contains("без SOC") })
        assertNull(journal.charge)
    }

    @Test
    fun `dc current is a dc session and heating is an alternating one`() {
        val dc = journal()
        dc.observe(car(flow = ChargeFlow.DC, soc = 20), profile, emptyList(), 0L)
        assertEquals(ChargeType.DC, dc.charge?.type)

        val heating = journal()
        heating.observe(car(flow = ChargeFlow.HEATING, soc = 20), profile, emptyList(), 0L)
        assertEquals(ChargeType.AC, heating.charge?.type)

        // Подключённый кабель без заряда — ещё не сессия.
        val plugged = journal()
        plugged.observe(car(flow = ChargeFlow.PLUGGED, soc = 20), profile, emptyList(), 0L)
        assertNull(plugged.charge)
    }

    @Test
    fun `one contradictory reading keeps the type while two in a row lose it`() {
        val journal = journal()
        // Поток говорит «сеть», разъём — «постоянка». Одно такое чтение — шум прошивки,
        // тип сессии должен вернуться, как только каналы снова согласны.
        journal.observe(
            car(flow = ChargeFlow.AC, connector = ChargeType.DC, soc = 20),
            profile, emptyList(), 0L
        )
        assertEquals(ChargeType.UNKNOWN, journal.charge?.type)

        journal.observe(car(flow = ChargeFlow.AC, soc = 21), profile, emptyList(), minute)
        assertEquals(ChargeType.AC, journal.charge?.type)

        val stuck = journal()
        stuck.observe(
            car(flow = ChargeFlow.AC, connector = ChargeType.DC, soc = 20),
            profile, emptyList(), 0L
        )
        stuck.observe(
            car(flow = ChargeFlow.AC, connector = ChargeType.DC, soc = 21),
            profile, emptyList(), minute
        )
        // Два чтения подряд спорят — ни одному каналу нельзя верить до конца сессии.
        stuck.observe(car(flow = ChargeFlow.AC, soc = 22), profile, emptyList(), 2 * minute)
        assertEquals(ChargeType.UNKNOWN, stuck.charge?.type)
    }

    @Test
    fun `integrated charge power is recorded as a measurement, not an estimate`() {
        val journal = journal()
        // SOC молчит, мощность измеряется: энергия берётся из интегратора, а не из ёмкости.
        journal.observe(
            car(flow = ChargeFlow.AC, soc = null, powerKw = 7.0, powerSource = ChargePowerSource.AC_METER),
            profile, emptyList(), 0L
        )
        journal.observe(
            car(flow = ChargeFlow.AC, soc = null, powerKw = 7.0, powerSource = ChargePowerSource.AC_METER),
            profile, emptyList(), 30_000L
        )
        journal.observe(
            car(flow = ChargeFlow.AC, soc = null, powerKw = 7.0, powerSource = ChargePowerSource.AC_METER),
            profile, emptyList(), 60_000L
        )
        journal.observe(
            car(flow = ChargeFlow.AC, soc = null, powerKw = 7.0, powerSource = ChargePowerSource.AC_METER),
            profile, emptyList(), 90_000L
        )
        journal.observe(car(flow = ChargeFlow.FINISHED, soc = null), profile, emptyList(), 11 * minute)
        val update = journal.observe(
            car(flow = ChargeFlow.FINISHED, soc = null), profile, emptyList(), 22 * minute
        )

        val session = update.sessions.single()
        assertFalse("Измеренная мощность — не оценка", session.energyEstimated)
        assertEquals(0, session.addedPercent)
        // Три шага по 30 с при 7 кВт: 7 × 90 / 3600.
        assertEquals(0.175, session.energyKwh, 0.001)
        assertEquals(ChargeType.AC, session.type)
    }

    @Test
    fun `reset forgets anchors so they cannot write into another journal`() {
        val trips = journal()
        trips.observe(car(odometer = 100.0, speed = 40, gear = Gear.D), profile, emptyList(), 0L)
        trips.observe(car(odometer = 103.0, speed = 40, gear = Gear.D), profile, emptyList(), minute)
        assertNotNull(trips.trip)

        val charges = journal()
        charges.observe(car(flow = ChargeFlow.AC, soc = 20), profile, emptyList(), 0L)
        assertNotNull(charges.charge)

        trips.reset()
        charges.reset()
        assertNull(trips.trip)
        assertNull(charges.charge)

        // Якорей нет — значит незакрытая сессия прошлого источника не допишет запись.
        assertTrue(
            trips.observe(car(odometer = 103.0, speed = 0, gear = Gear.P), profile, emptyList(), 2 * minute)
                .trips.isEmpty()
        )
        assertTrue(
            charges.observe(car(flow = ChargeFlow.FINISHED, soc = 30), profile, emptyList(), 2 * minute)
                .sessions.isEmpty()
        )
    }
}
