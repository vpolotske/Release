package com.ex2hub.data

import org.junit.Assert.assertEquals
import org.junit.Test

/** Деньги и тарифы видны до сотой: копейки не должны пропадать в округлении. */
class FmtTest {
    @Test
    fun `money keeps two decimals`() {
        assertEquals("5,50 р.", Fmt.money(5.5))
        assertEquals("0,28 р.", Fmt.money(0.28))
        assertEquals("123,46 р.", Fmt.money(123.456))
        assertEquals("—", Fmt.money(null))
    }

    @Test
    fun `n2 formats tariffs like money`() {
        assertEquals("5,50", Fmt.n2(5.5))
        assertEquals("0,00", Fmt.n2(0.0))
        assertEquals("—", Fmt.n2(null))
    }
}
