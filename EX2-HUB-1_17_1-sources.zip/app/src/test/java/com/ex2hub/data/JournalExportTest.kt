package com.ex2hub.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.ZoneId

/**
 * Выгрузка читается Excel и программами, поэтому важны ровно три вещи: разделитель,
 * количество полей и десятичная запятая. Проверки идут по тексту файла, а не по
 * внутренним спискам — так тест ловит расхождение заголовка и строк.
 */
class JournalExportTest {

    private val utc: ZoneId = ZoneId.of("UTC")

    private fun trip(
        id: String = "t1",
        startedAt: Long = 1_760_000_000_000L,
        note: String = "",
        fromLat: Double? = null,
        fromLon: Double? = null
    ) = Trip(
        id = id,
        startedAt = startedAt,
        from = "Дом",
        to = "Работа",
        distanceKm = 12.34,
        durationMin = 21,
        energyKwh = 2.5,
        note = note,
        source = RecordSource.CAR,
        driveMode = DriveMode.COMFORT,
        regen = RegenLevel.MID,
        fromLat = fromLat,
        fromLon = fromLon
    )

    @Test
    fun `trips csv ends every line with crlf and has one line per trip`() {
        val csv = JournalExport.tripsCsv(
            listOf(trip(id = "b", startedAt = 1_760_100_000_000L), trip(id = "a", startedAt = 1_760_000_000_000L)),
            tariffPerKwh = 5.0,
            zone = utc
        )
        val lines = csv.linesOfTable()
        assertEquals(3, lines.size)
        assertTrue(csv.endsWith(JournalExport.LINE_END))
        assertEquals("Ид", lines.first().split(";").first())
        assertEquals("a", lines[1].split(";").first())
        assertEquals("b", lines[2].split(";").first())
    }

    @Test
    fun `every trip row repeats the header column count`() {
        val csv = JournalExport.tripsCsv(
            listOf(trip(note = "Поездки; с \"кавычкой\"", fromLat = 59.9381, fromLon = 30.3152)),
            tariffPerKwh = 5.0,
            zone = utc
        )
        val header = csv.linesOfTable().first().parseRow()
        val row = csv.linesOfTable()[1].parseRow()
        assertEquals(20, header.size)
        assertEquals(header.size, row.size)
        assertEquals("Поездки; с \"кавычкой\"", row[15])
        assertEquals("59,93810", row[16])
        assertEquals("30,31520", row[17])
        assertEquals("", row[18])
        assertEquals("", row[19])
    }

    @Test
    fun `trip numbers use the comma decimal separator like the screen`() {
        val row = JournalExport.tripsCsv(listOf(trip()), 5.0, utc)
            .linesOfTable()[1].parseRow()
        assertEquals("12,3", row[5])
        assertEquals("21", row[6])
        assertEquals("2,5", row[7])
        assertEquals("20,3", row[8])
        assertEquals("12,50", row[9])
        assertEquals("COMFORT", row[10])
        assertEquals("MID", row[11])
        assertEquals("CAR", row[14])
    }

    @Test
    fun `flags stay empty instead of writing false`() {
        val rows = JournalExport.tripsCsv(listOf(trip()), 5.0, utc).linesOfTable()
        assertEquals("", rows[1].parseRow()[12])
        assertEquals("", rows[1].parseRow()[13])
        val estimated = JournalExport.tripsCsv(
            listOf(trip().copy(energyEstimated = true, mixedDriveMode = true)),
            5.0,
            utc
        ).linesOfTable()[1].parseRow()
        assertEquals("да", estimated[12])
        assertEquals("да", estimated[13])
    }

    @Test
    fun `empty journal exports only the header`() {
        val trips = JournalExport.tripsCsv(emptyList(), 5.0, utc)
        assertEquals(1, trips.linesOfTable().size)
        assertTrue(trips.startsWith("Ид;Дата;Время;Откуда;Куда;"))
        val charges = JournalExport.chargesCsv(emptyList(), 5.0, utc)
        assertEquals(1, charges.linesOfTable().size)
        assertTrue(charges.startsWith("Ид;Дата;Время;Место;Тип;"))
    }

    @Test
    fun `charge row keeps power and cost computed the same way as the journal`() {
        val csv = JournalExport.chargesCsv(
            listOf(
                ChargeSession(
                    id = "c1",
                    startedAt = 1_760_000_000_000L,
                    place = "Дом",
                    addedPercent = 38,
                    energyKwh = 20.0,
                    durationMin = 60,
                    type = ChargeType.AC,
                    source = RecordSource.CAR
                )
            ),
            5.0,
            utc
        )
        val header = csv.linesOfTable().first().parseRow()
        val row = csv.linesOfTable()[1].parseRow()
        assertEquals(header.size, row.size)
        assertEquals(12, header.size)
        assertEquals("38", row[5])
        assertEquals("20,0", row[6])
        assertEquals("20,0", row[8])
        assertEquals("100,00", row[9])
        assertEquals("AC", row[4])
    }

    @Test
    fun `cell quotes only what the separator or a line break would break`() {
        assertEquals("обычное поле", JournalExport.cell("обычное поле"))
        assertEquals("\"а;б\"", JournalExport.cell("а;б"))
        assertEquals("\"с \"\"кавычкой\"\"\"", JournalExport.cell("с \"кавычкой\""))
        assertEquals("\"две\nстроки\"", JournalExport.cell("две\nстроки"))
    }

    private fun String.linesOfTable(): List<String> =
        split(JournalExport.LINE_END).filter { it.isNotEmpty() }

    /** Разбор по состоянию, а не split: поле в кавычках может содержать разделитель. */
    private fun String.parseRow(): List<String> {
        val cells = mutableListOf<String>()
        val current = StringBuilder()
        var quoted = false
        var index = 0
        while (index < length) {
            val symbol = this[index]
            when {
                quoted && symbol == '"' && getOrNull(index + 1) == '"' -> {
                    current.append('"'); index++
                }
                symbol == '"' -> quoted = !quoted
                symbol == ';' && !quoted -> {
                    cells += current.toString(); current.setLength(0)
                }
                else -> current.append(symbol)
            }
            index++
        }
        cells += current.toString()
        return cells
    }
}
