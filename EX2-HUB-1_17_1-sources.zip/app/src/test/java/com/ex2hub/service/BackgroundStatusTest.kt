package com.ex2hub.service

import com.ex2hub.data.ChargeAnchor
import com.ex2hub.data.ChargeType
import com.ex2hub.data.SourceMode
import com.ex2hub.data.TripAnchor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BackgroundStatusTest {
    private val trip = TripAnchor(
        startedAt = 0L,
        startOdometerKm = 100.0,
        startSoc = 80,
        lastMovingAt = 0L,
        distanceKm = 12.3
    )
    private val charge = ChargeAnchor(
        startedAt = 0L,
        startSoc = 40,
        type = ChargeType.AC,
        lastChargingAt = 0L
    )

    @Test
    fun `idle car api says the journal runs in the background`() {
        val status = BackgroundStatus.of(SourceMode.CAR_API, null, null, null, 70, null)
        assertEquals("Car API: журнал ведётся в фоне", status.title)
        assertTrue(status.text.contains("без открытого экрана"))
    }

    @Test
    fun `running trip and charge are named in the title`() {
        val driving = BackgroundStatus.of(SourceMode.CAR_API, null, trip, null, 70, null)
        assertTrue(driving.title.startsWith("Поездка идёт"))
        assertTrue(driving.title.contains("км"))

        val charging = BackgroundStatus.of(SourceMode.CAR_API, null, null, charge, 54, null)
        assertEquals("Зарядка идёт · 54%", charging.title)
        assertEquals("Зарядка идёт", BackgroundStatus.of(SourceMode.CAR_API, null, null, charge, null, null).title)
    }

    @Test
    fun `gps recording wins the title and works without polling`() {
        val status = BackgroundStatus.of(SourceMode.DEMO, 3.2, trip, null, null, null)
        assertTrue(status.title.startsWith("GPS-запись поездки"))
        assertTrue(status.text.contains("пока не остановлена"))
    }

    @Test
    fun `anchors of another source do not pretend to be a car session`() {
        val status = BackgroundStatus.of(SourceMode.MANUAL, null, trip, charge, 50, null)
        assertEquals("EX2 HUB", status.title)
    }

    @Test
    fun `root polling does not promise an automatic car journal`() {
        val status = BackgroundStatus.of(SourceMode.ROOT, null, trip, charge, 50, null)
        assertEquals("Root: чтение данных в фоне", status.title)
        assertTrue(status.text.contains("root-команд"))
    }

    @Test
    fun `the last journal note replaces the generic text`() {
        val status = BackgroundStatus.of(SourceMode.CAR_API, null, null, null, null, "поездка записана: 4,1 км")
        assertEquals("поездка записана: 4,1 км", status.text)
    }
}
