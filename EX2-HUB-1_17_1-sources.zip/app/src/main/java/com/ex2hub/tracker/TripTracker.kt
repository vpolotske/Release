package com.ex2hub.tracker

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import androidx.core.content.ContextCompat
import com.ex2hub.data.TrackResult
import kotlin.math.roundToInt

class TripTracker(
    context: Context,
    private val onUpdate: (distanceKm: Double, points: Int) -> Unit,
    private val onError: (String) -> Unit
) {
    private val appContext = context.applicationContext
    private val locationManager =
        appContext.getSystemService(Context.LOCATION_SERVICE) as? LocationManager

    private var manager: LocationManager? = null
    private var listener: LocationListener? = null
    private var startedAt = 0L
    private var distanceMeters = 0.0
    private var points = 0
    private var lastLocation: Location? = null
    private var firstFix: Location? = null
    private var lastTrackFix: Location? = null

    var lastError: String? = null
        private set

    val isRunning: Boolean
        get() = listener != null

    fun start(): Boolean {
        if (isRunning) return true
        if (!hasAnyLocationPermission(appContext)) {
            lastError = "Нет разрешения на геолокацию"
            return false
        }
        val lm = locationManager
        if (lm == null) {
            lastError = "Служба геолокации недоступна"
            return false
        }

        val fine = hasPreciseLocationPermission(appContext)
        val gpsEnabled = runCatching { lm.isProviderEnabled(LocationManager.GPS_PROVIDER) }.getOrDefault(false)
        val networkEnabled = runCatching { lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) }.getOrDefault(false)
        val provider = when {
            fine && gpsEnabled -> LocationManager.GPS_PROVIDER
            networkEnabled -> LocationManager.NETWORK_PROVIDER
            gpsEnabled -> LocationManager.GPS_PROVIDER
            else -> {
                lastError = "GPS выключен на устройстве"
                return false
            }
        }

        val locationListener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                handleLocation(location)
            }

            @Deprecated("Deprecated in the platform, kept for older head units")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit

            override fun onProviderEnabled(provider: String) = Unit

            override fun onProviderDisabled(provider: String) {
                onError("GPS-провайдер отключён")
            }
        }

        return try {
            lm.requestLocationUpdates(provider, 1000L, 2f, locationListener, Looper.getMainLooper())
            manager = lm
            listener = locationListener
            startedAt = System.currentTimeMillis()
            distanceMeters = 0.0
            points = 0
            lastLocation = null
            firstFix = null
            lastTrackFix = null
            lastError = null
            onUpdate(0.0, 0)
            true
        } catch (t: SecurityException) {
            lastError = "Доступ к геолокации запрещён"
            false
        } catch (t: Throwable) {
            lastError = t.message ?: "Не удалось запустить запись"
            false
        }
    }

    fun stop(): TrackResult? {
        val started = startedAt
        val from = firstFix
        val to = lastTrackFix ?: from
        runCatching { manager?.removeUpdates(listener ?: return@runCatching) }
        manager = null
        listener = null
        lastLocation = null
        firstFix = null
        lastTrackFix = null
        startedAt = 0L
        if (started <= 0L) return null
        val distanceKm = distanceMeters / 1000.0
        val minutes = ((System.currentTimeMillis() - started) / 60_000.0)
            .roundToInt()
            .coerceAtLeast(1)
        return TrackResult(
            startedAt = started,
            distanceKm = (distanceKm * 10).roundToInt() / 10.0,
            durationMin = minutes,
            fromLat = from?.latitude,
            fromLon = from?.longitude,
            toLat = to?.latitude,
            toLon = to?.longitude
        )
    }

    private fun handleLocation(location: Location) {
        if (!location.hasAccuracy() || location.accuracy > 60f) return
        if (location.isFromMockProvider) return

        val previous = lastLocation
        if (previous == null) {
            lastLocation = location
            firstFix = location
            return
        }
        if (location.time <= previous.time) return

        val delta = previous.distanceTo(location).toDouble()
        val seconds = ((location.time - previous.time) / 1000.0).coerceAtLeast(0.001)
        val impliedSpeed = delta / seconds
        lastLocation = location

        if (delta < 1.5 || delta > 2000.0) return
        if (impliedSpeed < 0.8 && delta < 20.0) return

        distanceMeters += delta
        points += 1
        lastTrackFix = location
        onUpdate(distanceMeters / 1000.0, points)
    }

    companion object {
        fun hasAnyLocationPermission(context: Context): Boolean {
            val fine = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
            val coarse = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
            return fine || coarse
        }

        fun hasPreciseLocationPermission(context: Context): Boolean =
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
    }
}
