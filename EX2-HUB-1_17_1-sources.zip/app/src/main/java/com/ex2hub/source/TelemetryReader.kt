package com.ex2hub.source

import android.content.Context
import com.ex2hub.data.CheckStatus
import com.ex2hub.data.ClimateChange
import com.ex2hub.data.ClimatePreset
import com.ex2hub.data.ClimateWriteResult
import com.ex2hub.data.DriveMode
import com.ex2hub.data.RegenLevel
import com.ex2hub.data.Profile
import com.ex2hub.data.ProbeOutcome
import com.ex2hub.data.SourceCheck
import com.ex2hub.data.SourceMode
import com.ex2hub.data.VehicleSnapshot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.withContext

class TelemetryReader(context: Context) {
    private val carApi = CarApiSource(context.applicationContext)
    private val root = RootSource()

    // Callback patches do not advance the full-read timestamp.
    val carUpdates: SharedFlow<VehicleSnapshot> = carApi.updates

    /** Живая подписка Car API: пока она работает, опрос — только сверка. */
    val eventsActive: Boolean get() = carApi.hasEventSubscription

    /** [full] = false пропускает климат и кузов: они нужны только экрану. */
    suspend fun read(profile: Profile, full: Boolean = true): ProbeOutcome = withContext(Dispatchers.IO) {
        when (profile.source) {
            SourceMode.CAR_API -> carApi.read(profile, full)
            SourceMode.ROOT -> root.read(profile)
            else -> ProbeOutcome(
                log = "",
                check = SourceCheck(
                    status = CheckStatus.ERROR,
                    summary = "источник не требует опроса",
                    checkedAt = System.currentTimeMillis()
                )
            )
        }
    }

    suspend fun probe(profile: Profile): ProbeOutcome = withContext(Dispatchers.IO) {
        when (profile.source) {
            SourceMode.CAR_API -> carApi.probe(profile)
            SourceMode.ROOT -> root.probe(profile)
            else -> ProbeOutcome(
                log = "",
                check = SourceCheck(
                    status = CheckStatus.ERROR,
                    summary = "источник не требует опроса",
                    checkedAt = System.currentTimeMillis()
                )
            )
        }
    }

    /**
     * Команда климата. Пишет только Car API: root-команды и ручной ввод в этом
     * проекте описывают чтение, а не управление, и выдумывать для них запись
     * нельзя. Журнал попытки возвращается вместе с результатом.
     *
     * [windshieldHeat] — цепочка записи, которую панель построила сама. Нужна
     * только обогреву лобового: этот сигнал не отвечает на чтение, и значение
     * берётся из нажатия, а не из ответа автомобиля.
     */
    suspend fun writeClimate(
        mode: SourceMode,
        change: ClimateChange,
        windshieldHeat: Boolean? = null
    ): Pair<ClimateWriteResult, String> =
        carOnly(mode, "set ${change.name.lowercase()}") { log ->
            carApi.writeClimate(change, log, windshieldHeat)
        }

    suspend fun writePreset(
        mode: SourceMode,
        preset: ClimatePreset,
        off: Boolean
    ): Pair<ClimateWriteResult, String> =
        carOnly(mode, "preset ${preset.name.lowercase()} ${if (off) "off" else "maximum"}") { log ->
            carApi.writePreset(preset, off, log)
        }

    suspend fun readDrive(): Triple<DriveMode?, RegenLevel?, String> = withContext(Dispatchers.IO) {
        carApi.readDrive()
    }

    /** Режим движения или рекуперация: одна цепочка записи одного свойства. */
    suspend fun writeChain(
        mode: SourceMode,
        title: String,
        chain: List<GeelyVhal.VhalWrite>,
        stopOnFirst: Boolean = true
    ): Pair<ClimateWriteResult, String> =
        carOnly(mode, "set $title") { log -> carApi.writeChain(chain, log, stopOnFirst) }

    private suspend fun carOnly(
        mode: SourceMode,
        command: String,
        write: (MutableList<String>) -> ClimateWriteResult
    ): Pair<ClimateWriteResult, String> = carApi.commandPriority.runCommand(mode == SourceMode.CAR_API) {
        val started = System.nanoTime()
        withContext(Dispatchers.IO) {
            val log = mutableListOf("$ ${slug(mode)} $command")
            val result = when (mode) {
                SourceMode.CAR_API -> write(log)
                else -> ClimateWriteResult(
                    status = CheckStatus.ERROR,
                    summary = when (mode) {
                        SourceMode.ROOT -> "root-источник читает, но автомобилем не управляет"
                        SourceMode.MANUAL -> "ручной режим ничего не пишет в автомобиль"
                        SourceMode.DEMO -> "демо-источник обрабатывается приложением"
                        SourceMode.CAR_API -> "Car API недоступен"
                    }
                )
            }
            log += "· длительность команды: ${(System.nanoTime() - started) / 1_000_000L} мс"
            result to (log + "· ${result.summary}").joinToString("\n")
        }
    }

    suspend fun isParkedForUpdate(): Boolean = withContext(Dispatchers.IO) {
        carApi.isParkedForUpdate()
    }

    fun close() {
        carApi.close()
    }

    private fun slug(mode: SourceMode): String = when (mode) {
        SourceMode.CAR_API -> "android.car"
        SourceMode.ROOT -> "su"
        SourceMode.MANUAL -> "manual-provider"
        SourceMode.DEMO -> "demo-provider"
    }
}
