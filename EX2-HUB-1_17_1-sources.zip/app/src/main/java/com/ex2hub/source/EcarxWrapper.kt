package com.ex2hub.source

import android.content.Context
import java.lang.reflect.InvocationTargetException

/**
 * Обёртка ECARX (`com.ecarx.xui.adaptapi.car.Car`), которой штатные приложения
 * переводят id функции в адрес свойства VHAL, а короткое число прошивки — в
 * адаптированное значение. Порядок тот же, что в Capy Energy (Apache-2.0):
 * `createWrapper` → `IWrapper.getWrappedPropertyId(idType, adaptId)` →
 * `IPropertyId.getPropertyId()` и `getPropertyAdaptValue(raw)`.
 *
 * Классов ECARX на обычной сборке головного устройства может не оказаться, и тогда
 * обёртка один раз признаётся недоступной: приложение переходит на сырые свойства.
 */
class EcarxWrapper(context: Context) {
    private val appContext = context.applicationContext

    /** Физический адрес свойства и объект, который умеет адаптировать его значение. */
    class Ref internal constructor(val propertyId: Int, internal val holder: Any)

    private var initialized = false
    private var wrapper: Any? = null
    private var wrapperClass: Class<*>? = null
    private var initError: String? = null
    private val resolved = HashMap<Int, Ref>()
    private val missed = HashSet<Int>()

    /** Причина, по которой адаптера нет на этом устройстве; null — если он доступен. */
    fun unavailableReason(): String? {
        ensure()
        return if (wrapper != null && wrapperClass != null) null else initError ?: "классы ECARX не найдены"
    }

    /** Адаптированный адрес свойства для логического id функции. */
    fun resolve(idType: Int, adaptId: Int): Ref? {
        ensure()
        val current = wrapper
        val iWrapper = wrapperClass
        if (current == null || iWrapper == null) return null
        resolved[adaptId]?.let { return it }
        if (missed.contains(adaptId)) return null
        val propertyIdObject = try {
            iWrapper
                .getMethod("getWrappedPropertyId", Integer.TYPE, Integer.TYPE)
                .invoke(current, idType, adaptId)
        } catch (t: Throwable) {
            initError = initError ?: "getWrappedPropertyId: ${rootMessage(t)}"
            null
        }
        if (propertyIdObject == null) {
            missed.add(adaptId)
            return null
        }
        val propertyId = try {
            propertyIdObject.javaClass.getMethod("getPropertyId").invoke(propertyIdObject) as? Int
        } catch (t: Throwable) {
            initError = initError ?: "getPropertyId: ${rootMessage(t)}"
            null
        }
        if (propertyId == null || propertyId == 0) {
            missed.add(adaptId)
            return null
        }
        val ref = Ref(propertyId, propertyIdObject)
        resolved[adaptId] = ref
        return ref
    }

    /** Число, которое обёртка показывает пользователю вместо сырого enum прошивки. */
    fun adapt(ref: Ref, raw: Int?): Int? {
        val value = raw ?: return null
        return try {
            ref.holder.javaClass
                .getMethod("getPropertyAdaptValue", Integer.TYPE)
                .invoke(ref.holder, value) as? Int
        } catch (t: Throwable) {
            initError = initError ?: "getPropertyAdaptValue: ${rootMessage(t)}"
            null
        }
    }

    private fun ensure() {
        if (initialized) return
        initialized = true
        try {
            val car = Class.forName("com.ecarx.xui.adaptapi.car.Car")
            val created = car.getMethod("createWrapper", Context::class.java).invoke(null, appContext)
            if (created == null) {
                initError = "Car.createWrapper вернул null"
                return
            }
            wrapper = created
            wrapperClass = Class.forName("com.ecarx.xui.adaptapi.car.IWrapper")
        } catch (t: Throwable) {
            wrapper = null
            wrapperClass = null
            initError = rootMessage(t)
        }
    }

    private fun rootMessage(t: Throwable): String {
        var current = t
        while (current is InvocationTargetException && current.targetException != null) {
            current = current.targetException
        }
        val raw = "${current.javaClass.simpleName}: ${current.message ?: "без описания"}"
        return if (raw.length > 160) raw.take(160) + "…" else raw
    }
}
