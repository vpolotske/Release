package com.ex2hub.source

import com.ex2hub.data.CheckStatus
import com.ex2hub.data.DriveMode
import com.ex2hub.data.Profile
import com.ex2hub.data.ProbeOutcome
import com.ex2hub.data.RegenLevel
import com.ex2hub.data.SourceCheck
import com.ex2hub.data.SourceMode
import com.ex2hub.data.VehicleSnapshot
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

/**
 * Чтение через `su -c <команда>`. Команды задаёт пользователь: приложение не знает,
 * какой узел на его прошивке отдаёт нужный сигнал, и не угадывает за него.
 *
 * Каждая команда должна печатать одно число. Температура — в °C; режим движения и
 * рекуперация — кодом свойства (0x220101xx, 0x200205xx) или коротким счётом 1/2/3.
 * Расшифровка кодов общая с Car API и живёт в [GeelyVhal].
 */
class RootSource {
    private data class CommandResult(
        val exitCode: Int,
        val output: String,
        val error: String? = null
    ) {
        val ok: Boolean get() = error == null && exitCode == 0
        val displayOutput: String
            get() = when {
                error != null -> error
                output.isBlank() -> "(пустой вывод)"
                output.length > LOG_LIMIT -> output.take(LOG_LIMIT) + "…"
                else -> output
            }
    }

    private data class Values(
        val soc: Int? = null,
        val rangeKm: Int? = null,
        val powerKw: Double? = null,
        val outsideTempC: Int? = null,
        val driveMode: DriveMode? = null,
        val regen: RegenLevel? = null
    )

    fun probe(profile: Profile): ProbeOutcome {
        val log = StringBuilder()
        val idResult = run("id")
        log.appendLine("$ su -c id")
        log.appendLine(idResult.displayOutput)

        if (!idResult.ok || !idResult.output.contains("uid=0")) {
            log.appendLine("✗ su недоступен или доступ не выдан")
            log.append("ℹ проверьте root на головном устройстве или используйте ручной режим")
            return ProbeOutcome(
                log = log.toString(),
                check = SourceCheck(
                    status = CheckStatus.ERROR,
                    summary = "su недоступен",
                    checkedAt = System.currentTimeMillis()
                )
            )
        }
        log.appendLine("✓ su доступен (uid=0)")
        log.appendLine()

        val values = collect(profile, log)
        val snapshot = values.toSnapshot(profile)
        val check = values.toCheck()
        log.appendLine()
        when (check.status) {
            CheckStatus.OK -> log.append("✓ ${check.summary}")
            CheckStatus.UNKNOWN -> log.append(
                "ℹ su работает, но заряд и запас хода команды не вернули: ${check.summary}"
            )
            CheckStatus.ERROR -> log.append("✗ ${check.summary}")
        }
        return ProbeOutcome(log = log.toString().trim(), check = check, snapshot = snapshot)
    }

    fun read(profile: Profile): ProbeOutcome {
        val log = StringBuilder()
        val values = collect(profile, log)
        val snapshot = values.toSnapshot(profile)
        val check = values.toCheck()
        return ProbeOutcome(log = log.toString().trim(), check = check, snapshot = snapshot)
    }

    private fun collect(profile: Profile, log: StringBuilder): Values {
        val soc = profile.rootSocCommand.trim().takeIf { it.isNotBlank() }
            ?.let { readNumber(it, "SOC", "%", 0.0, 100.0, log)?.roundToInt() }

        val range = profile.rootRangeCommand.trim().takeIf { it.isNotBlank() }
            ?.let { readNumber(it, "Запас", "км", 0.0, GeelyVhal.RANGE_MAX_KM, log)?.roundToInt() }

        val power = profile.rootPowerCommand.trim().takeIf { it.isNotBlank() }
            ?.let { readNumber(it, "Мощность", "кВт", 0.0, 1000.0, log) }

        val temp = profile.rootTempCommand.trim().takeIf { it.isNotBlank() }
            ?.let { command ->
                val raw = readNumber(command, "Температура", "°C", GeelyVhal.TEMP_MIN_C, GeelyVhal.TEMP_MAX_C, log)
                if (raw == null) {
                    log.appendLine("ℹ если узел отдаёт сырое кодирование Flyme, введите команду, " +
                        "которая печатает (значение − 80) / 2")
                }
                GeelyVhal.tempC(raw)
            }

        val driveMode = profile.rootDriveModeCommand.trim().takeIf { it.isNotBlank() }
            ?.let { command ->
                readCode(command, "Режим движения", log, GeelyVhal::driveMode) { mode ->
                    "режим ${mode.name.lowercase(Locale.US)}"
                }
            }

        val regen = profile.rootRegenCommand.trim().takeIf { it.isNotBlank() }
            ?.let { command ->
                readCode(command, "Рекуперация", log, GeelyVhal::regenLevel) { level ->
                    "рекуперация ${level.name.lowercase(Locale.US)}"
                }
            }

        if (soc == null && range == null && power == null && temp == null &&
            driveMode == null && regen == null &&
            profile.rootSocCommand.isBlank() && profile.rootRangeCommand.isBlank() &&
            profile.rootPowerCommand.isBlank() && profile.rootTempCommand.isBlank() &&
            profile.rootDriveModeCommand.isBlank() && profile.rootRegenCommand.isBlank()
        ) {
            log.appendLine("$ su -c <команда>")
            log.appendLine("ℹ команды чтения не заданы в настройках")
        }

        return Values(soc, range, power, temp, driveMode, regen)
    }

    private fun readNumber(
        command: String,
        label: String,
        unit: String,
        min: Double,
        max: Double,
        log: StringBuilder
    ): Double? {
        val result = run(command)
        log.appendLine("$ su -c $command")
        log.appendLine(result.displayOutput)
        val value = if (result.ok) ValueParser.parseInRange(result.output, min, max) else null
        log.appendLine(
            if (value != null) {
                val shown = trimNumber(value)
                "✓ $label = ${if (unit.isEmpty()) shown else "$shown $unit"}"
            } else {
                "✗ $label: значение не распознано — нужно число от ${trimNumber(min)} до ${trimNumber(max)}"
            }
        )
        log.appendLine()
        return value
    }

    /** Кодовые сигналы: число из вывода команды расшифровывает [decode]. */
    private fun <T> readCode(
        command: String,
        label: String,
        log: StringBuilder,
        decode: (Int?) -> T?,
        describe: (T) -> String
    ): T? {
        val result = run(command)
        log.appendLine("$ su -c $command")
        log.appendLine(result.displayOutput)
        val code = if (result.ok) ValueParser.parseInRange(result.output, 0.0, CODE_MAX)?.roundToInt() else null
        val value = code?.let(decode)
        log.appendLine(
            when {
                code == null -> "✗ $label: вывод команды должен содержать число-код"
                value == null -> "✗ $label: код $code не расшифрован"
                else -> "✓ ${describe(value)} (код $code)"
            }
        )
        log.appendLine()
        return value
    }

    private fun trimNumber(value: Double): String =
        if (value == value.roundToInt().toDouble()) value.roundToInt().toString()
        else "%.1f".format(Locale.US, value)

    private fun Values.toSnapshot(profile: Profile): VehicleSnapshot? {
        if (soc == null && rangeKm == null && powerKw == null && outsideTempC == null &&
            driveMode == null && regen == null
        ) {
            return null
        }
        return VehicleSnapshot(
            source = SourceMode.ROOT,
            soc = soc,
            rangeKm = rangeKm,
            batteryKwh = profile.batteryKwh,
            outsideTempC = outsideTempC,
            isCharging = powerKw?.let { it > GeelyVhal.MIN_CHARGE_POWER_KW },
            chargePowerKw = powerKw,
            driveMode = driveMode,
            regen = regen,
            updatedAt = System.currentTimeMillis(),
            note = "Данные из root-команд"
        )
    }

    private fun Values.toCheck(): SourceCheck {
        val parts = buildList {
            soc?.let { add("SOC $it%") }
            rangeKm?.let { add("запас $it км") }
            powerKw?.let { add("мощность ${"%.1f".format(Locale.US, it)} кВт") }
            outsideTempC?.let { add("$it °C") }
            driveMode?.let { add("режим ${it.name.lowercase(Locale.US)}") }
            regen?.let { add("рекуперация ${it.name.lowercase(Locale.US)}") }
        }
        if (parts.isEmpty()) {
            return SourceCheck(
                status = CheckStatus.ERROR,
                summary = "нет данных: задайте команды чтения",
                checkedAt = System.currentTimeMillis()
            )
        }
        // Заряд и запас хода — главный сигнал источника. Ответ только температурой
        // или режимом означает, что su работает, но главные команды ничего не дали.
        val hasCore = soc != null || rangeKm != null
        return SourceCheck(
            status = if (hasCore) CheckStatus.OK else CheckStatus.UNKNOWN,
            summary = parts.joinToString(" · "),
            checkedAt = System.currentTimeMillis()
        )
    }

    private fun run(command: String): CommandResult {
        return try {
            val process = ProcessBuilder("su", "-c", command)
                .redirectErrorStream(true)
                .start()
            // Вывод читает собственный поток, а не общий пул: пул на ГУ из пары потоков, и
            // зависшая команда забирала бы их у остального приложения. Читаем с потолком —
            // команда, печатающая без остановки, не должна съесть память до таймаута.
            val captured = StringBuilder()
            val reader = Thread({
                runCatching {
                    process.inputStream.bufferedReader().use { input ->
                        val chunk = CharArray(1024)
                        while (true) {
                            val count = input.read(chunk)
                            if (count < 0) break
                            synchronized(captured) {
                                val room = OUTPUT_LIMIT - captured.length
                                if (room > 0) captured.append(chunk, 0, minOf(count, room))
                            }
                        }
                    }
                }
            }, "EX2Hub-su-output").apply { isDaemon = true }
            reader.start()
            val finished = process.waitFor(TIMEOUT_SECONDS, TimeUnit.SECONDS)
            if (!finished) {
                process.destroyForcibly()
                reader.interrupt()
                return CommandResult(-1, "", "✗ таймаут ${TIMEOUT_SECONDS} с")
            }
            reader.join(2_000L)
            val output = synchronized(captured) { captured.toString() }.trim()
            CommandResult(process.exitValue(), output)
        } catch (t: Throwable) {
            CommandResult(-1, "", "✗ ${t.javaClass.simpleName}: ${t.message ?: "ошибка запуска su"}")
        }
    }

    companion object {
        private const val TIMEOUT_SECONDS = 8L
        private const val LOG_LIMIT = 700

        /** Числовой ответ — несколько байт; 64 КБ с запасом хватает любому разумному выводу. */
        private const val OUTPUT_LIMIT = 64 * 1024

        /** Принимает и полные коды AutoFuncId (0x220101xx), и короткий счёт 1/2/3. */
        private const val CODE_MAX = 1_073_741_823.0
    }
}
