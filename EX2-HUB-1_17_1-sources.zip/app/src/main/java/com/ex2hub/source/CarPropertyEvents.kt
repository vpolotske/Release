package com.ex2hub.source

import com.ex2hub.data.Body
import com.ex2hub.data.BodyPart
import com.ex2hub.data.Climate
import com.ex2hub.data.VehicleSnapshot
import java.lang.reflect.Method
import java.lang.reflect.Proxy
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.roundToInt

internal data class PropertyAddress(val propertyId: Int, val areaId: Int = GeelyVhal.AREA_GLOBAL)

/** No Android dependency. Only an actual CarPropertyValue may supply a value. */
internal data class PropertyHolder(
    val address: PropertyAddress,
    val status: Int,
    val value: Any?,
    val timestamp: Long
) {
    val available: Boolean get() = status == 0 && value != null

    fun recent(nowNanos: Long): Boolean = available && timestamp > 0L &&
        nowNanos - timestamp in 0L..5_000_000_000L

    companion object {
        private class Accessors(type: Class<*>) {
            val property = type.getMethod("getPropertyId")
            val area = type.getMethod("getAreaId")
            val status = type.getMethod("getStatus")
            val value by lazy { type.getMethod("getValue") }
            val timestamp = runCatching { type.getMethod("getTimestamp") }.getOrNull()
        }

        private val holders = ConcurrentHashMap<Class<*>, Accessors>()
        private val readers = ConcurrentHashMap<Class<*>, Method>()

        fun decode(holder: Any?): PropertyHolder {
            requireNotNull(holder) { "getProperty returned no holder" }
            val methods = holders.computeIfAbsent(holder.javaClass) { Accessors(it) }
            val property = methods.property.invoke(holder) as? Int
                ?: error("holder propertyId is not Int")
            val area = methods.area.invoke(holder) as? Int
                ?: error("holder areaId is not Int")
            val status = methods.status.invoke(holder) as? Int
                ?: error("holder status is not Int")
            // Unavailable holders must not expose a primitive default as a value.
            val value = if (status == 0) methods.value.invoke(holder) else null
            val timestamp = (runCatching { methods.timestamp?.invoke(holder) }.getOrNull() as? Long)
                ?.coerceAtLeast(0L) ?: 0L
            return PropertyHolder(PropertyAddress(property, area), status, value, timestamp)
        }

        /**
         * ECARX канонизирует вендорские id и зоны в AOSP-адреса: на запрос
         * 0x2140A6ED приходит 0x00404000, на 0x15200505 в зоне 75 — зона 117.
         * Это ответ того же сигнала, поэтому по умолчанию он принимается, а
         * исходный адрес остаётся в логе. Строгий режим нужен только там, где
         * чужой ответ нельзя приписывать запрошенному сигналу.
         */
        fun read(manager: Any, address: PropertyAddress, requireExact: Boolean = false): PropertyHolder {
            val method = readers.computeIfAbsent(manager.javaClass) { type ->
                val intType = Int::class.javaPrimitiveType
                type.getMethod("getProperty", intType, intType)
            }
            val holder = decode(method.invoke(manager, address.propertyId, address.areaId))
            if (requireExact) {
                require(holder.address == address) { "holder address ${holder.address}, requested $address" }
            }
            return holder
        }
    }
}

/** Object methods must use proxy identity, not vehicle callback dispatch. */
internal fun propertyCallback(type: Class<*>, dispatch: (String, Array<out Any?>) -> Unit): Any =
    Proxy.newProxyInstance(type.classLoader, arrayOf(type)) { proxy, method, args ->
        when (method.name) {
            "equals" -> proxy === args?.firstOrNull()
            "hashCode" -> System.identityHashCode(proxy)
            "toString" -> "EX2HubPropertyCallback@${System.identityHashCode(proxy).toString(16)}"
            else -> { dispatch(method.name, args ?: emptyArray()); null }
        }
    }

// Reservations precede Binder calls; patches retain the full-read timestamp.
internal class CarPropertyEvents {
    private data class Binding(
        val address: PropertyAddress,
        val decode: (Any?, VehicleSnapshot) -> Any?
    )
    private data class Signal(
        val bindings: List<Binding>,
        val patch: (VehicleSnapshot, Any?) -> VehicleSnapshot,
        val alternateChannel: Boolean = false
    )
    internal data class Sample(val holder: PropertyHolder, val order: Long)
    private data class Event(val binding: Binding, val order: Long)
    internal class Poll(val generation: Long, val started: Long) {
        internal val addresses = LinkedHashSet<PropertyAddress>()
        internal val samples = HashMap<PropertyAddress, Sample>()
        internal var outsideTemperatureC: Int? = null
        internal var outsideTemperatureOrder = 0L
    }

    private val signals = mutableListOf<Signal>()
    private val outsideSignal: Signal
    private val samples = HashMap<PropertyAddress, Sample>()
    private val active = HashMap<Signal, Binding>()
    private val events = HashMap<Signal, Event>()
    private var revision = 0L
    var generation = 0L
        private set
    private var live = false
    private var snapshot: VehicleSnapshot? = null

    init {
        signal(listOf(GeelyVhal.PROP_PERF_VEHICLE_SPEED), { raw, _ -> GeelyVhal.speedKmh(number(raw)) })
            { s, v -> s.copy(speedKmh = v as? Int) }
        signal(listOf(GeelyVhal.PROP_SOC_PERCENT, GeelyVhal.PROP_BATTERY_LEVEL), { raw, s ->
            GeelyVhal.socPercent(number(raw), null, s.batteryKwh * 1000.0)
        }, alternate = { raw, s -> GeelyVhal.socPercent(null, number(raw), s.batteryKwh * 1000.0) })
            { s, v -> s.copy(soc = v as? Int) }
        signal(listOf(GeelyVhal.PROP_PERF_ODOMETER, GeelyVhal.PROP_ODOMETER),
            { raw, _ -> GeelyVhal.odometerKm(number(raw)) }) { s, v -> s.copy(odometerKm = v as? Double) }
        signal(listOf(GeelyVhal.PROP_DRIVE_MODE), { raw, _ -> GeelyVhal.driveMode(integer(raw)) }, alternateChannel = true)
            { s, v -> s.copy(driveMode = v as? com.ex2hub.data.DriveMode) }
        add(
            GeelyVhal.REGEN_AREAS.map { PropertyAddress(GeelyVhal.PROP_REGEN_LEVEL, it) } +
                PropertyAddress(GeelyVhal.PROP_REGEN_LEVEL_VENDOR),
            { raw, _ -> GeelyVhal.regenLevel(integer(raw)) }, alternateChannel = true
        ) { s, v -> s.copy(regen = v as? com.ex2hub.data.RegenLevel) }
        add(listOf(GeelyVhal.PROP_CURRENT_GEAR, GeelyVhal.PROP_GEAR_SELECTION).flatMap { id ->
            GeelyVhal.GEAR_AREAS.map { PropertyAddress(id, it) }
        }, { raw, _ -> GeelyVhal.gear(integer(raw)) }) { s, v -> s.copy(gear = v as? com.ex2hub.data.Gear) }
        // За бортом: 0x11600703 в зонах {1, 4, 0, 7} — так читает Central EX Auto;
        // вендорский AC_AMBIENT_TEMP и AOSP 0x11400703 остаются резервом. У каждого
        // адреса свой декодер: зоны отдают десятые доли, Flyme — сырые полградуса.
        outsideSignal = addBindings(
            GeelyVhal.OUTSIDE_TEMP_AREAS.map { area ->
                PropertyAddress(GeelyVhal.PROP_ENV_OUTSIDE_TEMP, area) to
                    { raw: Any?, _: VehicleSnapshot -> GeelyVhal.outsideCelsius(raw) }
            } + GeelyVhal.OUTSIDE_AMBIENT_AREAS.map { area ->
                PropertyAddress(GeelyVhal.PROP_AC_AMBIENT_TEMP, area) to
                    { raw: Any?, _: VehicleSnapshot -> GeelyVhal.tempC(GeelyVhal.flymeTemp(number(raw))) }
            } + listOf(
                PropertyAddress(GeelyVhal.PROP_ENV_OUTSIDE_TEMPERATURE) to
                    { raw: Any?, _: VehicleSnapshot -> GeelyVhal.outsideCelsius(raw) }
            )
        ) { s, v -> s.copy(outsideTempC = v as? Int) }
        signal(listOf(GeelyVhal.PROP_AC_INSIDE_TEMP), { raw, _ -> GeelyVhal.tempC(GeelyVhal.flymeTemp(number(raw))) })
            { s, v -> s.copy(insideTempC = v as? Int) }
        climate(listOf(PropertyAddress(GeelyVhal.PROP_HVAC_POWER_ON, GeelyVhal.AREA_ROW_1_ALL),
            PropertyAddress(GeelyVhal.PROP_HVAC_POWER_VENDOR)), ::flag) { c, v -> c.copy(hvacOn = v as? Boolean) }
        climate(listOf(PropertyAddress(GeelyVhal.PROP_HVAC_AC_ON, GeelyVhal.AREA_HVAC_DA)) +
            GeelyVhal.HVAC_AREAS.map { PropertyAddress(GeelyVhal.PROP_HVAC_AC_ON_ALT, it) } +
            PropertyAddress(GeelyVhal.PROP_HVAC_AC_ON, GeelyVhal.AREA_HVAC_ALL), ::flag)
            { c, v -> c.copy(acOn = v as? Boolean) }
        climate(listOf(PropertyAddress(GeelyVhal.PROP_HVAC_RECIRC_ON, GeelyVhal.AREA_HVAC_ALL),
            PropertyAddress(GeelyVhal.PROP_HVAC_RECIRC_VENDOR)), ::flag) { c, v -> c.copy(recircOn = v as? Boolean) }
        climate(listOf(PropertyAddress(GeelyVhal.PROP_HVAC_MAX_DEFROST_DA, GeelyVhal.AREA_HVAC_DA),
            PropertyAddress(GeelyVhal.PROP_HVAC_MAX_DEFROST, GeelyVhal.AREA_ROW_1_ALL)), ::flag)
            { c, v -> c.copy(frontDefrostOn = v as? Boolean) }
        climate(listOf(PropertyAddress(GeelyVhal.PROP_HVAC_WINDSHIELD_HEAT, GeelyVhal.AREA_HVAC_ALL)), ::flag)
            { c, v -> c.copy(windshieldHeatOn = v as? Boolean) }
        climate(listOf(PropertyAddress(GeelyVhal.PROP_HVAC_REAR_DEFROST)), ::flag)
            { c, v -> c.copy(rearDefrostOn = v as? Boolean) }
        climate(GeelyVhal.HVAC_AREAS.map { PropertyAddress(GeelyVhal.PROP_HVAC_FAN_SPEED, it) } +
            PropertyAddress(GeelyVhal.PROP_HVAC_FAN_VENDOR), { GeelyVhal.fanSpeed(number(it)) })
            { c, v -> c.copy(fanSpeed = v as? Int) }
        // Уставка: сначала зоны 0x15600503 {1, 4, 0, 7} — первая, ответившая Float,
        // это та же зона, в которую пишет Central EX Auto. Зона 1 на этом ГУ отдаёт
        // целое (4 при 20 °C), поэтому декодер Float-only: иначе целое «заняло» бы
        // сигнал и заблокировало Float из другой зоны. Зеркало и его канонический
        // ответ идут ниже, целый шаг 0x15200503 — последним, только как показ.
        addBindings(
            GeelyVhal.SETPOINT_AREAS.map { area ->
                PropertyAddress(GeelyVhal.PROP_HVAC_TEMPERATURE_SET, area) to
                    { raw: Any?, _: VehicleSnapshot -> GeelyVhal.setpointFloatCelsius(raw) }
            } + listOf(
                PropertyAddress(GeelyVhal.PROP_HVAC_TEMPERATURE_SET_VENDOR, GeelyVhal.AREA_SEAT_LEFT) to
                    { raw: Any?, _: VehicleSnapshot -> GeelyVhal.setpointFloatCelsius(raw) },
                PropertyAddress(GeelyVhal.PROP_HVAC_TEMPERATURE_SET_CANONICAL, GeelyVhal.AREA_GLOBAL) to
                    { raw: Any?, _: VehicleSnapshot -> GeelyVhal.setpointFloatCelsius(raw) },
                PropertyAddress(GeelyVhal.PROP_HVAC_TEMPERATURE_ADJUST, GeelyVhal.AREA_SEAT_LEFT) to
                    { raw: Any?, _: VehicleSnapshot -> GeelyVhal.setpointFloatCelsius(raw) },
                PropertyAddress(GeelyVhal.PROP_HVAC_TEMPERATURE_SET_INT, GeelyVhal.AREA_SEAT_LEFT) to
                    { raw: Any?, _: VehicleSnapshot -> GeelyVhal.setpointFromRaw(number(raw)) }
            ), alternateChannel = true
        ) { s, v ->
            // «Нет значения» здесь не стирает показание: целая зона 1 присылает
            // события постоянно, и каждое такое событие гасило бы Float-ответ.
            if (v == null) s else {
                val climate = (s.climate ?: Climate()).copy(driverTempC = v as? Double)
                s.copy(climate = climate.takeUnless { it.isEmpty })
            }
        }
        climate(listOf(PropertyAddress(GeelyVhal.PROP_HVAC_FAN_DIRECTION_VENDOR),
            PropertyAddress(GeelyVhal.PROP_HVAC_FAN_DIRECTION, GeelyVhal.AREA_SEAT_LEFT)),
            { GeelyVhal.fanDirection(number(it)) }) { c, v -> c.copy(fanDirection = v as? Int) }
        climate(listOf(PropertyAddress(GeelyVhal.PROP_HVAC_SEAT_HEAT, GeelyVhal.AREA_SEAT_LEFT)),
            { GeelyVhal.heatLevel(number(it)) }) { c, v -> c.copy(seatHeatDriver = v as? Int) }
        climate(listOf(PropertyAddress(GeelyVhal.PROP_HVAC_SEAT_HEAT, GeelyVhal.AREA_SEAT_RIGHT)),
            { GeelyVhal.heatLevel(number(it)) }) { c, v -> c.copy(seatHeatPassenger = v as? Int) }
        climate(listOf(PropertyAddress(GeelyVhal.PROP_HVAC_WHEEL_HEAT)),
            { GeelyVhal.heatLevel(number(it)) }) { c, v -> c.copy(wheelHeat = v as? Int) }
        // На экране из кузова используется только капот. Двери, замки, стёкла и свет
        // не выводятся, поэтому не подписываются и остаются в диагностической пробе.
        BodyPart.HOOD.let { part ->
            add(
                listOf(PropertyAddress(GeelyVhal.PROP_DOOR_POS, GeelyVhal.DOOR_AREAS.getValue(part))),
                { raw, _ -> GeelyVhal.doorOpen(integer(raw)) }
            ) { s, v -> s.bodyPatch { it.copy(open = mapPatch(it.open, part, v as? Boolean)) } }
        }
        // Headlights require two corroborating holders; they stay in the diagnostic probe only.
    }

    val propertyIds: Set<Int> get() = signals.flatMap { it.bindings }.map { it.address.propertyId }.toSet()
    fun knows(address: PropertyAddress): Boolean = signals.any { s -> s.bindings.any { it.address == address } }
    fun open(): Long { reset(); live = true; return generation }
    fun reset() {
        generation++
        live = false
        snapshot = null
        samples.clear()
        active.clear()
        events.clear()
        revision = 0L
    }
    fun beginPoll(): Poll = Poll(generation, revision)
    fun reserve(): Long = ++revision

    fun observe(poll: Poll?, holder: PropertyHolder, order: Long) {
        if (!live || !knows(holder.address) || (poll != null && poll.generation != generation)) return
        poll?.addresses?.add(holder.address)
        accept(holder, order, poll?.samples ?: samples)
    }

    fun discardPoll(poll: Poll) {
        poll.samples.clear()
        poll.addresses.clear()
        poll.outsideTemperatureC = null
        poll.outsideTemperatureOrder = 0L
    }

    fun observeOutsideTemperature(poll: Poll, celsius: Int, order: Long) {
        if (!live || poll.generation != generation) return
        poll.outsideTemperatureC = celsius
        poll.outsideTemperatureOrder = order
    }

    private fun accept(
        holder: PropertyHolder,
        order: Long,
        cache: MutableMap<PropertyAddress, Sample> = samples
    ): Boolean {
        val old = cache[holder.address]
        if (old != null) {
            if (holder.timestamp > 0 && old.holder.timestamp > 0) {
                if (holder.timestamp < old.holder.timestamp) return false
                if (holder.timestamp == old.holder.timestamp) {
                    // Equal timestamps cannot restore a measurement after explicit invalidation.
                    if (holder.available || !old.holder.available || order <= old.order) return false
                }
            } else if (order <= old.order) return false
        }
        cache[holder.address] = Sample(holder, order)
        return true
    }

    fun superseded(holder: PropertyHolder, order: Long): Boolean {
        val latest = samples[holder.address] ?: return false
        if (latest.holder.available == holder.available && latest.holder.value == holder.value) return false
        return if (latest.holder.timestamp > 0L && holder.timestamp > 0L) {
            latest.holder.timestamp >= holder.timestamp
        } else latest.order > order
    }

    fun event(expectedGeneration: Long, holder: PropertyHolder): VehicleSnapshot? =
        observation(expectedGeneration, holder, reserve())

    fun observation(expectedGeneration: Long, holder: PropertyHolder, order: Long): VehicleSnapshot? {
        if (!live || expectedGeneration != generation || !knows(holder.address)) return null
        if (!accept(holder, order)) return null
        val signal = signals.first { s -> s.bindings.any { it.address == holder.address } }
        val binding = signal.bindings.first { it.address == holder.address }
        val selected = active[signal]
        val base = snapshot
        // A fallback event must not replace a known preferred address while that
        // address still answers. Once the preferred address reports unavailable,
        // a fresh fallback event may take over; the unavailable event itself has
        // already cleared the field, so this is not a stale cache resurrection.
        // «Отвечает» — значит даёт значение, а не просто статус 0: целая зона
        // уставки доступна, но ничего не декодирует и не должна заслонять Float.
        val selectedAvailable = selected?.let { preferred ->
            samples[preferred.address]?.holder?.takeIf { it.available }?.let { sample ->
                preferred.decode(sample.value, base ?: VehicleSnapshot())
            }
        } != null
        if (selected != null && binding !== selected &&
            signal.bindings.indexOf(binding) > signal.bindings.indexOf(selected) &&
            selectedAvailable) return null
        val value = if (holder.available && base != null) binding.decode(holder.value, base) else null
        if (selected != binding && value == null && holder.available && base != null) return null
        active[signal] = binding
        events[signal] = Event(binding, order)
        if (base == null) return null
        val patched = signal.patch(base, value)
        if (patched == base) return null
        snapshot = patched
        return patched
    }

    fun seed(base: VehicleSnapshot?, poll: Poll, full: Boolean = true): VehicleSnapshot? {
        if (!live || poll.generation != generation || base == null) return null
        // Speculative reads must not suppress callbacks until a full snapshot can be published.
        for (sample in poll.samples.values) accept(sample.holder, sample.order)
        // A fast/core poll intentionally omits these groups. Keep their last actual
        // observations in the callback baseline, without reading them again.
        var merged = base.copy(
            climate = if (full) base.climate else snapshot?.climate,
            body = if (full) base.body else snapshot?.body
        )
        for (signal in signals) {
            val typedOutside = poll.outsideTemperatureC
            if (signal === outsideSignal && typedOutside != null &&
                (events[signal]?.order ?: 0L) <= poll.outsideTemperatureOrder) {
                // Getter не даёт timestamp: приоритет определяется резервом до Binder-вызова.
                merged = signal.patch(merged, typedOutside)
                active.remove(signal)
                events.remove(signal)
                continue
            }
            val during = events[signal]?.takeIf { event ->
                event.order > poll.started || signal.bindings.none { it.address in poll.addresses }
            }
            if (during != null) {
                val preferred = signal.bindings.takeWhile { it != during.binding }.firstOrNull { binding ->
                    binding.address in poll.addresses && samples[binding.address]?.holder?.takeIf { it.available }
                        ?.let { binding.decode(it.value, merged) } != null
                }
                val binding = preferred ?: during.binding
                val sample = samples[binding.address]
                val value = sample?.holder?.takeIf { it.available }?.let { binding.decode(it.value, merged) }
                merged = signal.patch(merged, value)
                active[signal] = binding
                if (preferred != null) events.remove(signal)
                continue
            }
            val readBindings = signal.bindings.filter { it.address in poll.addresses }
            if (readBindings.isEmpty()) continue // partial poll does not erase climate/body
            val chosen = readBindings.firstOrNull { binding ->
                samples[binding.address]?.holder?.takeIf { it.available }
                    ?.let { binding.decode(it.value, merged) } != null
            }
            if (chosen != null) {
                merged = signal.patch(merged, chosen.decode(samples.getValue(chosen.address).holder.value, merged))
                active[signal] = chosen
            } else {
                active.remove(signal)
                // Null is an invalidation, not an old primitive from a rejected poll.
                // Flyme drive/regen may provide a genuine independently-read baseline.
                if (!signal.alternateChannel) merged = signal.patch(merged, null)
            }
        }
        snapshot = merged
        poll.samples.clear()
        return merged
    }

    private fun signal(ids: List<Int>, decode: (Any?, VehicleSnapshot) -> Any?,
        alternate: (Any?, VehicleSnapshot) -> Any? = decode, alternateChannel: Boolean = false,
        patch: (VehicleSnapshot, Any?) -> VehicleSnapshot) {
        signals += Signal(ids.mapIndexed { index, id -> Binding(PropertyAddress(id), if (index == 0) decode else alternate) },
            patch, alternateChannel)
    }
    private fun add(addresses: List<PropertyAddress>, decode: (Any?, VehicleSnapshot) -> Any?,
        alternateChannel: Boolean = false, patch: (VehicleSnapshot, Any?) -> VehicleSnapshot) {
        signals += Signal(addresses.map { Binding(it, decode) }, patch, alternateChannel)
    }
    private fun addBindings(
        bindings: List<Pair<PropertyAddress, (Any?, VehicleSnapshot) -> Any?>>,
        alternateChannel: Boolean = false,
        patch: (VehicleSnapshot, Any?) -> VehicleSnapshot
    ): Signal {
        val signal = Signal(bindings.map { (address, decode) -> Binding(address, decode) }, patch, alternateChannel)
        signals += signal
        return signal
    }
    private fun climate(addresses: List<PropertyAddress>, decode: (Any?) -> Any?, patch: (Climate, Any?) -> Climate) {
        add(addresses, { raw, _ -> decode(raw) }) { s, v ->
            val climate = patch(s.climate ?: Climate(), v)
            s.copy(climate = climate.takeUnless { it.isEmpty })
        }
    }
    private fun VehicleSnapshot.bodyPatch(patch: (Body) -> Body): VehicleSnapshot {
        val body = patch(body ?: Body())
        return copy(body = body.takeIf { it.readableSignals > 0 })
    }
    private fun <T> mapPatch(map: Map<BodyPart, T>, part: BodyPart, value: T?): Map<BodyPart, T> =
        if (value == null) map - part else map + (part to value)
    private fun flag(raw: Any?): Boolean? = GeelyVhal.flag(number(raw))
    private fun number(raw: Any?): Double? = when (raw) {
        is Number -> raw.toDouble()
        is Boolean -> if (raw) 1.0 else 0.0
        else -> null
    }
    private fun integer(raw: Any?): Int? = when (raw) {
        is Int -> raw
        is Long -> raw.toInt()
        is Float -> if (raw.isFinite()) raw.roundToInt() else null
        is Double -> if (raw.isFinite()) raw.roundToInt() else null
        else -> null
    }
}
