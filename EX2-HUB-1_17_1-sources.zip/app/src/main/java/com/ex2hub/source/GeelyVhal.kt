package com.ex2hub.source

import com.ex2hub.data.BodyPart
import com.ex2hub.data.ChargeFlow
import com.ex2hub.data.ChargeType
import com.ex2hub.data.ChargePowerSource
import com.ex2hub.data.ChargingSignals
import com.ex2hub.data.Climate
import com.ex2hub.data.ClimateChange
import com.ex2hub.data.ClimatePreset
import com.ex2hub.data.DriveMode
import com.ex2hub.data.Gear
import com.ex2hub.data.IgnitionState
import com.ex2hub.data.RegenLevel
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.roundToInt

/**
 * Идентификаторы VHAL-свойств Geely EX2 (головное устройство IHU629G, Flyme Auto)
 * и способы декода их значений. Больше нигде в приложении чисел свойств нет.
 *
 * Числа взяты не из спецификации AOSP, а из приложений, которые проверяли их на
 * живой машине: Capy Energy (profile/GeelyProperties.kt, GeelyDeclarations.kt,
 * vehicle/BatteryPercentDecoder.kt, vehicle/HvacClimateController.kt), geely_ex2_tools
 * (data/vhal/VhalConstants.kt, data/temperature/TemperatureReader.kt) и CentralEXAuto —
 * разобран его classes.dex (AppConstants, TelemetryReader, PhoneSyncService,
 * TempStepperService), то есть адреса, зоны и способы записи взяты из приложения,
 * которое реально управляет климатом на этом головном устройстве. Помечено «2×» то,
 * что совпало минимум в двух независимых реализациях.
 *
 * При смене прошивки идентификаторы и декоды надо перепроверять — авторы
 * источников предупреждают об этом прямо.
 */
object GeelyVhal {

    const val AREA_GLOBAL = 0

    /** SOC, %. Вендорское ED_EV_BATTERY_PERCENTAGE 0x2140A6ED. Основной источник. 2× */
    const val PROP_SOC_PERCENT = 557885165

    /** EV_BATTERY_LEVEL 0x11600309: гу отдаёт либо %, либо Вт·ч — решает величина. 2× */
    const val PROP_BATTERY_LEVEL = 291504905

    /** RANGE_REMAINING 0x11400308, INT32 в километрах. 2× */
    const val PROP_RANGE_REMAINING_KM = 289407752

    /**
     * Остаточная и полная энергия батареи в Вт·ч.
     *
     * Оба читаются только в пробе, в работе не участвуют: INFO_EV_BATTERY_CAPACITY на
     * живой машине отвечает VHAL-заглушкой 150 000 Вт·ч вместо реальных ~39 600, и
     * Capy прямо пишет, что все посчитанные от неё цифры расхода оказались завышены
     * в 3,8 раза. Ёмкость берётся из настроек приложения.
     */
    const val PROP_EV_CURRENT_BATTERY_CAPACITY = 291504909
    const val PROP_INFO_EV_BATTERY_CAPACITY = 291504390

    /**
     * Одометр, километры. Основной — PERF_ODOMETER 0x11600204: на нашем ГУ проба прочитала
     * его дробным (5451,9 км), а дробная часть нужна журналу для коротких поездок.
     * 0x11400204 стоит в дампе EX2, Drive Assist отмечает его проверенным, а EX Sapo
     * Central 2.19.78 опрашивает первым, но тип у него INT32 и дробь он может потерять,
     * поэтому он резерв и читается, только когда основной не ответил.
     */
    const val PROP_ODOMETER = 289407492
    const val PROP_PERF_ODOMETER = 291504644

    /**
     * 0x2140A6AC в дампе числился одометром приборки — это неверно. Журнал 2026-10-28
     * прочитал здесь 61,0 км при одометре 5528,1, ровно как RANGE_REMAINING (61 км):
     * это зеркало запаса хода, и прежний резерв давал поездку в 5467,1 км за минуту.
     * В расчёт пробега адрес не входит; строка остаётся только для пробы.
     */
    const val PROP_RANGE_MIRROR = 557885100

    /**
     * PERF_VEHICLE_SPEED 0x11600207. На этом ГУ значение уже в км/ч, а не в м/с,
     * как предполагает AOSP: обе справочные реализации читают его как км/ч и
     * ставят потолок 140. Умножать на 3,6 нельзя. 2×
     */
    const val PROP_PERF_VEHICLE_SPEED = 291504647

    /** EV_BATTERY_INSTANTANEOUS_CHARGE_RATE, мВт. */
    const val PROP_CHARGE_RATE_MW = 291504908

    /**
     * 0x2140B085 — состояние физической вилки в разъёме: `3` = кабель вставлен,
     * `0` = нет. В разборе Drive Assist id приведён только десятичным числом
     * (557887621), hex — наш пересчёт. Та же проверка называет его надёжным
     * признаком подключения, не зависящим от тока заряда. 2×
     */
    const val PROP_PORT_CONNECTED = 557887621
    const val PORT_CONNECTED = 3
    const val PORT_DISCONNECTED = 0

    /**
     * EV_CHARGE_PORT_CONNECTED 0x1120030B, AOSP-bool. Только резерв: Drive Assist
     * помечает его unwired на этом ГУ — свойство отвечает `false` посреди активной
     * зарядки, поэтому первично читается [PROP_PORT_CONNECTED]. 2×
     */
    const val PROP_CHARGE_PORT_CONNECTED = 287310603

    /**
     * CHARGING_DISCHARGING_STATE 0x2140737E — сырое свойство VHAL. 2×
     *
     * Значение здесь — короткий перечислитель прошивки, а таблица [STATE_*] ниже
     * описывает адаптированные числа. Приоритет у обёртки ECARX
     * ([CHARGING_STATE_LOGICAL]); прямое чтение остаётся резервом, и если оно
     * ответит числом вне таблицы, состояние останется нерасшифрованным.
     */
    const val PROP_CHARGING_STATE = 557871998

    /** CHARGING_PLUG_STATE 0x21407289. 2× */
    const val PROP_CHARGING_PLUG = 557871753

    /**
     * Те же два сигнала в адаптированном виде: обёртка ECARX по этим логическим
     * идентификаторам выдаёт физический адрес и переводит короткое число прошивки
     * в константы [STATE_*] и [PLUG_*]. 0x24205C00 и 0x24130200 — не адреса VHAL,
     * а id функций, их нельзя читать CarPropertyManager напрямую.
     */
    const val CHARGING_STATE_LOGICAL = 606100480
    const val CHARGING_PLUG_LOGICAL = 605225472

    /** `IWrapper.WrappedIdType` для функций заряда и энергии. */
    const val ECARX_ID_TYPE_FUNCTION = 2

    /** `IWrapper.WrappedIdType` для сенсоров: зажигание и режим использования. */
    const val ECARX_ID_TYPE_SENSOR = 3

    /** Мощность на стороне AC, кВт. 2× */
    const val PROP_CHARGE_AC_POWER_KW = 606098432

    /** Мощность на стороне DC, кВт. 2× */
    const val PROP_CHARGE_DC_POWER_KW = 606105856

    /**
     * Ток и напряжение зарядки, A и V. Это вход несущей сети зарядного устройства
     * (DCHA_CHARGE_ACDC_*, на машине измерено 211 B / 6,8 A), а не высоковольтный
     * пакет 395 B. Называть эти цифры «напряжением батареи» нельзя.
     */
    const val PROP_CHARGE_INPUT_A = 605291008
    const val PROP_CHARGE_INPUT_V = 605290752

    /** Оценка времени до конца зарядки, мин. 2× */
    const val PROP_CHARGE_ESTIMATE_MIN = 605291264

    // --- Статистика заряда, которую знает автомобиль ---------------------------

    /**
     * CHARGING_WORK_TIME 0x24205500 — сколько минут идёт текущая сессия заряда.
     * Capy читает это свойство как `workTimeMinutes` (vehicle/VehiclePropertyHelper.kt,
     * `readCharging`) рядом с оценкой до конца. Как и оценка, время «живёт» только
     * пока зарядка идёт: после остановки прошивка держит последнее число.
     */
    const val PROP_CHARGE_WORK_TIME_MIN = 606098688

    /**
     * CHARGING_ALTERNATING_CURRENT_VAL / _MAX / _MIN 0x2140A6D8…DA — INT32 в амперах:
     * заданный ток AC-зарядки и границы, которые объявляет сам автомобиль. Capy
     * наблюдает на машине 7 A в покое и 5 A во время заряда, MIN = 5 и MAX = 32, и
     * отдельно пишет, что диапазон взять из автомобиля, потому что интерфейс,
     * придумавший себе 48 A, обещал то, чего машина никогда не сообщала.
     */
    const val PROP_AC_CURRENT_SET_A = 557885144
    const val PROP_AC_CURRENT_MAX_A = 557885145
    const val PROP_AC_CURRENT_MIN_A = 557885146

    /**
     * Разбивка энергопотребления из дампа свойств EX2 (0x2160A6E9…EC): движением,
     * климатом, батареей и «прочим». Из них на живой машине отвечает только
     * DRIVING-канал, и Capy описывает его как долю (строки сходятся к 100), а не
     * киловатты; в эффективность её подставлять нельзя. Её тень — логический id
     * обёртки 0x24804100 — резолвится в тот же адрес (1701 из 1701 пар имеют одно
     * и то же значение). Вендорское зеркало 0x216074E9, HYBRID_POWER_FLOW и
     * DRIVE_POWER_OUT_PUT на записях машины держали 0.0.
     *
     * Поэтому все четыре числа приложение показывает в журнале пробы сырыми:
     * подтверждённой шкалы нет ни у одного из разобранных источников, а придумывать
     * единицу мы не будем.
     */
    const val PROP_ED_DRIVING_ENERGY_FLOW = 559982313      // 0x2160A6E9
    const val PROP_ED_CLIMATE_ENERGY_FLOW = 559982314      // 0x2160A6EA
    const val PROP_ED_BATTERY_ENERGY_FLOW = 559982315      // 0x2160A6EB
    const val PROP_ED_OTHER_ENERGY_FLOW = 559982316        // 0x2160A6EC
    const val PROP_ED_DRIVING_ENERGY_FLOW_TRIP = 559969513 // 0x216074E9, вендорское зеркало
    const val LOGICAL_TRIP_ED_DRIVING_ENERGY_FLOW = 612385024 // 0x24804100, id функции обёртки

    /** HYBRID_POWER_FLOW 0x21407173 и DRIVE_POWER_OUT_PUT 0x21402006 — сырые числа. */
    const val PROP_HYBRID_POWER_FLOW = 557871475
    const val PROP_DRIVE_POWER_OUTPUT = 557850630

    /**
     * Второй канал среднего расхода: IPK_AVERAGE_POWER_CONSUMPTION 0x2140A6AA — то,
     * что показывает приборная панель. Capy держит его в raw-логе со шкалой «не
     * подтверждена» и замечает, что на всех записях машины это одно и то же
     * число — 328,0. Подтверждённая шкала есть только у IPK_AVG_ENERGY_CONSUMPTION_100
     * (сотые доли кВт·ч/100 км), и его приложение читает в пробе сейчас.
     */
    const val PROP_IPK_AVERAGE_POWER_CONSUMPTION = 557885098

    /**
     * Кандидаты на мгновенные числа пакета из каталога IHU629G: ток и напряжение
     * батареи, Bus-напряжение, SOE. Capy их не опрашивает (в её профиле сигналов
     * нет), интеграция мощности по ним невозможна, а шкала не подтверждена. Мы
     * читаем их только в пробе — чтобы владелец увидел, отвечает ли ими это ГУ.
     */
    const val PROP_BMSH_BAT_CURRENT = 557885494   // 0x2140A836
    const val PROP_BMSH_PACK_VOLT = 557885495     // 0x2140A837
    const val PROP_BMSH_BUS_VOLT = 557887508      // 0x2140B014
    const val PROP_BMSH_BAT_SOE = 557885483       // 0x2140A82B
    const val PROP_IC_HR_TRIP = 557884167         // 0x2140A307, трип-компьютер панели

    /** AC_AMBIENT_TEMP 0x2140A377: сырое число декодируется как (raw − 80) / 2 °C. 3× */
    const val PROP_AC_AMBIENT_TEMP = 557884279

    /** AC_INSIDE_TEMP 0x2140A379, тот же декод. 2× */
    const val PROP_AC_INSIDE_TEMP = 557884281

    /** ENV_OUTSIDE_TEMPERATURE 0x11600703, уже в °C. резервный путь. 3× */
    const val PROP_ENV_OUTSIDE_TEMP = 291505923

    /**
     * DM_FUNC_DRIVE_MODE_SELECT 0x22010100. 2×
     *
     * Это id функции Flyme, который совпадает с hex-адресом VHAL-свойства. План был
     * читать режим через AutoFuncManager ([FlymeAutoFunc]), а свойство оставить
     * резервом, но проба 2026-10-25 на `IHU629G` показала
     * `ClassNotFoundException: com.flyme.auto.api.AutoFuncManager`: канала AutoFunc на
     * этой прошивке нет, и работает именно чтение свойства (0x22010102 → Комфорт).
     * AutoFunc остался второй попыткой — на прошивке, где он есть.
     */
    const val PROP_DRIVE_MODE = 570491136
    const val DRIVE_MODE_FUNC = "DM_FUNC_DRIVE_MODE_SELECT"

    /** SETTING_FUNC_ENERGY_REGENERATION 0x20020500. 2× */
    const val PROP_REGEN_LEVEL = 537003264
    const val REGEN_FUNC = "SETTING_FUNC_ENERGY_REGENERATION"

    /**
     * REGENCY_LEVEL 0x2140A201 — вендорское свойство уровня рекуперации из дампа
     * свойств EX2. Пробуется после AutoFunc-идентификатора: в дампе оно есть, а
     * что из двух отдаёт это ГУ — видно только по логу пробы.
     */
    const val PROP_REGEN_LEVEL_VENDOR = 557883905

    /** Regen живёт в двух областях: читают сначала 0, затем 1. */
    val REGEN_AREAS = intArrayOf(0, 1)

    // --- Передача и зажигание --------------------------------------------------

    /**
     * CURRENT_GEAR 0x11400401 и GEAR_SELECTION 0x11400400 — адреса из дампа
     * свойств EX2, которыми пользуется Capy (vehicle/VehiclePropertyHelper.kt,
     * `readGear`). Оба пробуются в области −1, затем 0: какую из двух областей
     * отдаёт это ГУ, видно только по логу пробы.
     */
    const val PROP_CURRENT_GEAR = 289408001     // 0x11400401
    const val PROP_GEAR_SELECTION = 289408000   // 0x11400400

    /** Области передачи: сначала −1 (любая), затем глобальная. */
    val GEAR_AREAS = intArrayOf(-1, 0)

    /** Значение свойства — битовая маска, а не счёт: P=4, R=2, N=1, D=8. */
    const val GEAR_NEUTRAL = 0x1
    const val GEAR_REVERSE = 0x2
    const val GEAR_PARK = 0x4
    const val GEAR_DRIVE = 0x8

    private const val GEAR_MASK = 0xF

    /**
     * Зажигание и режим использования ключа. Сырые вендорские свойства
     * PEPS_POWER_MODE 0x2140A331 и PEPS_USAGE_MODE 0x2140A822 коротким числом
     * ничего не объясняют: Capy читает их через сенсорную обёртку ECARX, значение
     * которой уже расшифровано в константы ISensorEvent (ниже). Прямое чтение
     * остаётся в probe-логе как есть и в расшифровку не попадает.
     */
    const val PROP_PEPS_POWER_MODE = 557884209  // 0x2140A331
    const val PROP_PEPS_USAGE_MODE = 557885474  // 0x2140A822

    const val IGNITION_SENSOR_LOGICAL = 2097408 // 0x200100 SENSOR_TYPE_IGNITION_STATE
    const val USAGE_SENSOR_LOGICAL = 2102016    // 0x201300 SENSOR_TYPE_USG_MODE

    // --- Кузов: только чтение ----------------------------------------------------

    /**
     * Двери, замки и стёкла — AOSP-свойства, которые Drive Assist читал на живом
     * IHU629G (статус ✅ в его таблице). DOOR_POS здесь отвечает не по AOSP: 1 — дверь
     * открыта, 2 — закрыта; так же их понимает EX Sapo Central. Замок двери 1/0.
     * Стекло 0…100, 0 — закрыто.
     *
     * Капот и багажник берутся тем же DOOR_POS в AOSP-областях HOOD/REAR: на живой
     * машине это не проверено, поэтому декодер принимает только те же 1 и 2, а
     * вендорские BCM_HOOD_STATUS и BODY_DOOR_TRUNK_DOOR_POS идут только в лог пробы.
     * Фары — AOSP HEADLIGHTS_STATE (0 выкл, 1 вкл, 2 ДХО), тоже без живой проверки.
     */
    const val PROP_DOOR_POS = 373295872               // 0x16400B00
    const val PROP_DOOR_LOCK = 641736874              // 0x264020AA, по дверям
    const val PROP_WINDOW_POS = 322964416             // 0x13400BC0
    const val PROP_HEADLIGHTS_STATE = 289410560       // 0x11400E00

    const val PROP_DOOR_POS_VENDOR = 641736873        // 0x264020A9, только лог
    const val PROP_WINDOW_POS_VENDOR = 591405227      // 0x234020AB, только лог
    const val PROP_CENTRAL_LOCK = 541129728           // 0x2040FC00, только лог
    const val PROP_HOOD_STATUS_VENDOR = 557875230     // 0x2140801E BCM_HOOD_STATUS, только лог
    const val PROP_TRUNK_POS_VENDOR = 557850643       // 0x21402013 BODY_DOOR_TRUNK_DOOR_POS, только лог
    const val PROP_BODY_LIGHT_STATUS = 557850814      // 0x214020BE, только лог
    const val PROP_HEADLIGHTS_SWITCH = 557850787      // 0x214020A3, только лог
    const val PROP_HIGH_BEAM_STATE = 289410561        // 0x11400E01, только лог
    const val PROP_FOG_LIGHTS_STATE = 289410562       // 0x11400E02, только лог
    const val PROP_HAZARD_LIGHTS_STATE = 289410563    // 0x11400E03, только лог
    const val PROP_TURN_SIGNAL_STATE = 289408008      // 0x11400408, только лог
    const val PROP_CHARGE_MAX_SOC = 557887499         // 0x2140B00B VCU_ALLOW_CHARGE_MAX_SOC_ACT, только лог

    const val AREA_DOOR_ROW_1_LEFT = 0x1
    const val AREA_DOOR_ROW_1_RIGHT = 0x4
    const val AREA_DOOR_ROW_2_LEFT = 0x10
    const val AREA_DOOR_ROW_2_RIGHT = 0x40
    const val AREA_DOOR_HOOD = 0x10000000
    const val AREA_DOOR_REAR = 0x20000000

    const val AREA_WINDOW_ROW_1_LEFT = 0x10
    const val AREA_WINDOW_ROW_1_RIGHT = 0x40
    const val AREA_WINDOW_ROW_2_LEFT = 0x100
    const val AREA_WINDOW_ROW_2_RIGHT = 0x400

    val DOOR_AREAS: Map<BodyPart, Int> = linkedMapOf(
        BodyPart.DOOR_FL to AREA_DOOR_ROW_1_LEFT,
        BodyPart.DOOR_FR to AREA_DOOR_ROW_1_RIGHT,
        BodyPart.DOOR_RL to AREA_DOOR_ROW_2_LEFT,
        BodyPart.DOOR_RR to AREA_DOOR_ROW_2_RIGHT,
        BodyPart.HOOD to AREA_DOOR_HOOD,
        BodyPart.TAILGATE to AREA_DOOR_REAR
    )

    val WINDOW_AREAS: Map<BodyPart, Int> = linkedMapOf(
        BodyPart.DOOR_FL to AREA_WINDOW_ROW_1_LEFT,
        BodyPart.DOOR_FR to AREA_WINDOW_ROW_1_RIGHT,
        BodyPart.DOOR_RL to AREA_WINDOW_ROW_2_LEFT,
        BodyPart.DOOR_RR to AREA_WINDOW_ROW_2_RIGHT
    )

    fun doorOpen(raw: Int?): Boolean? = when (raw) {
        1 -> true
        2 -> false
        else -> null
    }

    fun doorLocked(raw: Int?): Boolean? = when (raw) {
        1 -> true
        0 -> false
        else -> null
    }

    fun windowPercent(raw: Int?): Int? = raw?.takeIf { it in 0..100 }

    /**
     * Горят ли фары: STATE corroborируется переключателем. Один STATE на этом ГУ
     * врёт — проба на живом IHU629G видела 1 при потушенных фарах днём, и старое
     * приложение считало их включёнными всегда. Горят, только когда STATE и
     * SWITCH утверждают это вместе; STATE=0 и STATE=1 без SWITCH=1 тушат свет;
     * прочее (включая ДХО-двойку, которая горит всю дорогу) — «неизвестно».
     */
    fun headlightsOn(state: Int?, switch: Int?): Boolean? = when {
        state == 1 && switch == 1 -> true
        state == 0 || state == 1 -> false
        else -> null
    }

    // --- Кузов: открытие переднего багажника (единственная запись в кузов) --------

    /**
     * Кандидаты записи из дампа EX2 (ex2_carprops, Capy Energy, Apache-2.0). Ни один
     * источник не проверял их записью на живой машине: Capy читает LOCK_HOOD как
     * телеметрию, штатные настройки Flyme держат отдельную функцию переднего
     * багажника. SWT — кнопка переднего, LOCK_* — замок капота. Что из них реально
     * открывает крышку, покажет только проба на автомобиле.
     * Заднего багажника здесь нет: в меню этого ГУ такой функции не нашлось.
     */
    const val PROP_FRONT_TRUNK_SWT = 557887560       // 0x2140B048 FRONT_TRUNK_SWT
    const val PROP_HOOD_LOCK = 557884754             // 0x2140A552 LOCK_HOOD

    /** Передний багажник: сначала переключатель, затем замок капота. */
    fun frunkOpenWrites(): List<VhalWrite> = listOf(
        VhalWrite(PROP_FRONT_TRUNK_SWT, AREA_GLOBAL, bool = true, label = "FRONT_TRUNK_SWT"),
        VhalWrite(PROP_FRONT_TRUNK_SWT, AREA_GLOBAL, int = 1, label = "FRONT_TRUNK_SWT int"),
        VhalWrite(PROP_HOOD_LOCK, AREA_GLOBAL, bool = true, label = "LOCK_HOOD"),
        VhalWrite(PROP_HOOD_LOCK, AREA_GLOBAL, int = 1, label = "LOCK_HOOD int")
    )

    // --- Зоны HVAC -------------------------------------------------------------

    /**
     * Области из `com.flyme.auto.hvac.car_api.Zone` (geely_ex2_tools,
     * docs/flyme-hvac-apk.md §5). Приложение использует только эти пять:
     * глобальную, два передних сиденья, весь первый ряд и «1+2 ряд», которым
     * прошивка помечает AC, рециркуляцию и ECO.
     */
    const val AREA_SEAT_LEFT = 1
    const val AREA_SEAT_RIGHT = 4
    const val AREA_ROW_1_ALL = 5
    const val AREA_HVAC_ALL = 117

    /**
     * Зоны, в которых CentralEXAuto ищет температуру за бортом (`TempStepperService.d`,
     * порядок {1, 4, 0, 7}). Свойство 0x11600703 перебирается, пока не ответит:
     * на этом ГУ зона 0 отвечала status=3, поэтому первыми идут зоны сидений.
     */
    val OUTSIDE_TEMP_AREAS = intArrayOf(AREA_SEAT_LEFT, AREA_SEAT_RIGHT, AREA_GLOBAL, 7)

    /**
     * Зоны вендорского AC_AMBIENT_TEMP. EX2 Tools читает его как
     * `getIntProperty(0x2140A377, 0)`, поэтому глобальная зона идёт первой,
     * а остальные остаются перебором: на этом ГУ обычный `getProperty` в зоне 0
     * ответил status=3, и типизированное чтение — отдельный канал, а не догадка.
     */
    val OUTSIDE_AMBIENT_AREAS = intArrayOf(AREA_GLOBAL, AREA_SEAT_LEFT, AREA_SEAT_RIGHT, AREA_HVAC_ALL)

    /**
     * Зона «1-й и 2-й ряд», которой CentralEXAuto пишет компрессор и которой
     * перебирает скорости вентилятора (`AppConstants.HVAC_AC_AREAS = {1, 5, 49, 0}`,
     * `PhoneSyncService.hvacFanAreaCandidates = {1, 49, 5, 0}`).
     */
    const val AREA_ROW_1_2 = 49

    /**
     * Порядок перебора зон для тех свойств, где приложение, работающее на этом гу,
     * не угадывает зону, а пробует четыре известные, пока запись не пройдёт.
     */
    val HVAC_AREAS = intArrayOf(AREA_SEAT_LEFT, AREA_ROW_1_2, AREA_ROW_1_ALL, AREA_GLOBAL)

    /**
     * Зоны уставки, которые перебирает CentralEXAuto (`TempStepperService.AREA_IDS`
     * = {1, 4, 0, 7}) и штатный климат Flyme (1 — водитель, 4 — пассажир, 16 — второй
     * ряд). На этом ГУ 0x15600503 в зоне 1 отдаёт целое, поэтому приложение ищет
     * первую зону, которая отвечает float в 15,5…33 °C, и пишет в неё.
     */
    val SETPOINT_AREAS = intArrayOf(AREA_SEAT_LEFT, AREA_SEAT_RIGHT, AREA_GLOBAL, 7)

    // --- Климат ----------------------------------------------------------------

    /**
     * Адаптированные AOSP-свойства климата, которыми пользуется штатный HVAC Flyme.
     * Типы и адреса взяты из таблицы `PropertyIds.createPropertyInfo()` в
     * docs/flyme-hvac-apk.md §6.1; там же описана запись через
     * `setBoolean/setInt/setFloatProperty` с правом `CONTROL_CAR_CLIMATE`. CentralEXAuto —
     * приложение, которое на этом гу действительно пишет климат, — объявляет
     * `android.car.permission.CAR_HVAC`, поэтому в манифесте есть оба права.
     *
     * Свойств обогревов в этой таблице четыре, и ни один из источников не даёт
     * расшифровку ступеней: приложение принимает число 0…3 и подписывает его
     * «ступень N», не придумывая ему название уровня.
     */
    const val PROP_HVAC_POWER_ON = 354419984        // 0x15200510 bool, общий выключатель
    const val PROP_HVAC_AC_ON = 354419973           // 0x15200505 bool, компрессор
    // HVAC_AUTO_ON (0x1520050A) по Drive Assist на этом ГУ — NOOP: не читается и не пишется.
    const val PROP_HVAC_RECIRC_ON = 354419976       // 0x15200508 bool, циркуляция
    const val PROP_HVAC_MAX_DEFROST = 354419985     // 0x15200511 bool, обдув лобового
    const val PROP_HVAC_REAR_DEFROST = 354419988    // 0x15200514 bool, заднее стекло
    const val PROP_HVAC_FAN_SPEED = 356517120       // 0x15400500 int, вентилятор
    const val PROP_HVAC_TEMPERATURE_SET = 358614275 // 0x15600503 float, устав
    const val PROP_HVAC_SEAT_HEAT = 356517131       // 0x1540050B int, подогрев сиденья
    const val PROP_HVAC_WHEEL_HEAT = 289408269      // 0x1140050D int, подогрев руля

    /** Датчик салона 0x15600502, только проба: EX Sapo Central принимает его в −45…65 °C. */
    const val PROP_HVAC_TEMPERATURE_CURRENT = 358614274

    /**
     * Направление обдува: ZONED_FAN_DIRECTION 0x21401020 и его AOSP-псевдоним 0x15400501.
     * Drive Assist читал и писал оба на живом IHU629G (✅): маска 1 лицо, 2 ноги, 3 лицо
     * и ноги, 4 стекло, 6 стекло и ноги; зона игнорируется, 5 машина отвергает.
     */
    const val PROP_HVAC_FAN_DIRECTION_VENDOR = 557846560
    const val PROP_HVAC_FAN_DIRECTION = 356517121

    const val DIRECTION_FACE = 1
    const val DIRECTION_FEET = 2
    const val DIRECTION_FACE_FEET = 3
    const val DIRECTION_GLASS = 4
    const val DIRECTION_GLASS_FEET = 6

    /**
     * `HVAC_MAX_DEFROST` 0x15200507 — адрес, по которому Drive Assist включает обдув
     * лобового на живом IHU629G (✅ с физическим откликом, зона 75). Пишется первым;
     * `PROP_HVAC_MAX_DEFROST` 0x15200511 из таблицы geely_ex2_tools включением не
     * проверялся и остаётся запасной попыткой в той же цепочке.
     */
    const val PROP_HVAC_MAX_DEFROST_DA = 354419975   // 0x15200507 bool

    /**
     * Нить обогрева лобового стекла 0x10200C00, зона 117, boolean. В Central EX
     * Auto 2.19.78 состояние читается `getBooleanProperty(0x10200C00, 117)`, а
     * кнопка пишет `setBooleanProperty(0x10200C00, 117, value)` — те же адрес,
     * зона и тип, что у нас. Это не MAX_DEFROST 0x15200507: тот включает
     * максимальный обдув лобового вентилятором, а здесь — электрический обогрев
     * стекла. Раньше панель показывала вместо него режим обдува, поэтому кнопка
     * «лобовое» ничего не грела.
     *
     * 270 535 680 = 0x10200C00. Прежнее число 270 536 704 — это 0x10201000, другой
     * адрес: журнал 2026-10-28 показал, что на него машина не отвечает ни чтением,
     * ни записью, поэтому кнопка уходила в пустоту.
     */
    const val PROP_HVAC_WINDSHIELD_HEAT = 270535680  // 0x10200C00 bool

    /**
     * Зона 75, в которой Drive Assist подтверждает основные HVAC-флаги того же
     * IHU629G (питание, компрессор, циркуляция, обдув, вентилятор). Это не 0x75 = 117
     * из таблицы CentralEXAuto, а другое число адаптированной зоны: прошивка отвечает
     * на адрес в одной зоне и молчит в другой, поэтому расхождение решает проба на
     * машине, а не выбор «похожей» константы.
     */
    const val AREA_HVAC_DA = 75

    /** Зона заднего стекла по проверке Drive Assist; CentralEXAuto пишет его в зону 0. */
    const val AREA_REAR_DEFROST_DA = 2

    /** Зоны уставки 0x1F и 0x2C, которыми оперирует разбор Drive Assist. */
    const val AREA_SETPOINT_DA_LEFT = 31
    const val AREA_SETPOINT_DA_RIGHT = 44

    /**
     * Свойства климата, которые CentralEXAuto действительно использует на этом гу:
     * `PhoneSyncService.setZoneTemp` и `readDriverTemp` пишут и читают устав
     * вендорским float-свойством, `setAcPower` — булевым компрессором с повтором
     * тем же числом, `setFanLevel` —int-свойством вентилятора.
     *
     * Уставку Central EX Auto пишет двумя путями: TempStepperService — AOSP-свойством
     * 0x15600503 в зону, ответившую Float, PhoneSyncService.setZoneTemp — вендорским
     * 0x25401036. Журнал 2026-10-28 показал, что запись float в 0x15600503 и
     * 0x25401036 в зону 1 принимается, но ни шаг, ни зеркало не меняются. Поэтому
     * после AOSP-адреса перебираются каналы, которые на этом ГУ отвечают float-°C:
     * канонический 0x24120300 (ответ VHAL на зеркало 0x2140A6DC, зона 0) и само
     * зеркало. Шкала целого шага (°C − 16) осталась только для показа.
     */
    const val PROP_HVAC_TEMPERATURE_ADJUST = 624955446      // 0x25401036 float, устав зоны в °C
    const val PROP_HVAC_TEMPERATURE_SET_INT = 354419971     // 0x15200503, шкала не подтверждена, без записи
    const val PROP_HVAC_TEMPERATURE_SET_VENDOR = 557885148  // 0x2140A6DC, зеркало уставки
    const val PROP_HVAC_TEMPERATURE_SET_CANONICAL = 605160192 // 0x24120300, канонический ответ на зеркало
    const val PROP_HVAC_AC_ON_ALT = 358613145               // 0x15600099 bool, затем int
    const val PROP_HVAC_POWER_VENDOR = 557884965            // 0x2140A625 V_AC_POWER, только чтение
    const val PROP_HVAC_FAN_VENDOR = 557884439              // 0x2140A417 V_AC_FAN_LEVEL, только чтение
    const val PROP_HVAC_RECIRC_VENDOR = 557846566           // 0x21401026, только чтение

    /**
     * TRIP_KM 0x2740A679 — адрес, который Drive Assist на живом IHU629G называет
     * счётчиком поездки. На этом ГУ он счётчиком не оказался: журнал 2026-10-28
     * прочитал в зоне 1 значение 5461,9 при одометре 5528,1, а канонический id
     * ответа — 0x24801500 из семейства энергии. Поэтому приложение читает его
     * только в диагностической пробе и не строит на нём расстояние поездки.
     */
    const val PROP_TRIP_KM = 658548345

    /** AOSP-обёртка температуры за бортом, уже в °C. */
    const val PROP_ENV_OUTSIDE_TEMPERATURE = 289408771      // 0x11400703, AOSP

    /** Средний расход: вендорское свойство в сотых долях кВт·ч/100 км (TelemetryReader). */
    const val PROP_AVG_ENERGY_CONSUMPTION = 557885176       // 0x2140A6F8

    // --- Состояние зарядки (адаптированные числа 0x24205C01…) -----------------

    const val STATE_NO_CHARGING = 606100481
    const val STATE_AC_CHARGING = 606100482
    const val STATE_CHARGING_END = 606100483
    const val STATE_CHARGING_COMPLETE = 606100484
    const val STATE_HEATING = 606100485
    const val STATE_BOOKING = 606100486
    const val STATE_DISCHARGING = 606100488
    const val STATE_DC_CHARGING = 606100501
    const val STATE_AC_SUSPEND = 606100517
    const val STATE_DC_CHARGING_END = 606100518

    // --- Разъём ---------------------------------------------------------------

    const val PLUG_NONE = 605225490
    const val PLUG_AC_CONNECTED = 605225491
    const val PLUG_DC_CONNECTED = 605225492
    const val PLUG_DISCHARGE_CONNECTED = 605225494
    const val PLUG_INTEGRATION_CONNECTED = 605225499

    // --- Режимы движения ------------------------------------------------------

    private const val DRIVE_MODE_ECO = 0x22010101
    private const val DRIVE_MODE_COMFORT = 0x22010102
    private const val DRIVE_MODE_DYNAMIC = 0x22010103
    private const val DRIVE_MODE_XC = 0x22010104
    private const val DRIVE_MODE_PURE = 0x22010106
    private const val DRIVE_MODE_HYBRID = 0x22010107
    private const val DRIVE_MODE_ADAPTIVE = 0x22010116

    // --- Уровни рекуперации ---------------------------------------------------

    private const val REGEN_LOW = 0x20020501
    private const val REGEN_MID = 0x20020502
    private const val REGEN_HIGH = 0x20020503
    private const val REGEN_AUTO = 0x20020504

    // --- Зажигание и ключ (адаптированные значения ISensorEvent) ---------------

    /** 0x200101 = UNDEFINED остаётся нерасшифрованным: оно и есть «не определено». */
    private const val IGNITION_LOCK = 0x200102
    private const val IGNITION_OFF = 0x200103
    private const val IGNITION_ACC = 0x200104
    private const val IGNITION_ON = 0x200105
    private const val IGNITION_START = 0x200106
    private const val IGNITION_DRIVING = 0x200107

    /** ACTV и DRKVG прошивка трактует как «авторизованный ключ в салоне». */
    private const val USG_ABANDONED = 0x201301
    private const val USG_INACTIVE = 0x201302
    private const val USG_CONVENIENCE = 0x201303
    private const val USG_ACTIVE = 0x201304
    private const val USG_DRIVING = 0x201305

    // --- Диапазоны приёмки ---------------------------------------------------

    const val SOC_MAX_PERCENT = 100.0

    /** Выше этого EV_BATTERY_LEVEL трактуется как остаточная энергия в Вт·ч. */
    const val LEVEL_IS_WATT_HOURS_ABOVE = 100.0
    const val CAPACITY_MIN_WH = 1000.0
    const val RANGE_MAX_KM = 2000.0
    const val SPEED_MAX_KMH = 140.0

    /**
     * Пределы одометра. Значение дробное, и округлять его до целого нельзя: короткая
     * поездка тогда исчезает. Ноль — ответ неготового адреса, а не пробег машины:
     * с ним цепочка переходит к следующему адресу, как и у EX Sapo Central.
     */
    const val ODOMETER_MIN_KM = 1.0
    const val ODOMETER_MAX_KM = 3_000_000.0

    fun odometerKm(raw: Double?): Double? =
        raw?.takeIf { it.isFinite() && it in ODOMETER_MIN_KM..ODOMETER_MAX_KM }

    /** Ниже этого показатель заряда — шум вокруг нуля, а не зарядка. */
    const val MIN_CHARGE_POWER_KW = ChargingSignals.MIN_POWER_KW

    /** Сутки: дольше этого свойства заряда не живут, всё остальное — заглушка. */
    const val CHARGE_MINUTES_MAX = 1440

    /**
     * Верхняя граница тока AC-зарядки, которую имеет смысл принимать: 32 A автомобиль
     * объявляет сам (Capy: MAX = 32 на живой машине), 64 A — потолок reasonable для
     * бытовой трёхфазной станции. Значение выше — не ответ, а мусор.
     */
    const val AC_CURRENT_MAX_A = 64
    const val TEMP_MIN_C = -50.0
    const val TEMP_MAX_C = 85.0

    /**
     * Какую уставку принимает чтение: 15,5…33 °C, кратно полградусу — границы
     * контроллера Capy. Шире, чем ставит панель, чтобы значение, выставленное
     * штатным климатом, не превращалось в «нет данных».
     */
    const val CLIMATE_TEMP_MIN_C = 15.5
    const val CLIMATE_TEMP_MAX_C = 33.0

    /**
     * Что ставит панель: 17…32 °C шагом в градус. Drive Assist на живом IHU629G видит
     * уставку квантованной по 1 °C — запись полуградуса читается обратно усечённой.
     */
    const val SETPOINT_MIN_C = 17.0
    const val SETPOINT_MAX_C = 32.0

    /**
     * Зона 1 (водитель) на этом ГУ отвечает целым шагом: 4 при 20,0 °C в зеркале,
     * то есть шаг = °C − 16. Центральное приложение перебирает {1, 4, 0, 7} и
     * принимает только Float, а запись делает в зону, которая ответила Float.
     * Целое здесь больше не пишется: его шкала не подтверждена, а запись в зону 1
     * журнал 2026-10-28 показал принятой и не изменившей ни шаг, ни зеркало.
     * Смещение осталось только для показа значения, когда ни один Float-канал
     * не отвечает.
     */
    const val SETPOINT_INT_OFFSET_C = 16.0

    /**
     * Диапазон, в который мы заводим уставку перед записью в
     * HVAC_TEMPERATURE_ADJUST: 16 — нижняя граница `PhoneSyncService.clampTemp`
     * (CentralEXAuto 2.11.114: `coerceIn(16f, 30f)`), 32 — верхняя граница
     * жестовой регулировки 2.19.78. Уже прочитанное значение этим не обрезаем —
     * срезается только то, что уходит в автомобиль.
     */
    const val ADJUST_TEMP_MIN_C = 16.0
    const val ADJUST_TEMP_MAX_C = 32.0

    /** Средний расход принимается в 0…60 кВт·ч/100 км. */
    const val CONSUMPTION_MAX_KWH_100KM = 60.0

    /**
     * Ступени вентилятора 0…8: Drive Assist на живом IHU629G видит 0 «выкл»
     * и 1…8. Ответивший ноль — это выключенный вентилятор, а не молчание
     * свойства: молчание в приложение приходит исключением, а не нулём.
     */
    const val FAN_MIN = 0
    const val FAN_MAX = 8

    /** Ступень вентилятора быстрых обогрева и охлаждения. */
    const val PRESET_FAN = 6

    /** Ступень вентилятора, которую оставляет повторное нажатие пресета. */
    const val PRESET_FAN_REPEAT = 2

    /** Уставка, которую оставляет повторное нажатие быстрого обогрева. */
    const val PRESET_HEAT_TEMP_REPEAT_C = 27.0

    /** Ступень подогрева: больше трёх значений ни один из источников не встречал. */
    const val HEAT_MIN_LEVEL = 0
    const val HEAT_MAX_LEVEL = 3

    /**
     * SOC в процентах.
     *
     * Вендорское свойство процентов выигрывает, когда значение в диапазоне;
     * значения выше 100 там трактуются как десятые доли. EV_BATTERY_LEVEL —
     * резерв, и он неоднозначен: этот же гу отвечает им либо в %, либо в Вт·ч,
     * поэтому свыше 100 он делится на ёмкость из настроек, а не на свойство
     * ёмкости автомобиля.
     */
    fun socPercent(
        vendorPercent: Double?,
        batteryLevel: Double?,
        capacityWh: Double?
    ): Int? {
        vendorPercent?.takeIf { it.isFinite() }?.let { raw ->
            val percent = if (raw > SOC_MAX_PERCENT) raw / 10.0 else raw
            if (percent in 0.0..SOC_MAX_PERCENT) return percent.roundToInt().coerceIn(0, 100)
        }
        val level = batteryLevel?.takeIf { it.isFinite() } ?: return null
        if (level <= LEVEL_IS_WATT_HOURS_ABOVE) return level.roundToInt().coerceIn(0, 100)
        val capacity = capacityWh?.takeIf { it.isFinite() && it > CAPACITY_MIN_WH } ?: return null
        return (level / capacity * 100.0).roundToInt().coerceIn(0, 100)
    }

    /** Сырое значение вендорского температурного свойства Flyme. */
    fun flymeTempC(raw: Double): Double = (raw - 80.0) / 2.0

    /**
     * Температура с вендорского свойства Flyme. Сырой ноль — не ответ датчика:
     * прошивка отдаёт его, когда значения нет, и формула превратила бы его в −40 °C.
     */
    fun flymeTemp(raw: Double?): Double? =
        raw?.takeIf { it.isFinite() && it != 0.0 }?.let { flymeTempC(it) }

    /** Температура принимается только в физическом диапазоне −50…85 °C. */
    fun tempC(value: Double?): Int? {
        val c = value?.takeIf { it.isFinite() } ?: return null
        if (c < TEMP_MIN_C || c > TEMP_MAX_C) return null
        return c.roundToInt()
    }

    /**
     * Температура за бортом с 0x11600703 по правилу CentralEXAuto: float — уже °C;
     * целое — десятые доли в пределах −55…70 °C (200 — это 20,0), иначе градусы.
     */
    fun outsideCelsius(raw: Any?): Int? {
        val value = when (raw) {
            is Float -> raw.toDouble()
            is Double -> raw
            is Int -> if (raw > -550 && raw < 700) raw / 10.0 else raw.toDouble()
            is Long -> if (raw > -550 && raw < 700) raw / 10.0 else raw.toDouble()
            else -> return null
        }
        return tempC(value)
    }

    /**
     * Скорость в км/ч. Значение свойство уже отдаёт в км/ч; поправка +1 выше
     * 10 км/ч — коррекция приборной панели, которую видит водитель.
     */
    fun speedKmh(raw: Double?): Int? {
        val value = raw?.takeIf { it.isFinite() } ?: return null
        val normalized = abs(value).coerceIn(0.0, SPEED_MAX_KMH)
        val corrected = if (normalized >= 10.0) normalized + 1.0 else normalized
        return corrected.coerceIn(0.0, SPEED_MAX_KMH).roundToInt()
    }

    /**
     * Режим движения из кода свойства.
     *
     * 1/2/3 принимаются как значения адаптера, которые прошивка отдаёт вместо
     * полного AutoFuncId (Comsport/Eco/Dynamic в порядке geely_ex2_tools).
     * Другая расшифровка — 0 NORMAL / 1 ECO / 2 SPORT — относится к сигналу
     * шины BCM_DM_TargetModeReq, до которого у нас нет транспорта, поэтому
     * здесь она сознательно не применяется.
     *
     * Кода 0x22010109 «Снег» в расшифровке больше нет: на этой машине такого
     * режима не существует, и отвеченный код означает что-то другое — он
     * остаётся нерасшифрованным, а не подписывает поездку чужим названием.
     */
    fun driveMode(raw: Int?): DriveMode? = when (raw) {
        DRIVE_MODE_ECO, 2 -> DriveMode.ECO
        DRIVE_MODE_COMFORT, 1 -> DriveMode.COMFORT
        DRIVE_MODE_DYNAMIC, 3 -> DriveMode.SPORT
        DRIVE_MODE_XC -> DriveMode.XC
        DRIVE_MODE_PURE -> DriveMode.PURE
        DRIVE_MODE_HYBRID -> DriveMode.HYBRID
        DRIVE_MODE_ADAPTIVE -> DriveMode.ADAPTIVE
        else -> null
    }

    /** Уровень рекуперации: полный AutoFuncId или короткий счёт 1/2/3. */
    fun regenLevel(raw: Int?): RegenLevel? = when (raw) {
        REGEN_LOW, 1 -> RegenLevel.LOW
        REGEN_MID, 2 -> RegenLevel.MID
        REGEN_HIGH, 3 -> RegenLevel.HIGH
        REGEN_AUTO -> RegenLevel.AUTO
        else -> null
    }

    /** Режимы, которые панель предлагает выбрать: коды Drive Assist для IHU629G. */
    val SELECTABLE_DRIVE_MODES = listOf(DriveMode.ECO, DriveMode.COMFORT, DriveMode.SPORT)
    val SELECTABLE_REGEN = listOf(RegenLevel.LOW, RegenLevel.MID, RegenLevel.HIGH)

    /**
     * Зоны режима и рекуперации: Central EX Auto 2.19.78 и пишет, и читает
     * 0x22010100 по {0, 1, 0x01000000}, а 0x20020500 — по {0, 1}.
     */
    val DRIVE_AREAS = intArrayOf(0, 1, 16_777_216)

    fun driveModeWrites(mode: DriveMode): List<VhalWrite> {
        val code = when (mode) {
            DriveMode.ECO -> DRIVE_MODE_ECO
            DriveMode.COMFORT -> DRIVE_MODE_COMFORT
            DriveMode.SPORT -> DRIVE_MODE_DYNAMIC
            else -> return emptyList()
        }
        return DRIVE_AREAS.map {
            VhalWrite(PROP_DRIVE_MODE, it, int = code, label = "DM_FUNC_DRIVE_MODE_SELECT")
        }
    }

    /** Запись рекуперации, проверенная Drive Assist на живом IHU629G (✅), зоны REGEN_AREAS. */
    fun regenWrites(level: RegenLevel): List<VhalWrite> {
        val code = when (level) {
            RegenLevel.LOW -> REGEN_LOW
            RegenLevel.MID -> REGEN_MID
            RegenLevel.HIGH -> REGEN_HIGH
            RegenLevel.AUTO -> return emptyList()
        }
        return REGEN_AREAS.map {
            VhalWrite(PROP_REGEN_LEVEL, it, int = code, label = "SETTING_FUNC_ENERGY_REGENERATION")
        }
    }

    /**
     * Передача из битовой маски свойства. Старшие биты отбрасываются — так же, как
     * в Capy, — но внутри маски должно быть ровно одно значение: двух передач
     * одновременно прошивка не сообщает, и угадывать приоритет приложение не будет.
     */
    fun gear(raw: Int?): Gear? {
        val bits = raw?.and(GEAR_MASK) ?: return null
        return when (bits) {
            GEAR_PARK -> Gear.P
            GEAR_REVERSE -> Gear.R
            GEAR_NEUTRAL -> Gear.N
            GEAR_DRIVE -> Gear.D
            else -> null
        }
    }

    /**
     * Зажигание по адаптированному значению сенсорной обёртки ECARX. Короткое
     * число сырого PEPS_POWER_MODE здесь сознательно не принимается: оно неоднозначно,
     * и его расшифровку не даёт ни один из разобранных источников.
     */
    fun ignition(raw: Int?): IgnitionState? = when (raw) {
        IGNITION_LOCK -> IgnitionState.LOCK
        IGNITION_OFF -> IgnitionState.OFF
        IGNITION_ACC -> IgnitionState.ACC
        IGNITION_ON -> IgnitionState.ON
        IGNITION_START -> IgnitionState.START
        IGNITION_DRIVING -> IgnitionState.DRIVING
        else -> null
    }

    /**
     * Ключ в салоне по режиму использования. Null — когда ответ не про ключ:
     * CONVENIENCE ни один из источников ключом не объясняет.
     */
    fun keyInCabin(raw: Int?): Boolean? = when (raw) {
        USG_ACTIVE, USG_DRIVING -> true
        USG_ABANDONED, USG_INACTIVE -> false
        else -> null
    }

    // --- Климат: декодеры ------------------------------------------------------

    /**
     * Флаг климата. Гу отдаёт либо boolean, либо число, где включено — `1`, а выключено
     * — `0` или `2`. Двойку он принимает выключенной не по догадке: разбор Drive Assist
     * на живом IHU629G описывает сырое `2` у 0x15200510 как «выключено» (адаптированный
     * `getBooleanProperty` отвечает на него false), и их приложение на этом же правиле
     * публиковало «вкл», считая любую ненулевую величину включённой. Любое другое
     * число — «неизвестно»: панель показывает отсутствие данных, а автомат записи не
     * отправляет, вместо того чтобы угадать состояние и toggle-командой включить то,
     * что пользователь собирался выключить.
     */
    fun flag(value: Double?): Boolean? = when {
        value == null || !value.isFinite() -> null
        value == 1.0 -> true
        value == 0.0 || value == 2.0 -> false
        else -> null
    }

    /**
     * Уставка климата в °C. Значение вне 15,5…33 или не кратное полуградусу
     * не принимается: это не «проверка на правдоподобие», а границы, за которые
     * штатный контроллер не выходит вообще.
     */
    fun climateTempC(raw: Double?): Double? {
        val value = raw?.takeIf { it.isFinite() } ?: return null
        val quantized = (value * 2.0).roundToInt() / 2.0
        return quantized.takeIf { it in CLIMATE_TEMP_MIN_C..CLIMATE_TEMP_MAX_C }
    }

    /**
     * Float-уставка события или типизированного чтения. Целое сюда не попадает:
     * зона 1 0x15600503 отдаёт шаг, а не градусы, и событие с ним не должно
     * затирать показание, полученное из зеркала или другой float-зоны.
     */
    fun setpointFloatCelsius(raw: Any?): Double? =
        if (raw is Float || raw is Double) climateTempC((raw as Number).toDouble()) else null

    /** Градусы шага 0x15600503 — только для показа, когда float-каналы молчат. */
    fun setpointFromRaw(raw: Double?): Double? {
        val value = raw?.takeIf { it.isFinite() } ?: return null
        return climateTempC(value + SETPOINT_INT_OFFSET_C)
    }

    /** Ступень вентилятора 0…8: ноль читается как «выкл», а не как отсутствие ответа. */
    fun fanSpeed(raw: Double?): Int? {
        val value = raw?.takeIf { it.isFinite() }?.roundToInt() ?: return null
        return value.takeIf { it in FAN_MIN..FAN_MAX }
    }

    /** Ступень подогрева 0…3. Больше трёх источников не наблюдало. */
    fun heatLevel(raw: Double?): Int? {
        val value = raw?.takeIf { it.isFinite() }?.roundToInt() ?: return null
        return value.takeIf { it in HEAT_MIN_LEVEL..HEAT_MAX_LEVEL }
    }

    /** Маска направления обдува; 5 машина отвергает, остальное — не ответ. */
    fun fanDirection(raw: Double?): Int? {
        val value = raw?.takeIf { it.isFinite() }?.roundToInt() ?: return null
        return value.takeIf {
            it == DIRECTION_FACE || it == DIRECTION_FEET || it == DIRECTION_FACE_FEET ||
                it == DIRECTION_GLASS || it == DIRECTION_GLASS_FEET
        }
    }

    /**
     * Что можно отправить в вендорский HVAC_TEMPERATURE_ADJUST. Значение сначала
     * проходит проверку уставки, затем квантуется на 0,5 и сжимается до 16…32.
     */
    fun adjustTempC(value: Double?): Double? = climateTempC(value)
        ?.let { (it * 2.0).roundToInt() / 2.0 }
        ?.coerceIn(ADJUST_TEMP_MIN_C, ADJUST_TEMP_MAX_C)

    /** Средний расход: свойство отдаёт сотые доли кВт·ч/100 км (TelemetryReader /100). */
    fun avgConsumption(raw: Double?): Double? {
        val value = raw?.takeIf { it.isFinite() }?.let { it / 100.0 } ?: return null
        if (value !in 0.0..CONSUMPTION_MAX_KWH_100KM) return null
        return (value * 10.0).roundToInt() / 10.0
    }

    /** Подключён ли кабель по адаптированному коду разъёма. */
    fun portConnected(raw: Int?): Boolean? = when (raw) {
        PORT_CONNECTED -> true
        PORT_DISCONNECTED -> false
        else -> null
    }

    /**
     * Следующее состояние климата после команды панели. Nil там, где автомобиль
     * сигнал не ответил: угадывать, что сейчас включено, приложение не будет —
     * вместо этого панель показывает «нет данных» и не отправляет запись.
     * Исключение — обогрев лобового: его адрес 0x10200C00 на этом ГУ не отвечает
     * на чтение, поэтому неизвестное состояние считается выключенным, и запись
     * отправляет выбор панели (см. [climateWrites] и `CarApiSource.writeClimate`).
     */
    fun climateNext(change: ClimateChange, current: Climate): Climate? = when (change) {
        ClimateChange.POWER -> current.hvacOn?.let { current.copy(hvacOn = !it) }
        ClimateChange.AC -> current.acOn?.let { current.copy(acOn = !it) }
        ClimateChange.RECIRC -> current.recircOn?.let { current.copy(recircOn = !it) }
        ClimateChange.FRONT_DEFROST ->
            current.frontDefrostOn?.let { current.copy(frontDefrostOn = !it) }

        ClimateChange.WINDSHIELD_HEAT ->
            current.windshieldHeatOn?.let { current.copy(windshieldHeatOn = !it) }

        ClimateChange.REAR_DEFROST ->
            current.rearDefrostOn?.let { current.copy(rearDefrostOn = !it) }

        ClimateChange.FAN_UP ->
            current.fanSpeed?.let { current.copy(fanSpeed = stepFan(it, 1)) }

        ClimateChange.FAN_DOWN ->
            current.fanSpeed?.let { current.copy(fanSpeed = stepFan(it, -1)) }

        ClimateChange.DRIVER_UP ->
            current.driverTempC?.let { current.copy(driverTempC = stepTemp(it, up = true)) }

        ClimateChange.DRIVER_DOWN ->
            current.driverTempC?.let { current.copy(driverTempC = stepTemp(it, up = false)) }

        ClimateChange.DIRECTION_FACE -> direction(current, DIRECTION_FACE)
        ClimateChange.DIRECTION_FEET -> direction(current, DIRECTION_FEET)
        ClimateChange.DIRECTION_GLASS -> direction(current, DIRECTION_GLASS)
        ClimateChange.DIRECTION_GLASS_FEET -> direction(current, DIRECTION_GLASS_FEET)

        ClimateChange.SEAT_DRIVER ->
            current.seatHeatDriver?.let { current.copy(seatHeatDriver = cycleHeat(it)) }

        ClimateChange.SEAT_PASSENGER ->
            current.seatHeatPassenger?.let { current.copy(seatHeatPassenger = cycleHeat(it)) }

        // Руль EX Sapo Central только включает и выключает (0/1): ступеней выше
        // единицы у этого свойства ни один из источников не писал.
        ClimateChange.WHEEL_HEAT ->
            current.wheelHeat?.let { current.copy(wheelHeat = if (it > HEAT_MIN_LEVEL) HEAT_MIN_LEVEL else 1) }
    }

    /**
     * Что именно приложение собирается записать в автомобиль: список попыток от
     * самого подтверждённого адреса к резервным, каждая — свойство, зона и значение
     * уже нужного типа. Порядок взят из CentralEXAuto (`PhoneSyncService.setAcPower`,
     * `setFanLevel`, `setZoneTemp`): там то же свойство сначала пишется булевым по
     * зонам {1, 49, 5, 0}, потом целым по тем же зонам. Уставку 2.19.78 пишет
     * AOSP-свойством `0x15600503` float-°C в зону, ответившую Float. Резервные
     * каналы — вендорский `0x25401036`, зеркало `0x2140A6DC` и его канонический
     * ответ `0x24120300`: на этом ГУ именно они отвечают float-°C, тогда как зона 1
     * 0x15600503 отдаёт целый шаг и запись игнорирует.
     *
     * Пустой список — когда состояние сигнала неизвестно: без прочитанного значения
     * приложение не знает, что ставить, и угадывать не будет.
     */
    fun climateWrites(
        change: ClimateChange,
        after: Climate,
        setpointArea: Int = AREA_SEAT_LEFT
    ): List<VhalWrite> = when (change) {
        ClimateChange.POWER -> after.hvacOn?.let { powerWrites(it) } ?: emptyList()

        ClimateChange.AC -> after.acOn?.let { acWrites(it) } ?: emptyList()

        ClimateChange.RECIRC -> after.recircOn?.let {
            listOf(VhalWrite(PROP_HVAC_RECIRC_ON, AREA_HVAC_ALL, bool = it, label = "HVAC_RECIRC_ON"))
        } ?: emptyList()

        ClimateChange.FRONT_DEFROST -> after.frontDefrostOn?.let { frontDefrostWrites(it) } ?: emptyList()

        ClimateChange.WINDSHIELD_HEAT ->
            after.windshieldHeatOn?.let { windshieldHeatWrites(it) } ?: emptyList()

        ClimateChange.REAR_DEFROST -> after.rearDefrostOn?.let { rearDefrostWrites(it) } ?: emptyList()

        ClimateChange.FAN_UP, ClimateChange.FAN_DOWN -> after.fanSpeed?.let { fanWrites(it) } ?: emptyList()

        ClimateChange.DRIVER_UP, ClimateChange.DRIVER_DOWN ->
            after.driverTempC?.let { setpointWrites(it, setpointArea) } ?: emptyList()

        ClimateChange.DIRECTION_FACE,
        ClimateChange.DIRECTION_FEET,
        ClimateChange.DIRECTION_GLASS,
        ClimateChange.DIRECTION_GLASS_FEET -> after.fanDirection?.let { directionWrites(it) } ?: emptyList()

        ClimateChange.SEAT_DRIVER -> after.seatHeatDriver?.let { seatWrites(AREA_SEAT_LEFT, it) } ?: emptyList()

        ClimateChange.SEAT_PASSENGER -> after.seatHeatPassenger?.let { seatWrites(AREA_SEAT_RIGHT, it) } ?: emptyList()

        ClimateChange.WHEEL_HEAT -> after.wheelHeat?.let { wheelWrites(it) } ?: emptyList()
    }

    /** Один шаг быстрого режима: что поменять и какой цепочкой записей. */
    data class PresetStep(val title: String, val writes: List<VhalWrite>, val after: (Climate) -> Climate)

    /**
     * Шаги быстрых режимов. Первое нажатие задаёт весь сценарий, повторное —
     * снимает его: обогревы гаснут, кондиционер выключается, вентилятор
     * переходит на вторую ступень, у быстрого обогрева уставка становится
     * 27 °C. Обдув и уставка охлаждения остаются на месте. Кондиционер
     * включается и выключается только тогда, когда прочитанное состояние ему
     * противоположно: «нажать» вслепую нельзя, иначе кнопка гасит уже
     * работающий компрессор.
     */
    fun presetSteps(
        preset: ClimatePreset,
        current: Climate,
        off: Boolean = false,
        setpointArea: Int = AREA_SEAT_LEFT
    ): List<PresetStep> {
        val steps = mutableListOf<PresetStep>()
        if (current.frontDefrostOn == true) {
            steps += PresetStep("максимальный обдув", frontDefrostWrites(false)) {
                it.copy(frontDefrostOn = false)
            }
        }
        if (!off && current.hvacOn == false) {
            steps += PresetStep("климат", powerWrites(true)) { it.copy(hvacOn = true) }
        }
        val cool = preset == ClimatePreset.QUICK_COOL
        val tempTarget: Double?
        val directionTarget: Int?
        val fanTarget: Int?
        val acTarget: Boolean
        // true — включить все обогревы, false — выключить все.
        val heaters: Boolean
        if (off) {
            tempTarget = if (cool) null else PRESET_HEAT_TEMP_REPEAT_C
            directionTarget = null
            fanTarget = PRESET_FAN_REPEAT
            acTarget = false
            heaters = false
        } else if (cool) {
            tempTarget = SETPOINT_MIN_C
            directionTarget = DIRECTION_FACE
            fanTarget = PRESET_FAN
            acTarget = true
            heaters = false
        } else {
            tempTarget = SETPOINT_MAX_C
            directionTarget = DIRECTION_GLASS_FEET
            fanTarget = PRESET_FAN
            acTarget = false
            heaters = true
        }
        if (tempTarget != null && current.driverTempC != null && current.driverTempC != tempTarget) {
            steps += PresetStep("уставка", setpointWrites(tempTarget, setpointArea)) {
                it.copy(driverTempC = tempTarget)
            }
        }
        if (directionTarget != null && current.fanDirection != null && current.fanDirection != directionTarget) {
            steps += PresetStep("обдув", directionWrites(directionTarget)) {
                it.copy(fanDirection = directionTarget)
            }
        }
        if (fanTarget != null && current.fanSpeed != null && current.fanSpeed != fanTarget) {
            steps += PresetStep("вентилятор", fanWrites(fanTarget)) { it.copy(fanSpeed = fanTarget) }
        }
        if (current.acOn != null && current.acOn != acTarget) {
            steps += PresetStep("кондиционер", acWrites(acTarget)) { it.copy(acOn = acTarget) }
        }
        val seatTarget = if (heaters) HEAT_MAX_LEVEL else HEAT_MIN_LEVEL
        val wheelTarget = if (heaters) 1 else HEAT_MIN_LEVEL
        if (current.seatHeatDriver != null && current.seatHeatDriver != seatTarget) {
            steps += PresetStep("сиденье водителя", seatWrites(AREA_SEAT_LEFT, seatTarget)) {
                it.copy(seatHeatDriver = seatTarget)
            }
        }
        if (current.seatHeatPassenger != null && current.seatHeatPassenger != seatTarget) {
            steps += PresetStep("сиденье пассажира", seatWrites(AREA_SEAT_RIGHT, seatTarget)) {
                it.copy(seatHeatPassenger = seatTarget)
            }
        }
        if (current.wheelHeat != null && current.wheelHeat != wheelTarget) {
            steps += PresetStep("руль", wheelWrites(wheelTarget)) { it.copy(wheelHeat = wheelTarget) }
        }
        if (current.rearDefrostOn != null && current.rearDefrostOn != heaters) {
            steps += PresetStep("заднее стекло", rearDefrostWrites(heaters)) {
                it.copy(rearDefrostOn = heaters)
            }
        }
        if (current.windshieldHeatOn != null && current.windshieldHeatOn != heaters) {
            steps += PresetStep("лобовое стекло", windshieldHeatWrites(heaters)) {
                it.copy(windshieldHeatOn = heaters)
            }
        }
        return steps
    }

    /**
     * Сценарий всё ещё держится по ключевым прочитанным свойствам. Совпадение
     * обычной летней настройки — 17 °C, кондиционер и «в лицо» — пресетом не
     * считается: включённым он остаётся, только пока приложение его включало.
     */
    fun presetHeld(preset: ClimatePreset, current: Climate): Boolean =
        if (current.hvacOn != true) false else when (preset) {
            ClimatePreset.QUICK_COOL ->
                current.acOn == true && current.driverTempC == SETPOINT_MIN_C &&
                    current.fanDirection == DIRECTION_FACE
            ClimatePreset.QUICK_HEAT ->
                current.driverTempC == SETPOINT_MAX_C &&
                    current.fanDirection == DIRECTION_GLASS_FEET
        }

    private fun powerWrites(on: Boolean) =
        listOf(VhalWrite(PROP_HVAC_POWER_ON, AREA_ROW_1_ALL, bool = on, label = "HVAC_POWER_ON"))

    /**
     * Компрессор: первым идёт 0x15200505 в зоне 75 — его Drive Assist включал на этом
     * же IHU629G с фактическим откликом. 0x15600099 остаётся запасом: проба 2026-10-25
     * показала, что прошивка принимает её, но чтение после записи оставалось нулём —
     * запись вхолостую, поэтому раньше цепочка обрывалась на ней и до компрессора
     * не доходила.
     */
    private fun acWrites(on: Boolean): List<VhalWrite> =
        listOf(VhalWrite(PROP_HVAC_AC_ON, AREA_HVAC_ALL, bool = on, label = "HVAC_AC_ON @117")) +
            listOf(VhalWrite(PROP_HVAC_AC_ON, AREA_HVAC_DA, bool = on, label = "HVAC_AC_ON_DA")) +
            HVAC_AREAS.map { VhalWrite(PROP_HVAC_AC_ON_ALT, it, bool = on, label = "HVAC_AC_ON") } +
            HVAC_AREAS.map {
                VhalWrite(PROP_HVAC_AC_ON_ALT, it, int = if (on) 1 else 0, label = "HVAC_AC_ON int")
            }

    /** Зона 5 — каноническая по логу; остальные остаются запасом. */
    private fun fanWrites(level: Int) =
        (listOf(AREA_ROW_1_ALL) + HVAC_AREAS.filter { it != AREA_ROW_1_ALL })
            .map { VhalWrite(PROP_HVAC_FAN_SPEED, it, int = level, label = "HVAC_FAN_SPEED") }

    /** Каноническая зона заднего стекла по логу — 2; зона 0 остаётся запасом. */
    private fun rearDefrostWrites(on: Boolean) = listOf(
        VhalWrite(PROP_HVAC_REAR_DEFROST, AREA_REAR_DEFROST_DA, bool = on, label = "HVAC_ELECTRIC_DEFROSTER_ON"),
        VhalWrite(PROP_HVAC_REAR_DEFROST, AREA_GLOBAL, bool = on, label = "HVAC_ELECTRIC_DEFROSTER_ON @0")
    )

    private fun frontDefrostWrites(on: Boolean) = listOf(
        VhalWrite(PROP_HVAC_MAX_DEFROST_DA, AREA_HVAC_DA, bool = on, label = "HVAC_MAX_DEFROST_DA"),
        VhalWrite(PROP_HVAC_MAX_DEFROST, AREA_ROW_1_ALL, bool = on, label = "HVAC_MAX_DEFROST")
    )

    /** Электрический обогрев лобового: один булев адрес в зоне 117. */
    private fun windshieldHeatWrites(on: Boolean) = listOf(
        VhalWrite(PROP_HVAC_WINDSHIELD_HEAT, AREA_HVAC_ALL, bool = on, label = "HVAC_FRONT_WINDSHIELD_HEAT")
    )

    private fun seatWrites(area: Int, level: Int) =
        listOf(VhalWrite(PROP_HVAC_SEAT_HEAT, area, int = level, label = "HVAC_SEAT_TEMPERATURE"))

    /** Каноническая зона руля по логу — 1; зона 0 остаётся запасом. */
    private fun wheelWrites(level: Int) = listOf(
        VhalWrite(PROP_HVAC_WHEEL_HEAT, AREA_SEAT_LEFT, int = level, label = "HVAC_STEERING_WHEEL_HEAT"),
        VhalWrite(PROP_HVAC_WHEEL_HEAT, AREA_GLOBAL, int = level, label = "HVAC_STEERING_WHEEL_HEAT @0")
    )

    /** Вендорский адрес Drive Assist, затем AOSP-псевдоним в зонах 0 и 1. */
    private fun directionWrites(mask: Int) = listOf(
        VhalWrite(PROP_HVAC_FAN_DIRECTION_VENDOR, AREA_GLOBAL, int = mask, label = "ZONED_FAN_DIRECTION"),
        VhalWrite(PROP_HVAC_FAN_DIRECTION, AREA_GLOBAL, int = mask, label = "HVAC_FAN_DIRECTION"),
        VhalWrite(PROP_HVAC_FAN_DIRECTION, AREA_SEAT_LEFT, int = mask, label = "HVAC_FAN_DIRECTION")
    )

    private fun direction(current: Climate, mask: Int): Climate? =
        current.fanDirection?.let { current.copy(fanDirection = mask) }

    // Уставка пишется только float-°C, как в Central EX Auto и штатном климате.
    // Первым — 0x15600503 в зону, которая ответила Float (её находит CarApiSource);
    // на этом ГУ зона 1 отвечает целым шагом и запись игнорирует, поэтому дальше
    // идут каналы, которые действительно отдают float: канонический 0x24120300
    // (ответ VHAL на зеркало 0x2140A6DC, зона 0), само зеркало и 0x25401036.
    // Целая шкала «°C − 16» осталась только для показа: её запись проверялась
    // 2026-10-28 и не изменила ни шаг, ни зеркало.
    private fun setpointWrites(value: Double, area: Int): List<VhalWrite> {
        val adjusted = adjustTempC(value) ?: return emptyList()
        return listOf(
            VhalWrite(PROP_HVAC_TEMPERATURE_SET, area, floatC = adjusted, label = "HVAC_TEMPERATURE_SET °C"),
            VhalWrite(
                PROP_HVAC_TEMPERATURE_SET_CANONICAL, AREA_GLOBAL, floatC = adjusted,
                label = "HVAC_TEMPERATURE_SET канон. °C"
            ),
            VhalWrite(
                PROP_HVAC_TEMPERATURE_SET_VENDOR, AREA_SEAT_LEFT, floatC = adjusted,
                label = "V_HVAC_TEMP_SET °C (зеркало)"
            ),
            VhalWrite(
                PROP_HVAC_TEMPERATURE_ADJUST, AREA_SEAT_LEFT, floatC = adjusted,
                label = "HVAC_TEMPERATURE_ADJUST °C (резерв)"
            )
        )
    }

    private fun stepFan(level: Int, delta: Int): Int = (level + delta).coerceIn(FAN_MIN, FAN_MAX)

    /**
     * Шаг уставки в целый градус внутри 17…32: прочитанные полградуса сначала
     * округляются в сторону шага, поэтому 22,5 вверх даёт 23, а вниз — 22.
     */
    private fun stepTemp(value: Double, up: Boolean): Double {
        val next = if (up) floor(value) + 1.0 else ceil(value) - 1.0
        return next.coerceIn(SETPOINT_MIN_C, SETPOINT_MAX_C)
    }

    private fun cycleHeat(level: Int): Int =
        if (level >= HEAT_MAX_LEVEL) HEAT_MIN_LEVEL else level + 1

    /**
     * Что происходит с зарядкой по мнению автомобиля.
     *
     * Кодированное состояние первично: разъём говорит только о том, что кабель
     * вставлен, и сам по себе не различает «заряжается» и «подключено, ждёт».
     *
     * Состояние, которого нет в таблице [STATE_*], не отбрасывает разъём: проба
     * 2026-10-25 на живом ГУ показала, что на это свойство обёртка ECARX отвечает
     * коротким числом прошивки (`CHARGING_DISCHARGING_STATE` = 2, «обёртка не
     * адаптировала»), а разъём при этом отдаёт полный код `PLUG_*`. Такого числа
     * в таблице нет ни в одном из разобранных источников, поэтому оно остаётся
     * нерасшифрованным, а решение принимается по разъёму.
     */
    fun chargeFlow(state: Int?, plug: Int?): ChargeFlow? {
        val fromState = when (state) {
            STATE_AC_CHARGING -> ChargeFlow.AC
            STATE_DC_CHARGING -> ChargeFlow.DC
            STATE_HEATING -> ChargeFlow.HEATING
            STATE_BOOKING -> ChargeFlow.BOOKING
            STATE_DISCHARGING -> ChargeFlow.DISCHARGING
            STATE_AC_SUSPEND -> ChargeFlow.SUSPENDED
            STATE_CHARGING_END, STATE_CHARGING_COMPLETE, STATE_DC_CHARGING_END -> ChargeFlow.FINISHED
            STATE_NO_CHARGING -> ChargeFlow.IDLE
            else -> null
        }
        if (fromState != null) return fromState
        return when (plug) {
            PLUG_AC_CONNECTED, PLUG_DC_CONNECTED, PLUG_INTEGRATION_CONNECTED -> ChargeFlow.PLUGGED
            PLUG_DISCHARGE_CONNECTED -> ChargeFlow.DISCHARGING
            PLUG_NONE -> ChargeFlow.IDLE
            else -> null
        }
    }

    /** Only full verified plug codes identify AC/DC; short enum contracts are unknown. */
    fun connectorType(plug: Int?): ChargeType? = when (plug) {
        PLUG_AC_CONNECTED -> ChargeType.AC
        PLUG_DC_CONNECTED -> ChargeType.DC
        else -> null
    }

    fun plugConnected(plug: Int?): Boolean? = when (plug) {
        PLUG_AC_CONNECTED, PLUG_DC_CONNECTED, PLUG_INTEGRATION_CONNECTED,
        PLUG_DISCHARGE_CONNECTED -> true
        PLUG_NONE -> false
        else -> null
    }

    /** Flow and connector disagreement is not grounds to prefer either channel. */
    fun chargeType(state: Int?, plug: Int?): ChargeType =
        ChargingSignals.type(chargeFlow(state, plug), connectorType(plug))

    data class ChargePowerReading(val kw: Double, val source: ChargePowerSource)

    /**
     * Route by reliable flow/connector, never by voltage or largest/stale channel.
     * A measured zero is retained: it must not fall through to a stale fallback.
     */
    fun chargePowerReading(
        state: Int?, plug: Int?, acKw: Double?, dcKw: Double?,
        rateMw: Double? = null, volts: Double? = null, amps: Double? = null
    ): ChargePowerReading? {
        val flow = chargeFlow(state, plug)
        if (ChargingSignals.detect(flow, null, null) == false) return null
        val type = chargeType(state, plug)
        if (type == ChargeType.UNKNOWN) return null
        val measured = if (type == ChargeType.AC) acKw else dcKw
        if (measured != null) {
            // A negative/invalid primary is not permission to use a different stale feed.
            return measured.takeIf { it.isFinite() && it >= 0.0 }?.let {
                ChargePowerReading(it, if (type == ChargeType.AC) ChargePowerSource.AC_METER else ChargePowerSource.DC_METER)
            }
        }
        // Generic battery rate needs a reliable active state, not just a cable.
        if (ChargingSignals.detect(flow, null, null) != true) return null
        if (rateMw != null) {
            return rateMw.takeIf { it.isFinite() && it >= 0.0 }?.let {
                ChargePowerReading(it / 1_000_000.0, ChargePowerSource.BATTERY_RATE)
            }
        }
        return derivedChargePowerKw(volts, amps, flow, connectorType(plug))?.let {
            ChargePowerReading(it, ChargePowerSource.INPUT_VI)
        }
    }

    fun chargePowerKw(state: Int?, acKw: Double?, dcKw: Double?, plug: Int? = null): Double? =
        chargePowerReading(state, plug, acKw, dcKw)?.kw

    /**
     * Минуты из свойств заряда: оценка до конца и длительность сессии. Ноль и
     * отрицательное — это «не отвечено», а не «ноль минут»; потолок суток, потому
     * что прошивка на этом ГУ при пустом свойстве отдаёт большое число.
     */
    fun minutes(raw: Double?): Int? =
        raw?.takeIf { it.isFinite() }?.roundToInt()?.takeIf { it in 1..CHARGE_MINUTES_MAX }

    /**
     * Длительность идущей зарядки, минуты. Число берут, только когда состояние
     * зарядки активно: после остановки прошивка держит последние значения ток/
     * напряжение и время (наблюдение Capy — ChargerReadingGuard), и молча отдать
     * залипшее «42 мин» значит нарисовать зарядку, которой уже нет.
     */
    fun chargeWorkMinutes(raw: Double?, flow: ChargeFlow?): Int? =
        flow?.let { it == ChargeFlow.AC || it == ChargeFlow.DC || it == ChargeFlow.HEATING }
            ?.takeIf { it }
            ?.let { minutes(raw) }

    /**
     * Границы тока AC-зарядки, которые объявляет автомобиль: заданное значение и
     * минимум с максимумом. Null, когда ни одно из трёх свойств не ответило, —
     * панель тогда не показывает ни диапазон, ни «задано», а не рисует 5…32 A
     * из головы.
     *
     * Амперы принимаются в пределах 1…64: больше не обещает ни одно из разобранных
     * приложений, а 0 у этих свойств означает «ответа нет». Границы принимаются
     * только парой и только если минимум не больше максимума.
     */
    data class AcCurrentBounds(
        val setA: Int?,
        val minA: Int?,
        val maxA: Int?
    ) {
        val hasRange: Boolean
            get() = minA != null && maxA != null && minA <= maxA
    }

    fun acCurrentBounds(setA: Int?, minA: Int?, maxA: Int?): AcCurrentBounds {
        val set = setA?.takeIf { it in 1..AC_CURRENT_MAX_A }
        val min = minA?.takeIf { it in 1..AC_CURRENT_MAX_A }
        val max = maxA?.takeIf { it in 1..AC_CURRENT_MAX_A }
        val ordered = min?.let { m -> max?.takeIf { it >= m } }
        return AcCurrentBounds(set, min, ordered)
    }

    /** Input V/A are the AC network channel, not verified DC pack measurements. */
    fun derivedChargePowerKw(
        volts: Double?, amps: Double?, flow: ChargeFlow?, connector: ChargeType? = null
    ): Double? {
        if (ChargingSignals.detect(flow, null, null) != true ||
            ChargingSignals.type(flow, connector) != ChargeType.AC) return null
        val v = volts?.takeIf { it.isFinite() && it > 0.0 } ?: return null
        val a = amps?.takeIf { it.isFinite() && it > 0.0 } ?: return null
        val kw = a * v / 1_000.0
        return kw.takeIf { it.isFinite() && it > MIN_CHARGE_POWER_KW }
    }

    /**
     * Шаг записи в VHAL. Ровно одно из значений [bool], [int], [floatC] непустое —
     * по нему исполнитель и выбирает `setBooleanProperty`, `setIntProperty` или
     * `setFloatProperty`.
     */
    data class VhalWrite(
        val propertyId: Int,
        val areaId: Int,
        val bool: Boolean? = null,
        val int: Int? = null,
        val floatC: Double? = null,
        val label: String
    ) {
        init {
            val kinds = listOf(bool, int, floatC).count { it != null }
            require(kinds == 1) { "запись должна содержать ровно одно значение" }
        }

        fun valueText(): String = when {
            bool != null -> if (bool) "вкл" else "выкл"
            int != null -> "$int"
            else -> "%.1f".format(java.util.Locale.US, floatC)
        }
    }
}
