package com.ex2hub.source

/**
 * Root commands are expected to print a single numeric value. The first number in the
 * output is used, which is why the command should not print debug dates or counts before it.
 */
object ValueParser {
    private val numberRegex = Regex("""-?\d+(?:[.,]\d+)?""")

    fun firstNumber(text: String): Double? {
        val match = numberRegex.find(text) ?: return null
        return match.value.replace(',', '.').toDoubleOrNull()
    }

    fun parseInRange(text: String, min: Double, max: Double): Double? {
        val value = firstNumber(text) ?: return null
        return value.takeIf { it.isFinite() && it in min..max }
    }
}
