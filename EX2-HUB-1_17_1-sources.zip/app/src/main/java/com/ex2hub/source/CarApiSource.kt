package com.ex2hub.source

import android.content.Context
import android.content.pm.PackageManager
import com.ex2hub.data.Body
import com.ex2hub.data.BodyPart
import com.ex2hub.data.ChargeFlow
import com.ex2hub.data.ChargeType
import com.ex2hub.data.ChargePowerSource
import com.ex2hub.data.ChargingSignals
import com.ex2hub.data.CheckStatus
import com.ex2hub.data.Climate
import com.ex2hub.data.ClimateChange
import com.ex2hub.data.ClimatePreset
import com.ex2hub.data.ClimateWriteResult
import com.ex2hub.data.DriveMode
import com.ex2hub.data.Gear
import com.ex2hub.data.IgnitionState
import com.ex2hub.data.Profile
import com.ex2hub.data.ProbeOutcome
import com.ex2hub.data.RegenLevel
import com.ex2hub.data.SourceCheck
import com.ex2hub.data.SourceMode
import com.ex2hub.data.VehicleSnapshot
import android.os.Looper
import java.lang.reflect.InvocationTargetException
import java.lang.reflect.Method
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Факультативная интеграция с Android Automotive. Библиотека `android.car` не входит
 * в публичный SDK, поэтому все вызовы идут через рефлексию и имеют право провалиться
 * на обычной сборке головного устройства.
 *
 * Идентификаторы свойств и декоды живут в [GeelyVhal] — здесь только чтение, запись
 * и сборка снимка. Кроме CarPropertyManager опробуются два канала, которыми пользуется
 * штатная прошивка: обёртка ECARX ([EcarxWrapper]) для адаптированных чисел зарядки и
 * Flyme AutoFunc ([FlymeAutoFunc]) для режима движения и рекуперации.
 *
 * Каждая проба выводит сырое значение свойства, способ чтения и ошибку, если
 * она была: по этому логу видно, что именно прошивка разрешает читать приложению.
 */
class CarApiSource(private val context: Context) {
    private var car: Any? = null
    private var propertyManager: Any? = null
    private var connected = false
    private var lastConnectionError: String? = null

    /**
     * Зона 0x15600503, которая последней ответила float-°C. CentralEXAuto ищет её
     * перебором {1, 4, 0, 7} и пишет в найденную; на этом ГУ зона 1 отвечает целым
     * шагом, поэтому одна запись в зону 1 ничего не меняла. Живёт до переподключения.
     */
    private var setpointArea = GeelyVhal.AREA_SEAT_LEFT
    private var setpointAreaLogged: Int? = null

    /** Когда в следующий раз пробовать типизированное чтение температуры за бортом. */
    private var outsideTypedRetryAt = 0L

    /** Адаптер ECARX: адаптированные числа состояния заряда (см. GeelyVhal). */
    private val ecarx by lazy { EcarxWrapper(context) }

    /** Flyme AutoFunc: канал, которым штатные Settings читают режим и рекуперацию. */
    private val flyme by lazy { FlymeAutoFunc(context) }

    internal val commandPriority = CarCommandPriority()
    private val eventLock = Any()
    private val eventState = CarPropertyEvents()
    private val mutableUpdates = MutableSharedFlow<VehicleSnapshot>(
        extraBufferCapacity = 1, onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    /** Event patches retain updatedAt of the last baseline, not full-snapshot freshness.
     * No replay: a new collector must use read() for its baseline; close cannot replay it.
     */
    val updates: SharedFlow<VehicleSnapshot> = mutableUpdates.asSharedFlow()
    private data class Registration(val manager: Any, val callback: Any, val unregister: Method)
    private val registrations = mutableListOf<Registration>()
    private var registrationSummary = "events not registered"

    /** Хотя бы часть свойств подписана: опрос можно сделать редкой сверкой. */
    @Volatile private var eventsRegistered = false
    val hasEventSubscription: Boolean get() = eventsRegistered
    private var poll: CarPropertyEvents.Poll? = null // guarded by the source monitor
    private val freshReads = ThreadLocal<Boolean>()
    private val supersededReads = ThreadLocal<Boolean>()
    private val cleanupExecutor by lazy {
        Executors.newSingleThreadExecutor { runnable -> Thread(runnable, "EX2Hub-car-close").apply { isDaemon = true } }
    }

    /**
     * Неотвечающие пары (свойство, зона). Каждая неудача — один holder-вызов через
     * binder, и опрос раз в 5 секунд тратил на них больше, чем на ответившие свойства.
     * После [SKIP_AFTER_FAILURES] неудач подряд обычный опрос пропускает пару на
     * [SKIP_MS]; проба читает всё без пропусков.
     */
    private class Failure(var count: Int = 0, var retryAt: Long = 0L)

    private val failures = HashMap<Long, Failure>()

    private data class CarValues(
        val connected: Boolean,
        val soc: Int? = null,
        val rangeKm: Int? = null,
        val odometerKm: Double? = null,
        val speedKmh: Int? = null,
        val outsideTempC: Int? = null,
        val insideTempC: Int? = null,
        val driveMode: DriveMode? = null,
        val regen: RegenLevel? = null,
        val gear: Gear? = null,
        val ignition: IgnitionState? = null,
        val chargeFlow: ChargeFlow? = null,
        val chargeConnectorType: ChargeType? = null,
        val chargePowerKw: Double? = null,
        val chargePowerSource: ChargePowerSource? = null,
        val chargeEstimateMin: Int? = null,
        val chargeInputV: Double? = null,
        val chargeInputA: Double? = null,
        val portConnected: Boolean? = null,
        val chargeWorkMin: Int? = null,
        val acCurrentSetA: Int? = null,
        val acCurrentMinA: Int? = null,
        val acCurrentMaxA: Int? = null,
        val climate: Climate? = null,
        val body: Body? = null
    )

    @Synchronized
    fun probe(profile: Profile): ProbeOutcome {
        // Even permission/package diagnostics can use Binder; reject main-thread
        // callers before those calls, not only at the car connection boundary.
        if (Looper.myLooper() == Looper.getMainLooper()) {
            lastConnectionError = "Car API requires a worker thread"
            return ProbeOutcome(log = lastConnectionError!!, check = CarValues(connected = false).toCheck())
        }
        val started = System.nanoTime()
        val log = mutableListOf<String>()
        log += "$ android.car probe"
        log += "· FEATURE_AUTOMOTIVE: " + if (context.packageManager.hasSystemFeature(PackageManager.FEATURE_AUTOMOTIVE)) "да" else "нет"
        logPermissions(log)
        logChannels(log)
        val (values, snapshot) = readBaseline(profile, log, full = true)
        log += "· конфигурация температурных свойств:"
        logPropertyConfig(GeelyVhal.PROP_HVAC_TEMPERATURE_SET, "HVAC_TEMPERATURE_SET", log)
        logPropertyConfig(GeelyVhal.PROP_HVAC_TEMPERATURE_SET_VENDOR, "V_HVAC_TEMP_SET (зеркало)", log)
        logPropertyConfig(GeelyVhal.PROP_HVAC_TEMPERATURE_SET_CANONICAL, "HVAC_TEMPERATURE_SET канон.", log)
        logPropertyConfig(GeelyVhal.PROP_HVAC_TEMPERATURE_ADJUST, "HVAC_TEMPERATURE_ADJUST", log)
        logPropertyConfig(GeelyVhal.PROP_HVAC_TEMPERATURE_SET_INT, "HVAC_TEMPERATURE_SET_INT", log)
        logPropertyConfig(GeelyVhal.PROP_AC_AMBIENT_TEMP, "AC_AMBIENT_TEMP", log)
        logPropertyConfig(GeelyVhal.PROP_ENV_OUTSIDE_TEMP, "ENV_OUTSIDE_TEMPERATURE 0x11600703", log)
        logPropertyConfig(GeelyVhal.PROP_ENV_OUTSIDE_TEMPERATURE, "ENV_OUTSIDE_TEMPERATURE 0x11400703", log)
        log += "· $registrationSummary"
        synchronized(eventLock) { eventDiagnostic?.let { log += "· event: $it" } }
        val check = values.toCheck()
        if (check.status == CheckStatus.ERROR) {
            log += "✗ ${check.summary}"
        } else {
            log += "✓ ${check.summary}"
        }
        log += "ℹ свойств прочитано: ${countReadable(values)}"
        log += "· климат: отвечает ${values.climate?.readableSignals ?: 0} из ${Climate().totalSignals} сигналов"
        log += "· длительность пробы: ${(System.nanoTime() - started) / 1_000_000L} мс"
        return ProbeOutcome(log.joinToString("\n").trim(), check, snapshot)
    }

    @Synchronized
    fun read(profile: Profile, full: Boolean = true): ProbeOutcome = try {
        val (values, snapshot) = readBaseline(profile, null, full)
        ProbeOutcome(log = "", check = values.toCheck(), snapshot = snapshot)
    } catch (_: CarCommandPriority.PollYield) {
        ProbeOutcome(log = "", check = SourceCheck(CheckStatus.UNKNOWN, "опрос уступил управление команде"))
    }

    private fun readBaseline(profile: Profile, log: MutableList<String>?, full: Boolean): Pair<CarValues, VehicleSnapshot?> {
        commandPriority.checkPoll(diagnostic = log != null)
        if (!ensureConnected(log)) return CarValues(connected = false) to null
        val token = synchronized(eventLock) { eventState.beginPoll() }
        poll = token
        return try {
            val values = readInternal(profile, log, full)
            commandPriority.checkPoll(diagnostic = log != null)
            val snapshot = synchronized(eventLock) { eventState.seed(values.toSnapshot(profile), token, full) }
            values to snapshot
        } finally {
            synchronized(eventLock) { eventState.discardPoll(token) }
            poll = null
        }
    }

    private inline fun <T> withFreshReads(block: () -> T): T {
        val previous = freshReads.get()
        if (previous != true) supersededReads.set(false)
        freshReads.set(true)
        return try { block() } finally {
            if (previous == null) freshReads.remove() else freshReads.set(previous)
            if (previous != true) supersededReads.remove()
        }
    }

    @Synchronized
    fun readDrive(): Triple<DriveMode?, RegenLevel?, String> = withFreshReads {
        val log = mutableListOf<String>()
        if (!ensureConnected(log)) return@withFreshReads Triple(null, null, (log + "нет связи с Car API").joinToString("\n"))
        val drive = readDriveMode(log)
        val regen = readRegen(log)
        val gear = readGear(log)
        log += "· ответ после записи: режим=$drive, рекуперация=$regen, передача=$gear"
        Triple(drive, regen, log.joinToString("\n"))
    }

    @Synchronized
    fun isParkedForUpdate(): Boolean = withFreshReads {
        if (!ensureConnected(null)) return@withFreshReads false
        val manager = propertyManager ?: return@withFreshReads false
        val speedOrder = synchronized(eventLock) { eventState.reserve() }
        val speed = runCatching {
            PropertyHolder.read(manager, PropertyAddress(GeelyVhal.PROP_PERF_VEHICLE_SPEED), requireExact = true)
        }.getOrNull() ?: return@withFreshReads false
        var gearSample: Pair<PropertyHolder, Long>? = null
        for (id in listOf(GeelyVhal.PROP_CURRENT_GEAR, GeelyVhal.PROP_GEAR_SELECTION)) {
            for (area in GeelyVhal.GEAR_AREAS) {
                val order = synchronized(eventLock) { eventState.reserve() }
                val holder = runCatching {
                    PropertyHolder.read(manager, PropertyAddress(id, area), requireExact = true)
                }.getOrNull()
                if (holder?.available == true && GeelyVhal.gear(integer(holder.value)) != null) {
                    gearSample = holder to order
                    break
                }
            }
            if (gearSample != null) break
        }
        val (gear, gearOrder) = gearSample ?: return@withFreshReads false
        val nowNanos = android.os.SystemClock.elapsedRealtimeNanos()
        speed.recent(nowNanos) && gear.recent(nowNanos) &&
            GeelyVhal.speedKmh(number(speed.value)) == 0 && GeelyVhal.gear(integer(gear.value)) == Gear.P &&
            synchronized(eventLock) { !eventState.superseded(speed, speedOrder) && !eventState.superseded(gear, gearOrder) }
    }

    @Synchronized
    fun close() {
        setpointArea = GeelyVhal.AREA_SEAT_LEFT
        setpointAreaLogged = null
        // Invalidate before unregister/disconnect: late callbacks cannot revive a snapshot.
        synchronized(eventLock) { eventState.reset() }
        val oldCar = car
        val oldRegistrations = registrations.toList()
        registrations.clear()
        car = null
        propertyManager = null
        connected = false
        failures.clear()
        poll = null
        registrationSummary = "events closed"
        eventsRegistered = false
        val cleanup = Runnable {
            oldRegistrations.forEach { registration ->
                runCatching { registration.unregister.invoke(registration.manager, registration.callback) }
            }
            runCatching { oldCar?.javaClass?.getMethod("disconnect")?.invoke(oldCar) }
        }
        if (Looper.myLooper() == Looper.getMainLooper()) cleanupExecutor.execute(cleanup) else cleanup.run()
    }

    private fun readInternal(profile: Profile, log: MutableList<String>?, full: Boolean = true): CarValues {
        // readBaseline has already connected and fixed the cache generation.
        if (!connected || propertyManager == null) return CarValues(connected = false)
        if (log != null && log.none { it.startsWith("✓ Car API подключён") }) {
            log += "✓ Car API подключён"
        }

        // Заряд. Вендорские проценты первичны: EV_BATTERY_LEVEL этот же гу отдаёт
        // то в процентах, то в Вт·ч, и различает их только величина.
        val vendorSoc = number(readRaw(GeelyVhal.PROP_SOC_PERCENT, "ED_EV_BATTERY_PERCENTAGE", log))
        val capacityWh = profile.batteryKwh * 1000.0
        val level = if (log != null || GeelyVhal.socPercent(vendorSoc, null, capacityWh) == null) {
            number(readRaw(GeelyVhal.PROP_BATTERY_LEVEL, "EV_BATTERY_LEVEL", log))
        } else null
        if (log != null) {
            // Ёмкость автомобиля не участвует в расчёте — её читают только затем,
            // чтобы в probe было видно: свойство возвращает заводскую заглушку.
            number(readRaw(GeelyVhal.PROP_EV_CURRENT_BATTERY_CAPACITY, "EV_CURRENT_BATTERY_CAPACITY (не используется)", log))
            number(readRaw(GeelyVhal.PROP_INFO_EV_BATTERY_CAPACITY, "INFO_EV_BATTERY_CAPACITY (не используется)", log))
        }
        val soc = GeelyVhal.socPercent(vendorSoc, level, capacityWh)

        val rangeRaw = number(readRaw(GeelyVhal.PROP_RANGE_REMAINING_KM, "RANGE_REMAINING", log))
        val rangeKm = rangeRaw
            ?.takeIf { it in 0.0..GeelyVhal.RANGE_MAX_KM }
            ?.roundToInt()?.coerceAtLeast(0)

        // Пробег остаётся дробным: по нему журнал считает расстояние поездки, и
        // округление до километра съедало короткие поездки. Резерв — тот же
        // физический счётчик под AOSP-адресом; 0x2140A6AC сюда больше не входит:
        // журнал 2026-10-28 показал у него 61,0 км при одометре 5528,1 — это
        // зеркало запаса хода, и оно дало в поездке 5467,1 км за минуту.
        val odometerPerf = GeelyVhal.odometerKm(number(readRaw(GeelyVhal.PROP_PERF_ODOMETER, "PERF_ODOMETER 0x11600204", log)))
        val odometerBus = if (log != null || odometerPerf == null) {
            GeelyVhal.odometerKm(number(readRaw(GeelyVhal.PROP_ODOMETER, "ODOMETER 0x11400204 (резерв)", log)))
        } else null
        val odometer = odometerPerf ?: odometerBus

        // Скорость: на этом ГУ свойство уже в км/ч, поправка +1 выше 10 км/ч —
        // коррекция приборной панели.
        val speedRaw = number(readRaw(GeelyVhal.PROP_PERF_VEHICLE_SPEED, "PERF_VEHICLE_SPEED", log))
        val speed = GeelyVhal.speedKmh(speedRaw)

        // Температура за бортом: 0x11600703 в зонах {1, 4, 0, 7} первично, как в
        // Central EX Auto; AC_AMBIENT_TEMP и 0x11400703 — резерв, когда зоны молчат.
        val outside = readOutsideTemp(log)
        // Температура в салоне не выводится ни на одном экране: без журнала пробы
        // адрес не опрашиваем, чтобы не тратить Binder-чтение в каждом цикле.
        val insideRaw = if (log != null) {
            number(readRaw(GeelyVhal.PROP_AC_INSIDE_TEMP, "AC_INSIDE_TEMP", log))
        } else null
        val inside = GeelyVhal.tempC(GeelyVhal.flymeTemp(insideRaw))

        // Бортовой счётчик поездки 0x2740A679 в снимок не входит: проба 2026-10-28
        // ответила в зоне 1 числом 5461,9 при одометре 5528,1, и канонический id
        // (0x24801500) относится к семейству энергии, а не к пробегу. Строка
        // остаётся только в журнале пробы, чтобы было видно, отвечает ли адрес.
        if (log != null) {
            number(readRaw(GeelyVhal.PROP_TRIP_KM, "TRIP_KM 0x2740A679 — только лог", log))
                ?.let { log += "· TRIP_KM 0x2740A679: $it — счётчиком поездки не считается" }
            number(readRaw(GeelyVhal.PROP_TRIP_KM, "TRIP_KM 0x2740A679 зона 1 — только лог", log, 1))
                ?.let { log += "· TRIP_KM 0x2740A679 зона 1: $it — счётчиком поездки не считается" }
            number(readRaw(GeelyVhal.PROP_RANGE_MIRROR, "0x2140A6AC (зеркало запаса хода, не одометр)", log))
                ?.let { log += "· 0x2140A6AC: $it — зеркало запаса хода, в пробег не входит" }
        }

        // Средний расход читается только в пробе: в снимок он пока не входит, и
        // приложение не будет выдавать его за расход поездки, пока мы не сверим
        // шкалу свойства с журналом.
        if (log != null) {
            GeelyVhal.avgConsumption(
                number(readRaw(GeelyVhal.PROP_AVG_ENERGY_CONSUMPTION, "V_IPK_AVG_ENERGY_CONSUMPTION (в пробе)", log))
            )?.let { log += "· средний расход автомобиля: %.1f кВт·ч/100 км".format(Locale.US, it) }
        }

        val driveMode = readDriveMode(log)
            ?: GeelyVhal.driveMode(flyme.readCode(GeelyVhal.DRIVE_MODE_FUNC, log))

        val regen = readRegen(log)
            ?: GeelyVhal.regenLevel(flyme.readCode(GeelyVhal.REGEN_FUNC, log))

        // Передача и зажигание: то, что автомобиль назвал сам. Молчание обёртки
        // оставляет поле пустым — вместо состояния из догадки.
        val gear = readGear(log)
        val ignitionCode = readAdapted(
            GeelyVhal.PROP_PEPS_POWER_MODE,
            GeelyVhal.IGNITION_SENSOR_LOGICAL,
            "PEPS_POWER_MODE",
            log,
            GeelyVhal.ECARX_ID_TYPE_SENSOR
        )
        val ignition = GeelyVhal.ignition(ignitionCode)
        // Ключ в салоне остаётся строкой журнала: на экране его нет, поэтому в
        // обычном цикле PEPS_USAGE_MODE не читается.
        if (log != null) {
            val usageCode = readAdapted(
                GeelyVhal.PROP_PEPS_USAGE_MODE,
                GeelyVhal.USAGE_SENSOR_LOGICAL,
                "PEPS_USAGE_MODE",
                log,
                GeelyVhal.ECARX_ID_TYPE_SENSOR
            )
            GeelyVhal.keyInCabin(usageCode)?.let { log.add("· ключ в салоне: ${if (it) "да" else "нет"}") }
        }

        val state = readAdapted(
            GeelyVhal.PROP_CHARGING_STATE,
            GeelyVhal.CHARGING_STATE_LOGICAL,
            "CHARGING_DISCHARGING_STATE",
            log
        )
        val plug = readAdapted(
            GeelyVhal.PROP_CHARGING_PLUG,
            GeelyVhal.CHARGING_PLUG_LOGICAL,
            "CHARGING_PLUG_STATE",
            log
        )
        val flow = GeelyVhal.chargeFlow(state, plug)
        val connectorType = GeelyVhal.connectorType(plug)
        val acKw = number(readRaw(GeelyVhal.PROP_CHARGE_AC_POWER_KW, "CHARGING_AC_POWER", log))
        val dcKw = number(readRaw(GeelyVhal.PROP_CHARGE_DC_POWER_KW, "CHARGING_DC_POWER", log))
        val rateMw = number(readRaw(GeelyVhal.PROP_CHARGE_RATE_MW, "EV_BATTERY_INSTANTANEOUS_CHARGE_RATE", log))
        val estimate = GeelyVhal.minutes(
            number(readRaw(GeelyVhal.PROP_CHARGE_ESTIMATE_MIN, "CHARGING_ESTIMATED_TIME", log))
        )
        val volts = number(readRaw(GeelyVhal.PROP_CHARGE_INPUT_V, "CHARGING_INPUT_VOLTAGE (сеть, не пакет)", log))
            ?.takeIf { it in 0.0..1000.0 }
        val amps = number(readRaw(GeelyVhal.PROP_CHARGE_INPUT_A, "CHARGING_INPUT_CURRENT (сеть, не пакет)", log))
            ?.takeIf { it in 0.0..400.0 }
        // Разъём: адаптированный код 0x2140B085 (3 = кабель вставлен) первичен.
        // AOSP-обёртку Drive Assist на живом ГУ ловил false посреди активной зарядки,
        // поэтому она осталась только резервом.
        val port = GeelyVhal.portConnected(
            integer(readRaw(GeelyVhal.PROP_PORT_CONNECTED, "PORT_CONNECTED", log))
        ) ?: (readRaw(GeelyVhal.PROP_CHARGE_PORT_CONNECTED, "EV_CHARGE_PORT_CONNECTED (резерв)", log) as? Boolean)

        // Длительность сессии берём только пока зарядка активна: после остановки
        // прошивка держит последние числа (наблюдение Capy на живой машине).
        val workMin = GeelyVhal.chargeWorkMinutes(
            number(readRaw(GeelyVhal.PROP_CHARGE_WORK_TIME_MIN, "CHARGING_WORK_TIME", log)),
            flow
        )
        // Заданный ток и границы, которые объявляет автомобиль: диапазон виден на
        // экране зарядки, поэтому все три адреса читаются и в обычном цикле.
        val currentBounds = GeelyVhal.acCurrentBounds(
            integer(readRaw(GeelyVhal.PROP_AC_CURRENT_SET_A, "CHARGING_ALTERNATING_CURRENT_VAL", log)),
            integer(readRaw(GeelyVhal.PROP_AC_CURRENT_MIN_A, "CHARGING_ALTERNATING_CURRENT_MIN", log)),
            integer(readRaw(GeelyVhal.PROP_AC_CURRENT_MAX_A, "CHARGING_ALTERNATING_CURRENT_MAX", log))
        )
        val power = GeelyVhal.chargePowerReading(state, plug, acKw, dcKw, rateMw, volts, amps)
        if (power?.source == ChargePowerSource.INPUT_VI) {
            log?.add("· мощность заряда из B×A: %.1f кВт".format(Locale.US, power.kw))
        }
        if (log != null && currentBounds.hasRange) {
            log += "· ток, который объявляет автомобиль: ${currentBounds.minA}…${currentBounds.maxA} A" +
                (currentBounds.setA?.let { ", задано ${it} A" } ?: "")
        }

        if (log != null) {
            readStatistics(log)
        }

        return CarValues(
            connected = true,
            soc = soc,
            rangeKm = rangeKm,
            odometerKm = odometer,
            speedKmh = speed,
            outsideTempC = outside,
            insideTempC = inside,
            driveMode = driveMode,
            regen = regen,
            gear = gear,
            ignition = ignition,
            chargeFlow = flow,
            chargeConnectorType = connectorType,
            chargePowerKw = power?.kw,
            chargePowerSource = power?.source,
            chargeEstimateMin = estimate,
            chargeWorkMin = workMin,
            chargeInputV = volts,
            chargeInputA = amps,
            acCurrentSetA = currentBounds.setA,
            acCurrentMinA = currentBounds.minA,
            acCurrentMaxA = currentBounds.maxA,
            portConnected = GeelyVhal.plugConnected(plug) ?: port,
            climate = if (full) readClimate(log) else null,
            body = if (full) readBody(log) else null
        )
    }

    /**
     * Кузов — только getter-чтение, без единой записи. На экране из него используется
     * лишь капот: по нему кнопка переднего багажника показывает открытое состояние.
     * Поэтому обычный цикл читает один адрес, а двери, замки, стёкла, свет и
     * вендорские дубли остаются в логе пробы.
     */
    private fun readBody(log: MutableList<String>?): Body? {
        if (log == null) {
            val hood = GeelyVhal.doorOpen(
                integer(
                    readRaw(
                        GeelyVhal.PROP_DOOR_POS,
                        "DOOR_POS HOOD",
                        null,
                        GeelyVhal.DOOR_AREAS.getValue(BodyPart.HOOD)
                    )
                )
            )
            return hood?.let { Body(open = mapOf(BodyPart.HOOD to it)) }
        }
        val open = LinkedHashMap<BodyPart, Boolean>()
        GeelyVhal.DOOR_AREAS.forEach { (part, area) ->
            GeelyVhal.doorOpen(integer(readRaw(GeelyVhal.PROP_DOOR_POS, "DOOR_POS ${part.name}", log, area)))
                ?.let { open[part] = it }
        }
        val locked = LinkedHashMap<BodyPart, Boolean>()
        val windows = LinkedHashMap<BodyPart, Int>()
        Body.DOORS.forEach { part ->
            val doorArea = GeelyVhal.DOOR_AREAS.getValue(part)
            GeelyVhal.doorLocked(integer(readRaw(GeelyVhal.PROP_DOOR_LOCK, "DOOR_LOCK ${part.name}", log, doorArea)))
                ?.let { locked[part] = it }
            val windowArea = GeelyVhal.WINDOW_AREAS.getValue(part)
            GeelyVhal.windowPercent(integer(readRaw(GeelyVhal.PROP_WINDOW_POS, "WINDOW_POS ${part.name}", log, windowArea)))
                ?.let { windows[part] = it }
        }
        val headlights = GeelyVhal.headlightsOn(
            integer(readRaw(GeelyVhal.PROP_HEADLIGHTS_STATE, "HEADLIGHTS_STATE", log)),
            integer(readRaw(GeelyVhal.PROP_HEADLIGHTS_SWITCH, "HEADLIGHTS_SWITCH", log))
        )
        Body.DOORS.forEach { part ->
            readRaw(GeelyVhal.PROP_DOOR_POS_VENDOR, "DOOR_POS вендорский ${part.name} — только лог", log, GeelyVhal.DOOR_AREAS.getValue(part))
            readRaw(GeelyVhal.PROP_WINDOW_POS_VENDOR, "WINDOW_POS вендорский ${part.name} — только лог", log, GeelyVhal.WINDOW_AREAS.getValue(part))
        }
        listOf(
            "CENTRAL_LOCK 0x2040FC00" to GeelyVhal.PROP_CENTRAL_LOCK,
            "BCM_HOOD_STATUS" to GeelyVhal.PROP_HOOD_STATUS_VENDOR,
            "BODY_DOOR_TRUNK_DOOR_POS" to GeelyVhal.PROP_TRUNK_POS_VENDOR,
            "BODY_LIGHT_STATUS" to GeelyVhal.PROP_BODY_LIGHT_STATUS,
            "HIGH_BEAM_LIGHTS_STATE" to GeelyVhal.PROP_HIGH_BEAM_STATE,
            "FOG_LIGHTS_STATE" to GeelyVhal.PROP_FOG_LIGHTS_STATE,
            "HAZARD_LIGHTS_STATE" to GeelyVhal.PROP_HAZARD_LIGHTS_STATE,
            "TURN_SIGNAL_STATE" to GeelyVhal.PROP_TURN_SIGNAL_STATE,
            "VCU_ALLOW_CHARGE_MAX_SOC_ACT" to GeelyVhal.PROP_CHARGE_MAX_SOC,
            // Кандидаты записи переднего багажника: отвечает ли ими это ГУ, видно по логу.
            "FRONT_TRUNK_SWT" to GeelyVhal.PROP_FRONT_TRUNK_SWT,
            "LOCK_HOOD" to GeelyVhal.PROP_HOOD_LOCK
        ).forEach { (label, propertyId) -> readRaw(propertyId, "$label — только лог", log) }
        val body = Body(open = open, locked = locked, windowPercent = windows, headlightsOn = headlights)
        log.add("· кузов: отвечает ${body.readableSignals} сигналов")
        return body.takeIf { it.readableSignals > 0 }
    }

    /**
     * Статистика автомобиля — только в журнал пробы, сырьём. Ни у одного из этих
     * сигналов разобранные источники не подтверждают шкалу: ED_*_ENERGY_FLOW Capy
     * описывает как долю (строки сходятся к 100), а не киловатты, канал пакета
     * BMSH в её профиле вообще отсутствует, а IPK_AVERAGE_POWER_CONSUMPTION на всех
     * записях машины держит одно число. Показать это в приложении «расходом» или
     * «мощностью пакета» значило бы придумать единицу, поэтому здесь остаются только
     * сами свойства: по логу видно, отвечает ли ими это ГУ.
     */
    private fun readStatistics(log: MutableList<String>) {
        log += "· статистика автомобиля (в снимок не входит: шкала не подтверждена)"
        listOf(
            "ED_DRIVING_ENERGY_FLOW (доля, не кВт)" to GeelyVhal.PROP_ED_DRIVING_ENERGY_FLOW,
            "ED_CLIMATE_ENERGY_FLOW" to GeelyVhal.PROP_ED_CLIMATE_ENERGY_FLOW,
            "ED_BATTERY_ENERGY_FLOW" to GeelyVhal.PROP_ED_BATTERY_ENERGY_FLOW,
            "ED_OTHER_ENERGY_FLOW" to GeelyVhal.PROP_ED_OTHER_ENERGY_FLOW,
            "ED_DRIVING_ENERGY_FLOW_TRIP 0x216074E9 (вендорское зеркало)" to
                GeelyVhal.PROP_ED_DRIVING_ENERGY_FLOW_TRIP,
            "HYBRID_POWER_FLOW" to GeelyVhal.PROP_HYBRID_POWER_FLOW,
            "DRIVE_POWER_OUT_PUT" to GeelyVhal.PROP_DRIVE_POWER_OUTPUT,
            "IPK_AVERAGE_POWER_CONSUMPTION (шкала не подтверждена)" to
                GeelyVhal.PROP_IPK_AVERAGE_POWER_CONSUMPTION,
            "IC_HR_TRIP (трип-компьютер панели)" to GeelyVhal.PROP_IC_HR_TRIP,
            "BMSH_BAT_CURRENT (кандидат)" to GeelyVhal.PROP_BMSH_BAT_CURRENT,
            "BMSH_PACK_VOLT (кандидат)" to GeelyVhal.PROP_BMSH_PACK_VOLT,
            "BMSH_BUS_VOLT (кандидат)" to GeelyVhal.PROP_BMSH_BUS_VOLT,
            "BMSH_BAT_SOE (кандидат)" to GeelyVhal.PROP_BMSH_BAT_SOE
        ).forEach { (label, propertyId) ->
            number(readRaw(propertyId, "$label — только лог", log))
        }

        // Логический id функции 0x24804100: обёртка раскрывает его в адрес свойства,
        // и по логу видно, совпадает ли он с прямым чтением ED_DRIVING_ENERGY_FLOW.
        val ref = ecarx.resolve(GeelyVhal.ECARX_ID_TYPE_FUNCTION, GeelyVhal.LOGICAL_TRIP_ED_DRIVING_ENERGY_FLOW)
        if (ref == null) {
            log += "· 0x24804100: обёртка не резолвит id функции" +
                (ecarx.unavailableReason()?.let { " ($it)" } ?: "")
        } else {
            number(readRaw(ref.propertyId, "TRIP_ED_DRIVING_ENERGY_FLOW ${hex(ref.propertyId)} — только лог", log))
        }

        // Компьютер поездки прошивки (TRIP_FUNC_*) остаётся недоступным: в разборе
        // GeelyProperties есть только имена и id сброса 0x24800200, числовых id функций
        // там нет, а выдумывать их нельзя.
        log += "· TRIP_FUNC_1…30: числовых id функций в разборе нет — бортовой компьютер поездки не читается"
    }

    // Отсутствующий ответ остаётся null: у управления нет права угадывать состояние.
    // ECARX может отвечать типизированным getter, даже когда обычный holder недоступен.
    private fun readOutsideTemp(log: MutableList<String>?): Int? {
        for (area in GeelyVhal.OUTSIDE_TEMP_AREAS) {
            GeelyVhal.outsideCelsius(
                readRaw(GeelyVhal.PROP_ENV_OUTSIDE_TEMP, "ENV_OUTSIDE_TEMPERATURE 0x11600703", log, area)
            )?.let { return it }
        }
        for (area in GeelyVhal.OUTSIDE_AMBIENT_AREAS) {
            GeelyVhal.tempC(
                GeelyVhal.flymeTemp(number(readRaw(GeelyVhal.PROP_AC_AMBIENT_TEMP, "AC_AMBIENT_TEMP", log, area)))
            )?.let { return it }
        }
        GeelyVhal.outsideCelsius(
            readRaw(GeelyVhal.PROP_ENV_OUTSIDE_TEMPERATURE, "ENV_OUTSIDE_TEMPERATURE 0x11400703", log)
        )?.let { return it }
        return readOutsideTyped(log)
    }

    private fun readOutsideTyped(log: MutableList<String>?): Int? {
        val now = System.currentTimeMillis()
        if (log == null && now < outsideTypedRetryAt) return null
        outsideTypedRetryAt = now + OUTSIDE_TYPED_RETRY_MS
        for (area in GeelyVhal.OUTSIDE_AMBIENT_AREAS) {
            typedTemperature(
                GeelyVhal.PROP_AC_AMBIENT_TEMP, "AC_AMBIENT_TEMP", log, area, preferFloat = false
            ) { raw -> GeelyVhal.tempC(GeelyVhal.flymeTemp(number(raw))) }?.let {
                outsideTypedRetryAt = 0L
                return it
            }
        }
        for (area in GeelyVhal.OUTSIDE_TEMP_AREAS) {
            typedTemperature(
                GeelyVhal.PROP_ENV_OUTSIDE_TEMP, "ENV_OUTSIDE_TEMPERATURE 0x11600703", log, area,
                preferFloat = true, decode = GeelyVhal::outsideCelsius
            )?.let {
                outsideTypedRetryAt = 0L
                return it
            }
        }
        return typedTemperature(
            GeelyVhal.PROP_ENV_OUTSIDE_TEMPERATURE, "ENV_OUTSIDE_TEMPERATURE 0x11400703", log,
            GeelyVhal.AREA_GLOBAL, preferFloat = true, decode = GeelyVhal::outsideCelsius
        )?.also { outsideTypedRetryAt = 0L }
    }

    private fun typedTemperature(
        propertyId: Int,
        label: String,
        log: MutableList<String>?,
        areaId: Int,
        preferFloat: Boolean,
        decode: (Any?) -> Int?
    ): Int? {
        if (poll != null) commandPriority.checkPoll(diagnostic = log != null)
        val manager = propertyManager ?: return null
        val token = poll
        val order = synchronized(eventLock) { eventState.reserve() }
        return readTypedTemperature(manager, PropertyAddress(propertyId, areaId), preferFloat, decode) { name, attempt, value ->
            if (value != null && token != null) synchronized(eventLock) {
                eventState.observeOutsideTemperature(token, value, order)
            }
            if (log != null) {
                val failure = attempt.exceptionOrNull()
                val result = when {
                    failure != null -> "✗ ${shortError(unwrap(failure))}"
                    value == null -> "· ${describe(attempt.getOrNull())} — температура не распознана"
                    else -> "✓ ${describe(attempt.getOrNull())} → $value °C"
                }
                log.add("· $label ${hex(propertyId)} area=$areaId [$name]: $result")
            }
        }
    }

    private fun readClimate(log: MutableList<String>?): Climate? {
        val climate = Climate(
            hvacOn = flag(readRaw(GeelyVhal.PROP_HVAC_POWER_ON, "HVAC_POWER_ON", log, GeelyVhal.AREA_ROW_1_ALL))
                ?: flag(readRaw(GeelyVhal.PROP_HVAC_POWER_VENDOR, "V_AC_POWER (резерв)", log)),
            acOn = readAcOn(log),
            recircOn = flag(readRaw(GeelyVhal.PROP_HVAC_RECIRC_ON, "HVAC_RECIRC_ON", log, GeelyVhal.AREA_HVAC_ALL))
                ?: flag(readRaw(GeelyVhal.PROP_HVAC_RECIRC_VENDOR, "HVAC_RECIRC (резерв)", log)),
            frontDefrostOn = flag(
                readRaw(GeelyVhal.PROP_HVAC_MAX_DEFROST_DA, "HVAC_MAX_DEFROST_DA", log, GeelyVhal.AREA_HVAC_DA)
            ) ?: flag(
                readRaw(GeelyVhal.PROP_HVAC_MAX_DEFROST, "HVAC_MAX_DEFROST (резерв)", log, GeelyVhal.AREA_ROW_1_ALL)
            ),
            windshieldHeatOn = flag(
                readRaw(
                    GeelyVhal.PROP_HVAC_WINDSHIELD_HEAT,
                    "HVAC_FRONT_WINDSHIELD_HEAT",
                    log,
                    GeelyVhal.AREA_HVAC_ALL
                )
            ),
            rearDefrostOn = flag(
                readRaw(
                    GeelyVhal.PROP_HVAC_REAR_DEFROST,
                    "HVAC_ELECTRIC_DEFROSTER_ON",
                    log,
                    GeelyVhal.AREA_REAR_DEFROST_DA
                )
            ) ?: flag(
                readRaw(
                    GeelyVhal.PROP_HVAC_REAR_DEFROST,
                    "HVAC_ELECTRIC_DEFROSTER_ON (резерв @0)",
                    log,
                    GeelyVhal.AREA_GLOBAL
                )
            ),
            fanSpeed = readFanSpeed(log),
            driverTempC = readZoneTemp(log),
            fanDirection = GeelyVhal.fanDirection(
                number(
                    readRaw(
                        GeelyVhal.PROP_HVAC_FAN_DIRECTION_VENDOR,
                        "ZONED_FAN_DIRECTION",
                        log,
                        GeelyVhal.AREA_GLOBAL
                    )
                )
            ) ?: GeelyVhal.fanDirection(
                number(readRaw(GeelyVhal.PROP_HVAC_FAN_DIRECTION, "HVAC_FAN_DIRECTION", log, GeelyVhal.AREA_SEAT_LEFT))
            ),
            seatHeatDriver = GeelyVhal.heatLevel(
                number(readRaw(GeelyVhal.PROP_HVAC_SEAT_HEAT, "HVAC_SEAT_TEMPERATURE", log, GeelyVhal.AREA_SEAT_LEFT))
            ),
            seatHeatPassenger = GeelyVhal.heatLevel(
                number(
                    readRaw(
                        GeelyVhal.PROP_HVAC_SEAT_HEAT,
                        "HVAC_SEAT_TEMPERATURE",
                        log,
                        GeelyVhal.AREA_SEAT_RIGHT
                    )
                )
            ),
            wheelHeat = GeelyVhal.heatLevel(
                number(readRaw(GeelyVhal.PROP_HVAC_WHEEL_HEAT, "HVAC_STEERING_WHEEL_HEAT", log, GeelyVhal.AREA_SEAT_LEFT))
            ) ?: GeelyVhal.heatLevel(
                number(readRaw(GeelyVhal.PROP_HVAC_WHEEL_HEAT, "HVAC_STEERING_WHEEL_HEAT (резерв @0)", log, GeelyVhal.AREA_GLOBAL))
            )
        )
        if (log != null) {
            readClimateCandidatesDriveAssist(log)
        }
        return if (climate.isEmpty) null else climate
    }

    /**
     * Те же свойства климата в тех зонах, где их проверял на живом IHU629G Drive
     * Assist: 75 для флагов и вентилятора, 2 для заднего стекла, 31 и 44 для уставок,
     * плюс обдув лобового по адресу 0x15200507. В состояние климата результаты не
     * входят: проба должна сначала показать, в какой зоне прошивка отвечает, и только
     * тогда менять цепочку чтения и записей. Обычный опрос этих вызовов не делает.
     */
    private fun readClimateCandidatesDriveAssist(log: MutableList<String>) {
        log += "· климат в зонах Drive Assist (в снимок не входят: сверяется зона)"
        readRaw(GeelyVhal.PROP_HVAC_POWER_ON, "HVAC_POWER_ON @75 — только лог", log, GeelyVhal.AREA_HVAC_DA)
        readRaw(GeelyVhal.PROP_HVAC_AC_ON, "HVAC_AC_ON @75 — только лог", log, GeelyVhal.AREA_HVAC_DA)
        readRaw(GeelyVhal.PROP_HVAC_RECIRC_ON, "HVAC_RECIRC_ON @75 — только лог", log, GeelyVhal.AREA_HVAC_DA)
        readRaw(GeelyVhal.PROP_HVAC_MAX_DEFROST, "HVAC_MAX_DEFROST 0x15200511 @75 — только лог", log, GeelyVhal.AREA_HVAC_DA)
        readRaw(GeelyVhal.PROP_HVAC_MAX_DEFROST_DA, "HVAC_MAX_DEFROST 0x15200507 @75 — только лог", log, GeelyVhal.AREA_HVAC_DA)
        readRaw(GeelyVhal.PROP_HVAC_REAR_DEFROST, "HVAC_ELECTRIC_DEFROSTER_ON @2 — только лог", log, GeelyVhal.AREA_REAR_DEFROST_DA)
        readRaw(GeelyVhal.PROP_HVAC_FAN_SPEED, "HVAC_FAN_SPEED @75 — только лог", log, GeelyVhal.AREA_HVAC_DA)
        readRaw(GeelyVhal.PROP_HVAC_SEAT_HEAT, "HVAC_SEAT_TEMPERATURE @75 — только лог", log, GeelyVhal.AREA_HVAC_DA)
        listOf(GeelyVhal.AREA_SETPOINT_DA_LEFT, GeelyVhal.AREA_SETPOINT_DA_RIGHT, GeelyVhal.AREA_HVAC_DA).forEach { area ->
            readRaw(GeelyVhal.PROP_HVAC_TEMPERATURE_SET, "ZONED_TEMP_SETPOINT @$area — только лог", log, area)
        }
        log += "· кандидаты EX Sapo Central 2.19.78 (в снимок не входят)"
        listOf(GeelyVhal.AREA_SEAT_LEFT, GeelyVhal.AREA_SEAT_RIGHT).forEach { area ->
            readRaw(GeelyVhal.PROP_HVAC_TEMPERATURE_CURRENT, "HVAC_TEMPERATURE_CURRENT @$area — только лог", log, area)
        }
        // Central EX Auto ищет зону уставки перебором {1, 4, 0, 7} и берёт первую,
        // где свойство отвечает float. На этом ГУ зона 1 отвечает целым 4, поэтому
        // в журнал пишутся типизированные чтения по всем четырём зонам: по ним
        // видно, есть ли отдельная float-зона и какого она масштаба.
        log += "· уставка: оба типизированных чтения по зонам ${GeelyVhal.SETPOINT_AREAS.joinToString()}"
        for (area in GeelyVhal.SETPOINT_AREAS) typedSetpoint(area, log)
        log += "· уставка: float-каналы и резервы (только лог)"
        readRaw(GeelyVhal.PROP_HVAC_TEMPERATURE_SET_VENDOR, "V_HVAC_TEMP_SET (зеркало)", log, GeelyVhal.AREA_SEAT_LEFT)
        readRaw(GeelyVhal.PROP_HVAC_TEMPERATURE_SET_CANONICAL, "SET канон. 0x24120300", log, GeelyVhal.AREA_GLOBAL)
        readRaw(GeelyVhal.PROP_HVAC_TEMPERATURE_ADJUST, "SET резерв 0x25401036", log, GeelyVhal.AREA_SEAT_LEFT)
        readRaw(GeelyVhal.PROP_HVAC_TEMPERATURE_SET_INT, "SET 0x15200503", log, GeelyVhal.AREA_SEAT_LEFT)
    }

    /**
     * Оба типизированных геттера без выбора «первого удачного». Central EX Auto
     * принимает только Float, а это ГУ на `getIntProperty` зоны 1 отдаёт шаг 4:
     * в журнале должно быть видно каждый ответ, иначе не различить «зона молчит»
     * и «зона отвечает целым».
     */
    private fun typedSetpoint(area: Int, log: MutableList<String>) {
        val manager = propertyManager ?: return
        val intType = Int::class.javaPrimitiveType
        for (name in listOf("getFloatProperty", "getIntProperty")) {
            val attempt = runCatching {
                manager.javaClass.getMethod(name, intType, intType)
                    .invoke(manager, GeelyVhal.PROP_HVAC_TEMPERATURE_SET, area)
            }
            val failure = attempt.exceptionOrNull()
            if (failure != null) {
                log += "· SET area=$area [$name]: ✗ ${shortError(unwrap(failure))}"
            } else {
                log += "· SET area=$area [$name]: ${describe(attempt.getOrNull())}"
            }
        }
    }

    /**
     * Компрессор: прошивка этого ГУ канонизирует 0x15200505 в зону 117 — по логу
     * она отвечает именно там, а запрос в зону 75 возвращает её же. Поэтому 117
     * читается первым, 75 остаётся запасом, затем — альтернативное свойство.
     */
    private fun readAcOn(log: MutableList<String>?): Boolean? {
        flag(readRaw(GeelyVhal.PROP_HVAC_AC_ON, "HVAC_AC_ON", log, GeelyVhal.AREA_HVAC_ALL))
            ?.let { return it }
        flag(readRaw(GeelyVhal.PROP_HVAC_AC_ON, "HVAC_AC_ON @75 (резерв)", log, GeelyVhal.AREA_HVAC_DA))
            ?.let { return it }
        for (area in GeelyVhal.HVAC_AREAS) {
            flag(readRaw(GeelyVhal.PROP_HVAC_AC_ON_ALT, "HVAC_AC_ON_ALT", log, area))
                ?.let { return it }
        }
        return null
    }

    /**
     * Ступень вентилятора: каноническая зона по логу — 5 (запрос в 1 и 49
     * возвращает её же), затем остальные известные зоны и вендорское зеркало.
     */
    private fun readFanSpeed(log: MutableList<String>?): Int? {
        GeelyVhal.fanSpeed(
            number(readRaw(GeelyVhal.PROP_HVAC_FAN_SPEED, "HVAC_FAN_SPEED", log, GeelyVhal.AREA_ROW_1_ALL))
        )?.let { return it }
        for (area in GeelyVhal.HVAC_AREAS) {
            if (area == GeelyVhal.AREA_ROW_1_ALL) continue
            GeelyVhal.fanSpeed(
                number(readRaw(GeelyVhal.PROP_HVAC_FAN_SPEED, "HVAC_FAN_SPEED", log, area))
            )?.let { return it }
        }
        return GeelyVhal.fanSpeed(number(readRaw(GeelyVhal.PROP_HVAC_FAN_VENDOR, "V_AC_FAN_LEVEL (резерв)", log)))
    }

    /**
     * Уставка водителя. Central EX Auto перебирает зоны 0x15600503 {1, 4, 0, 7}
     * и принимает только Float; на этом ГУ зона 1 отдаёт целое (4 при 20 °C в
     * зеркале), поэтому целое — шаг шкалы, а не градусы. Сначала читается зона,
     * которая уже ответила Float, иначе — весь перебор. Если ни одна зона не
     * ответила Float, берутся каналы, которые на этом ГУ отдают float-°C:
     * зеркало 0x2140A6DC, его канонический ответ 0x24120300 и 0x25401036.
     * Целый шаг остаётся только показом (шаг + 16 °C), когда float-каналов нет.
     */
    private fun readZoneTemp(log: MutableList<String>?): Double? {
        var intStep: Double? = null
        for (area in setpointCandidates()) {
            val raw = readRaw(GeelyVhal.PROP_HVAC_TEMPERATURE_SET, "HVAC_TEMPERATURE_SET", log, area)
                ?: continue
            val celsius = GeelyVhal.setpointFloatCelsius(raw)
            if (celsius != null) {
                learnSetpointArea(area, log)
                return celsius
            }
            if (area == GeelyVhal.AREA_SEAT_LEFT) intStep = number(raw)?.takeIf { it % 1.0 == 0.0 }
        }
        // Найденная когда-то Float-зона остаётся первой и для записи: пропавший
        // на одно чтение ответ не повод снова писать в целую зону 1.
        GeelyVhal.setpointFloatCelsius(
            readRaw(GeelyVhal.PROP_HVAC_TEMPERATURE_SET_VENDOR, "V_HVAC_TEMP_SET °C (зеркало)", log,
                GeelyVhal.AREA_SEAT_LEFT)
        )?.let { return it }
        GeelyVhal.setpointFloatCelsius(
            readRaw(GeelyVhal.PROP_HVAC_TEMPERATURE_SET_CANONICAL, "HVAC_TEMPERATURE_SET канон.", log,
                GeelyVhal.AREA_GLOBAL)
        )?.let { return it }
        GeelyVhal.setpointFloatCelsius(
            readRaw(GeelyVhal.PROP_HVAC_TEMPERATURE_ADJUST, "HVAC_TEMPERATURE_ADJUST °C", log,
                GeelyVhal.AREA_SEAT_LEFT)
        )?.let { return it }
        return GeelyVhal.setpointFromRaw(intStep)
    }

    /** Зона, ответившая float, читается первой; остальные — перебор Central EX Auto. */
    private fun setpointCandidates(): IntArray {
        val primary = setpointArea
        val order = IntArray(GeelyVhal.SETPOINT_AREAS.size)
        order[0] = primary
        var index = 1
        for (area in GeelyVhal.SETPOINT_AREAS) if (area != primary) order[index++] = area
        return order
    }

    private fun learnSetpointArea(area: Int, log: MutableList<String>?) {
        setpointArea = area
        if (log != null && setpointAreaLogged != area) {
            setpointAreaLogged = area
            log.add("· уставка: 0x15600503 отвечает float в зоне $area")
        }
    }

    private fun flag(raw: Any?): Boolean? = GeelyVhal.flag(number(raw))

    /** A single control only queries its own signal, including existing read fallbacks. */
    private fun readClimateSignal(change: ClimateChange): Climate? {
        val climate = when (change) {
            ClimateChange.POWER -> Climate(hvacOn =
                flag(readRaw(GeelyVhal.PROP_HVAC_POWER_ON, "HVAC_POWER_ON", null, GeelyVhal.AREA_ROW_1_ALL))
                    ?: flag(readRaw(GeelyVhal.PROP_HVAC_POWER_VENDOR, "V_AC_POWER", null)))
            ClimateChange.AC -> Climate(acOn = readAcOn(null))
            ClimateChange.RECIRC -> Climate(recircOn =
                flag(readRaw(GeelyVhal.PROP_HVAC_RECIRC_ON, "HVAC_RECIRC_ON", null, GeelyVhal.AREA_HVAC_ALL))
                    ?: flag(readRaw(GeelyVhal.PROP_HVAC_RECIRC_VENDOR, "HVAC_RECIRC", null)))
            ClimateChange.FRONT_DEFROST -> Climate(frontDefrostOn =
                flag(readRaw(GeelyVhal.PROP_HVAC_MAX_DEFROST_DA, "HVAC_MAX_DEFROST_DA", null, GeelyVhal.AREA_HVAC_DA))
                    ?: flag(readRaw(GeelyVhal.PROP_HVAC_MAX_DEFROST, "HVAC_MAX_DEFROST", null, GeelyVhal.AREA_ROW_1_ALL)))
            ClimateChange.WINDSHIELD_HEAT -> Climate(windshieldHeatOn =
                flag(readRaw(GeelyVhal.PROP_HVAC_WINDSHIELD_HEAT, "HVAC_FRONT_WINDSHIELD_HEAT", null,
                    GeelyVhal.AREA_HVAC_ALL)))
            ClimateChange.REAR_DEFROST -> Climate(rearDefrostOn =
                flag(readRaw(GeelyVhal.PROP_HVAC_REAR_DEFROST, "HVAC_ELECTRIC_DEFROSTER_ON", null,
                    GeelyVhal.AREA_REAR_DEFROST_DA))
                    ?: flag(readRaw(GeelyVhal.PROP_HVAC_REAR_DEFROST, "HVAC_ELECTRIC_DEFROSTER_ON @0", null)))
            ClimateChange.FAN_UP, ClimateChange.FAN_DOWN -> Climate(fanSpeed = readFanSpeed(null))
            ClimateChange.DRIVER_UP, ClimateChange.DRIVER_DOWN ->
                Climate(driverTempC = readZoneTemp(null))
            ClimateChange.DIRECTION_FACE, ClimateChange.DIRECTION_FEET,
            ClimateChange.DIRECTION_GLASS, ClimateChange.DIRECTION_GLASS_FEET -> Climate(fanDirection =
                GeelyVhal.fanDirection(number(readRaw(GeelyVhal.PROP_HVAC_FAN_DIRECTION_VENDOR, "ZONED_FAN_DIRECTION", null)))
                    ?: GeelyVhal.fanDirection(number(readRaw(GeelyVhal.PROP_HVAC_FAN_DIRECTION, "HVAC_FAN_DIRECTION", null,
                        GeelyVhal.AREA_SEAT_LEFT))))
            ClimateChange.SEAT_DRIVER -> Climate(seatHeatDriver = GeelyVhal.heatLevel(number(
                readRaw(GeelyVhal.PROP_HVAC_SEAT_HEAT, "HVAC_SEAT_TEMPERATURE", null, GeelyVhal.AREA_SEAT_LEFT))))
            ClimateChange.SEAT_PASSENGER -> Climate(seatHeatPassenger = GeelyVhal.heatLevel(number(
                readRaw(GeelyVhal.PROP_HVAC_SEAT_HEAT, "HVAC_SEAT_TEMPERATURE", null, GeelyVhal.AREA_SEAT_RIGHT))))
            ClimateChange.WHEEL_HEAT -> Climate(wheelHeat = GeelyVhal.heatLevel(number(
                readRaw(GeelyVhal.PROP_HVAC_WHEEL_HEAT, "HVAC_STEERING_WHEEL_HEAT", null, GeelyVhal.AREA_SEAT_LEFT)))
                ?: GeelyVhal.heatLevel(number(
                    readRaw(GeelyVhal.PROP_HVAC_WHEEL_HEAT, "HVAC_STEERING_WHEEL_HEAT @0", null, GeelyVhal.AREA_GLOBAL))))
        }
        return climate.takeUnless { it.isEmpty }
    }

    /**
     * Запись климата. Значение берётся из уже прочитанного состояния, поэтому
     * команда без ответа автомобиля не отправляется — кроме обогрева лобового:
     * на этом ГУ 0x10200C00 не отвечает на чтение, и тогда пишется значение,
     * которое выбрал пользователь ([windshieldHeatTarget]).
     */
    @Synchronized
    fun writeClimate(
        change: ClimateChange,
        log: MutableList<String>?,
        windshieldHeatTarget: Boolean? = null
    ): ClimateWriteResult = withFreshReads {
        if (!ensureConnected(log)) {
            return@withFreshReads ClimateWriteResult(CheckStatus.ERROR, lastConnectionError ?: "Car API недоступен")
        }
        val fresh = readClimateSignal(change)
        val blindHeat = change == ClimateChange.WINDSHIELD_HEAT &&
            fresh?.windshieldHeatOn == null && windshieldHeatTarget != null
        if (blindHeat) {
            log?.add(
                "ℹ HVAC_FRONT_WINDSHIELD_HEAT: состояние не читается, " +
                    "записывается ${if (windshieldHeatTarget == true) "включение" else "выключение"}"
            )
        }
        val next = if (blindHeat) {
            Climate(windshieldHeatOn = windshieldHeatTarget)
        } else {
            val readable = fresh
                ?: return@withFreshReads ClimateWriteResult(CheckStatus.ERROR, "климат не отвечает этот сигнал")
            GeelyVhal.climateNext(change, readable)
                ?: return@withFreshReads ClimateWriteResult(
                    status = CheckStatus.ERROR,
                    summary = "автомобиль не ответил этот сигнал, включать вслепую нельзя"
                )
        }
        val writes = GeelyVhal.climateWrites(change, next, setpointArea)
        if (change == ClimateChange.DRIVER_UP || change == ClimateChange.DRIVER_DOWN) {
            return@withFreshReads writeSetpoint(writes, next.driverTempC, log)
        }
        val result = writeChain(writes, log)
        confirmClimate(result, log, readObserved = { readClimateSignal(change) }) { observed ->
            GeelyVhal.climateWrites(change, observed, setpointArea) == writes
        }
    }

    /**
     * Уставка проверяется после каждой записи, а не после цепочки: на этом ГУ
     * запись без исключения ещё не значит, что прошивка сменила значение.
     * Кандидаты идут по одному — 0x15600503 float в зону, ответившую Float, затем
     * канонический 0x24120300, зеркало 0x2140A6DC и 0x25401036. Первый ответ,
     * совпавший с целью в любом канале, останавливает перебор. Прошивка может
     * обновить только одно свойство, поэтому подтверждением считается любой канал,
     * а не обязательно тот, в который писали.
     */
    @Synchronized
    private fun writeSetpoint(
        writes: List<GeelyVhal.VhalWrite>,
        targetC: Double?,
        log: MutableList<String>?
    ): ClimateWriteResult {
        if (writes.isEmpty()) {
            return ClimateWriteResult(CheckStatus.ERROR, "автомобиль не ответил уставку")
        }
        val target = targetC ?: return writeChain(writes, log)
        var accepted: String? = null
        var lastError: String? = null
        for ((index, write) in writes.withIndex()) {
            val attempt = writeChain(listOf(write), log)
            if (attempt.status != CheckStatus.OK) {
                lastError = attempt.summary
                continue
            }
            if (accepted == null) accepted = attempt.summary.removePrefix("запрошено: ")
            val observed = awaitSetpoint(target, log)
            if (observed != null) {
                val climate = Climate(driverTempC = observed)
                return ClimateWriteResult(
                    status = CheckStatus.OK,
                    summary = "${attempt.summary}; подтверждено чтением",
                    applied = climate,
                    observed = climate,
                    confirmed = true
                )
            }
            if (index < writes.lastIndex) log?.add("· значение не изменилось, пробую резерв")
        }
        val reason = accepted ?: lastError ?: "нет ответа"
        return ClimateWriteResult(
            status = if (accepted != null) CheckStatus.OK else CheckStatus.ERROR,
            summary = "запрошено: $reason; изменение пока не подтверждено"
        )
    }

    private data class SetpointReading(val label: String, val celsius: Double?, val raw: Any?)

    private fun readSetpointReadings(target: Double, log: MutableList<String>?): List<SetpointReading> {
        val readings = mutableListOf<SetpointReading>()
        for (area in GeelyVhal.SETPOINT_AREAS) {
            val raw = readRaw(GeelyVhal.PROP_HVAC_TEMPERATURE_SET, "HVAC_TEMPERATURE_SET @$area", null, area)
            val celsius = GeelyVhal.setpointFloatCelsius(raw)
            if (celsius != null) learnSetpointArea(area, log)
            readings += SetpointReading("SET@$area", celsius, raw)
            if (celsius != null && abs(celsius - target) <= 0.25) return readings
        }
        val mirror = readRaw(
            GeelyVhal.PROP_HVAC_TEMPERATURE_SET_VENDOR, "V_HVAC_TEMP_SET °C (зеркало)", null,
            GeelyVhal.AREA_SEAT_LEFT
        )
        val mirrorC = GeelyVhal.setpointFloatCelsius(mirror)
        readings += SetpointReading("зеркало", mirrorC, mirror)
        if (mirrorC != null && abs(mirrorC - target) <= 0.25) return readings
        val canonical = readRaw(
            GeelyVhal.PROP_HVAC_TEMPERATURE_SET_CANONICAL, "HVAC_TEMPERATURE_SET канон.", null,
            GeelyVhal.AREA_GLOBAL
        )
        val canonicalC = GeelyVhal.setpointFloatCelsius(canonical)
        readings += SetpointReading("канон.", canonicalC, canonical)
        if (canonicalC != null && abs(canonicalC - target) <= 0.25) return readings
        val adjust = readRaw(
            GeelyVhal.PROP_HVAC_TEMPERATURE_ADJUST, "HVAC_TEMPERATURE_ADJUST °C", null,
            GeelyVhal.AREA_SEAT_LEFT
        )
        readings += SetpointReading("ADJUST", GeelyVhal.setpointFloatCelsius(adjust), adjust)
        return readings
    }

    /** Ответ прошивки может прийти после Binder-вызова, поэтому чтение повторяется. */
    private fun awaitSetpoint(target: Double, log: MutableList<String>?): Double? {
        repeat(2) { attempt ->
            if (attempt > 0) Thread.sleep(180L)
            val readings = readSetpointReadings(target, log)
            log?.add("· сверка уставки: " + readings.joinToString("; ") { reading ->
                "${reading.label}=${reading.raw?.let(::describe) ?: "нет"}"
            })
            readings.firstOrNull { it.celsius != null && abs(it.celsius - target) <= 0.25 }
                ?.celsius?.let { return it }
        }
        return null
    }

    /**
     * Сценарий климата: шаги из [GeelyVhal.presetSteps] пишутся по очереди, и отказ
     * одного шага не останавливает остальные — быстрый обогрев без подогрева руля
     * всё равно полезен. В итоге видно, сколько шагов принято.
     */
    @Synchronized
    fun writePreset(preset: ClimatePreset, off: Boolean, log: MutableList<String>?): ClimateWriteResult = withFreshReads {
        if (!ensureConnected(log)) {
            return@withFreshReads ClimateWriteResult(CheckStatus.ERROR, lastConnectionError ?: "Car API недоступен")
        }
        val current = readClimate(null)
            ?: return@withFreshReads ClimateWriteResult(CheckStatus.ERROR, "климат не отвечает")
        val initial = GeelyVhal.presetSteps(preset, current, off, setpointArea)
        if (initial.isEmpty()) {
            // Снятие пресета часто не находит работы: обогревы и кондиционер уже
            // выключены. Это не отказ автомобиля.
            return@withFreshReads ClimateWriteResult(
                status = CheckStatus.OK,
                summary = "менять нечего: климат уже в нужном состоянии",
                applied = current
            )
        }
        val plannedTarget = initial.fold(current) { climate, step -> step.after(climate) }
        var target = plannedTarget.copy(recircOn = null)
        // Acceptance is never observed state. POWER is deliberately first: firmware
        // can re-enable MAX/AC, so remaining steps must be planned from a fresh read.
        val power = initial.firstOrNull { step -> step.writes.any {
            it.propertyId == GeelyVhal.PROP_HVAC_POWER_ON && it.bool == true
        } }
        var remaining = initial.filterNot { it === power }
        var attempted = 0
        var accepted = 0
        val failed = mutableListOf<String>()
        // Ожидаемое состояние после каждого шага: уставке нужно точное значение
        // для проверки чтением, а не только итог всего сценария.
        var expectation = current
        if (power != null) {
            attempted++
            log?.add("· шаг: ${power.title}")
            if (writeChain(power.writes, log).status == CheckStatus.OK) {
                accepted++
                Thread.sleep(250L)
                val afterPower = readClimate(null) // scoped bypass, never poll-suppressed
                log?.add("· климат после POWER: ${afterPower ?: "нет данных"}")
                if (afterPower != null) {
                    remaining = GeelyVhal.presetSteps(preset, afterPower.copy(hvacOn = null), off, setpointArea)
                    expectation = afterPower
                    // AC OFF остаётся инвариантом прогрева: чтение AC до POWER уже
                    // доказало, что команда поддерживается, даже если после POWER
                    // сигнал на мгновение пропал.
                    if (preset == ClimatePreset.QUICK_HEAT && afterPower.acOn == null && current.acOn != null) {
                        remaining = remaining + GeelyVhal.PresetStep("кондиционер",
                            GeelyVhal.climateWrites(ClimateChange.AC, Climate(acOn = false))) {
                            it.copy(acOn = false)
                        }
                    }
                    target = remaining.fold(target) { climate, step -> step.after(climate) }
                } else {
                    // План уже построен по чтению до POWER; отсутствие повторного
                    // чтения не повод бросать остальные шаги.
                    failed += "чтение после POWER"
                }
            } else failed += power.title
        }
        if (remaining.isEmpty() && attempted == 0) {
            return@withFreshReads ClimateWriteResult(
                status = CheckStatus.OK,
                summary = "менять нечего: климат уже в нужном состоянии",
                applied = current
            )
        }
        remaining.forEach { step ->
            attempted++
            log?.add("· шаг: ${step.title}")
            val stepTarget = step.after(expectation)
            expectation = stepTarget
            val stepResult = if (step.writes.any { it.propertyId == GeelyVhal.PROP_HVAC_TEMPERATURE_SET }) {
                writeSetpoint(step.writes, stepTarget.driverTempC, log)
            } else {
                writeChain(step.writes, log)
            }
            if (stepResult.status == CheckStatus.OK) accepted++ else failed += step.title
        }
        val result = ClimateWriteResult(
            status = if (accepted > 0) CheckStatus.OK else CheckStatus.ERROR,
            summary = "запрошено $accepted из $attempted шагов" +
                failed.takeIf { it.isNotEmpty() }?.joinToString(prefix = "; не принято: ").orEmpty()
        )
        // Сценарий из нескольких шагов: короткая пауза, чтобы чтение увидело
        // последнюю запись, уже принятую прошивкой.
        confirmClimate(result, log, settleMs = 120L) { it.confirms(target) && failed.isEmpty() }
    }

    @Synchronized
    private fun confirmClimate(
        result: ClimateWriteResult,
        log: MutableList<String>?,
        settleMs: Long = 0L,
        readObserved: () -> Climate? = { readClimate(null) },
        matches: (Climate) -> Boolean
    ): ClimateWriteResult = withFreshReads {
        if (result.status != CheckStatus.OK) return@withFreshReads result.copy(applied = null)
        // Central EX Auto читает HAL сразу после записи и не держит панель занятой.
        // Пауза нужна только сценарию из нескольких шагов, где следующий шаг
        // зависит от прочитанного состояния.
        if (settleMs > 0L) Thread.sleep(settleMs)
        val observed = readObserved()
        val confirmed = observed != null && matches(observed)
        log?.add("· ответ после записи: ${observed ?: "нет данных"}")
        val summary = result.summary + if (confirmed) "; подтверждено чтением" else "; изменение пока не подтверждено"
        result.copy(summary = summary, applied = observed.takeIf { confirmed }, observed = observed, confirmed = confirmed)
    }

    /**
     * Цепочка попыток записи одного свойства. По умолчанию успешной считается
     * первая запись без исключения, остальные перебираются молча. С выключенным
     * stopOnFirst (режим движения пишется в несколько зон) предпринимаются все
     * записи цепочки: успехом считается хотя бы одна принятая, непринятые зоны
     * остаются в логе. Подтверждением служит следующее чтение.
     */
    @Synchronized
    fun writeChain(
        chain: List<GeelyVhal.VhalWrite>,
        log: MutableList<String>?,
        stopOnFirst: Boolean = true
    ): ClimateWriteResult {
        if (chain.isEmpty()) {
            return ClimateWriteResult(status = CheckStatus.ERROR, summary = "нет адреса свойства для команды")
        }
        if (chain.any { it.propertyId in READ_ONLY_BODY_PROPERTIES }) {
            return ClimateWriteResult(status = CheckStatus.ERROR, summary = "двери, замки, стёкла и свет — только чтение")
        }
        if (!ensureConnected(log)) {
            return ClimateWriteResult(
                status = CheckStatus.ERROR,
                summary = lastConnectionError ?: "Car API недоступен"
            )
        }
        val manager = propertyManager
            ?: return ClimateWriteResult(status = CheckStatus.ERROR, summary = "CarPropertyManager недоступен")

        var lastError: String? = null
        var firstAccepted: String? = null
        var accepted = 0
        for (index in chain.indices) {
            val write = chain[index]
            val described = "${write.label} ${hex(write.propertyId)} area=${write.areaId} → ${write.valueText()}"
            val failure = runCatching { applyWrite(manager, write) }.exceptionOrNull()
            if (failure == null) {
                if (index == 0 || firstAccepted == null) firstAccepted = described
                accepted++
                if (stopOnFirst) {
                    val attempt = if (index == 0) "" else " (попытка ${index + 1} из ${chain.size})"
                    log?.add("✓ запись $described$attempt")
                    return ClimateWriteResult(status = CheckStatus.OK, summary = "запрошено: $described")
                }
                log?.add("✓ запись $described")
            } else {
                lastError = shortError(unwrap(failure))
                if (!stopOnFirst) log?.add("· $described — не принято: $lastError")
            }
        }
        if (accepted > 0) {
            val areas = if (accepted == chain.size) "" else " (зон: $accepted из ${chain.size})"
            return ClimateWriteResult(
                status = CheckStatus.OK,
                summary = "запрошено: $firstAccepted$areas"
            )
        }
        val reason = lastError ?: "нет ответа"
        log?.add("✗ ${chain.size} записей не принято: $reason")
        return ClimateWriteResult(
            status = CheckStatus.ERROR,
            summary = "$reason — автомобиль не принял запись"
        )
    }

    private fun applyWrite(manager: Any, write: GeelyVhal.VhalWrite) {
        val intType = Int::class.javaPrimitiveType
        when {
            write.bool != null -> manager.javaClass
                .getMethod("setBooleanProperty", intType, intType, Boolean::class.javaPrimitiveType)
                .invoke(manager, write.propertyId, write.areaId, write.bool)

            write.int != null -> manager.javaClass
                .getMethod("setIntProperty", intType, intType, Int::class.javaPrimitiveType)
                .invoke(manager, write.propertyId, write.areaId, write.int)

            else -> manager.javaClass
                .getMethod("setFloatProperty", intType, intType, Float::class.javaPrimitiveType)
                .invoke(manager, write.propertyId, write.areaId, write.floatC!!.toFloat())
        }
    }

    /**
     * Режим движения: 0x22010100 в тех же зонах, куда идёт запись. Central EX Auto
     * читает {0, 1, 0x01000000} и принимает только коды 01…03; остальные значения
     * остаются без ответа, а не превращаются в режим по догадке.
     */
    private fun readDriveMode(log: MutableList<String>?): DriveMode? {
        for (area in GeelyVhal.DRIVE_AREAS) {
            GeelyVhal.driveMode(
                integer(readRaw(GeelyVhal.PROP_DRIVE_MODE, "DM_FUNC_DRIVE_MODE_SELECT", log, area))
            )?.let { return it }
        }
        return null
    }

    /**
     * Уровень рекуперации: AutoFunc-идентификатор в двух областях, затем вендорское
     * REGENCY_LEVEL из дампа свойств EX2.
     */
    private fun readRegen(log: MutableList<String>?): RegenLevel? {
        for (area in GeelyVhal.REGEN_AREAS) {
            val raw = integer(
                readRaw(GeelyVhal.PROP_REGEN_LEVEL, "SETTING_FUNC_ENERGY_REGENERATION", log, area)
            )
            GeelyVhal.regenLevel(raw)?.let { return it }
        }
        val vendor = integer(readRaw(GeelyVhal.PROP_REGEN_LEVEL_VENDOR, "REGENCY_LEVEL", log))
        return GeelyVhal.regenLevel(vendor)
    }

    /**
     * Передача: CURRENT_GEAR и GEAR_SELECTION в областях −1 и 0 — тот же перебор,
     * что делает Capy. Берётся первая маска, которую удалось расшифровать.
     */
    private fun readGear(log: MutableList<String>?): Gear? {
        for (propertyId in intArrayOf(GeelyVhal.PROP_CURRENT_GEAR, GeelyVhal.PROP_GEAR_SELECTION)) {
            val label = if (propertyId == GeelyVhal.PROP_CURRENT_GEAR) "CURRENT_GEAR" else "GEAR_SELECTION"
            for (area in GeelyVhal.GEAR_AREAS) {
                val raw = integer(readRaw(propertyId, label, log, area))
                GeelyVhal.gear(raw)?.let { return it }
            }
        }
        return null
    }

    /**
     * Свойство через обёртку ECARX: она даёт физический адрес и переводит короткое
     * число прошивки в те же константы, что разбирает [GeelyVhal.chargeFlow] или
     * [GeelyVhal.ignition]. Без обёртки остаётся прямое чтение сырого свойства.
     */
    private fun readAdapted(
        rawPropertyId: Int,
        logicalId: Int,
        label: String,
        log: MutableList<String>?,
        idType: Int = GeelyVhal.ECARX_ID_TYPE_FUNCTION
    ): Int? {
        val ref = ecarx.resolve(idType, logicalId)
        if (ref != null) {
            val raw = integer(readRaw(ref.propertyId, "$label (через обёртку)", log))
            val adapted = ecarx.adapt(ref, raw)
            if (adapted != null) return adapted
            if (raw != null) log?.add("· $label: обёртка не адаптировала $raw")
        }
        return integer(readRaw(rawPropertyId, label, log))
    }

    private fun logChannels(log: MutableList<String>) {
        log += "· Flyme AutoFunc: " + (flyme.unavailableReason() ?: "доступен")
        log += "· ECARX-обёртка: " + (ecarx.unavailableReason() ?: "доступна")
    }

    /**
     * Объявлено ли свойство в CarService и с каким типом/зонами. По этому видно,
     * существует ли адрес вообще и стоит ли ждать от него ответа: «не объявлено»
     * и «объявлено, но не отвечает» — разные причины пустой температуры.
     */
    private fun logPropertyConfig(propertyId: Int, label: String, log: MutableList<String>) {
        val manager = propertyManager ?: run {
            log += "· config $label ${hex(propertyId)}: Car API не подключён"
            return
        }
        val config = runCatching {
            manager.javaClass.getMethod("getCarPropertyConfig", Int::class.javaPrimitiveType)
                .invoke(manager, propertyId)
        }
        val failure = config.exceptionOrNull()
        if (failure != null) {
            log += "· config $label ${hex(propertyId)}: ${shortError(unwrap(failure))}"
            return
        }
        val value = config.getOrNull() ?: run {
            log += "· config $label ${hex(propertyId)}: не объявлено"
            return
        }
        val type = runCatching { value.javaClass.getMethod("getPropertyType").invoke(value) }
            .getOrNull() ?: "?"
        val areas = runCatching { value.javaClass.getMethod("getAreaIds").invoke(value) }
            .getOrNull()
            ?.let { (it as? IntArray)?.joinToString(",") ?: it.toString() }
            ?: "?"
        val access = runCatching { value.javaClass.getMethod("getAccess").invoke(value) }
            .getOrNull() ?: "?"
        log += "· config $label ${hex(propertyId)}: type=$type areas=[$areas] access=$access"
    }

    private fun ensureConnected(log: MutableList<String>?): Boolean {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            lastConnectionError = "Car API requires a worker thread"
            log?.add(lastConnectionError!!)
            return false
        }
        if (connected && car != null && propertyManager != null) {
            val alive = runCatching { car!!.javaClass.getMethod("isConnected").invoke(car) == true }
                .getOrDefault(false)
            if (alive) return true
            close()
        }
        lastConnectionError = null
        return try {
            val carClass = Class.forName("android.car.Car")
            val created = createCar(carClass)
                ?: throw IllegalStateException("createCar вернул null")
            car = created

            val isConnectedMethod = carClass.getMethod("isConnected")
            var isConnected = isConnectedMethod.invoke(created) as? Boolean ?: false
            var attempts = 0
            while (!isConnected && attempts < 20) {
                Thread.sleep(100)
                isConnected = isConnectedMethod.invoke(created) as? Boolean ?: false
                attempts++
            }
            if (!isConnected) {
                throw IllegalStateException("Car Service не подключён")
            }

            val manager = carClass
                .getMethod("getCarManager", String::class.java)
                .invoke(created, "property")
                ?: throw IllegalStateException("CarPropertyManager недоступен")
            propertyManager = manager
            connected = true
            runCatching { registerEvents(manager) }.onFailure {
                registrationSummary = "events unavailable; full polling fallback: ${shortError(unwrap(it))}"
            }
            log?.add("$ Car.createCar(context)")
            log?.add("✓ Car API подключён")
            true
        } catch (t: Throwable) {
            val cause = unwrap(t)
            lastConnectionError = shortError(cause)
            close()
            log?.add("$ Car.createCar(context)")
            log?.add("✗ ${shortError(cause)}")
            false
        }
    }

    private var eventDiagnostic: String? = null // guarded by eventLock

    private fun registerEvents(manager: Any) {
        eventsRegistered = false
        val generation = synchronized(eventLock) {
            eventDiagnostic = null
            eventState.open()
        }
        val details = mutableListOf<String>()
        for ((registerName, callbackName, unregisterName) in listOf(
            Triple("registerListener", "CarPropertyEventListener", "unregisterListener"),
            Triple("registerCallback", "CarPropertyEventCallback", "unregisterCallback")
        )) {
            val register = manager.javaClass.methods.firstOrNull { method ->
                method.name == registerName && method.parameterTypes.size == 3 &&
                    method.parameterTypes[0].simpleName == callbackName && method.parameterTypes[0].isInterface &&
                    method.parameterTypes[1] == Int::class.javaPrimitiveType &&
                    method.parameterTypes[2] == Float::class.javaPrimitiveType
            } ?: continue
            val type = register.parameterTypes[0]
            val unregister = runCatching { manager.javaClass.getMethod(unregisterName, type) }.getOrNull()
                ?: continue
            val callback = propertyCallback(type) { name, args ->
                // Local reflection + pure decoding only. No source monitor and no Binder.
                if (name == "onChangeEvent") {
                    val decoded = runCatching { PropertyHolder.decode(args.firstOrNull()) }
                    synchronized(eventLock) {
                        if (eventState.generation == generation) {
                            decoded.fold(onSuccess = { holder ->
                                eventState.event(generation, holder)?.let { mutableUpdates.tryEmit(it) }
                            }, onFailure = { error -> eventDiagnostic = shortError(unwrap(error)) })
                        }
                    }
                } else if (name == "onErrorEvent") {
                    synchronized(eventLock) {
                        if (eventState.generation == generation) {
                            eventDiagnostic = "onErrorEvent ${args.joinToString()}"
                            val id = args.getOrNull(0) as? Int
                            val area = args.getOrNull(1) as? Int
                            if (id != null && area != null) {
                                eventState.event(generation, PropertyHolder(PropertyAddress(id, area), -1, null, 0L))
                                    ?.let { mutableUpdates.tryEmit(it) }
                            }
                        }
                    }
                }
            }
            val registration = Registration(manager, callback, unregister)
            registrations += registration // strong reference, also for partial registrations
            var accepted = 0
            val ids = eventState.propertyIds
            ids.forEach { id ->
                val rate = if (id == GeelyVhal.PROP_PERF_VEHICLE_SPEED) 5.0f else 0.0f
                val attempt = runCatching { register.invoke(manager, callback, id, rate) }
                if (attempt.isSuccess && attempt.getOrNull() != false) {
                    accepted++
                } else if (details.size < 3) {
                    val reason = attempt.exceptionOrNull()?.let { shortError(unwrap(it)) } ?: "returned false"
                    details += "${hex(id)}: $reason"
                }
            }
            if (accepted > 0) {
                eventsRegistered = true
                registrationSummary = "$registerName: $accepted/${ids.size} properties; speed <=5 Hz, others on-change" +
                    details.takeIf { it.isNotEmpty() }?.joinToString(prefix = "; ").orEmpty()
                return
            }
            if (runCatching { unregister.invoke(manager, callback) }.isSuccess) {
                registrations.remove(registration)
            } // retain a strong reference if cleanup failed; close will retry
        }
        registrationSummary = "events unavailable; full polling fallback" +
            details.takeIf { it.isNotEmpty() }?.joinToString(prefix = "; ").orEmpty()
    }

    private fun createCar(carClass: Class<*>): Any? {
        val single = runCatching {
            carClass.getMethod("createCar", Context::class.java).invoke(null, context)
        }
        if (single.isSuccess) return single.getOrNull()

        val fourArg = carClass.methods.firstOrNull {
            it.name == "createCar" && it.parameterTypes.size == 4
        } ?: throw single.exceptionOrNull()
            ?: IllegalStateException("метод createCar не найден")
        return fourArg.invoke(null, context, null, 1000L, null)
    }

    private fun logPermissions(log: MutableList<String>) {
        val permissions = listOf(
            "android.car.permission.CAR_ENERGY",
            "android.car.permission.CAR_ENERGY_PORTS",
            "android.car.permission.CAR_INFO",
            "android.car.permission.CAR_MILEAGE",
            "android.car.permission.CAR_MILEAGE_3P",
            "android.car.permission.CAR_SPEED",
            "android.car.permission.CAR_POWERTRAIN",
            "android.car.permission.CAR_EXTERIOR_ENVIRONMENT",
            "android.car.permission.CAR_VENDOR_EXTENSION",
            "android.car.permission.CAR_PROPERTY_ACCESS",
            "android.car.permission.CAR_HVAC",
            "android.car.permission.CONTROL_CAR_CLIMATE"
        )
        val denied = permissions.filter {
            context.checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (denied.isEmpty()) {
            log += "· права Car API: выданы (${permissions.size})"
        } else {
            log += "· права Car API: не выданы (${denied.size} из ${permissions.size})"
            denied.forEach { log += "  − ${it.substringAfterLast('.')}" }
            log += "ℹ это взгляд приложения на манифестные права; фактический ответ CarService виден по строкам записи"
        }
    }

    /**
     * Ответ, обогнанный событием, под свежим чтением перечитывается: иначе одна
     * гонка оставляла запись без исходного значения, и пресет молча не выполнялся.
     */
    private fun readRaw(
        propertyId: Int,
        label: String,
        log: MutableList<String>?,
        areaId: Int = GeelyVhal.AREA_GLOBAL
    ): Any? {
        val attempts = if (freshReads.get() == true) 3 else 1
        repeat(attempts) { attempt ->
            supersededReads.set(false)
            val value = readRawOnce(propertyId, label, log, areaId)
            if (value != null || supersededReads.get() != true) return value
            if (attempt < attempts - 1) Thread.sleep(40L)
        }
        return null
    }

    private fun readRawOnce(
        propertyId: Int,
        label: String,
        log: MutableList<String>?,
        areaId: Int
    ): Any? {
        if (poll != null) commandPriority.checkPoll(diagnostic = log != null)
        val manager = propertyManager ?: return null
        val address = PropertyAddress(propertyId, areaId)
        val key = (propertyId.toLong() shl 32) or (areaId.toLong() and 0xFFFFFFFFL)
        val now = System.currentTimeMillis()
        if (log == null && freshReads.get() != true) {
            val failure = failures[key]
            if (failure != null && failure.count >= SKIP_AFTER_FAILURES && now < failure.retryAt) return null
        }
        // Reserve before Binder so a callback during the call can supersede its reply.
        val token = poll
        val reconcile = token == null && freshReads.get() == true
        val (generation, order) = synchronized(eventLock) { eventState.generation to eventState.reserve() }
        val attempt = runCatching { PropertyHolder.read(manager, address) }
        val holder = attempt.getOrNull()
        var superseded = false
        if (token != null || reconcile) synchronized(eventLock) {
            // Кэш событий живёт по запрошенному адресу: канонический ответ обёртки
            // относится к тому же сигналу, иначе seed не нашёл бы чтение.
            val observed = holder?.copy(address = address)
                ?: PropertyHolder(address, -1, null, 0L)
            if (token != null) {
                eventState.observe(token, observed, order)
            } else {
                superseded = eventState.superseded(observed, order)
                eventState.observation(generation, observed, order)?.let { mutableUpdates.tryEmit(it) }
            }
        }
        if (superseded) {
            supersededReads.set(true)
            log?.add("· $label ${hex(propertyId)} area=$areaId: ответ устарел относительно события")
            return null
        }
        if (holder?.available == true) {
            failures.remove(key)
            if (log != null) {
                val canonical = if (holder.address == address) "" else
                    " · канонизировано: ${hex(holder.address.propertyId)} area=${holder.address.areaId}"
                log.add("✓ $label ${hex(propertyId)} area=$areaId [holder status=0 timestamp=${holder.timestamp}]: ${describe(holder.value)}$canonical")
            }
            return holder.value // false, 0 and floats remain exactly what the holder supplied
        }
        val failure = failures.getOrPut(key) { Failure() }
        failure.count++
        if (failure.count >= SKIP_AFTER_FAILURES) failure.retryAt = now + SKIP_MS
        if (log != null) {
            val reason = attempt.exceptionOrNull()?.let { shortError(unwrap(it)) }
                ?: holder?.let { "holder status=${it.status}, value=${describe(it.value)}" }
                ?: "нет holder"
            log.add("✗ $label ${hex(propertyId)} area=$areaId [holder]: $reason")
        }
        return null
    }

    private fun number(raw: Any?): Double? = when (raw) {
        is Number -> raw.toDouble()
        is Boolean -> if (raw) 1.0 else 0.0
        else -> null
    }

    private fun integer(raw: Any?): Int? = when (raw) {
        is Int -> raw
        is Long -> raw.toInt()
        is Float -> if (raw.isFinite()) raw.roundToInt() else null
        is Double -> if (raw.isFinite()) raw.roundToInt() else null
        else -> null
    }

    private fun describe(raw: Any?): String = when (raw) {
        null -> "null"
        is Float, is Double -> "%.3f".format(Locale.US, (raw as Number).toDouble())
        is Boolean -> raw.toString()
        is Number -> raw.toString()
        else -> raw.javaClass.simpleName + "(" + raw + ")"
    }

    private fun countReadable(values: CarValues): Int {
        val optional: List<Any?> = listOf(
            values.soc, values.rangeKm, values.odometerKm, values.speedKmh,
            values.outsideTempC, values.insideTempC, values.driveMode, values.regen,
            values.gear, values.ignition,
            values.chargeFlow, values.chargePowerKw, values.chargeEstimateMin, values.chargeWorkMin,
            values.acCurrentSetA, values.acCurrentMinA, values.acCurrentMaxA, values.portConnected
        )
        return optional.count { it != null } + (values.climate?.readableSignals ?: 0)
    }

    private fun CarValues.toSnapshot(profile: Profile): VehicleSnapshot? {
        if (!connected) return null
        if (soc == null && rangeKm == null && chargePowerKw == null && odometerKm == null &&
            outsideTempC == null && speedKmh == null && driveMode == null && regen == null &&
            gear == null && ignition == null && climate == null && chargeFlow == null &&
            portConnected == null && chargeConnectorType == null
        ) {
            return null
        }
        val isCharging = ChargingSignals.detect(chargeFlow, portConnected, chargePowerKw)
        return VehicleSnapshot(
            source = SourceMode.CAR_API,
            soc = soc,
            rangeKm = rangeKm,
            odometerKm = odometerKm,
            outsideTempC = outsideTempC,
            insideTempC = insideTempC,
            batteryKwh = profile.batteryKwh,
            isCharging = isCharging,
            chargePowerKw = chargePowerKw,
            speedKmh = speedKmh,
            driveMode = driveMode,
            regen = regen,
            gear = gear,
            ignition = ignition,
            chargeFlow = chargeFlow,
            chargeEstimateMin = chargeEstimateMin,
            chargeWorkMin = chargeWorkMin,
            chargeInputV = chargeInputV,
            chargeInputA = chargeInputA,
            acCurrentSetA = acCurrentSetA,
            acCurrentMinA = acCurrentMinA,
            acCurrentMaxA = acCurrentMaxA,
            climate = climate,
            body = body,
            updatedAt = System.currentTimeMillis(),
            note = "Car API"
        )
    }

    private fun CarValues.toCheck(): SourceCheck {
        if (!connected) {
            return SourceCheck(
                status = CheckStatus.ERROR,
                summary = lastConnectionError ?: "Car API недоступен",
                checkedAt = System.currentTimeMillis()
            )
        }
        val parts = buildList {
            soc?.let { add("SOC $it%") }
            rangeKm?.let { add("запас $it км") }
            outsideTempC?.let { add("$it °C") }
            chargePowerKw?.let { add("%.1f кВт".format(Locale.US, it)) }
            chargeFlow?.let { add("зарядка ${it.name.lowercase(Locale.US)}") }
            chargeWorkMin?.let { add("сессия $it мин") }
            gear?.let { add("передача ${it.name}") }
            ignition?.let { add("зажигание ${it.name}") }
            climate?.let { add("климат ${it.readableSignals} сигн.") }
        }
        if (soc == null && rangeKm == null && outsideTempC == null && driveMode == null &&
            regen == null && chargeFlow == null && gear == null && ignition == null &&
            climate == null
        ) {
            return SourceCheck(
                status = CheckStatus.ERROR,
                summary = "Car API подключён, но свойства не читаются",
                checkedAt = System.currentTimeMillis()
            )
        }
        return SourceCheck(
            status = CheckStatus.OK,
            summary = parts.joinToString(" · ").ifBlank { "Car API подключён" },
            checkedAt = System.currentTimeMillis()
        )
    }

    private fun unwrap(t: Throwable): Throwable {
        var current = t
        while (current is InvocationTargetException && current.targetException != null) {
            current = current.targetException
        }
        return current
    }

    private fun shortError(t: Throwable): String {
        val raw = "${t.javaClass.simpleName}: ${t.message ?: "без описания"}"
        return if (raw.length > 220) raw.take(220) + "…" else raw
    }

    private fun hex(value: Int): String = "0x%08X".format(Locale.US, value)

    companion object {
        // Trunk/frunk actuator candidates are intentionally not changed here.
        private val READ_ONLY_BODY_PROPERTIES = setOf(
            GeelyVhal.PROP_DOOR_POS, GeelyVhal.PROP_DOOR_POS_VENDOR, GeelyVhal.PROP_DOOR_LOCK,
            GeelyVhal.PROP_WINDOW_POS, GeelyVhal.PROP_WINDOW_POS_VENDOR, GeelyVhal.PROP_CENTRAL_LOCK,
            GeelyVhal.PROP_HOOD_STATUS_VENDOR, GeelyVhal.PROP_TRUNK_POS_VENDOR,
            GeelyVhal.PROP_HEADLIGHTS_STATE, GeelyVhal.PROP_HEADLIGHTS_SWITCH,
            GeelyVhal.PROP_BODY_LIGHT_STATUS, GeelyVhal.PROP_HIGH_BEAM_STATE,
            GeelyVhal.PROP_FOG_LIGHTS_STATE, GeelyVhal.PROP_HAZARD_LIGHTS_STATE, GeelyVhal.PROP_TURN_SIGNAL_STATE
        )
        private const val SKIP_AFTER_FAILURES = 3

        /** Минута: столько может опоздать свойство, которое прошивка включила позже (например, на зарядке). */
        private const val SKIP_MS = 60_000L

        /**
         * Типизированный перебор свойств за бортом — до десятка Binder-вызовов,
         * почти все с исключением. В обычном опросе он повторяется не чаще этого,
         * в пробе — каждый раз.
         */
        private const val OUTSIDE_TYPED_RETRY_MS = 15_000L
    }
}

internal class CarCommandPriority {
    private val pending = AtomicInteger()

    suspend fun <T> runCommand(enabled: Boolean = true, block: suspend () -> T): T {
        if (!enabled) return block()
        pending.incrementAndGet()
        return try { block() } finally { pending.decrementAndGet() }
    }

    fun checkPoll(diagnostic: Boolean = false) {
        // Binder-вызов не прерывается; опрос уступает монитор перед следующим чтением.
        if (!diagnostic && pending.get() > 0) throw PollYield()
    }

    class PollYield : RuntimeException(null, null, false, false)
}

internal fun readTypedTemperature(
    manager: Any,
    address: PropertyAddress,
    preferFloat: Boolean,
    decode: (Any?) -> Int?,
    report: (String, Result<Any?>, Int?) -> Unit = { _, _, _ -> }
): Int? {
    val intType = Int::class.javaPrimitiveType
    val names = if (preferFloat) listOf("getFloatProperty", "getIntProperty")
        else listOf("getIntProperty", "getFloatProperty")
    for (name in names) {
        val attempt = runCatching {
            manager.javaClass.getMethod(name, intType, intType)
                .invoke(manager, address.propertyId, address.areaId)
        }
        // Int хранит десятые доли, Float — градусы; приведение к Double меняет шкалу.
        val value = decode(attempt.getOrNull())
        report(name, attempt, value)
        if (value != null) return value
    }
    return null
}
