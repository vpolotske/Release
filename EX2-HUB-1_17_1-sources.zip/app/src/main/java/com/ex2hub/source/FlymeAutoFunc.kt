package com.ex2hub.source

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.lang.reflect.InvocationTargetException
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Второй канал к данным автомобиля: Flyme AutoFunc API, через который штатные
 * Settings читают режим движения и уровень рекуперации. Путь найден в
 * geely_ex2_tools (`data/driving/FlymeDrivingModeApi.kt`, лицензию репозиторий не
 * содержит), поэтому здесь воспроизведён только порядок вызовов:
 * `AutoFuncManager.getInstance(context)` → `getAutoFuncInterface()` →
 * `EnumFuncLiveData(AutoFuncId.X, false)` → `init()` → поле `mValue`.
 *
 * Значение LiveData нельзя читать из фонового потока, поэтому снятие значения
 * ставится в главный поток с коротким таймаутом. Классов Flyme на обычном ГУ нет,
 * и тогда канал молча считается недоступным.
 */
class FlymeAutoFunc(context: Context) {
    private val appContext = context.applicationContext
    private val liveData = HashMap<String, Any>()
    private var initialized = false
    private var manager: Any? = null
    private var autoFuncIdClass: Class<*>? = null
    private var enumLiveDataClass: Class<*>? = null
    private var initError: String? = null
    private val unavailableFunctions = HashSet<String>()

    fun unavailableReason(): String? {
        ensure()
        return initError
    }

    /**
     * Код функции по имени AutoFuncId. Возвращает null, когда канал недоступен,
     * функция в этой прошивке не объявлена или значение ещё не пришло.
     */
    fun readCode(functionName: String, log: MutableList<String>?): Int? {
        ensure()
        if (manager == null || autoFuncIdClass == null || enumLiveDataClass == null) return null
        if (unavailableFunctions.contains(functionName)) return null
        val current = getLiveData(functionName, log) ?: run {
            unavailableFunctions.add(functionName)
            return null
        }
        val value = readValue(current)
        if (value == null) {
            log?.add("✗ Flyme $functionName: значение не получено")
            return null
        }
        log?.add("✓ Flyme $functionName: код $value")
        return value
    }

    private fun getLiveData(functionName: String, log: MutableList<String>?): Any? {
        liveData[functionName]?.let { return it }
        val id = try {
            autoFuncIdClass?.getField(functionName)?.get(null)
        } catch (t: Throwable) {
            log?.add("✗ Flyme $functionName: ${rootMessage(t)}")
            return null
        } ?: return null
        val created = try {
            newLiveData(id)
        } catch (t: Throwable) {
            log?.add("✗ Flyme $functionName: ${rootMessage(t)}")
            null
        } ?: return null
        return try {
            runCatching { created.javaClass.getMethod("init2").invoke(created) }
                .onFailure { runCatching { created.javaClass.getMethod("init").invoke(created) } }
            liveData[functionName] = created
            created
        } catch (t: Throwable) {
            log?.add("✗ Flyme $functionName: инициализация ${rootMessage(t)}")
            null
        }
    }

    /** Прошивки расходятся в составе конструкторов: сначала таймаутный, затем обычный. */
    private fun newLiveData(id: Any): Any? {
        val liveClass = enumLiveDataClass ?: return null
        val timeoutCtor = runCatching {
            liveClass.getConstructor(
                autoFuncIdClass,
                Long::class.javaPrimitiveType,
                Boolean::class.javaPrimitiveType
            )
        }.getOrNull()
        if (timeoutCtor != null) {
            val withTimeout = runCatching {
                timeoutCtor.newInstance(id, READ_TIMEOUT_MS, false)
            }.getOrNull()
            if (withTimeout != null) return withTimeout
        }
        return liveClass
            .getConstructor(autoFuncIdClass, Boolean::class.javaPrimitiveType)
            .newInstance(id, false)
    }

    private fun readValue(source: Any): Int? {
        val holder = try {
            source.javaClass.getField("mValue").get(source)
        } catch (t: Throwable) {
            return null
        } ?: return null
        val raw = if (Looper.myLooper() == Looper.getMainLooper()) {
            readOnMain(holder)
        } else {
            val latch = CountDownLatch(1)
            val box = arrayOfNulls<Any>(1)
            Handler(Looper.getMainLooper()).post {
                box[0] = readOnMain(holder)
                latch.countDown()
            }
            if (!latch.await(MAIN_WAIT_MS, TimeUnit.MILLISECONDS)) return null
            box[0]
        }
        return parseCode(raw)
    }

    private fun readOnMain(holder: Any): Any? =
        runCatching { holder.javaClass.getMethod("getValue").invoke(holder) }.getOrNull()

    /** Прошивка отдаёт то число, то объект AutoFuncId с полем `id`. */
    private fun parseCode(value: Any?): Int? = when (value) {
        null -> null
        is Int -> value
        is Number -> value.toInt()
        else -> runCatching {
            (value.javaClass.getField("id").get(value) as? Number)?.toInt()
        }.getOrNull()
    }

    private fun ensure() {
        if (initialized) return
        initialized = true
        try {
            val managerClass = Class.forName("com.flyme.auto.api.AutoFuncManager")
            val instance = managerClass.getMethod("getInstance", Context::class.java)
                .invoke(null, appContext)
            if (instance == null) {
                initError = "AutoFuncManager.getInstance вернул null"
                return
            }
            try {
                managerClass.getMethod("getAutoFuncInterface", Context::class.java)
                    .invoke(instance, appContext)
            } catch (_: NoSuchMethodException) {
                managerClass.getMethod("getAutoFuncInterface").invoke(instance)
            }
            autoFuncIdClass = Class.forName("com.flyme.auto.api.AutoFuncId")
            enumLiveDataClass = Class.forName("com.flyme.auto.api.data.EnumFuncLiveData")
            manager = instance
        } catch (t: Throwable) {
            manager = null
            autoFuncIdClass = null
            enumLiveDataClass = null
            initError = rootMessage(t)
        }
    }

    private fun rootMessage(t: Throwable): String {
        var current = t
        while (current is InvocationTargetException && current.targetException != null) {
            current = current.targetException
        }
        val raw = "${current.javaClass.simpleName}: ${current.message ?: "без описания"}"
        return if (raw.length > 160) raw.take(160) + "…" else raw
    }

    private companion object {
        const val MAIN_WAIT_MS = 1_500L
        const val READ_TIMEOUT_MS = 3_000L
    }
}
