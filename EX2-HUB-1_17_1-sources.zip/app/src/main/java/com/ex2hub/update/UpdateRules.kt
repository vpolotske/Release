package com.ex2hub.update

import java.math.BigInteger
import java.net.URI
import java.security.MessageDigest
import java.util.Locale

internal const val LATEST_RELEASE_URL =
    "https://api.github.com/repos/vpolotske/Release/releases/latest"
internal const val MAX_JSON_BYTES = 512 * 1024
internal const val MAX_APK_BYTES = 64L * 1024 * 1024
internal const val MAX_REDIRECTS = 5
private const val REPOSITORY_PATH = "/vpolotske/Release"

/** Strict SemVer 2.0 comparison. Build metadata does not affect precedence. */
fun compareVersionNames(candidate: String, installed: String): Int =
    SemVersion.parse(candidate).compareTo(SemVersion.parse(installed))

internal data class SemVersion(
    val core: List<BigInteger>,
    val prerelease: List<String>
) : Comparable<SemVersion> {
    override fun compareTo(other: SemVersion): Int {
        core.indices.forEach { index ->
            core[index].compareTo(other.core[index]).let { if (it != 0) return it }
        }
        if (prerelease.isEmpty() || other.prerelease.isEmpty()) {
            return when {
                prerelease.isEmpty() && other.prerelease.isEmpty() -> 0
                prerelease.isEmpty() -> 1
                else -> -1
            }
        }
        repeat(minOf(prerelease.size, other.prerelease.size)) { index ->
            val left = prerelease[index]
            val right = other.prerelease[index]
            val leftNumber = left.all { it in '0'..'9' }
            val rightNumber = right.all { it in '0'..'9' }
            val order = when {
                leftNumber && rightNumber -> BigInteger(left).compareTo(BigInteger(right))
                leftNumber -> -1
                rightNumber -> 1
                else -> left.compareTo(right)
            }
            if (order != 0) return order
        }
        return prerelease.size.compareTo(other.prerelease.size)
    }

    companion object {
        private val pattern = Regex(
            "^(0|[1-9][0-9]*)\\.(0|[1-9][0-9]*)\\.(0|[1-9][0-9]*)" +
                "(?:-([0-9A-Za-z-]+(?:\\.[0-9A-Za-z-]+)*))?" +
                "(?:\\+([0-9A-Za-z-]+(?:\\.[0-9A-Za-z-]+)*))?$"
        )

        fun parse(value: String): SemVersion {
            require(value.length in 1..128) { "Некорректная версия SemVer." }
            val match = requireNotNull(pattern.matchEntire(value)) { "Некорректная версия SemVer." }
            val prerelease = match.groupValues[4].takeIf { it.isNotEmpty() }?.split('.') ?: emptyList()
            require(prerelease.none {
                it.length > 1 && it[0] == '0' && it.all { char -> char in '0'..'9' }
            }) { "Некорректная версия SemVer." }
            return SemVersion((1..3).map { BigInteger(match.groupValues[it]) }, prerelease)
        }
    }
}

internal fun versionFromTag(tag: String): String {
    val version = tag.removePrefix("v")
    require(SemVersion.parse(version).prerelease.isEmpty()) { "Предварительный релиз запрещён." }
    return version
}

private fun httpsUri(value: String): URI {
    require(value.length in 1..16_384) { "Некорректный URL обновления." }
    val uri = try {
        URI(value)
    } catch (_: Exception) {
        throw IllegalArgumentException("Некорректный URL обновления.")
    }
    require(
        uri.scheme.equals("https", ignoreCase = true) && uri.host != null &&
            uri.rawUserInfo == null && uri.rawFragment == null &&
            (uri.port == -1 || uri.port == 443)
    ) { "Требуется HTTPS URL без пользовательских данных." }
    return uri
}

internal fun validateReleaseUrls(apiUrl: String, htmlUrl: String, tag: String) {
    val api = httpsUri(apiUrl)
    require(api.host.equals("api.github.com", true) && api.rawQuery == null &&
        Regex("^/repos$REPOSITORY_PATH/releases/[1-9][0-9]*$").matches(api.path)
    ) { "Релиз принадлежит другому репозиторию." }
    val html = httpsUri(htmlUrl)
    require(html.host.equals("github.com", true) && html.rawQuery == null &&
        html.path == "$REPOSITORY_PATH/releases/tag/$tag"
    ) { "URL релиза не соответствует репозиторию и тегу." }
}

internal fun validateAssetUrl(url: String, tag: String, assetName: String) {
    val version = versionFromTag(tag)
    require(assetName == "EX2-HUB-$version.apk") { "Неверное имя APK." }
    val uri = httpsUri(url)
    require(uri.host.equals("github.com", true) && uri.rawQuery == null &&
        uri.path == "$REPOSITORY_PATH/releases/download/$tag/$assetName"
    ) { "URL APK не соответствует репозиторию, тегу и имени." }
}

/** Only download redirects may use these hosts. API redirects are rejected. */
internal fun resolveDownloadRedirect(current: String, location: String, release: UpdateRelease): String {
    val destination = try {
        URI(current).resolve(location).toString()
    } catch (_: Exception) {
        throw IllegalArgumentException("Некорректное перенаправление.")
    }
    val uri = httpsUri(destination)
    val host = uri.host.lowercase(Locale.ROOT)
    require(host in setOf("github.com", "release-assets.githubusercontent.com", "objects.githubusercontent.com")) {
        "Хост перенаправления запрещён."
    }
    if (host == "github.com") validateAssetUrl(destination, release.tag, release.assetName)
    return destination
}

internal fun normalizeDigest(digest: String): String {
    require(Regex("^sha256:[0-9a-fA-F]{64}$").matches(digest)) { "Отсутствует корректный SHA-256 APK." }
    return digest.lowercase(Locale.ROOT)
}

internal fun validateAssetSize(size: Long) {
    require(size in 1..MAX_APK_BYTES) { "Размер APK должен быть от 1 байта до 64 MiB." }
}

internal fun verifyDownload(release: UpdateRelease, size: Long, sha256: ByteArray) {
    validateAssetSize(release.size)
    require(size == release.size) { "Размер загруженного APK не совпадает с релизом." }
    val expectedHex = normalizeDigest(release.digest).removePrefix("sha256:")
    val expected = ByteArray(32) { index ->
        expectedHex.substring(index * 2, index * 2 + 2).toInt(16).toByte()
    }
    require(MessageDigest.isEqual(expected, sha256)) { "SHA-256 загруженного APK не совпадает." }
}

internal fun sha256Hex(bytes: ByteArray): String =
    MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") {
        (it.toInt() and 0xff).toString(16).padStart(2, '0')
    }
