package com.ex2hub.update

enum class UpdatePhase {
    IDLE, CHECKING, UP_TO_DATE, AVAILABLE, DOWNLOADING, READY, ERROR
}

/** digest is the required GitHub digest, normalized as sha256:<64 lowercase hex>. */
data class UpdateRelease(
    val versionName: String,
    val tag: String,
    val assetName: String,
    val url: String,
    val digest: String,
    val size: Long
)

data class UpdateState(
    val phase: UpdatePhase = UpdatePhase.IDLE,
    val release: UpdateRelease? = null,
    val progress: Int? = null,
    val message: String? = null
)
