package com.ex2hub.update

import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction

/** Pure JVM parser; no Android JSON stubs or additional dependencies in unit tests. */
internal fun parseLatestRelease(bytes: ByteArray): UpdateRelease = selectApk(readReleaseRoot(bytes))

/** Old/current releases need no downloadable APK; no download or install is offered. */
internal fun latestUpdateFor(bytes: ByteArray, installedVersionName: String): UpdateRelease? {
    val root = readReleaseRoot(bytes)
    val version = versionFromTag(root.text("tag_name"))
    return if (compareVersionNames(version, installedVersionName) <= 0) null else selectApk(root)
}

private fun readReleaseRoot(bytes: ByteArray): Map<*, *> {
    require(bytes.size <= MAX_JSON_BYTES) { "Ответ GitHub превышает 512 KiB." }
    val json = try {
        Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(bytes)).toString()
    } catch (_: Exception) {
        throw IllegalArgumentException("Ответ GitHub содержит некорректный UTF-8.")
    }
    val root = ReleaseJson(json).parse().objectValue()
    require(root["draft"] == false && root["prerelease"] == false) {
        "Черновики и предварительные релизы запрещены."
    }
    val tag = root.text("tag_name")
    versionFromTag(tag)
    validateReleaseUrls(root.text("url"), root.text("html_url"), tag)
    return root
}

private fun selectApk(root: Map<*, *>): UpdateRelease {
    val tag = root.text("tag_name")
    val version = versionFromTag(tag)
    val expectedName = "EX2-HUB-$version.apk"
    val assets = requireNotNull(root["assets"] as? List<*>) { "Нет списка APK релиза." }
    val candidates = assets.map { it.objectValue() }.filter { it.text("name") == expectedName }
    require(candidates.size == 1) { "Нужен ровно один APK $expectedName." }
    val asset = candidates.single()
    require(asset.text("state") == "uploaded") { "APK ещё не загружен в GitHub." }
    val size = (asset["size"] as? JsonNumber)?.value?.toLongOrNull()
        ?: throw IllegalArgumentException("Некорректный размер APK.")
    validateAssetSize(size)
    val url = asset.text("browser_download_url")
    validateAssetUrl(url, tag, expectedName)
    return UpdateRelease(version, tag, expectedName, url, normalizeDigest(asset.text("digest")), size)
}

private fun Any?.objectValue(): Map<*, *> =
    requireNotNull(this as? Map<*, *>) { "Некорректный объект JSON релиза." }

private fun Map<*, *>.text(key: String): String =
    requireNotNull(this[key] as? String) { "Нет строкового поля $key в релизе." }

private data class JsonNumber(val value: String)

/** Strict, bounded JSON reader only for the release response. Rejects ambiguous duplicate keys. */
private class ReleaseJson(private val text: String) {
    private var position = 0
    private var nodes = 0

    fun parse(): Any? {
        val result = value(0)
        whitespace()
        require(position == text.length) { "Данные после JSON релиза." }
        return result
    }

    private fun value(depth: Int): Any? {
        require(depth <= 32 && ++nodes <= 32_768) { "JSON релиза слишком сложный." }
        whitespace()
        require(position < text.length) { "Неполный JSON релиза." }
        return when (text[position]) {
            '{' -> objectValue(depth + 1)
            '[' -> arrayValue(depth + 1)
            '"' -> stringValue()
            't' -> literal("true", true)
            'f' -> literal("false", false)
            'n' -> literal("null", null)
            '-', in '0'..'9' -> numberValue()
            else -> throw IllegalArgumentException("Некорректный JSON релиза.")
        }
    }

    private fun objectValue(depth: Int): Map<String, Any?> {
        position++
        whitespace()
        val result = LinkedHashMap<String, Any?>()
        if (consume('}')) return result
        while (true) {
            whitespace()
            require(position < text.length && text[position] == '"') { "Нет ключа JSON." }
            val key = stringValue()
            require(!result.containsKey(key)) { "Повторный ключ JSON релиза." }
            whitespace()
            require(consume(':')) { "Нет двоеточия JSON." }
            result[key] = value(depth)
            whitespace()
            if (consume('}')) return result
            require(consume(',')) { "Нет разделителя JSON." }
        }
    }

    private fun arrayValue(depth: Int): List<Any?> {
        position++
        whitespace()
        val result = ArrayList<Any?>()
        if (consume(']')) return result
        while (true) {
            result.add(value(depth))
            whitespace()
            if (consume(']')) return result
            require(consume(',')) { "Нет разделителя массива JSON." }
        }
    }

    private fun stringValue(): String {
        position++
        val result = StringBuilder()
        while (position < text.length) {
            val char = text[position++]
            when {
                char == '"' -> return result.toString()
                char == '\\' -> {
                    require(position < text.length) { "Неполная escape-последовательность JSON." }
                    when (val escaped = text[position++]) {
                        '"', '\\', '/' -> result.append(escaped)
                        'b' -> result.append('\b')
                        'f' -> result.append('\u000c')
                        'n' -> result.append('\n')
                        'r' -> result.append('\r')
                        't' -> result.append('\t')
                        'u' -> {
                            require(position + 4 <= text.length) { "Неполный Unicode в JSON." }
                            val hex = text.substring(position, position + 4)
                            require(hex.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }) {
                                "Некорректный Unicode в JSON."
                            }
                            result.append(hex.toInt(16).toChar())
                            position += 4
                        }
                        else -> throw IllegalArgumentException("Некорректная escape-последовательность JSON.")
                    }
                }
                char < ' ' -> throw IllegalArgumentException("Управляющий символ в JSON.")
                else -> result.append(char)
            }
        }
        throw IllegalArgumentException("Незавершённая строка JSON.")
    }

    private fun numberValue(): JsonNumber {
        val start = position
        consume('-')
        require(position < text.length) { "Некорректное число JSON." }
        if (!consume('0')) {
            require(text[position] in '1'..'9') { "Некорректное число JSON." }
            digits()
        }
        if (consume('.')) {
            require(position < text.length && text[position] in '0'..'9') { "Нет дробной части JSON." }
            digits()
        }
        if (consume('e') || consume('E')) {
            if (!consume('+')) consume('-')
            require(position < text.length && text[position] in '0'..'9') { "Нет экспоненты JSON." }
            digits()
        }
        return JsonNumber(text.substring(start, position))
    }

    private fun digits() {
        while (position < text.length && text[position] in '0'..'9') position++
    }

    private fun literal(expected: String, result: Any?): Any? {
        require(text.startsWith(expected, position)) { "Некорректное значение JSON." }
        position += expected.length
        return result
    }

    private fun whitespace() {
        while (position < text.length && text[position] in " \t\r\n") position++
    }

    private fun consume(char: Char): Boolean {
        if (position >= text.length || text[position] != char) return false
        position++
        return true
    }
}
