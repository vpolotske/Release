package com.ex2hub.update

import java.io.ByteArrayOutputStream
import java.io.File
import java.net.URL
import java.security.MessageDigest
import javax.net.ssl.HttpsURLConnection
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive

/** Called only on Dispatchers.IO. TLS verification stays at the platform defaults. */
internal object UpdateHttp {
    suspend fun latestJson(): ByteArray {
        currentCoroutineContext().ensureActive()
        val connection = connection(LATEST_RELEASE_URL, "application/vnd.github+json")
        try {
            val status = connection.responseCode
            require(status == 200) {
                latestReleaseFailure(
                    status,
                    repositoryStatus = if (status == 404) repositoryStatus() else null,
                    rateLimited = connection.getHeaderField("X-RateLimit-Remaining") == "0"
                )
            }
            requireIdentityEncoding(connection)
            require(connection.contentLengthLong <= MAX_JSON_BYTES) { "Ответ GitHub превышает 512 KiB." }
            return connection.inputStream.use { input ->
                val output = ByteArrayOutputStream()
                val buffer = ByteArray(8 * 1024)
                var total = 0
                while (true) {
                    currentCoroutineContext().ensureActive()
                    val read = input.read(buffer, 0, minOf(buffer.size, MAX_JSON_BYTES - total + 1))
                    if (read == -1) break
                    total += read
                    require(total <= MAX_JSON_BYTES) { "Ответ GitHub превышает 512 KiB." }
                    output.write(buffer, 0, read)
                }
                currentCoroutineContext().ensureActive()
                output.toByteArray()
            }
        } finally {
            connection.disconnect()
        }
    }

    /** Streams into an app-private .part file. Caller owns deletion on any failure/cancellation. */
    suspend fun download(release: UpdateRelease, part: File, progress: (Int) -> Unit) {
        validateAssetUrl(release.url, release.tag, release.assetName)
        normalizeDigest(release.digest)
        validateAssetSize(release.size)
        var url = release.url
        var redirects = 0
        while (true) {
            currentCoroutineContext().ensureActive()
            val connection = connection(url, "application/octet-stream")
            try {
                val status = connection.responseCode
                if (status in setOf(301, 302, 303, 307, 308)) {
                    require(redirects < MAX_REDIRECTS) { "Более пяти перенаправлений APK." }
                    val location = requireNotNull(connection.getHeaderField("Location")) {
                        "Перенаправление APK без адреса."
                    }
                    url = resolveDownloadRedirect(url, location, release)
                    redirects++
                    continue
                }
                require(status == 200) { "Загрузка APK: HTTP $status." }
                requireIdentityEncoding(connection)
                val declaredSize = connection.contentLengthLong
                require(declaredSize == -1L || declaredSize == release.size) {
                    "Размер HTTP-ответа не совпадает с релизом."
                }
                val digest = MessageDigest.getInstance("SHA-256")
                var total = 0L
                var lastProgress = 0
                var lastProgressTime = System.nanoTime()
                connection.inputStream.use { input ->
                    part.outputStream().use { output ->
                        val buffer = ByteArray(32 * 1024)
                        while (true) {
                            currentCoroutineContext().ensureActive()
                            val read = input.read(buffer)
                            if (read == -1) break
                            total += read
                            require(total <= release.size && total <= MAX_APK_BYTES) {
                                "APK превышает допустимый размер."
                            }
                            output.write(buffer, 0, read)
                            digest.update(buffer, 0, read)
                            val percent = ((total * 100) / release.size).toInt().coerceAtMost(99)
                            val now = System.nanoTime()
                            // Chunk progress: at most 4 Hz; 100 belongs only to the verified READY state.
                            if (percent != lastProgress && now - lastProgressTime >= 250_000_000L) {
                                currentCoroutineContext().ensureActive()
                                progress(percent)
                                lastProgress = percent
                                lastProgressTime = now
                            }
                        }
                    }
                }
                currentCoroutineContext().ensureActive()
                verifyDownload(release, total, digest.digest())
                return
            } finally {
                connection.disconnect()
            }
        }
    }

    private suspend fun repositoryStatus(): Int? {
        currentCoroutineContext().ensureActive()
        return try {
            val repository = connection(LATEST_RELEASE_URL.removeSuffix("/releases/latest"), "application/vnd.github+json")
            try {
                repository.responseCode
            } finally {
                repository.disconnect()
            }
        } catch (_: java.io.IOException) {
            null
        }
    }

    internal fun latestReleaseFailure(
        status: Int,
        repositoryStatus: Int? = null,
        rateLimited: Boolean = false
    ): String = when {
        status == 429 || (status == 403 && rateLimited) ->
            "GitHub API: HTTP $status — исчерпан лимит запросов. Повторите проверку позже."
        status == 404 && repositoryStatus == 200 ->
            "В vpolotske/Release нет опубликованного стабильного релиза. " +
                "Владелец должен опубликовать релиз с APK; установленная версия не проверена."
        status == 404 && repositoryStatus == 404 ->
            "GitHub API: HTTP 404 — репозиторий vpolotske/Release не найден или закрыт. " +
                "Анонимная проверка требует публичного репозитория и опубликованного релиза."
        status == 404 ->
            "GitHub API: HTTP 404 — стабильный релиз недоступен. Не удалось уточнить доступность репозитория."
        status == 401 || status == 403 ->
            "GitHub API: HTTP $status — сервер отказал в доступе. Проверка выполняется без токена."
        else -> "GitHub API: HTTP $status."
    }

    private fun connection(url: String, accept: String): HttpsURLConnection =
        (URL(url).openConnection() as HttpsURLConnection).apply {
            requestMethod = "GET"
            instanceFollowRedirects = false
            connectTimeout = 10_000
            readTimeout = 20_000
            useCaches = false
            setRequestProperty("Accept", accept)
            setRequestProperty("Accept-Encoding", "identity")
            setRequestProperty("User-Agent", "EX2-HUB-Updater")
            // No Authorization, tokens, custom trust manager, or hostname verifier.
        }

    private fun requireIdentityEncoding(connection: HttpsURLConnection) {
        val encoding = connection.getHeaderField("Content-Encoding")
        require(encoding.isNullOrBlank() || encoding.equals("identity", true)) {
            "Сжатый HTTP-ответ обновления запрещён."
        }
    }
}
