package com.ex2hub.update

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import java.io.File

internal const val UPDATE_PACKAGE_NAME = "com.ex2hub"

@Suppress("DEPRECATION")
internal object ApkVerifier {
    fun installed(context: Context): PackageInfo {
        require(context.packageName == UPDATE_PACKAGE_NAME) { "Updater предназначен только для com.ex2hub." }
        return context.packageManager.getPackageInfo(context.packageName, signatureFlags())
    }

    fun verify(context: Context, apk: File, release: UpdateRelease) {
        require(apk.isFile && apk.length() == release.size) { "Размер файла APK не совпадает с релизом." }
        val installed = installed(context)
        val installedVersion = requireNotNull(installed.versionName) { "Нет установленной версии." }
        require(compareVersionNames(release.versionName, installedVersion) > 0) {
            "Версия APK не новее установленной."
        }
        val verified = com.android.apksig.ApkVerifier.Builder(apk)
            .setMinCheckedPlatformVersion(Build.VERSION.SDK_INT)
            .setMaxCheckedPlatformVersion(Build.VERSION.SDK_INT)
            .build()
            .verify()
        require(verified.isVerified) { "Криптографическая подпись APK недействительна." }
        val archive = requireNotNull(
            context.packageManager.getPackageArchiveInfo(apk.absolutePath, signatureFlags())
        ) { "PackageManager не смог прочитать APK." }
        require(archive.packageName == UPDATE_PACKAGE_NAME) { "APK принадлежит другому приложению." }
        require(archive.versionName == release.versionName &&
            release.versionName == versionFromTag(release.tag)
        ) { "Версия APK не соответствует тегу релиза." }
        require(versionCode(archive) > versionCode(installed)) { "versionCode APK не новее установленного." }
        val application = requireNotNull(archive.applicationInfo) { "В APK нет ApplicationInfo." }
        require(application.minSdkVersion <= Build.VERSION.SDK_INT) { "APK требует более новый Android." }
        val installedCertificates = certificates(installed)
        // Сертификаты берём из проверенной подписи: getPackageArchiveInfo на части
        // прошивок не разбирает подписи архива и возвращает пустой список.
        val archiveCertificates = verified.signerCertificates.map { sha256Hex(it.encoded) }.toSet()
        require(archiveCertificates.isNotEmpty()) { "В APK нет подписанта." }
        require(installedCertificates == archiveCertificates) {
            "APK подписан не тем же ключом, что установленное приложение."
        }
    }

    private fun signatureFlags(): Int = if (Build.VERSION.SDK_INT >= 28) {
        PackageManager.GET_SIGNING_CERTIFICATES
    } else {
        PackageManager.GET_SIGNATURES
    }

    private fun versionCode(info: PackageInfo): Long = if (Build.VERSION.SDK_INT >= 28) {
        info.longVersionCode
    } else {
        info.versionCode.toLong()
    }

    private fun certificates(info: PackageInfo): Set<String> {
        // Current signers only. Certificate rotation/history must not widen the accepted set.
        val signatures = if (Build.VERSION.SDK_INT >= 28) {
            info.signingInfo?.apkContentsSigners
        } else {
            info.signatures
        }
        require(!signatures.isNullOrEmpty()) { "Установленное приложение не сообщило сертификат подписи." }
        return signatures.map { sha256Hex(it.toByteArray()) }.toSet()
    }
}
