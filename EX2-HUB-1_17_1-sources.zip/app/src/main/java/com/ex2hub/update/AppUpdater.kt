package com.ex2hub.update

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.FileProvider
import java.io.File
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext

class AppUpdater(context: Context) {
    private val app = context.applicationContext
    private val operations = Mutex()
    private val stateLock = Any()
    private val mutableState = MutableStateFlow(UpdateState())
    private var readyApk: File? = null // guarded by stateLock together with the state transition

    val state: StateFlow<UpdateState> = mutableState.asStateFlow()

    suspend fun checkLatest() {
        if (!operations.tryLock()) return
        var obsolete: File? = null
        try {
            obsolete = publish(UpdateState(UpdatePhase.CHECKING))
            val release = withContext(Dispatchers.IO) {
                val installed = ApkVerifier.installed(app)
                val installedVersion = requireNotNull(installed.versionName) { "Нет установленной версии." }
                // Invalid installed SemVer fails closed before making an internet request.
                SemVersion.parse(installedVersion)
                latestUpdateFor(UpdateHttp.latestJson(), installedVersion)
            }
            currentCoroutineContext().ensureActive()
            publish(if (release == null) {
                UpdateState(UpdatePhase.UP_TO_DATE, message = "Установлена актуальная версия.")
            } else {
                UpdateState(UpdatePhase.AVAILABLE, release)
            })
        } catch (cancelled: CancellationException) {
            publish(UpdateState(UpdatePhase.IDLE, message = "Проверка отменена."))
            throw cancelled
        } catch (error: Exception) {
            publish(UpdateState(UpdatePhase.ERROR, message = errorMessage(error)))
        } finally {
            try {
                withContext(NonCancellable + Dispatchers.IO) { obsolete?.delete() }
            } finally {
                operations.unlock()
            }
        }
    }

    /** Available after a successful check; ERROR with a release also permits an explicit retry. */
    suspend fun download() {
        if (!operations.tryLock()) return
        var part: File? = null
        var verified: File? = null
        var completed = false
        var obsolete: File? = null
        val snapshot = state.value
        val release = snapshot.release
        try {
            if (release == null || snapshot.phase !in setOf(UpdatePhase.AVAILABLE, UpdatePhase.ERROR)) return
            obsolete = publish(UpdateState(UpdatePhase.DOWNLOADING, release, progress = 0))
            val apk = withContext(Dispatchers.IO) {
                currentCoroutineContext().ensureActive()
                val directory = File(app.cacheDir, "updates")
                require(directory.isDirectory || directory.mkdirs()) { "Не удалось создать кеш обновления." }
                val temporary = File.createTempFile("update-", ".part", directory)
                part = temporary
                UpdateHttp.download(release, temporary) { percent ->
                    publish(UpdateState(UpdatePhase.DOWNLOADING, release, progress = percent))
                }
                ApkVerifier.verify(app, temporary, release)
                currentCoroutineContext().ensureActive()
                val destination = File(directory, temporary.name.removeSuffix(".part") + ".apk")
                require(!destination.exists() && temporary.renameTo(destination)) {
                    "Не удалось сохранить проверенный APK."
                }
                verified = destination
                destination
            }
            currentCoroutineContext().ensureActive()
            publish(UpdateState(UpdatePhase.READY, release, progress = 100), apk)
            completed = true
        } catch (cancelled: CancellationException) {
            publish(UpdateState(UpdatePhase.AVAILABLE, release, message = "Загрузка отменена."))
            throw cancelled
        } catch (error: Exception) {
            publish(UpdateState(UpdatePhase.ERROR, release, message = errorMessage(error)))
        } finally {
            try {
                // Also handles prompt cancellation on return from withContext(IO), after rename.
                withContext(NonCancellable + Dispatchers.IO) {
                    part?.delete()
                    if (!completed) verified?.delete()
                    obsolete?.delete()
                }
            } finally {
                operations.unlock()
            }
        }
    }

    fun canRequestPackageInstalls(): Boolean = app.packageManager.canRequestPackageInstalls()

    fun permissionIntent(): Intent = Intent(
        Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
        Uri.parse("package:${app.packageName}")
    )

    /** Returns null until verified READY. Does not request permission or launch installation. */
    fun installerIntent(): Intent? = synchronized(stateLock) {
        val snapshot = mutableState.value
        val apk = readyApk ?: return@synchronized null
        val release = snapshot.release ?: return@synchronized null
        if (snapshot.phase != UpdatePhase.READY) return@synchronized null
        if (!apk.isFile || apk.length() != release.size) {
            mutableState.value = UpdateState(
                UpdatePhase.ERROR, release, message = "Файл обновления недоступен. Загрузите APK повторно."
            )
            return@synchronized null
        }
        val uri = FileProvider.getUriForFile(app, "${app.packageName}.updates", apk)
        Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }

    /** Returns the former ready file, for deletion on IO after invalidating the intent getter. */
    private fun publish(next: UpdateState, apk: File? = null): File? = synchronized(stateLock) {
        val previous = readyApk
        readyApk = apk
        mutableState.value = next
        previous.takeIf { it != apk }
    }

    private fun errorMessage(error: Exception): String = when (error) {
        is IllegalArgumentException -> error.message ?: "Обновление отклонено."
        is SecurityException -> "Android запретил доступ к обновлению."
        else -> "Не удалось получить обновление. Проверьте сеть и свободное место."
    }
}
