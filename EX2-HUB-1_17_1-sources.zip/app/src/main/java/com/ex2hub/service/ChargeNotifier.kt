package com.ex2hub.service

import android.Manifest
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.ex2hub.MainActivity
import com.ex2hub.R
import com.ex2hub.data.ChargeAlert

/**
 * События зарядки идут отдельным каналом: постоянная строка сервиса с IMPORTANCE_LOW
 * не позволила бы ни звука, ни баннера, а одно уведомление не должно молча заменять другое.
 */
class ChargeNotifier(context: Context) {
    private val app = context.applicationContext
    private val manager = NotificationManagerCompat.from(app)

    init {
        manager.createNotificationChannel(
            NotificationChannelCompat.Builder(CHANNEL_ID, NotificationManagerCompat.IMPORTANCE_DEFAULT)
                .setName("Зарядка")
                .setDescription("Достижение порога и завершение зарядного сеанса")
                .build()
        )
    }

    fun show(alert: ChargeAlert) {
        if (!manager.areNotificationsEnabled() || !granted()) return
        try {
            manager.notify(alert.kind.notificationId, build(alert))
        } catch (error: SecurityException) {
            // Разрешение отобрали между проверкой и вызовом: событие пропускаем.
        }
    }

    private fun granted(): Boolean = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(
            app,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED

    private fun build(alert: ChargeAlert) =
        NotificationCompat.Builder(app, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_hub)
            .setContentTitle(alert.title)
            .setContentText(alert.text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(alert.text))
            .setAutoCancel(true)
            .setContentIntent(
                PendingIntent.getActivity(
                    app,
                    alert.kind.notificationId,
                    Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
            .build()

    companion object {
        const val CHANNEL_ID = "charge"
    }
}
