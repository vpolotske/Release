package com.ex2hub.service

import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.ex2hub.MainActivity
import com.ex2hub.R
import com.ex2hub.tracker.TripTracker
import com.ex2hub.ui.HubController

class HubService : Service() {
    private lateinit var hub: HubController

    override fun onCreate() {
        super.onCreate()
        hub = HubController.get(this)
        NotificationManagerCompat.from(this).createNotificationChannel(
            NotificationChannelCompat.Builder(CHANNEL_ID, NotificationManagerCompat.IMPORTANCE_LOW)
                .setName("Работа в фоне")
                .setDescription("Журнал поездок и зарядок, возврат режима, GPS-запись")
                .setShowBadge(false)
                .build()
        )
        if (!enterForeground()) return
        hub.attachService { status ->
            if (NotificationManagerCompat.from(this).areNotificationsEnabled()) {
                NotificationManagerCompat.from(this).notify(NOTIFICATION_ID, build(status))
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!hub.needsBackground()) {
            stopSelf()
            return START_NOT_STICKY
        }
        return if (enterForeground()) START_STICKY else START_NOT_STICKY
    }

    override fun onDestroy() {
        hub.detachService()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun enterForeground(): Boolean {
        var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        if (hub.wantsLocation() && TripTracker.hasAnyLocationPermission(this)) {
            type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
        }
        return try {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, build(hub.status()), type)
            true
        } catch (error: SecurityException) {
            hub.serviceFailed()
            stopSelf()
            false
        } catch (error: IllegalStateException) {
            hub.serviceFailed()
            stopSelf()
            false
        }
    }

    private fun build(status: BackgroundStatus) =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_hub)
            .setContentTitle(status.title)
            .setContentText(status.text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(
                PendingIntent.getActivity(
                    this,
                    0,
                    Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
            .build()

    companion object {
        private const val CHANNEL_ID = "background"
        private const val NOTIFICATION_ID = 1

        fun start(context: Context): Boolean = try {
            ContextCompat.startForegroundService(context, Intent(context, HubService::class.java))
            true
        } catch (error: SecurityException) {
            false
        } catch (error: IllegalStateException) {
            false
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, HubService::class.java))
        }
    }
}
