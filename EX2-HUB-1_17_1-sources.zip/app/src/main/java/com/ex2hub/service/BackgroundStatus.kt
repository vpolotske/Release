package com.ex2hub.service

import com.ex2hub.data.ChargeAnchor
import com.ex2hub.data.Fmt
import com.ex2hub.data.SourceMode
import com.ex2hub.data.TripAnchor

data class BackgroundStatus(val title: String, val text: String) {
    companion object {
        fun of(
            source: SourceMode,
            trackingKm: Double?,
            trip: TripAnchor?,
            charge: ChargeAnchor?,
            soc: Int?,
            note: String?
        ): BackgroundStatus {
            val carApi = source == SourceMode.CAR_API
            val title = when {
                trackingKm != null -> "GPS-запись поездки · ${Fmt.km(trackingKm)}"
                carApi && trip != null -> "Поездка идёт · ${Fmt.km(trip.distanceKm)}"
                carApi && charge != null -> "Зарядка идёт" + (soc?.let { " · $it%" } ?: "")
                carApi -> "Car API: журнал ведётся в фоне"
                source == SourceMode.ROOT -> "Root: чтение данных в фоне"
                else -> "EX2 HUB"
            }
            val text = note ?: when (source) {
                SourceMode.CAR_API -> "Поездки, зарядки и выбранный режим — без открытого экрана"
                SourceMode.ROOT -> "Чтение выбранных root-команд — без открытого экрана"
                else -> "Запись идёт, пока не остановлена в приложении"
            }
            return BackgroundStatus(title, text)
        }
    }
}
