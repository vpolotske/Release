package com.ex2hub.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.ex2hub.ui.HubController

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED &&
            intent.action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            return
        }
        HubController.get(context).syncService()
    }
}
