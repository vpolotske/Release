package com.ex2hub.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executor
import java.util.concurrent.Executors

/**
 * Persists the journal and settings as a single JSON document in SharedPreferences.
 * No Room/SQL dependency is needed for a journal of this size.
 */
class Store(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext
        .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /**
     * Журнал меняется редко, а сохранение зовут на каждый сдвиг якоря поездки. Готовый
     * JSON-массив переиспользуется, пока список тот же объект, и не собирается заново
     * из сотен записей. Списки не меняются на месте — только заменяются новыми.
     */
    private class CachedArray(val source: Any, val json: JSONArray)

    @Volatile private var tripsCache: CachedArray? = null
    @Volatile private var sessionsCache: CachedArray? = null
    private val writer = Executors.newSingleThreadExecutor()
    private val writes = CoalescingStoreWriter<PersistedState>(writer) { state ->
        if (state == null) {
            prefs.edit().remove(KEY_STATE).apply()
        } else {
            runCatching {
                prefs.edit().putString(KEY_STATE, toJson(state).toString()).apply()
            }
        }
    }

    fun load(): PersistedState {
        val raw = prefs.getString(KEY_STATE, null) ?: return PersistedState()
        return runCatching { parse(JSONObject(raw)) }.getOrElse {
            // Битый документ нельзя просто заменить пустым состоянием: первое же сохранение
            // стёрло бы журнал насовсем. Исходный текст остаётся в файле рядом.
            keepCorrupt(raw)
            PersistedState()
        }
    }

    private fun keepCorrupt(raw: String) {
        runCatching {
            File(appContext.filesDir, CORRUPT_FILE).writeText(raw, Charsets.UTF_8)
        }
    }

    fun save(state: PersistedState) {
        writes.submit(state)
    }

    fun clear() {
        writes.clear()
    }

    /**
     * Резервная копия журнала тем же документом, что хранится в приложении, но без
     * незакрытых якорей: перенесённый якорь продолжил бы чужую поездку на другой машине.
     */
    fun backupJson(
        state: PersistedState,
        appVersion: String,
        exportedAt: Long = nowMillis()
    ): String {
        val root = toJson(state.copy(tripAnchor = null, chargeAnchor = null))
        root.put("exportedAt", exportedAt)
        root.put("appVersion", appVersion)
        return root.toString()
    }

    /** null — файл битый или не похож на копию журнала: восстанавливать нечего. */
    fun parseBackup(json: String): PersistedState? = runCatching {
        val root = JSONObject(json)
        if (!root.has("trips") && !root.has("sessions")) {
            throw IllegalArgumentException("not a journal backup")
        }
        parse(root)
    }.getOrNull()

    private fun parse(root: JSONObject): PersistedState {
        val profileJson = root.optJSONObject("profile")
        val profile = if (profileJson != null) parseProfile(profileJson) else Profile()

        val trips = mutableListOf<Trip>()
        root.optJSONArray("trips")?.let { array ->
            for (i in 0 until array.length()) {
                array.optJSONObject(i)?.let { parseTrip(it)?.let(trips::add) }
            }
        }

        val sessions = mutableListOf<ChargeSession>()
        root.optJSONArray("sessions")?.let { array ->
            for (i in 0 until array.length()) {
                array.optJSONObject(i)?.let { parseSession(it)?.let(sessions::add) }
            }
        }

        val checks = mutableMapOf<SourceMode, SourceCheck>()
        root.optJSONObject("checks")?.let { objectValue ->
            val keys = objectValue.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val mode = enumOrNull<SourceMode>(key) ?: continue
                val checkJson = objectValue.optJSONObject(key) ?: continue
                checks[mode] = SourceCheck(
                    status = enumOrNull<CheckStatus>(checkJson.optString("status")) ?: CheckStatus.UNKNOWN,
                    summary = checkJson.optString("summary"),
                    checkedAt = checkJson.optLong("checkedAt")
                )
            }
        }

        return PersistedState(
            profile = profile,
            trips = trips,
            sessions = sessions,
            checks = checks,
            demoSeeded = root.optBoolean("demoSeeded", false),
            tripAnchor = root.optJSONObject("tripAnchor")?.let { parseTripAnchor(it) },
            chargeAnchor = root.optJSONObject("chargeAnchor")?.let { parseChargeAnchor(it) }
        )
    }

    /**
     * Якорь незакрытой поездки. Несчитаемые поля (null) пишутся как пропущенные:
     * восстановленный якорь обязан отличаться от «якоря не было», иначе поездка
     * начнётся заново посреди уже идущей.
     */
    private fun parseTripAnchor(json: JSONObject): TripAnchor? {
        val startedAt = json.optLong("startedAt")
        if (startedAt <= 0L) return null
        return TripAnchor(
            startedAt = startedAt,
            startOdometerKm = json.optDoubleOrNull("startOdometerKm"),
            startSoc = json.optIntOrNull("startSoc"),
            lastMovingAt = json.optLong("lastMovingAt").takeIf { it > 0L } ?: startedAt,
            distanceKm = json.finiteDouble("distanceKm", 0.0).coerceAtLeast(0.0),
            endSoc = json.optIntOrNull("endSoc"),
            driveMode = enumOrNull<DriveMode>(json.optString("driveMode")),
            regen = enumOrNull<RegenLevel>(json.optString("regen")),
            pendingEndSince = json.optLong("pendingEndSince").takeIf { it > 0L },
            mixedDriveMode = json.optBoolean("mixedDriveMode", false)
        )
    }

    private fun parseChargeAnchor(json: JSONObject): ChargeAnchor? {
        val startedAt = json.optLong("startedAt")
        if (startedAt <= 0L) return null
        return ChargeAnchor(
            startedAt = startedAt,
            startSoc = json.optIntOrNull("startSoc"),
            type = enumOrNull<ChargeType>(json.optString("type")) ?: ChargeType.UNKNOWN,
            lastChargingAt = json.optLong("lastChargingAt").takeIf { it > 0L } ?: startedAt,
            endSoc = json.optIntOrNull("endSoc"),
            carMinutes = json.optIntOrNull("carMinutes"),
            stoppedSince = json.optLongOrNull("stoppedSince"),
            typeConflicted = json.optBoolean("typeConflicted", false),
            typeClash = json.optInt("typeClash", 0),
            integratedKwh = json.optDoubleOrNull("integratedKwh")?.coerceAtLeast(0.0) ?: 0.0,
            lastPowerKw = json.optDoubleOrNull("lastPowerKw")?.takeIf { it > 0.0 },
            lastPowerAt = json.optLongOrNull("lastPowerAt"),
            lastPowerType = enumOrNull<ChargeType>(json.optString("lastPowerType")),
            lastPowerSource = enumOrNull<ChargePowerSource>(json.optString("lastPowerSource")),
            lastObservedAt = json.optLongOrNull("lastObservedAt"),
            lastSnapshotAt = json.optLongOrNull("lastSnapshotAt")
        )
    }

    private fun parseProfile(json: JSONObject): Profile {
        val defaults = Profile()
        return Profile(
            // EX2 и 39,6 кВт·ч — фиксированные значения по умолчанию. Не возвращать
            // старые поля модели и ёмкости: историческая энергия пересчитана бы была иначе.
            tariffPerKwh = json.optDouble("tariffPerKwh", defaults.tariffPerKwh)
                .takeIf { it.isFinite() && it >= 0 } ?: defaults.tariffPerKwh,
            source = enumOrNull<SourceMode>(json.optString("source")) ?: SourceMode.DEMO,
            manualSoc = json.optIntOrNull("manualSoc"),
            manualRangeKm = json.optIntOrNull("manualRangeKm"),
            manualUpdatedAt = json.optLong("manualUpdatedAt"),
            rootSocCommand = json.optString("rootSocCommand"),
            rootRangeCommand = json.optString("rootRangeCommand"),
            rootPowerCommand = json.optString("rootPowerCommand"),
            rootTempCommand = json.optString("rootTempCommand"),
            rootDriveModeCommand = json.optString("rootDriveModeCommand"),
            rootRegenCommand = json.optString("rootRegenCommand"),
            dockApps = json.optJSONArray("dockApps")?.let { array ->
                (0 until array.length())
                    .mapNotNull { array.optString(it).takeIf(String::isNotBlank) }
                    .distinct()
                    .take(MAX_DOCK_APPS)
            } ?: emptyList(),
            preferredDriveMode = enumOrNull<DriveMode>(json.optString("preferredDriveMode")),
            preferredRegen = enumOrNull<RegenLevel>(json.optString("preferredRegen")),
            restoreDrive = json.optBoolean("restoreDrive", false),
            chargeAlertSoc = json.optInt("chargeAlertSoc", 0).coerceIn(0, 100),
            chargeDoneAlert = json.optBoolean("chargeDoneAlert", true)
        )
    }

    private fun parseTrip(json: JSONObject): Trip? {
        val id = json.optString("id").ifBlank { return null }
        val startedAt = json.optLong("startedAt")
        if (startedAt <= 0L) return null
        return Trip(
            id = id,
            startedAt = startedAt,
            from = json.optString("from", "Старт").ifBlank { "Старт" },
            to = json.optString("to", "Финиш").ifBlank { "Финиш" },
            distanceKm = json.finiteDouble("distanceKm", 0.0).coerceAtLeast(0.0),
            durationMin = json.optInt("durationMin", 1).coerceAtLeast(1),
            energyKwh = json.finiteDouble("energyKwh", 0.0).coerceAtLeast(0.0),
            note = json.optString("note"),
            source = enumOrNull<RecordSource>(json.optString("source")) ?: RecordSource.MANUAL,
            energyEstimated = json.optBoolean("energyEstimated", false),
            driveMode = enumOrNull<DriveMode>(json.optString("driveMode")),
            regen = enumOrNull<RegenLevel>(json.optString("regen")),
            mixedDriveMode = json.optBoolean("mixedDriveMode", false),
            endedAt = json.optLongOrNull("endedAt")?.takeIf { it >= startedAt },
            fromLat = json.optCoordinate("fromLat", 90.0),
            fromLon = json.optCoordinate("fromLon", 180.0),
            toLat = json.optCoordinate("toLat", 90.0),
            toLon = json.optCoordinate("toLon", 180.0)
        )
    }

    /** Пара координат принимается только в своих диапазонах: битая точка ломает маршрут. */
    private fun JSONObject.optCoordinate(key: String, limit: Double): Double? =
        optDoubleOrNull(key)?.takeIf { it.isFinite() && it in -limit..limit }

    private fun parseSession(json: JSONObject): ChargeSession? {
        val id = json.optString("id").ifBlank { return null }
        val startedAt = json.optLong("startedAt")
        if (startedAt <= 0L) return null
        return ChargeSession(
            id = id,
            startedAt = startedAt,
            place = json.optString("place", "Зарядка").ifBlank { "Зарядка" },
            addedPercent = json.optInt("addedPercent", 0).coerceIn(0, 100),
            energyKwh = json.finiteDouble("energyKwh", 0.0).coerceAtLeast(0.0),
            durationMin = json.optInt("durationMin", 1).coerceAtLeast(1),
            type = enumOrNull<ChargeType>(json.optString("type")) ?: ChargeType.UNKNOWN,
            source = enumOrNull<RecordSource>(json.optString("source")) ?: RecordSource.MANUAL,
            energyEstimated = json.optBoolean("energyEstimated", false)
        )
    }

    private fun toJson(state: PersistedState): JSONObject {
        val root = JSONObject()
        root.put("version", 1)
        root.put("demoSeeded", state.demoSeeded)

        val profile = JSONObject()
        with(state.profile) {
            profile.put("model", model)
            profile.put("batteryKwh", batteryKwh)
            profile.put("tariffPerKwh", tariffPerKwh)
            profile.put("source", source.name)
            profile.put("manualSoc", manualSoc ?: JSONObject.NULL)
            profile.put("manualRangeKm", manualRangeKm ?: JSONObject.NULL)
            profile.put("manualUpdatedAt", manualUpdatedAt)
            profile.put("rootSocCommand", rootSocCommand)
            profile.put("rootRangeCommand", rootRangeCommand)
            profile.put("rootPowerCommand", rootPowerCommand)
            profile.put("rootTempCommand", rootTempCommand)
            profile.put("rootDriveModeCommand", rootDriveModeCommand)
            profile.put("rootRegenCommand", rootRegenCommand)
            profile.put("dockApps", JSONArray(dockApps))
            profile.put("preferredDriveMode", preferredDriveMode?.name ?: JSONObject.NULL)
            profile.put("preferredRegen", preferredRegen?.name ?: JSONObject.NULL)
            profile.put("restoreDrive", restoreDrive)
            profile.put("chargeAlertSoc", chargeAlertSoc)
            profile.put("chargeDoneAlert", chargeDoneAlert)
        }
        root.put("profile", profile)

        root.put("trips", tripsJson(state.trips))
        root.put("sessions", sessionsJson(state.sessions))

        val checks = JSONObject()
        state.checks.forEach { (mode, check) ->
            checks.put(mode.name, JSONObject().apply {
                put("status", check.status.name)
                put("summary", check.summary)
                put("checkedAt", check.checkedAt)
            })
        }
        root.put("checks", checks)

        state.tripAnchor?.let { anchor ->
            root.put("tripAnchor", JSONObject().apply {
                put("startedAt", anchor.startedAt)
                put("startOdometerKm", anchor.startOdometerKm ?: JSONObject.NULL)
                put("startSoc", anchor.startSoc ?: JSONObject.NULL)
                put("lastMovingAt", anchor.lastMovingAt)
                put("distanceKm", anchor.distanceKm)
                put("endSoc", anchor.endSoc ?: JSONObject.NULL)
                put("driveMode", anchor.driveMode?.name ?: JSONObject.NULL)
                put("regen", anchor.regen?.name ?: JSONObject.NULL)
                put("pendingEndSince", anchor.pendingEndSince ?: JSONObject.NULL)
                put("mixedDriveMode", anchor.mixedDriveMode)
            })
        }
        state.chargeAnchor?.let { anchor ->
            root.put("chargeAnchor", JSONObject().apply {
                put("startedAt", anchor.startedAt)
                put("startSoc", anchor.startSoc ?: JSONObject.NULL)
                put("type", anchor.type.name)
                put("lastChargingAt", anchor.lastChargingAt)
                put("endSoc", anchor.endSoc ?: JSONObject.NULL)
                put("carMinutes", anchor.carMinutes ?: JSONObject.NULL)
                put("stoppedSince", anchor.stoppedSince ?: JSONObject.NULL)
                put("typeConflicted", anchor.typeConflicted)
                put("typeClash", anchor.typeClash)
                put("integratedKwh", anchor.integratedKwh)
                put("lastPowerKw", anchor.lastPowerKw ?: JSONObject.NULL)
                put("lastPowerAt", anchor.lastPowerAt ?: JSONObject.NULL)
                put("lastPowerType", anchor.lastPowerType?.name ?: JSONObject.NULL)
                put("lastPowerSource", anchor.lastPowerSource?.name ?: JSONObject.NULL)
                put("lastObservedAt", anchor.lastObservedAt ?: JSONObject.NULL)
                put("lastSnapshotAt", anchor.lastSnapshotAt ?: JSONObject.NULL)
            })
        }
        return root
    }

    private fun tripsJson(list: List<Trip>): JSONArray {
        tripsCache?.takeIf { it.source === list }?.let { return it.json }
        val trips = JSONArray()
        list.forEach { trip ->
            trips.put(JSONObject().apply {
                put("id", trip.id)
                put("startedAt", trip.startedAt)
                put("from", trip.from)
                put("to", trip.to)
                put("distanceKm", trip.distanceKm)
                put("durationMin", trip.durationMin)
                put("energyKwh", trip.energyKwh)
                put("note", trip.note)
                put("source", trip.source.name)
                put("energyEstimated", trip.energyEstimated)
                trip.driveMode?.let { put("driveMode", it.name) }
                trip.regen?.let { put("regen", it.name) }
                put("mixedDriveMode", trip.mixedDriveMode)
                trip.endedAt?.let { put("endedAt", it) }
                trip.fromLat?.let { put("fromLat", it) }
                trip.fromLon?.let { put("fromLon", it) }
                trip.toLat?.let { put("toLat", it) }
                trip.toLon?.let { put("toLon", it) }
            })
        }
        tripsCache = CachedArray(list, trips)
        return trips
    }

    private fun sessionsJson(list: List<ChargeSession>): JSONArray {
        sessionsCache?.takeIf { it.source === list }?.let { return it.json }
        val sessions = JSONArray()
        list.forEach { session ->
            sessions.put(JSONObject().apply {
                put("id", session.id)
                put("startedAt", session.startedAt)
                put("place", session.place)
                put("addedPercent", session.addedPercent)
                put("energyKwh", session.energyKwh)
                put("durationMin", session.durationMin)
                put("type", session.type.name)
                put("source", session.source.name)
                put("energyEstimated", session.energyEstimated)
            })
        }
        sessionsCache = CachedArray(list, sessions)
        return sessions
    }

    private fun JSONObject.optIntOrNull(key: String): Int? {
        if (!has(key) || isNull(key)) return null
        return optInt(key)
    }

    private fun JSONObject.optLongOrNull(key: String): Long? {
        if (!has(key) || isNull(key)) return null
        return optLong(key, -1L).takeIf { it >= 0L }
    }

    /** optDouble пропускает NaN и бесконечность из «битого» файла копии: дальше они ломают суммы. */
    private fun JSONObject.finiteDouble(key: String, default: Double): Double =
        optDouble(key, default).takeIf { it.isFinite() } ?: default

    private fun JSONObject.optDoubleOrNull(key: String): Double? {
        if (!has(key) || isNull(key)) return null
        return optDouble(key).takeIf { it.isFinite() }
    }

    private inline fun <reified T : Enum<T>> enumOrNull(value: String?): T? {
        if (value.isNullOrBlank()) return null
        return enumValues<T>().firstOrNull { it.name == value }
    }

    companion object {
        const val MAX_DOCK_APPS = 10
        private const val PREFS_NAME = "ex2hub_state"
        private const val KEY_STATE = "state_json"
        private const val CORRUPT_FILE = "state_json.corrupt"
    }
}

// Clear remains a barrier before later snapshots; superseded saves retain no queue slot.
internal class CoalescingStoreWriter<T : Any>(
    private val executor: Executor,
    private val consume: (T?) -> Unit
) {
    private val lock = Any()
    private var pending: T? = null
    private var clearPending = false
    private var scheduled = false

    fun submit(snapshot: T) {
        synchronized(lock) {
            pending = snapshot
            scheduleLocked()
        }
    }

    fun clear() {
        synchronized(lock) {
            pending = null
            clearPending = true
            scheduleLocked()
        }
    }

    private fun scheduleLocked() {
        if (scheduled) return
        scheduled = true
        try {
            executor.execute(::drain)
        } catch (failure: Throwable) {
            scheduled = false
            throw failure
        }
    }

    private fun drain() {
        try {
            while (true) {
                val next = synchronized(lock) {
                    if (clearPending) {
                        clearPending = false
                        null
                    } else {
                        val snapshot = pending
                        if (snapshot == null) {
                            // Submission and the idle handoff use the same lock: no lost wakeup.
                            scheduled = false
                            return
                        }
                        pending = null
                        snapshot
                    }
                }
                consume(next)
            }
        } catch (failure: Throwable) {
            synchronized(lock) {
                scheduled = false
                if (clearPending || pending != null) {
                    try {
                        scheduleLocked()
                    } catch (schedulingFailure: Throwable) {
                        if (schedulingFailure !== failure) failure.addSuppressed(schedulingFailure)
                    }
                }
            }
            throw failure
        }
    }
}
