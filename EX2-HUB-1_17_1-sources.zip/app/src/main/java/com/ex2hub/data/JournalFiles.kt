package com.ex2hub.data

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.nio.charset.StandardCharsets

/**
 * Файлы выгрузки лежат в каталоге приложения на общем накопителе: их видит штатный
 * проводник и USB-копирование, и на это не нужно разрешение на запись. Путь показывает
 * экран настроек — тот же каталог читаёт восстановление.
 */
class JournalFiles(context: Context) {
    private val dir: File = context.getExternalFilesDir(null) ?: context.filesDir

    val path: String = dir.absolutePath

    fun export(tripsCsv: String, chargesCsv: String, backupJson: String) {
        dir.mkdirs()
        writeCsv(TRIPS_FILE, tripsCsv)
        writeCsv(CHARGES_FILE, chargesCsv)
        writeAtomically(BACKUP_FILE) { stream ->
            stream.write(backupJson.toByteArray(StandardCharsets.UTF_8))
        }
    }

    /**
     * Текст копии или null, если файла ещё нет. Файл лежит на общем накопителе, и подсунуть
     * туда можно что угодно: слишком большой отклоняется, пока не прочитан в память.
     */
    fun backupText(): String? {
        val file = File(dir, BACKUP_FILE).takeIf { it.isFile } ?: return null
        require(file.length() <= MAX_BACKUP_BYTES) {
            "файл ${BACKUP_FILE} больше ${MAX_BACKUP_BYTES / (1024 * 1024)} МБ — это не копия журнала"
        }
        return file.readText(Charsets.UTF_8)
    }

    private fun writeCsv(name: String, text: String) {
        writeAtomically(name) { stream ->
            stream.write(UTF8_BOM)
            stream.write(text.toByteArray(StandardCharsets.UTF_8))
        }
    }

    /**
     * Сначала временный файл, потом переименование: оборванная запись (выключили ГУ,
     * кончилось место) не затирает прежнюю копию, из которой можно восстановиться.
     */
    private fun writeAtomically(name: String, write: (FileOutputStream) -> Unit) {
        val target = File(dir, name)
        val temporary = File(dir, "$name.tmp")
        try {
            FileOutputStream(temporary).use { stream ->
                write(stream)
                stream.fd.sync()
            }
            if (!temporary.renameTo(target)) {
                // На части файловых систем rename не заменяет существующий файл.
                target.delete()
                check(temporary.renameTo(target)) { "не удалось сохранить $name" }
            }
        } finally {
            if (temporary.exists()) temporary.delete()
        }
    }

    companion object {
        const val TRIPS_FILE = "EX2-trips.csv"
        const val CHARGES_FILE = "EX2-charges.csv"
        const val BACKUP_FILE = "EX2-backup.json"

        /** Журнал на сотни тысяч записей — это десятки мегабайт; всё выше не копия. */
        private const val MAX_BACKUP_BYTES = 64L * 1024 * 1024
        private val UTF8_BOM = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte())
    }
}
