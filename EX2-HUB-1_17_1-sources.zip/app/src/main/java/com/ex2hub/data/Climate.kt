package com.ex2hub.data

import androidx.compose.runtime.Immutable

/**
 * Состояние климата и обогревов так, как его ответил автомобиль.
 *
 * Null-поле означает «сигнал не пришёл», и тогда соответствующая кнопка панели
 * неактивна: включение вслепую выглядело бы как управление, которым приложение
 * не владеет. Исключение одно — электрический обогрев лобового: 0x10200C00 на
 * этом ГУ не отвечает на чтение, поэтому его кнопка нажимается, null считается
 * выключенным, а значение после записи панель помнит сама.
 */
@Immutable
data class Climate(
    val hvacOn: Boolean? = null,
    val acOn: Boolean? = null,
    val recircOn: Boolean? = null,
    val frontDefrostOn: Boolean? = null,
    /** Электрический обогрев лобового стекла 0x10200C00, не режим максимального обдува. */
    val windshieldHeatOn: Boolean? = null,
    val rearDefrostOn: Boolean? = null,
    val fanSpeed: Int? = null,
    val driverTempC: Double? = null,
    val seatHeatDriver: Int? = null,
    val seatHeatPassenger: Int? = null,
    val wheelHeat: Int? = null,
    /** Маска направления обдува: 1 лицо, 2 ноги, 3 лицо+ноги, 4 стекло, 6 стекло+ноги. */
    val fanDirection: Int? = null
) {
    val isEmpty: Boolean
        get() = readableSignals == 0

    /** Сколько сигналов климата панель вообще различает. */
    val totalSignals: Int
        get() = SIGNAL_COUNT

    /**
     * Сколько сигналов климата автомобиль действительно ответил. Считается полями,
     * без промежуточного списка: метод зовётся на каждом опросе рабочего стола.
     */
    val readableSignals: Int
        get() {
            var count = 0
            if (hvacOn != null) count++
            if (acOn != null) count++
            if (recircOn != null) count++
            if (frontDefrostOn != null) count++
            if (windshieldHeatOn != null) count++
            if (rearDefrostOn != null) count++
            if (fanSpeed != null) count++
            if (driverTempC != null) count++
            if (seatHeatDriver != null) count++
            if (seatHeatPassenger != null) count++
            if (wheelHeat != null) count++
            if (fanDirection != null) count++
            return count
        }

    /** Есть ли чем управлять: хотя бы один сигнал прочитан. */
    val controllable: Boolean
        get() = readableSignals > 0

    fun withSignalObservation(change: ClimateChange, observed: Climate?): Climate = when (change) {
        ClimateChange.POWER -> copy(hvacOn = observed?.hvacOn)
        ClimateChange.AC -> copy(acOn = observed?.acOn)
        ClimateChange.RECIRC -> copy(recircOn = observed?.recircOn)
        ClimateChange.FRONT_DEFROST -> copy(frontDefrostOn = observed?.frontDefrostOn)
        ClimateChange.WINDSHIELD_HEAT -> copy(windshieldHeatOn = observed?.windshieldHeatOn)
        ClimateChange.REAR_DEFROST -> copy(rearDefrostOn = observed?.rearDefrostOn)
        ClimateChange.FAN_UP, ClimateChange.FAN_DOWN -> copy(fanSpeed = observed?.fanSpeed)
        ClimateChange.DRIVER_UP, ClimateChange.DRIVER_DOWN -> copy(driverTempC = observed?.driverTempC)
        ClimateChange.SEAT_DRIVER -> copy(seatHeatDriver = observed?.seatHeatDriver)
        ClimateChange.SEAT_PASSENGER -> copy(seatHeatPassenger = observed?.seatHeatPassenger)
        ClimateChange.WHEEL_HEAT -> copy(wheelHeat = observed?.wheelHeat)
        ClimateChange.DIRECTION_FACE, ClimateChange.DIRECTION_FEET,
        ClimateChange.DIRECTION_GLASS, ClimateChange.DIRECTION_GLASS_FEET -> copy(fanDirection = observed?.fanDirection)
    }

    fun confirms(target: Climate): Boolean =
        agrees(hvacOn, target.hvacOn) &&
            agrees(acOn, target.acOn) &&
            agrees(recircOn, target.recircOn) &&
            agrees(frontDefrostOn, target.frontDefrostOn) &&
            agrees(windshieldHeatOn, target.windshieldHeatOn) &&
            agrees(rearDefrostOn, target.rearDefrostOn) &&
            agrees(fanSpeed, target.fanSpeed) &&
            agrees(driverTempC, target.driverTempC) &&
            agrees(seatHeatDriver, target.seatHeatDriver) &&
            agrees(seatHeatPassenger, target.seatHeatPassenger) &&
            agrees(wheelHeat, target.wheelHeat) &&
            agrees(fanDirection, target.fanDirection)

    /** Сигнал, которого не было в запросе, сверять не с чем; уставка — с допуском. */
    private fun agrees(actual: Boolean?, want: Boolean?): Boolean = want == null || actual == want

    private fun agrees(actual: Int?, want: Int?): Boolean = want == null || actual == want

    private fun agrees(actual: Double?, want: Double?): Boolean =
        want == null || (actual != null && kotlin.math.abs(actual - want) <= 0.25)

    private companion object {
        const val SIGNAL_COUNT = 12
    }
}

/** Команда климат-панели: переключить флаг, шагнуть уставку или ступень нагрева. */
enum class ClimateChange {
    POWER,
    AC,
    RECIRC,
    FRONT_DEFROST,
    WINDSHIELD_HEAT,
    REAR_DEFROST,
    FAN_UP,
    FAN_DOWN,
    DRIVER_UP,
    DRIVER_DOWN,
    SEAT_DRIVER,
    SEAT_PASSENGER,
    WHEEL_HEAT,
    DIRECTION_FACE,
    DIRECTION_FEET,
    DIRECTION_GLASS,
    DIRECTION_GLASS_FEET
}

/** Готовые сценарии: несколько записей подряд одной кнопкой. */
enum class ClimatePreset {
    QUICK_COOL,
    QUICK_HEAT
}

/**
 * Итог попытки записи. [applied] — состояние, которое приложение запросило;
 * подтверждением считается следующее чтение автомобиля, а не этот результат.
 */
@Immutable
data class ClimateWriteResult(
    val status: CheckStatus,
    val summary: String,
    val applied: Climate? = null,
    val observed: Climate? = null,
    val confirmed: Boolean = false
)
