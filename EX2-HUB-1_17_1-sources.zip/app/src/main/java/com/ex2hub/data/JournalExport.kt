package com.ex2hub.data

import java.time.ZoneId

/**
 * Выгрузка журнала в CSV. Разделитель — точка с запятой, десятичный знак — запятая:
 * файл открывается в русской локали Excel без ручных настроек, цифры в нём такие же,
 * как на экране. UTF-8 с BOM пишет тот, кто сохраняет файл.
 */
object JournalExport {
    const val LINE_END = "\r\n"

    private val tripHeader = listOf(
        "Ид", "Дата", "Время", "Откуда", "Куда", "Км", "Мин", "КВт·ч", "КВт·ч/100",
        "Стоимость, р.", "Режим", "Рекуперация", "Режим менялся", "Оценка", "Источник",
        "Заметка", "Старт, широта", "Старт, долгота", "Финиш, широта", "Финиш, долгота"
    )

    private val chargeHeader = listOf(
        "Ид", "Дата", "Время", "Место", "Тип", "Прирост, %", "КВт·ч", "Мин",
        "Ср. мощность, кВт", "Стоимость, р.", "Оценка", "Источник"
    )

    fun tripsCsv(
        trips: List<Trip>,
        tariffPerKwh: Double,
        zone: ZoneId = ZoneId.systemDefault()
    ): String {
        val rows = trips.sortedBy { it.startedAt }.map { trip ->
            listOf(
                trip.id,
                Fmt.dateInput(Stats.dateOf(trip.startedAt, zone)),
                Fmt.time(trip.startedAt),
                trip.from,
                trip.to,
                Fmt.n1(trip.distanceKm),
                trip.durationMin.toString(),
                Fmt.n1(trip.energyKwh),
                Fmt.n1(trip.consumption),
                Fmt.n2(trip.energyKwh * tariffPerKwh),
                trip.driveMode?.name.orEmpty(),
                trip.regen?.name.orEmpty(),
                if (trip.mixedDriveMode) "да" else "",
                if (trip.energyEstimated) "да" else "",
                trip.source.name,
                trip.note,
                Fmt.coord(trip.fromLat),
                Fmt.coord(trip.fromLon),
                Fmt.coord(trip.toLat),
                Fmt.coord(trip.toLon)
            )
        }
        return table(tripHeader, rows)
    }

    fun chargesCsv(
        sessions: List<ChargeSession>,
        tariffPerKwh: Double,
        zone: ZoneId = ZoneId.systemDefault()
    ): String {
        val rows = sessions.sortedBy { it.startedAt }.map { session ->
            listOf(
                session.id,
                Fmt.dateInput(Stats.dateOf(session.startedAt, zone)),
                Fmt.time(session.startedAt),
                session.place,
                session.type.name,
                session.addedPercent.toString(),
                Fmt.n1(session.energyKwh),
                session.durationMin.toString(),
                Fmt.n1(session.averagePowerKw),
                Fmt.n2(session.energyKwh * tariffPerKwh),
                if (session.energyEstimated) "да" else "",
                session.source.name
            )
        }
        return table(chargeHeader, rows)
    }

    fun table(header: List<String>, rows: List<List<String>>): String =
        (listOf(header) + rows).joinToString(separator = LINE_END, postfix = LINE_END) { cells ->
            cells.joinToString(separator = ";") { cell(it) }
        }

    /** Кавычка удваивается, поле с разделителем или переносом строки закрывается в кавычки. */
    fun cell(value: String): String =
        if (value.any { it == ';' || it == '"' || it == '\n' || it == '\r' }) {
            "\"" + value.replace("\"", "\"\"") + "\""
        } else {
            value
        }
}
