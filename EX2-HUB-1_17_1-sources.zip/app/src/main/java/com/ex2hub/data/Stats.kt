package com.ex2hub.data

import androidx.compose.runtime.Immutable
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import kotlin.math.roundToInt

@Immutable
data class DayStat(
    val date: LocalDate,
    val distanceKm: Double,
    val energyKwh: Double,
    val minutes: Int,
    val trips: Int
) {
    val consumption: Double?
        get() = if (distanceKm > 0.05) energyKwh / distanceKm * 100.0 else null
}

@Immutable
data class WeekStats(
    val days: List<DayStat>,
    val distanceKm: Double,
    val energyKwh: Double,
    val minutes: Int,
    val trips: Int,
    val consumption: Double?,
    val cost: Double
) {
    val bestEfficiencyDay: DayStat?
        get() = days.filter { (it.consumption ?: 0.0) > 0.0 }
            .minByOrNull { it.consumption ?: Double.MAX_VALUE }

    /** Деньги на сто километров — то, с чем сравнивают зарядку и бензин. */
    val costPer100Km: Double?
        get() = cost.per100(distanceKm)
}

/** Календарный месяц поездок: то же правило отбора, что у заряда в [ChargeSummary]. */
@Immutable
data class MonthStats(
    val month: YearMonth,
    val distanceKm: Double,
    val energyKwh: Double,
    val minutes: Int,
    val trips: Int,
    val days: Int,
    val consumption: Double?,
    val cost: Double
) {
    val costPer100Km: Double?
        get() = cost.per100(distanceKm)
}

private fun Double.per100(distanceKm: Double): Double? =
    if (distanceKm > 0.05) this / distanceKm * 100.0 else null

@Immutable
data class ModeStat(
    val mode: DriveMode,
    val trips: Int,
    val distanceKm: Double,
    val energyKwh: Double
) {
    val consumption: Double?
        get() = if (distanceKm > 0.05) energyKwh / distanceKm * 100.0 else null
}

@Immutable
data class ChargeSummary(
    val month: YearMonth,
    val sessions: List<ChargeSession>,
    val kwh: Double,
    val cost: Double,
    val count: Int,
    val minutes: Int,
    val acKwh: Double,
    val dcKwh: Double,
    val averagePowerKw: Double,
    val unknownKwh: Double = 0.0
)

@Immutable
data class ChargeDayStat(
    val date: LocalDate,
    val kwh: Double,
    val minutes: Int,
    val sessions: Int
)

@Immutable
data class ChargeWeekStats(
    val days: List<ChargeDayStat>,
    val kwh: Double,
    val minutes: Int,
    val sessions: Int,
    val cost: Double,
    val acKwh: Double,
    val dcKwh: Double
) {
    val averagePowerKw: Double
        get() = if (minutes > 0) kwh / (minutes / 60.0) else 0.0
}

object Stats {
    private const val FALLBACK_CONSUMPTION = 13.5

    fun todayTrips(
        trips: List<Trip>,
        nowMillis: Long = System.currentTimeMillis(),
        zone: ZoneId = ZoneId.systemDefault()
    ): List<Trip> {
        val today = Instant.ofEpochMilli(nowMillis).atZone(zone).toLocalDate()
        return trips
            .filter { dateOf(it.startedAt, zone) == today }
            .sortedBy { it.startedAt }
    }

    /** Окно из [days] дней, кончающееся сегодня; [weeksBack] сдвигает его назад на целые окна. */
    fun weekStats(
        trips: List<Trip>,
        nowMillis: Long = System.currentTimeMillis(),
        zone: ZoneId = ZoneId.systemDefault(),
        days: Int = 7,
        tariffPerKwh: Double = 0.28,
        weeksBack: Int = 0
    ): WeekStats {
        val safeDays = days.coerceAtLeast(1)
        val end = Instant.ofEpochMilli(nowMillis).atZone(zone).toLocalDate()
            .minusDays(safeDays.toLong() * weeksBack.coerceAtLeast(0))
        val start = end.minusDays((safeDays - 1).toLong())
        val filtered = trips.filter {
            val date = dateOf(it.startedAt, zone)
            !date.isBefore(start) && !date.isAfter(end)
        }
        val byDay = filtered.groupBy { dateOf(it.startedAt, zone) }
        val dayStats = (0 until safeDays).map { index ->
            val date = start.plusDays(index.toLong())
            val items = byDay[date].orEmpty()
            DayStat(
                date = date,
                distanceKm = items.sumOf { it.distanceKm },
                energyKwh = items.sumOf { it.energyKwh },
                minutes = items.sumOf { it.durationMin },
                trips = items.size
            )
        }
        val distance = filtered.sumOf { it.distanceKm }
        val energy = filtered.sumOf { it.energyKwh }
        return WeekStats(
            days = dayStats,
            distanceKm = distance,
            energyKwh = energy,
            minutes = filtered.sumOf { it.durationMin },
            trips = filtered.size,
            consumption = if (distance > 0.05) energy / distance * 100.0 else null,
            cost = energy * tariffPerKwh
        )
    }

    /** Календарный месяц поездок, кончающийся сегодня; окно [weekStats] остаётся отдельным. */
    fun monthStats(
        trips: List<Trip>,
        nowMillis: Long = System.currentTimeMillis(),
        zone: ZoneId = ZoneId.systemDefault(),
        tariffPerKwh: Double = 0.28
    ): MonthStats {
        val month = YearMonth.from(Instant.ofEpochMilli(nowMillis).atZone(zone).toLocalDate())
        val inMonth = trips.filter { YearMonth.from(dateOf(it.startedAt, zone)) == month }
        val distance = inMonth.sumOf { it.distanceKm }
        val energy = inMonth.sumOf { it.energyKwh }
        return MonthStats(
            month = month,
            distanceKm = distance,
            energyKwh = energy,
            minutes = inMonth.sumOf { it.durationMin },
            trips = inMonth.size,
            days = inMonth.map { dateOf(it.startedAt, zone) }.distinct().size,
            consumption = if (distance > 0.05) energy / distance * 100.0 else null,
            cost = energy * tariffPerKwh
        )
    }

    fun chargeSummary(
        sessions: List<ChargeSession>,
        nowMillis: Long = System.currentTimeMillis(),
        zone: ZoneId = ZoneId.systemDefault(),
        tariffPerKwh: Double = 0.28
    ): ChargeSummary {
        val month = YearMonth.from(Instant.ofEpochMilli(nowMillis).atZone(zone).toLocalDate())
        val inMonth = sessions
            .filter { YearMonth.from(dateOf(it.startedAt, zone)) == month }
            .sortedByDescending { it.startedAt }
        val kwh = inMonth.sumOf { it.energyKwh }
        val minutes = inMonth.sumOf { it.durationMin }
        return ChargeSummary(
            month = month,
            sessions = inMonth,
            kwh = kwh,
            cost = kwh * tariffPerKwh,
            count = inMonth.size,
            minutes = minutes,
            acKwh = inMonth.filter { it.type == ChargeType.AC }.sumOf { it.energyKwh },
            dcKwh = inMonth.filter { it.type == ChargeType.DC }.sumOf { it.energyKwh },
            unknownKwh = inMonth.filter { it.type == ChargeType.UNKNOWN }.sumOf { it.energyKwh },
            averagePowerKw = if (minutes > 0) kwh / (minutes / 60.0) else 0.0
        )
    }

    /** Окно зарядок из [days] дней по тому же правилу, что и [weekStats] для поездок. */
    fun chargeWeekStats(
        sessions: List<ChargeSession>,
        nowMillis: Long = System.currentTimeMillis(),
        zone: ZoneId = ZoneId.systemDefault(),
        days: Int = 7,
        tariffPerKwh: Double = 0.28,
        weeksBack: Int = 0
    ): ChargeWeekStats {
        val safeDays = days.coerceAtLeast(1)
        val end = Instant.ofEpochMilli(nowMillis).atZone(zone).toLocalDate()
            .minusDays(safeDays.toLong() * weeksBack.coerceAtLeast(0))
        val start = end.minusDays((safeDays - 1).toLong())
        val filtered = sessions.filter {
            val date = dateOf(it.startedAt, zone)
            !date.isBefore(start) && !date.isAfter(end)
        }
        val byDay = filtered.groupBy { dateOf(it.startedAt, zone) }
        val dayStats = (0 until safeDays).map { index ->
            val date = start.plusDays(index.toLong())
            val items = byDay[date].orEmpty()
            ChargeDayStat(
                date = date,
                kwh = items.sumOf { it.energyKwh },
                minutes = items.sumOf { it.durationMin },
                sessions = items.size
            )
        }
        val kwh = filtered.sumOf { it.energyKwh }
        return ChargeWeekStats(
            days = dayStats,
            kwh = kwh,
            minutes = filtered.sumOf { it.durationMin },
            sessions = filtered.size,
            cost = kwh * tariffPerKwh,
            acKwh = filtered.filter { it.type == ChargeType.AC }.sumOf { it.energyKwh },
            dcKwh = filtered.filter { it.type == ChargeType.DC }.sumOf { it.energyKwh }
        )
    }

    /**
     * Only single-mode trips can be attributed to a mode. Legacy records retain
     * their attribution: without historical mode samples it cannot be repaired.
     */
    fun byDriveMode(trips: List<Trip>): List<ModeStat> =
        trips.filterNot { it.mixedDriveMode }
            .mapNotNull { trip -> trip.driveMode?.let { it to trip } }
            .groupBy({ it.first }, { it.second })
            .map { (mode, items) ->
                ModeStat(
                    mode = mode,
                    trips = items.size,
                    distanceKm = items.sumOf { it.distanceKm },
                    energyKwh = items.sumOf { it.energyKwh }
                )
            }
            .sortedByDescending { it.distanceKm }

    fun averageConsumption(trips: List<Trip>): Double? {
        if (trips.isEmpty()) return null
        val km = trips.sumOf { it.distanceKm }
        val kwh = trips.sumOf { it.energyKwh }
        return if (km > 0.05) kwh / km * 100.0 else null
    }

    fun estimateEnergy(distanceKm: Double, trips: List<Trip>): Double {
        val rate = averageConsumption(trips) ?: FALLBACK_CONSUMPTION
        return distanceKm * rate / 100.0
    }

    fun potentialRangeKm(energyKwh: Double, trips: List<Trip>): Double? {
        val rate = averageConsumption(trips) ?: return null
        if (rate <= 0.01) return null
        return energyKwh / rate * 100.0
    }

    fun sessionsCost(sessions: List<ChargeSession>, tariffPerKwh: Double): Double =
        sessions.sumOf { it.energyKwh } * tariffPerKwh

    fun monthOf(epochMillis: Long, zone: ZoneId = ZoneId.systemDefault()): YearMonth =
        YearMonth.from(dateOf(epochMillis, zone))

    fun dateOf(epochMillis: Long, zone: ZoneId = ZoneId.systemDefault()): LocalDate =
        Instant.ofEpochMilli(epochMillis).atZone(zone).toLocalDate()

    fun roundedSoc(batteryWh: Double?, capacityWh: Double?): Int? {
        if (batteryWh == null) return null
        if (capacityWh != null && capacityWh > 1000.0) {
            return (batteryWh / capacityWh * 100.0).roundToInt().coerceIn(0, 100)
        }
        return batteryWh.roundToInt().coerceIn(0, 100)
    }
}
