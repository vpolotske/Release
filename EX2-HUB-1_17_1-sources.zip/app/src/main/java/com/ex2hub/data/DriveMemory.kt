package com.ex2hub.data

/**
 * Что приложение помнит о текущем включении автомобиля: была ли уже передача D или R
 * (без неё прошивка не включает обогрев руля) и вернули ли выбранные режим движения
 * и рекуперацию.
 *
 * Возврат делается один раз за цикл зажигания. Журнал 2026-10-28 показал, почему
 * повторять его нельзя: стоя на P, прошивка принимает запись режима, но через
 * несколько секунд снова отдаёт «Комфорт», и прежняя логика с паузой в 15 с писала
 * режим заново десятки раз — на экране это выглядело как мигание кнопок. Один
 * запрос за включение эту петлю убирает; ручной выбор владельца отменяет возврат
 * до следующего включения.
 */
class DriveMemory {
    var seenDriveGear = false
        private set

    private var restoreIssued = false

    data class Plan(val mode: DriveMode?, val regen: RegenLevel?) {
        fun matches(observedMode: DriveMode?, observedRegen: RegenLevel?): Boolean =
            (mode != null || regen != null) &&
                (mode == null || observedMode == mode) &&
                (regen == null || observedRegen == regen)

        fun remember(profile: Profile): Profile = profile.copy(
            preferredDriveMode = mode ?: profile.preferredDriveMode,
            preferredRegen = regen ?: profile.preferredRegen
        )
    }

    fun observe(snapshot: VehicleSnapshot, profile: Profile, now: Long): Plan? {
        if (snapshot.ignition in OFF_STATES) {
            reset()
            return null
        }
        if (snapshot.gear == Gear.D || snapshot.gear == Gear.R) seenDriveGear = true
        if (!profile.restoreDrive || snapshot.gear != Gear.P || restoreIssued) return null

        val wantMode = profile.preferredDriveMode
        val wantRegen = profile.preferredRegen
        // null — «автомобиль не назвал значение»: перезаписывать вслепую нельзя.
        val mode = wantMode?.takeIf { snapshot.driveMode != null && snapshot.driveMode != it }
        val regen = wantRegen?.takeIf { snapshot.regen != null && snapshot.regen != it }
        if (mode == null && regen == null) return null
        restoreIssued = true
        return Plan(mode, regen)
    }

    /** Ручной выбор владельца: возврат в этом включении больше не выполняется. */
    fun settle() {
        restoreIssued = true
    }

    fun reset() {
        seenDriveGear = false
        restoreIssued = false
    }

    companion object {
        private val OFF_STATES = setOf(IgnitionState.LOCK, IgnitionState.OFF, IgnitionState.ACC)
    }
}
