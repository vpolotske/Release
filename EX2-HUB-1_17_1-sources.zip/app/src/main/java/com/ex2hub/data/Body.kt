package com.ex2hub.data

import androidx.compose.runtime.Immutable

/** Проёмы кузова. На экране используется только [HOOD]; остальные — в диагностике. */
enum class BodyPart { DOOR_FL, DOOR_FR, DOOR_RL, DOOR_RR, HOOD, TAILGATE }

/**
 * Кузов так, как его ответил автомобиль. Приложение здесь только читает: ни одна
 * кнопка не пишет в двери, замки, стёкла или свет.
 *
 * Обычный опрос заполняет только [open] для капота — по нему кнопка переднего
 * багажника показывает открытое состояние. Двери, замки, стёкла и свет приходят
 * лишь в диагностической пробе и на экране не выводятся.
 */
@Immutable
data class Body(
    val open: Map<BodyPart, Boolean> = emptyMap(),
    /** Замок двери: true — заперта. */
    val locked: Map<BodyPart, Boolean> = emptyMap(),
    /** Открытие стекла, 0 — закрыто, 100 — опущено полностью. */
    val windowPercent: Map<BodyPart, Int> = emptyMap(),
    val headlightsOn: Boolean? = null
) {
    fun isOpen(part: BodyPart): Boolean? = open[part]

    /** Открытые части в порядке [BodyPart]; первая выбирает кадр автомобиля. */
    val openParts: List<BodyPart>
        get() = BodyPart.values().filter { open[it] == true }

    /** Заперт, только когда ответили все четыре двери и все заперты. */
    val allLocked: Boolean?
        get() {
            val doors = DOORS.mapNotNull { locked[it] }
            if (doors.size < DOORS.size) return if (doors.any { !it }) false else null
            return doors.all { it }
        }

    val readableSignals: Int
        get() = open.size + locked.size + windowPercent.size + (if (headlightsOn != null) 1 else 0)

    companion object {
        val DOORS = listOf(BodyPart.DOOR_FL, BodyPart.DOOR_FR, BodyPart.DOOR_RL, BodyPart.DOOR_RR)
    }
}
