package com.ex2hub.data

/**
 * Растёт ли заряд на самом деле. Процент приходит раз в несколько минут, поэтому
 * прирост держится [HOLD_MS]: между чтениями пульсация не должна гаснуть.
 * Флаг visibility только скрывает событие — состояние накопления не сбрасывается,
 * и возвращение на экран во время роста показывается сразу.
 */
class SocRising(private val holdMillis: Long = HOLD_MS) {
    private var raisedAt = 0L
    private var last: Int? = null

    fun update(soc: Int?, charging: Boolean, visible: Boolean, now: Long): Boolean {
        val previous = last
        last = soc
        if (!charging) {
            raisedAt = 0L
            return false
        }
        if (previous != null && soc != null && soc > previous) raisedAt = now
        if (!visible) return false
        return raisedAt != 0L && now - raisedAt <= holdMillis
    }

    companion object {
        const val HOLD_MS = 180_000L
    }
}
