package com.ex2hub.data

import androidx.compose.runtime.Immutable
import java.util.UUID
import kotlin.math.roundToInt

/**
 * Якорь незавершённой поездки: всё, что приложение уже знает о ней, пока она идёт.
 * Нужен не только автомату — он переживает перезапуск приложения через [Store], чтобы
 * поездка, начатая до перезапуска, не превратилась в две записи.
 */
@Immutable
data class TripAnchor(
    val startedAt: Long,
    val startOdometerKm: Double?,
    val startSoc: Int?,
    val lastMovingAt: Long,
    val distanceKm: Double = 0.0,
    val endSoc: Int? = null,
    val driveMode: DriveMode? = null,
    val regen: RegenLevel? = null,
    val pendingEndSince: Long? = null,
    val mixedDriveMode: Boolean = false
)

/** Якорь незавершённой сессии заряда. */
@Immutable
data class ChargeAnchor(
    val startedAt: Long,
    val startSoc: Int?,
    val type: ChargeType,
    val lastChargingAt: Long,
    val endSoc: Int? = null,
    val carMinutes: Int? = null,
    val stoppedSince: Long? = null,
    val typeConflicted: Boolean = false,
    /** Подряд идущие чтения, в которых поток и разъём спорят: одно — шум, два — конфликт. */
    val typeClash: Int = 0,
    val integratedKwh: Double = 0.0,
    val lastPowerKw: Double? = null,
    val lastPowerAt: Long? = null,
    val lastPowerType: ChargeType? = null,
    val lastPowerSource: ChargePowerSource? = null,
    /** Оба счётчика сохраняются, чтобы после перезапуска воспроизведённый снимок не сложил энергию дважды. */
    val lastObservedAt: Long? = null,
    val lastSnapshotAt: Long? = null
)

/** Что автомат дописал в журнал после очередного ответа автомобиля. */
@Immutable
data class JournalUpdate(
    val trips: List<Trip> = emptyList(),
    val sessions: List<ChargeSession> = emptyList(),
    val notes: List<String> = emptyList()
)

/**
 * Поездки и зарядки, которые приложение выводит из ответов автомобиля само.
 *
 * Бортовой компьютер поездки (`TRIP_FUNC_*`) недоступен: в разборе свойств EX2 у него
 * только имена и id сброса 0x24800200, числовых id функций нет, а суточные, месячные
 * и годовые суммы Geely считает в облаке OneOSS за PKI eCarX — из обычного APK их не
 * получить. Адрес 0x2740A679, который Drive Assist описывает как счётчик поездки, на
 * нашем ГУ отвечает 5461,9 км при одометре 5528,1 (журнал 2026-10-28) и в расчёт не
 * входит. Поэтому расстояние поездки — только разница одометра, а журнал растёт из
 * сигналов состояния конечным автоматом, как это делает Capy Energy (Apache-2.0):
 * `telemetry/TripSessionDetector.kt` и `telemetry/ChargeSessionDetector.kt`. Пороги
 * взяты оттуда же, и у каждого в коде стоит источник; там, где правило наше, это
 * написано прямо в комментарии.
 *
 * Автомат записывает только то, что автомобиль назвал сам: пробег, заряд, передачу,
 * состояние зарядки. Нет сигнала — нет записи, а не достроенная догадка. Журнал
 * работает на источнике Car API: root-команды дают числа заряда и запаса хода, но не
 * пробег и не состояние зарядки, а без них поездку и сессию не определить.
 */
class CarJournal(
    restoredTrip: TripAnchor? = null,
    restoredCharge: ChargeAnchor? = null,
    private val idFactory: () -> String = { UUID.randomUUID().toString() }
) {
    /** Поездка, которая идёт сейчас; null — автомобиль стоит, записи не начаты. */
    var trip: TripAnchor? = restoredTrip
        private set

    /** Сессия заряда, которая идёт сейчас или ждёт тишины, чтобы записаться. */
    var charge: ChargeAnchor? = restoredCharge
        private set

    /**
     * Пробег, который автомобиль показывал, когда поездки не было. По нему видно
     * движение до того, как скорость или передача успеют что-то сообщить.
     */
    private var idleOdometerKm: Double? = restoredTrip?.startOdometerKm
    private var lastTripStartedAt: Long? = null
    private var lastChargeStartedAt: Long? = null

    /**
     * Пропустить один ответ автомобиля через автомат. [history] — уже записанные
     * поездки: из них берётся средний расход для оценки энергии и проверяется, не
     * записана ли такая поездка раньше.
     */
    fun observe(
        snapshot: VehicleSnapshot,
        profile: Profile,
        history: List<Trip> = emptyList(),
        now: Long = System.currentTimeMillis()
    ): JournalUpdate {
        if (!usable(snapshot)) {
            charge = charge?.withoutPowerSample()
            return JournalUpdate()
        }
        val notes = mutableListOf<String>()
        val trips = mutableListOf<Trip>()
        val sessions = mutableListOf<ChargeSession>()
        advanceTrip(snapshot, profile, history, now, trips, notes)
        advanceCharge(snapshot, profile, now, sessions, notes)
        return JournalUpdate(trips, sessions, notes)
    }

    private fun usable(snapshot: VehicleSnapshot): Boolean =
        snapshot.source == SourceMode.CAR_API && !snapshot.isFallback && !snapshot.stale

    /**
     * Забыть незакрытые поездку и зарядку. Нужно при смене источника и при очистке
     * журнала: якорь, живущий от Car API, не должен дописать запись в демо-журнал.
     */
    fun reset() {
        trip = null
        charge = null
        idleOdometerKm = null
        lastTripStartedAt = null
        lastChargeStartedAt = null
    }

    // --- Поездки ---------------------------------------------------------------

    private fun advanceTrip(
        snapshot: VehicleSnapshot,
        profile: Profile,
        history: List<Trip>,
        now: Long,
        trips: MutableList<Trip>,
        notes: MutableList<String>
    ) {
        val odometer = snapshot.odometerKm
        val speed = snapshot.speedKmh ?: 0
        val baseline = idleOdometerKm
        val crept = odometer != null && baseline != null &&
            odometer - baseline >= MIN_TRIP_ODOMETER_DELTA_KM
        var startOdometerKm = baseline
        if (odometer != null && (baseline == null || odometer < baseline)) {
            // Первый ответ после перезапуска или одометр откатился (замена GU):
            // считаем это новой точкой отсчёта, а не поездкой назад.
            idleOdometerKm = odometer
            // Старт поездки в этом же чтении берётся от новой точки: старая больше
            // не соответствует одометру и дала бы поездке чужие километры.
            startOdometerKm = odometer
        } else if (trip == null && odometer != null) {
            idleOdometerKm = odometer
        }

        val current = trip
        if (current == null) {
            // Capy вооружает поездку на входе в D (TripSessionDetector.maybeArmTrip);
            // здесь то же начало, плюс одометр: он трогается раньше, чем прошивка
            // успеет назвать передачу.
            val moving = speed > MOVEMENT_SPEED_KMH || snapshot.gear == Gear.D || crept
            if (moving) {
                trip = TripAnchor(
                    startedAt = now,
                    startOdometerKm = startOdometerKm ?: odometer,
                    startSoc = snapshot.soc,
                    lastMovingAt = now,
                    endSoc = snapshot.soc,
                    driveMode = snapshot.driveMode,
                    regen = snapshot.regen
                )
            }
            return
        }

        if (now - current.startedAt > STALE_ANCHOR_MS) {
            trip = null
            idleOdometerKm = odometer ?: idleOdometerKm
            notes += "поездка начата больше суток назад — якорь сброшен, записи нет"
            return
        }

        val byOdometer = if (odometer != null && current.startOdometerKm != null) {
            odometer - current.startOdometerKm
        } else {
            null
        }
        // Расстояние считается только по одометру: на этом ГУ 0x2740A679 оказался не
        // счётчиком поездки (журнал 2026-10-28: 5461,9 при одометре 5528,1), а другой
        // канал давал 5467,1 км за минуту. Нет одометра — расстояние остаётся тем, что
        // уже накоплено, и запись не получает чужих километров.
        val distance = maxOf(current.distanceKm, byOdometer ?: 0.0)
        val moved = distance > current.distanceKm || speed > MOVEMENT_SPEED_KMH || snapshot.gear == Gear.D
        val parked = snapshot.gear == Gear.P && speed <= MOVEMENT_SPEED_KMH && distance == current.distanceKm

        val anchor = current.copy(
            distanceKm = distance,
            endSoc = snapshot.soc ?: current.endSoc,
            driveMode = current.driveMode ?: snapshot.driveMode,
            mixedDriveMode = current.mixedDriveMode || (current.driveMode != null &&
                snapshot.driveMode != null && current.driveMode != snapshot.driveMode),
            regen = snapshot.regen ?: current.regen,
            lastMovingAt = if (moved) now else current.lastMovingAt,
            pendingEndSince = when {
                parked -> current.pendingEndSince ?: now
                moved -> null
                else -> current.pendingEndSince
            }
        )

        val parkConfirmed = anchor.pendingEndSince != null &&
            now - anchor.pendingEndSince >= PARK_CONFIRM_MS
        val chargingStarted = snapshot.isCharging == true
        val idleTooLong = now - anchor.lastMovingAt >= TRIP_IDLE_TIMEOUT_MS

        when {
            // Тот же конец, что у Capy: P + тишина (PARK_GEAR_STABLE_CONFIRM_MILLIS)
            // или уход в зарядку (TripEndReason.CHARGING_STARTED).
            parkConfirmed -> {
                writeTrip(anchor, anchor.pendingEndSince ?: now, profile, history, trips, notes)
                trip = null
                idleOdometerKm = odometer ?: idleOdometerKm
            }
            chargingStarted || idleTooLong -> {
                writeTrip(anchor, anchor.lastMovingAt, profile, history, trips, notes)
                trip = null
                idleOdometerKm = odometer ?: idleOdometerKm
            }
            else -> trip = anchor
        }
    }

    private fun writeTrip(
        anchor: TripAnchor,
        endedAt: Long,
        profile: Profile,
        history: List<Trip>,
        trips: MutableList<Trip>,
        notes: MutableList<String>
    ) {
        if (anchor.distanceKm < MIN_TRIP_DISTANCE_KM) {
            if (anchor.distanceKm > 0.0) {
                notes += "поездка ${Fmt.n1(anchor.distanceKm)} км короче порога — не записана"
            }
            return
        }
        if (anchor.startedAt == lastTripStartedAt || history.any { it.startedAt == anchor.startedAt }) {
            notes += "такая поездка уже в журнале — вторая запись отброшена"
            return
        }
        val minutes = ((endedAt - anchor.startedAt) / 60_000.0)
            .roundToInt()
            .coerceIn(1, MAX_MINUTES)
        val startSoc = anchor.startSoc
        val endSoc = anchor.endSoc
        val delta = if (startSoc != null && endSoc != null) startSoc - endSoc else null
        val bySoc = delta != null && delta >= MIN_SOC_STEP_PERCENT
        val energy = (if (bySoc) {
            delta!! / 100.0 * profile.batteryKwh
        } else {
            Stats.estimateEnergy(anchor.distanceKm, history)
        }).coerceAtLeast(0.1)
        val note = when {
            bySoc -> "энергия по ΔSOC $delta%"
            delta != null -> "заряд не упал — энергия по среднему расходу"
            else -> "SOC не читался — энергия по среднему расходу"
        }
        val distance = (anchor.distanceKm * 10).roundToInt() / 10.0
        lastTripStartedAt = anchor.startedAt
        // У автопоездки адреса нет: GPS её не писал, а одометр в названии маршрута
        // читался как пробег. Показываем честное окно времени, а километры остаются
        // в отдельном столбце расстояния.
        trips += Trip(
            id = idFactory(),
            startedAt = anchor.startedAt,
            from = Fmt.time(anchor.startedAt),
            to = Fmt.time(endedAt),
            endedAt = endedAt,
            distanceKm = distance,
            durationMin = minutes,
            energyKwh = (energy * 10).roundToInt() / 10.0,
            note = note.take(80),
            source = RecordSource.CAR,
            // Ёмкость берётся из настроек, а SOC имеет шаг в 1%: даже число из
            // автомобиля здесь остаётся оценкой, а не измерением в розетке.
            energyEstimated = true,
            driveMode = anchor.driveMode.takeUnless { anchor.mixedDriveMode },
            mixedDriveMode = anchor.mixedDriveMode,
            regen = anchor.regen
        )
        notes += "поездка записана: ${Fmt.n1(distance)} км · ${Fmt.duration(minutes)} · $note"
    }

    // --- Зарядки ---------------------------------------------------------------

    private fun advanceCharge(
        snapshot: VehicleSnapshot,
        profile: Profile,
        now: Long,
        sessions: MutableList<ChargeSession>,
        notes: MutableList<String>
    ) {
        // The source uses ChargingSignals.detect. Keep its third state: silence is not a stop.
        val charging = snapshot.isCharging
        var current = charge
        val stamp = snapshot.updatedAt.takeIf { it > 0L } ?: now
        // updatedAt=0 is the explicit synthetic/test clock. Real snapshots must agree with now.
        if (now < 0L || snapshot.updatedAt < 0L || now - stamp !in 0L..MAX_POWER_GAP_MS) {
            charge = current?.withoutPowerSample()
            return
        }
        if (current != null && (now < current.startedAt ||
                current.lastObservedAt?.let { now <= it } == true ||
                current.lastSnapshotAt?.let { stamp <= it } == true)) return

        if (current != null && now - current.startedAt > STALE_ANCHOR_MS) {
            charge = null
            notes += "зарядка начата больше суток назад — якорь сброшен, записи нет"
            return
        }
        // A resumed reading after the merge window belongs to a new session, even if
        // no poll happened exactly at the deadline. Unknown readings never finalize it.
        if (current?.stoppedSince != null && charging != null &&
            now - current.stoppedSince!! >= CHARGE_QUIET_MS) {
            writeCharge(current, current.stoppedSince!!, profile, sessions, notes)
            charge = null
            current = null
        }
        val soc = snapshot.soc?.takeIf { it in 0..100 }
        val observedType = snapshot.chargeType
        val conflict = ChargingSignals.typeConflict(snapshot.chargeFlow, snapshot.chargeConnectorType)
        if (current == null) {
            if (charging == true) {
                charge = withPowerSample(ChargeAnchor(
                    startedAt = now,
                    startSoc = soc,
                    type = observedType,
                    lastChargingAt = now,
                    endSoc = soc,
                    carMinutes = snapshot.chargeWorkMin,
                    typeClash = if (conflict) 1 else 0,
                    lastObservedAt = now,
                    lastSnapshotAt = stamp
                ), snapshot, now)
            }
            return
        }

        val base = current.copy(lastObservedAt = now, lastSnapshotAt = stamp)
        charge = when (charging) {
            true -> {
                val clash = conflict ||
                    (current.type != ChargeType.UNKNOWN && observedType != ChargeType.UNKNOWN &&
                        current.type != observedType)
                // Одно расхождение каналов — шум: из-за него тип теряли на всю сессию.
                val typeClash = if (clash) current.typeClash + 1 else 0
                val typeConflicted = current.typeConflicted || typeClash >= TYPE_CLASH_LIMIT
                withPowerSample(base.copy(
                    lastChargingAt = now,
                    stoppedSince = null,
                    // Первая измеренная SOC — базовая точка, а не выдуманный ноль.
                    startSoc = current.startSoc ?: soc,
                    endSoc = maxOfNullable(current.endSoc, soc),
                    carMinutes = snapshot.chargeWorkMin ?: current.carMinutes,
                    typeConflicted = typeConflicted,
                    typeClash = typeClash,
                    type = when {
                        typeConflicted -> ChargeType.UNKNOWN
                        observedType != ChargeType.UNKNOWN -> observedType
                        else -> current.type
                    }
                ), snapshot, now)
            }
            false -> {
                // Capture the final step at the FIRST safe stop only. Later idle SOC
                // (rebalancing, driving, regeneration) must not repair a finished session.
                val safeFinal = current.stoppedSince == null && !conflict &&
                    snapshot.chargeFlow != ChargeFlow.DISCHARGING &&
                    snapshot.gear != Gear.D && snapshot.gear != Gear.R &&
                    (snapshot.speedKmh ?: 0) <= MOVEMENT_SPEED_KMH
                base.withoutPowerSample().copy(
                    stoppedSince = current.stoppedSince ?: now,
                    startSoc = current.startSoc ?: soc.takeIf { safeFinal },
                    endSoc = if (safeFinal) maxOfNullable(current.endSoc, soc) else current.endSoc
                )
            }
            null -> base.withoutPowerSample()
        }
        // Ten-minute quiet merge is intentional; integration never bridges this pause.
    }

    private fun ChargeAnchor.withoutPowerSample() = copy(
        lastPowerKw = null, lastPowerAt = null, lastPowerType = null, lastPowerSource = null
    )

    private fun withPowerSample(anchor: ChargeAnchor, snapshot: VehicleSnapshot, now: Long): ChargeAnchor {
        val type = snapshot.chargeType
        val source = snapshot.chargePowerSource
        val kw = snapshot.chargePowerKw?.takeIf { it.isFinite() && it > 0.0 }
        if (kw == null || !ChargingSignals.trustworthyPower(type, source)) return anchor.withoutPowerSample()
        val elapsed = anchor.lastPowerAt?.let { now - it }
        val previous = anchor.lastPowerKw?.takeIf { it.isFinite() && it > 0.0 }
        val increment = if (elapsed != null && elapsed in 1L..MAX_POWER_GAP_MS && previous != null &&
            anchor.lastPowerType == type && anchor.lastPowerSource == source) {
            (previous / 2.0 + kw / 2.0) * (elapsed / 3_600_000.0)
        } else 0.0
        val accumulated = anchor.integratedKwh.takeIf { it.isFinite() && it >= 0.0 } ?: 0.0
        val total = (accumulated + increment).takeIf { it.isFinite() } ?: accumulated
        return anchor.copy(
            integratedKwh = total, lastPowerKw = kw, lastPowerAt = now,
            lastPowerType = type, lastPowerSource = source
        )
    }

    private fun writeCharge(
        anchor: ChargeAnchor,
        endedAt: Long,
        profile: Profile,
        sessions: MutableList<ChargeSession>,
        notes: MutableList<String>
    ) {
        if (anchor.startedAt == lastChargeStartedAt) {
            notes += "такая зарядка уже записана — вторая запись отброшена"
            return
        }
        val startSoc = anchor.startSoc
        val endSoc = anchor.endSoc
        val added = if (endSoc != null && startSoc != null) endSoc - startSoc else null
        val bySoc = added != null && added >= MIN_SOC_STEP_PERCENT
        val integrated = anchor.integratedKwh.takeIf { it.isFinite() && it > MIN_CHARGE_ENERGY_KWH }
        if (!bySoc && integrated == null) {
            notes += if (added == null) "зарядка без SOC и измеренной энергии — записывать нечего"
                else "зарядка не добавила процентов и измеренной энергии — запись отброшена"
            return
        }
        val clockMinutes = ((endedAt - anchor.startedAt) / 60_000.0).roundToInt()
        val minutes = (anchor.carMinutes ?: clockMinutes).coerceIn(1, MAX_MINUTES)
        // Меньшее интегрированное значение не округлять до нуля и не выдумывать из прошедшего времени.
        val energy = if (bySoc) added!! / 100.0 * profile.batteryKwh else integrated!!
        if (!energy.isFinite() || energy <= 0.0) return
        val percent = (added ?: 0).coerceIn(0, 100)
        lastChargeStartedAt = anchor.startedAt
        sessions += ChargeSession(
            id = idFactory(),
            startedAt = anchor.startedAt,
            place = if (anchor.carMinutes != null) "Автомобиль · время машины" else "Автомобиль",
            addedPercent = percent,
            energyKwh = energy,
            durationMin = minutes,
            type = anchor.type,
            source = RecordSource.CAR,
            // Интегрированная мощность — измерение; процент, пересчитанный через ёмкость, остаётся оценкой.
            energyEstimated = bySoc
        )
        val source = if (anchor.carMinutes != null) "по часам автомобиля" else "по часам приложения"
        notes += "зарядка записана: +$percent% · ${Fmt.kwh(energy)} · ${Fmt.duration(minutes)} $source"
    }

    private fun maxOfNullable(a: Int?, b: Int?): Int? = when {
        a == null -> b
        b == null -> a
        else -> maxOf(a, b)
    }

    companion object {
        /** TripSessionDetector.MOVEMENT_SPEED_KMH — ниже этой скорости машина стоит. */
        private const val MOVEMENT_SPEED_KMH = 2

        /** TripSessionDetector.MIN_TRIP_ODOMETER_DELTA_KM: пробег, подтверждающий ход. */
        private const val MIN_TRIP_ODOMETER_DELTA_KM = 0.2

        /** TripSessionDetector.MIN_TRIP_ESTIMATED_DISTANCE_KM: поездка короче — шум. */
        private const val MIN_TRIP_DISTANCE_KM = 0.2

        /** TripSessionDetector.PARK_GEAR_STABLE_CONFIRM_MILLIS. */
        private const val PARK_CONFIRM_MS = 30_000L

        /**
         * Наше правило: поездка считается законченной, если 10 минут не было ни
         * движения, ни P от прошивки. Без него запись не закроется, когда передача
         * вообще не читается, а приложение сворачивают на парковке.
         */
        private const val TRIP_IDLE_TIMEOUT_MS = 10 * 60_000L

        /** ChargeSessionDetector.END_CONFIRM_MILLIS, увеличенное до 10 минут. */
        private const val CHARGE_QUIET_MS = 10 * 60_000L

        /** TripSessionDetector.STALE_OPEN_SESSION_THRESHOLD_MILLIS. */
        private const val STALE_ANCHOR_MS = 24L * 60L * 60L * 1_000L

        /** SOC приходит целым процентом: меньшее изменение — не расход. */
        private const val MIN_SOC_STEP_PERCENT = 1

        /** Энергия не интегрируется через пропущенные интервалы, паузы и длинные gaps опроса. */
        private const val MAX_POWER_GAP_MS = 60_000L
        private const val MIN_CHARGE_ENERGY_KWH = 0.01

        /** Столько подряд расхождений потока и разъёма стоит типом «не определён». */
        private const val TYPE_CLASH_LIMIT = 2

        private const val MAX_MINUTES = 24 * 60
    }
}
