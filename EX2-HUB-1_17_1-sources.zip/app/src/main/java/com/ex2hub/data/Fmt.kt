package com.ex2hub.data

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

object Fmt {
    val RU: Locale = Locale("ru", "RU")

    private val symbols = DecimalFormatSymbols(RU).apply {
        decimalSeparator = ','
        groupingSeparator = ' '
    }

    /**
     * DecimalFormat хранит рабочие буферы внутри себя и не потокобезопасен. Цифры форматируют
     * и композиция на главном потоке, и выгрузка журнала в IO-потоке; на общем экземпляре
     * параллельные вызовы портят текст или падают. У каждого потока свой экземпляр.
     */
    private fun decimalFormat(pattern: String): ThreadLocal<DecimalFormat> =
        ThreadLocal.withInitial { DecimalFormat(pattern, symbols) }

    private val decimal1 = decimalFormat("0.0")
    private val decimal2 = decimalFormat("0.00")
    private val decimal5 = decimalFormat("0.00000")
    private val decimal0 = decimalFormat("0")

    private val timeFmt = DateTimeFormatter.ofPattern("HH:mm", RU)
    private val dayMonthFmt = DateTimeFormatter.ofPattern("d MMM", RU)
    private val weekdayFmt = DateTimeFormatter.ofPattern("EE", RU)
    private val fullDateFmt = DateTimeFormatter.ofPattern("EE, d MMMM", RU)
    private val monthYearFmt = DateTimeFormatter.ofPattern("LLLL uuuu", RU)
    private val dateInputFmt = DateTimeFormatter.ofPattern("dd.MM.uuuu", RU)
    private val timeInputFmt = DateTimeFormatter.ofPattern("HH:mm", RU)

    fun n1(value: Double?): String = value?.let { decimal1.get().format(it) } ?: "—"

    /** Деньги и тарифы: копейки видны всегда, округление до сотой. */
    fun n2(value: Double?): String = value?.let { decimal2.get().format(it) } ?: "—"

    fun n0(value: Double?): String = value?.let { decimal0.get().format(it) } ?: "—"

    /** Координаты для выгрузки: пустая строка вместо прочерка, пять знаков после запятой. */
    fun coord(value: Double?): String = value?.let { decimal5.get().format(it) } ?: ""

    fun int(value: Int?): String = value?.let { decimal0.get().format(it) } ?: "—"

    fun grouped(value: Int?): String {
        if (value == null) return "—"
        return String.format(Locale.US, "%,d", value).replace(',', ' ')
    }

    fun km(value: Double?): String = value?.let { "${n1(it)} км" } ?: "—"
    fun kwh(value: Double?): String = value?.let { "${n1(it)} кВт·ч" } ?: "—"
    fun money(value: Double?): String = value?.let { "${decimal2.get().format(it)} р." } ?: "—"
    fun percent(value: Int?): String = value?.let { "$it%" } ?: "—"
    fun signedPercent(value: Int?): String = value?.let { if (it >= 0) "+$it%" else "$it%" } ?: "—"
    fun temp(value: Int?): String {
        if (value == null) return "—"
        return if (value > 0) "+$value°" else "$value°"
    }

    fun power(value: Double?): String = value?.let { "${n1(it)} кВт" } ?: "—"

    fun time(epochMillis: Long): String =
        timeFmt.format(Instant.ofEpochMilli(epochMillis).atZone(ZoneId.systemDefault()))

    fun dayMonth(date: LocalDate): String = dayMonthFmt.format(date).replace(".", "")

    fun weekdayShort(date: LocalDate): String = weekdayFmt.format(date).replace(".", "").lowercase(RU)

    fun weekdayCapital(date: LocalDate): String {
        val raw = weekdayShort(date)
        return raw.replaceFirstChar { it.titlecase(RU) }
    }

    fun fullDate(date: LocalDate): String {
        val raw = fullDateFmt.format(date).replace(".", "")
        return raw.replaceFirstChar { it.titlecase(RU) }
    }

    fun monthTitle(month: YearMonth): String {
        val raw = monthYearFmt.format(month)
        return raw.replaceFirstChar { it.titlecase(RU) }
    }

    fun tableDate(epochMillis: Long): String {
        val date = Instant.ofEpochMilli(epochMillis).atZone(ZoneId.systemDefault()).toLocalDate()
        return "${dayMonth(date)} · ${time(epochMillis)}"
    }

    fun dayLabel(epochMillis: Long): String {
        val zone = ZoneId.systemDefault()
        val date = Instant.ofEpochMilli(epochMillis).atZone(zone).toLocalDate()
        val today = LocalDate.now(zone)
        return when (date) {
            today -> "Сегодня"
            today.minusDays(1) -> "Вчера"
            else -> dayMonth(date)
        }
    }

    fun duration(minutes: Int?): String {
        if (minutes == null) return "—"
        val m = minutes.coerceAtLeast(0)
        if (m < 60) return "$m мин"
        val hours = m / 60
        val rest = m % 60
        return if (rest == 0) "$hours ч" else "$hours ч $rest мин"
    }

    fun relativeUpdated(updatedAt: Long, now: Long = System.currentTimeMillis()): String {
        if (updatedAt <= 0L) return "нет данных"
        val seconds = ((now - updatedAt).coerceAtLeast(0L)) / 1000
        return when {
            seconds < 15 -> "только что"
            seconds < 60 -> "$seconds с назад"
            seconds < 3600 -> "${seconds / 60} мин назад"
            seconds < 86400 -> "${seconds / 3600} ч назад"
            else -> "${seconds / 86400} дн назад"
        }
    }

    fun weekRange(days: List<LocalDate>): String {
        if (days.isEmpty()) return "—"
        val first = days.first()
        val last = days.last()
        return if (first.year == last.year && first.month == last.month) {
            "${first.dayOfMonth}–${last.dayOfMonth} ${last.month.getDisplayName(TextStyle.FULL, RU)}"
        } else {
            "${dayMonth(first)} — ${dayMonth(last)}"
        }
    }

    fun plural(count: Int, one: String, few: String, many: String): String {
        val mod100 = abs(count) % 100
        val mod10 = abs(count) % 10
        return when {
            mod100 in 11..14 -> many
            mod10 == 1 -> one
            mod10 in 2..4 -> few
            else -> many
        }
    }

    fun trips(count: Int): String = "$count ${plural(count, "поездка", "поездки", "поездок")}"

    fun sessions(count: Int): String = "$count ${plural(count, "сессия", "сессии", "сессий")}"

    fun records(count: Int): String = "$count ${plural(count, "запись", "записи", "записей")}"

    fun dateInput(date: LocalDate): String = dateInputFmt.format(date)

    fun timeInput(time: LocalTime): String = timeInputFmt.format(time)

    fun parseDate(text: String): LocalDate? {
        val raw = text.trim()
        if (raw.isEmpty()) return null
        return runCatching { LocalDate.parse(raw, dateInputFmt) }.getOrNull()
            ?: runCatching { LocalDate.parse(raw) }.getOrNull()
    }

    fun parseTime(text: String): LocalTime? {
        val raw = text.trim()
        if (raw.isEmpty()) return null
        return runCatching { LocalTime.parse(raw, timeInputFmt) }.getOrNull()
            ?: runCatching { LocalTime.parse(raw) }.getOrNull()
    }

    fun combine(date: LocalDate, time: LocalTime, zone: ZoneId = ZoneId.systemDefault()): Long =
        date.atTime(time).atZone(zone).toInstant().toEpochMilli()

    fun roundToIntOrNull(value: Double?): Int? = value?.roundToInt()
}
