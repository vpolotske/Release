package com.ex2hub.data

import androidx.compose.runtime.Immutable
import java.time.Instant

enum class SourceMode {
    DEMO,
    MANUAL,
    CAR_API,
    ROOT
}

enum class RecordSource {
    DEMO,
    MANUAL,
    GPS,
    CAR
}

enum class ChargeType(val label: String) {
    AC("AC"),
    DC("DC"),
    UNKNOWN("Неизвестно")
}

/** Provenance of a measured power sample; never a duration/default-power estimate. */
enum class ChargePowerSource {
    AC_METER, DC_METER, BATTERY_RATE, INPUT_VI
}

/**
 * Режим движения. Короткие коды 1/2/3 приходят из VHAL DM_FUNC_DRIVE_MODE_SELECT,
 * когда прошивка отвечает числом адаптера, а не полным AutoFuncId.
 * Кода «Снег» нет: на этой машине такого режима не существует, и код 0x22010109
 * из общего справочника Geely остаётся нерасшифрованным.
 */
enum class DriveMode {
    ECO,
    COMFORT,
    SPORT,
    XC,
    PURE,
    HYBRID,
    ADAPTIVE
}

/** Уровень рекуперации, заявленный автомобилем. */
enum class RegenLevel {
    LOW,
    MID,
    HIGH,
    AUTO
}

/**
 * Передача из битовой маски CURRENT_GEAR: четыре независимых бита, а не счётчик.
 * Поля [VehicleSnapshot.gear] нет, когда автомобиль не ответил или ответил
 * двусмысленно (например, два бита сразу).
 */
enum class Gear {
    P,
    R,
    N,
    D
}

/**
 * Состояние зажигания по сенсорной обёртке ECARX (ISensorEvent.IGNITION_STATE_*).
 * UNDEFINED в список не входит: это «не определено», то же самое, что null.
 */
enum class IgnitionState {
    LOCK,
    OFF,
    ACC,
    ON,
    START,
    DRIVING
}

/** Что автомобиль говорит о зарядном сеансе прямо сейчас. */
enum class ChargeFlow {
    IDLE,
    PLUGGED,
    AC,
    DC,
    HEATING,
    BOOKING,
    FINISHED,
    SUSPENDED,
    DISCHARGING
}

/** Pure charging contract shared by the source and regressions. Null means no decision. */
object ChargingSignals {
    const val MIN_POWER_KW = 0.2

    fun detect(flow: ChargeFlow?, connected: Boolean?, powerKw: Double?): Boolean? = when (flow) {
        ChargeFlow.AC, ChargeFlow.DC, ChargeFlow.HEATING -> true
        ChargeFlow.IDLE, ChargeFlow.FINISHED, ChargeFlow.SUSPENDED,
        ChargeFlow.BOOKING, ChargeFlow.DISCHARGING -> false
        ChargeFlow.PLUGGED, null -> when {
            flow != ChargeFlow.PLUGGED && connected == false -> false
            flow != ChargeFlow.PLUGGED && connected != true -> null
            powerKw == null || !powerKw.isFinite() -> null
            else -> powerKw > MIN_POWER_KW
        }
    }

    fun typeConflict(flow: ChargeFlow?, connector: ChargeType?): Boolean =
        (flow == ChargeFlow.AC && connector == ChargeType.DC) ||
            (flow == ChargeFlow.DC && connector == ChargeType.AC)

    fun type(flow: ChargeFlow?, connector: ChargeType?): ChargeType {
        if (typeConflict(flow, connector) || flow == ChargeFlow.DISCHARGING) return ChargeType.UNKNOWN
        return when (flow) {
            ChargeFlow.AC -> ChargeType.AC
            // Обогрев на этом ГУ идёт от сети: сессия с подогревом — AC, а не «не определено».
            ChargeFlow.HEATING -> ChargeType.AC
            ChargeFlow.DC -> ChargeType.DC
            else -> connector ?: ChargeType.UNKNOWN
        }
    }

    fun trustworthyPower(type: ChargeType, source: ChargePowerSource?): Boolean = when (source) {
        ChargePowerSource.AC_METER, ChargePowerSource.INPUT_VI -> type == ChargeType.AC
        ChargePowerSource.DC_METER -> type == ChargeType.DC
        ChargePowerSource.BATTERY_RATE -> type != ChargeType.UNKNOWN
        null -> false
    }
}

enum class CheckStatus {
    UNKNOWN,
    OK,
    ERROR
}

@Immutable
data class Trip(
    val id: String,
    val startedAt: Long,
    val from: String,
    val to: String,
    val distanceKm: Double,
    val durationMin: Int,
    val energyKwh: Double,
    val note: String = "",
    val source: RecordSource = RecordSource.MANUAL,
    val energyEstimated: Boolean = false,
    val driveMode: DriveMode? = null,
    val regen: RegenLevel? = null,
    /** Legacy records have no mode history; their old attribution cannot be repaired. */
    val mixedDriveMode: Boolean = false,
    /** Exact observed end, absent on legacy/manual records rather than reconstructed. */
    val endedAt: Long? = null,
    /** Концы GPS-трека: по ним маршрут строится в картах. У ручной и автомобильной записи их нет. */
    val fromLat: Double? = null,
    val fromLon: Double? = null,
    val toLat: Double? = null,
    val toLon: Double? = null
) {
    val consumption: Double
        get() = if (distanceKm > 0.05) energyKwh / distanceKm * 100.0 else 0.0
}

@Immutable
data class ChargeSession(
    val id: String,
    val startedAt: Long,
    val place: String,
    val addedPercent: Int,
    val energyKwh: Double,
    val durationMin: Int,
    val type: ChargeType,
    val source: RecordSource = RecordSource.MANUAL,
    /** Проценты, пересчитанные через ёмкость, — оценка; интегрированная мощность является измерением. */
    val energyEstimated: Boolean = false
) {
    val averagePowerKw: Double
        get() = if (durationMin > 0) energyKwh / (durationMin / 60.0) else 0.0
}

@Immutable
data class Profile(
    val model: String = "Geely EX2",
    /**
     * Ёмкость тяговой батареи, кВт·ч. Берётся из настроек, а не из автомобиля:
     * INFO_EV_BATTERY_CAPACITY на этом ГУ, по наблюдению Capy, отвечает
     * VHAL-заглушкой 150 000 Вт·ч, и все расходы, посчитанные от неё, оказались
     * в 3,8 раза выше измеренных.
     */
    val batteryKwh: Double = 39.6,
    val tariffPerKwh: Double = 0.28,
    val source: SourceMode = SourceMode.DEMO,
    val manualSoc: Int? = null,
    val manualRangeKm: Int? = null,
    val manualUpdatedAt: Long = 0L,
    val rootSocCommand: String = "",
    val rootRangeCommand: String = "",
    val rootPowerCommand: String = "",
    val rootTempCommand: String = "",
    val rootDriveModeCommand: String = "",
    val rootRegenCommand: String = "",
    /** Пакеты приложений в нижней строке главной, в порядке показа. */
    val dockApps: List<String> = emptyList(),
    /** Последний выбор на панели; автомобиль сбрасывает режим при каждом включении. */
    val preferredDriveMode: DriveMode? = null,
    val preferredRegen: RegenLevel? = null,
    /** Возвращать выбор после включения автомобиля — только если владелец разрешил. */
    val restoreDrive: Boolean = false,
    /** Докладывать о достижении этого заряда во время зарядки; 0 — молчать. */
    val chargeAlertSoc: Int = 0,
    /** Докладывать о завершении зарядного сеанса. */
    val chargeDoneAlert: Boolean = true
)

@Immutable
data class SourceCheck(
    val status: CheckStatus = CheckStatus.UNKNOWN,
    val summary: String = "",
    val checkedAt: Long = 0L
)

@Immutable
data class PersistedState(
    val profile: Profile = Profile(),
    val trips: List<Trip> = emptyList(),
    val sessions: List<ChargeSession> = emptyList(),
    val checks: Map<SourceMode, SourceCheck> = emptyMap(),
    val demoSeeded: Boolean = false,
    /**
     * Незакрытые поездка и зарядка. Они живут между запусками специально: без этого
     * перезапуск посреди поездки начал бы вторую запись с тем же началом, а поездка
     * первой половины не увидела бы вовсе.
     */
    val tripAnchor: TripAnchor? = null,
    val chargeAnchor: ChargeAnchor? = null
)

@Immutable
data class VehicleSnapshot(
    val source: SourceMode = SourceMode.DEMO,
    val soc: Int? = null,
    val rangeKm: Int? = null,
    /**
     * Пробег автомобиля в километрах, дробный. Округлять до целого нельзя: поездку
     * короче километра журнал тогда потерял бы, а PERF_ODOMETER этот гу отдаёт именно
     * дробным числом (Capy читает его float без масштаба — vehicle/VehiclePropertyHelper.kt,
     * `readOdometer`).
     */
    val odometerKm: Double? = null,
    val outsideTempC: Int? = null,
    val insideTempC: Int? = null,
    val batteryKwh: Double = 39.6,
    val isCharging: Boolean? = null,
    val chargePowerKw: Double? = null,
    val speedKmh: Int? = null,
    val driveMode: DriveMode? = null,
    val regen: RegenLevel? = null,
    val gear: Gear? = null,
    val ignition: IgnitionState? = null,
    val chargeFlow: ChargeFlow? = null,
    val chargeEstimateMin: Int? = null,
    val chargeInputV: Double? = null,
    val chargeInputA: Double? = null,
    /**
     * Сколько минут идёт текущая сессия заряда по часам автомобиля
     * (CHARGING_WORK_TIME). Null — когда зарядка не активна или свойство молчит:
     * после остановки заряда прошивка держит последние значения, и показывать их
     * как «идущую» зарядку нельзя.
     */
    val chargeWorkMin: Int? = null,
    /** Заданный ток AC-зарядки и границы, которые объявил автомобиль, A. */
    val acCurrentSetA: Int? = null,
    val acCurrentMinA: Int? = null,
    val acCurrentMaxA: Int? = null,
    val climate: Climate? = null,
    val body: Body? = null,
    val updatedAt: Long = 0L,
    val isFallback: Boolean = false,
    val stale: Boolean = false,
    val note: String = "",
    /** Verified connector identity, independent of flow (including heating). */
    val chargeConnectorType: ChargeType? = null,
    val chargePortConnected: Boolean? = null,
    val chargePowerSource: ChargePowerSource? = null
) {
    val usableKwh: Double?
        get() = soc?.let { batteryKwh * it / 100.0 }

    val hasCoreData: Boolean
        get() = soc != null || rangeKm != null

    /** Voltage alone cannot identify the provenance of a charger channel. */
    val chargeType: ChargeType
        get() = ChargingSignals.type(chargeFlow, chargeConnectorType)
}

@Immutable
data class TrackingInfo(
    val startedAt: Long,
    val distanceKm: Double,
    val points: Int = 0
)

@Immutable
data class TrackResult(
    val startedAt: Long,
    val distanceKm: Double,
    val durationMin: Int,
    /** Первая и последняя точки трека: по ним маршрут получает адреса или координаты. */
    val fromLat: Double? = null,
    val fromLon: Double? = null,
    val toLat: Double? = null,
    val toLon: Double? = null
)

@Immutable
data class TrackedTripPrefill(
    val distanceKm: Double,
    val durationMin: Int,
    val startedAt: Long,
    val fromLat: Double? = null,
    val fromLon: Double? = null,
    val toLat: Double? = null,
    val toLon: Double? = null
)

@Immutable
data class TripDraft(
    val from: String,
    val to: String,
    val startedAt: Long,
    val distanceKm: Double,
    val durationMin: Int,
    val energyKwh: Double?,
    val note: String,
    val source: RecordSource = RecordSource.MANUAL,
    val driveMode: DriveMode? = null,
    val regen: RegenLevel? = null,
    val fromLat: Double? = null,
    val fromLon: Double? = null,
    val toLat: Double? = null,
    val toLon: Double? = null
)

@Immutable
data class ChargeDraft(
    val place: String,
    val startedAt: Long,
    val addedPercent: Int,
    val energyKwh: Double,
    val durationMin: Int,
    val type: ChargeType,
    val source: RecordSource = RecordSource.MANUAL
)

@Immutable
data class ProbeOutcome(
    val log: String,
    val check: SourceCheck,
    val snapshot: VehicleSnapshot? = null
)

fun nowMillis(): Long = Instant.now().toEpochMilli()
