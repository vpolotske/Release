package com.ex2hub.data

import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId

object DemoData {
    private data class DemoTripSpec(
        val offset: Long,
        val time: String,
        val from: String,
        val to: String,
        val km: Double,
        val minutes: Int,
        val energy: Double,
        val mode: DriveMode,
        val regen: RegenLevel
    )

    private data class DemoChargeSpec(
        val offset: Long,
        val time: String,
        val type: ChargeType,
        val place: String,
        val added: Int,
        val kwh: Double,
        val minutes: Int
    )

    private val tripSpecs = listOf(
        DemoTripSpec(0, "08:12", "Дом", "Офис", 17.4, 26, 2.3, DriveMode.COMFORT, RegenLevel.MID),
        DemoTripSpec(0, "12:38", "Офис", "Спортзал", 8.6, 16, 1.1, DriveMode.ECO, RegenLevel.HIGH),
        DemoTripSpec(0, "18:05", "Спортзал", "Дом", 8.2, 14, 1.3, DriveMode.SPORT, RegenLevel.LOW),
        DemoTripSpec(-1, "08:05", "Дом", "Офис", 17.4, 27, 2.5, DriveMode.COMFORT, RegenLevel.MID),
        DemoTripSpec(-1, "18:10", "Офис", "Дом", 17.8, 29, 2.5, DriveMode.COMFORT, RegenLevel.MID),
        DemoTripSpec(-2, "08:20", "Дом", "Офис", 12.8, 21, 1.7, DriveMode.ECO, RegenLevel.HIGH),
        DemoTripSpec(-2, "13:10", "Офис", "Кафе", 7.4, 16, 1.0, DriveMode.ECO, RegenLevel.HIGH),
        DemoTripSpec(-2, "18:35", "Кафе", "Дом", 8.4, 16, 1.1, DriveMode.COMFORT, RegenLevel.MID),
        DemoTripSpec(-3, "08:00", "Дом", "Офис", 17.9, 29, 2.7, DriveMode.COMFORT, RegenLevel.LOW),
        DemoTripSpec(-3, "18:15", "Офис", "Дом", 18.2, 22, 2.7, DriveMode.SPORT, RegenLevel.LOW),
        DemoTripSpec(-4, "09:40", "Дом", "Родители", 21.3, 28, 2.9, DriveMode.COMFORT, RegenLevel.MID),
        DemoTripSpec(-4, "14:10", "Родители", "ТЦ", 9.1, 18, 1.2, DriveMode.ECO, RegenLevel.HIGH),
        DemoTripSpec(-5, "08:10", "Дом", "Офис", 17.1, 26, 2.2, DriveMode.COMFORT, RegenLevel.MID),
        DemoTripSpec(-5, "17:50", "Офис", "Дом", 18.7, 24, 2.4, DriveMode.COMFORT, RegenLevel.MID),
        DemoTripSpec(-6, "11:20", "Дом", "Парк", 12.4, 20, 1.9, DriveMode.COMFORT, RegenLevel.MID),
        DemoTripSpec(-6, "16:05", "Парк", "Дом", 7.2, 18, 1.0, DriveMode.ECO, RegenLevel.HIGH)
    )

    private val chargeSpecs = listOf(
        DemoChargeSpec(-1, "20:10", ChargeType.AC, "Дом", 42, 17.1, 143),
        DemoChargeSpec(-4, "14:30", ChargeType.DC, "Зарядная станция", 36, 14.5, 28),
        DemoChargeSpec(-7, "21:00", ChargeType.AC, "Дом", 58, 23.2, 195),
        DemoChargeSpec(-12, "13:40", ChargeType.DC, "Зарядная станция", 34, 13.7, 26),
        DemoChargeSpec(-17, "20:30", ChargeType.AC, "Дом", 70, 27.9, 235)
    )

    fun seedTrips(
        nowMillis: Long = System.currentTimeMillis(),
        zone: ZoneId = ZoneId.systemDefault()
    ): List<Trip> {
        val today = java.time.Instant.ofEpochMilli(nowMillis).atZone(zone).toLocalDate()
        return tripSpecs.mapIndexed { index, spec ->
            val date = today.minusDays(-spec.offset)
            val startedAt = Fmt.combine(date, LocalTime.parse(spec.time), zone)
            Trip(
                id = "demo-trip-${index + 1}",
                startedAt = startedAt,
                from = spec.from,
                to = spec.to,
                distanceKm = spec.km,
                durationMin = spec.minutes,
                energyKwh = spec.energy,
                note = "",
                source = RecordSource.DEMO,
                driveMode = spec.mode,
                regen = spec.regen
            )
        }
    }

    fun seedSessions(
        nowMillis: Long = System.currentTimeMillis(),
        zone: ZoneId = ZoneId.systemDefault()
    ): List<ChargeSession> {
        val today = java.time.Instant.ofEpochMilli(nowMillis).atZone(zone).toLocalDate()
        return chargeSpecs.mapIndexed { index, spec ->
            val date = today.minusDays(-spec.offset)
            val startedAt = Fmt.combine(date, LocalTime.parse(spec.time), zone)
            ChargeSession(
                id = "demo-charge-${index + 1}",
                startedAt = startedAt,
                place = spec.place,
                addedPercent = spec.added,
                energyKwh = spec.kwh,
                durationMin = spec.minutes,
                type = spec.type,
                source = RecordSource.DEMO
            )
        }
    }

    fun snapshot(profile: Profile): VehicleSnapshot = VehicleSnapshot(
        source = SourceMode.DEMO,
        soc = 68,
        rangeKm = 204,
        odometerKm = 18452.4,
        outsideTempC = 9,
        insideTempC = 21,
        batteryKwh = profile.batteryKwh,
        isCharging = false,
        chargePowerKw = 0.0,
        driveMode = DriveMode.COMFORT,
        regen = RegenLevel.MID,
        gear = Gear.P,
        ignition = IgnitionState.ON,
        chargeFlow = ChargeFlow.IDLE,
        climate = Climate(
            hvacOn = true,
            acOn = true,
            recircOn = false,
            frontDefrostOn = false,
            rearDefrostOn = false,
            fanSpeed = 3,
            driverTempC = 22.0,
            seatHeatDriver = 0,
            seatHeatPassenger = 0,
            wheelHeat = 0,
            fanDirection = 1
        ),
        body = Body(
            open = BodyPart.values().associateWith { false },
            locked = Body.DOORS.associateWith { true },
            windowPercent = Body.DOORS.associateWith { 0 },
            headlightsOn = false
        ),
        updatedAt = System.currentTimeMillis(),
        note = "Синтетические демонстрационные значения"
    )

    fun probeLog(): String = buildString {
        appendLine("$ demo-provider --probe")
        appendLine("✓ провайдер доступен")
        appendLine("✓ SOC 68%, запас хода 204 км")
        appendLine("✓ режим COMFORT, рекуперация MID")
        appendLine("✓ передача P, зажигание ON — тоже синтетика")
        appendLine("✓ климат 22,0 °C, вентилятор 3 — тоже синтетика")
        appendLine("ℹ используются синтетические значения")
        append("ℹ журнал помечен как демонстрационный")
    }

    fun check(): SourceCheck = SourceCheck(
        status = CheckStatus.OK,
        summary = "синтетические значения",
        checkedAt = System.currentTimeMillis()
    )
}
