package com.ex2hub.data

/** Чем именно уведомить: у каждого события свой id, чтобы они не заменяли друг друга. */
enum class ChargeAlertKind(val notificationId: Int) {
    THRESHOLD(2),
    FINISHED(3)
}

data class ChargeAlert(val kind: ChargeAlertKind, val title: String, val text: String)

/**
 * Уведомления о зарядке: момент и текст решаются здесь, а не в сервисе, — правило
 * можно проверить без Android. Молчание демона зарядки ничего не решает: приложение
 * только докладывает о том, что уже видно на экране.
 */
class ChargeAlerts {
    private var armed = true

    /**
     * Порог объявляется один раз за сеанс. Как только зарядка останавливается,
     * флаг взводится снова: следующая зарядка на той же уставке напомнит о себе.
     * Возвращает заряд, при котором надо говорить, — null значит «молчать».
     */
    fun thresholdReached(soc: Int?, charging: Boolean, limitPercent: Int): Int? {
        if (!charging) {
            armed = true
            return null
        }
        if (limitPercent <= 0 || !armed) return null
        val current = soc ?: return null
        if (current < limitPercent) return null
        armed = false
        return current
    }

    companion object {
        fun threshold(limitPercent: Int, soc: Int, rangeKm: Int?): ChargeAlert = ChargeAlert(
            kind = ChargeAlertKind.THRESHOLD,
            title = "Заряд достиг $limitPercent%",
            text = listOfNotNull(
                "сейчас $soc%",
                rangeKm?.takeIf { it > 0 }?.let { "запас хода $it км" }
            ).joinToString(" · ")
        )

        fun finished(session: ChargeSession, tariffPerKwh: Double): ChargeAlert = ChargeAlert(
            kind = ChargeAlertKind.FINISHED,
            title = "Зарядка завершена",
            text = listOfNotNull(
                session.place.takeIf(String::isNotBlank),
                "+${session.addedPercent}%",
                Fmt.kwh(session.energyKwh),
                Fmt.duration(session.durationMin),
                (session.energyKwh * tariffPerKwh)
                    .takeIf { tariffPerKwh > 0.0 && it > 0.0 }
                    ?.let(Fmt::money)
            ).joinToString(" · ")
        )
    }
}
