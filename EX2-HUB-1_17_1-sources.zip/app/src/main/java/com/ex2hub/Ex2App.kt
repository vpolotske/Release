package com.ex2hub

import android.app.Application

/**
 * Единственная задача — начать загрузку хранилища раньше, чем экран дойдёт до него.
 *
 * `HubController` читает журнал синхронно в `onCreate` активности, и SharedPreferences
 * при этом ждёт разбора XML-файла, который сам начинается только с первого обращения.
 * Здесь обращение происходит на старте процесса, в фоновом потоке, и разбор идёт
 * параллельно созданию окна. Сервис и приёмник загрузки получают тот же выигрыш.
 */
class Ex2App : Application() {
    override fun onCreate() {
        super.onCreate()
        Thread({
            // getSharedPreferences запускает разбор файла; contains() дожидается его конца.
            runCatching {
                getSharedPreferences("ex2hub_state", MODE_PRIVATE).contains("state_json")
            }
        }, "EX2Hub-warmup").apply { isDaemon = true }.start()
    }
}
