package com.ex2hub.ui

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

data class LaunchableApp(
    val packageName: String,
    val label: String,
    val icon: ImageBitmap?
)

/** Приложения ГУ с ярлыком в лаунчере: список для настроек и запуск из нижней строки. */
object InstalledApps {
    private const val ICON_PX = 128
    private val described = LruCache<String, LaunchableApp>(32)

    fun all(context: Context): List<LaunchableApp> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { it.activityInfo.packageName }
            .filter { it != context.packageName }
            .distinct()
            .mapNotNull { describe(pm, it) }
            .sortedBy { it.label.lowercase() }
    }

    fun resolve(context: Context, packages: List<String>): List<LaunchableApp> {
        val pm = context.packageManager
        return packages.mapNotNull { pkg ->
            if (pm.getLaunchIntentForPackage(pkg) == null) {
                described.remove(pkg)
                null
            } else {
                describe(pm, pkg)
            }
        }
    }

    /** То, что уже известно без обращения к PackageManager; можно звать из главного потока. */
    fun cached(packages: List<String>): List<LaunchableApp> = packages.mapNotNull { described[it] }

    fun launch(context: Context, packageName: String): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return runCatching { context.startActivity(intent) }.isSuccess
    }

    /** Открывается ли по кнопке «Домой» именно это приложение. */
    fun isDefaultHome(context: Context): Boolean {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val home = context.packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
        return home?.activityInfo?.packageName == context.packageName
    }

    /**
     * Выбор рабочего стола в системе. В прошивках без экрана «Приложения по умолчанию»
     * остаются общие настройки, а дальше — adb, как описано в docs/flash-install.md.
     */
    fun openHomeSettings(context: Context): Boolean = listOf(
        Settings.ACTION_HOME_SETTINGS,
        Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS,
        Settings.ACTION_SETTINGS
    ).any { action ->
        runCatching {
            context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }.isSuccess
    }

    private fun describe(pm: PackageManager, pkg: String): LaunchableApp? {
        described[pkg]?.let { return it }
        val info = runCatching { pm.getApplicationInfo(pkg, 0) }.getOrNull() ?: return null
        val icon = runCatching {
            pm.getApplicationIcon(info).toBitmap(ICON_PX, ICON_PX).asImageBitmap()
        }.getOrNull()
        return LaunchableApp(pkg, pm.getApplicationLabel(info).toString(), icon)
            .also { described.put(pkg, it) }
    }
}
