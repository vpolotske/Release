package com.ex2hub.ui.dialogs

import android.content.Context
import android.location.Address
import android.location.Geocoder
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.ex2hub.data.ChargeDraft
import com.ex2hub.data.ChargeType
import com.ex2hub.data.DriveMode
import com.ex2hub.data.Fmt
import com.ex2hub.data.RegenLevel
import com.ex2hub.data.RecordSource
import com.ex2hub.data.TrackedTripPrefill
import com.ex2hub.data.TripDraft
import com.ex2hub.ui.AppIcons
import com.ex2hub.ui.Badge
import com.ex2hub.ui.CardHead
import com.ex2hub.ui.HubButton
import com.ex2hub.ui.HubButtonStyle
import com.ex2hub.ui.HubIconButton
import com.ex2hub.ui.HubTextField
import com.ex2hub.ui.SectionNote
import com.ex2hub.ui.SegmentedControl
import com.ex2hub.ui.WarningBox
import com.ex2hub.ui.color
import com.ex2hub.ui.theme.HubColors
import com.ex2hub.ui.title
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

@Composable
fun HubDialog(
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    width: Dp = 620.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.66f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onDismiss
                )
                .padding(20.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = modifier
                    .widthIn(max = width)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(HubColors.CardTop, HubColors.Bg)
                        )
                    )
                    .border(1.dp, HubColors.Border, RoundedCornerShape(20.dp))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {}
                    )
            ) {
                Column(
                    Modifier
                        .heightIn(max = 660.dp)
                        .verticalScroll(rememberScrollState())
                        .padding(22.dp),
                    content = content
                )
            }
        }
    }
}

private const val GPS_TRACK_PLACEHOLDER = "GPS-трек"

/** Системный геокодер называет точки трека адресами; сетью ходит сам сервис ГУ, а не приложение. */
private suspend fun reverseGeocodeTrack(
    context: Context,
    fromLat: Double,
    fromLon: Double,
    toLat: Double,
    toLon: Double
): Pair<String?, String?> = withContext(Dispatchers.IO) {
    if (!Geocoder.isPresent()) return@withContext null to null
    val geocoder = Geocoder(context, Locale.getDefault())
    val fromName = runCatching {
        geocoder.getFromLocation(fromLat, fromLon, 1)?.firstOrNull()?.let(::shortPlaceName)
    }.getOrNull()
    val toName = runCatching {
        geocoder.getFromLocation(toLat, toLon, 1)?.firstOrNull()?.let(::shortPlaceName)
    }.getOrNull()
    fromName to toName
}

private fun shortPlaceName(address: Address): String {
    val street = listOfNotNull(
        address.thoroughfare?.takeIf { it.isNotBlank() },
        address.subThoroughfare?.takeIf { it.isNotBlank() }
    ).joinToString(", ")
    if (street.isNotBlank()) return street
    val area = listOfNotNull(
        address.locality ?: address.subAdminArea,
        address.adminArea
    ).filter { !it.isNullOrBlank() }
        .joinToString(", ")
    if (area.isNotBlank()) return area
    return address.getAddressLine(0)
        ?.substringBefore(',')
        ?.takeIf { it.isNotBlank() }
        ?: address.featureName.orEmpty()
}

private fun coordText(lat: Double, lon: Double): String =
    String.format(Locale.US, "%.5f, %.5f", lat, lon)

@Composable
fun AddTripDialog(
    tariff: Double,
    prefill: TrackedTripPrefill?,
    suggestedDriveMode: DriveMode?,
    suggestedRegen: RegenLevel?,
    onDismiss: () -> Unit,
    onSave: (TripDraft) -> Boolean
) {
    val zone = ZoneId.systemDefault()
    val context = LocalContext.current
    val prefillDate = prefill?.let {
        Instant.ofEpochMilli(it.startedAt).atZone(zone).toLocalDate()
    }
    val prefillTime = prefill?.let {
        Instant.ofEpochMilli(it.startedAt).atZone(zone).toLocalTime()
    }
    var from by rememberSaveable { mutableStateOf(if (prefill != null) GPS_TRACK_PLACEHOLDER else "") }
    var to by rememberSaveable { mutableStateOf("") }
    var date by rememberSaveable {
        mutableStateOf(Fmt.dateInput(prefillDate ?: LocalDate.now()))
    }
    var time by rememberSaveable {
        mutableStateOf(Fmt.timeInput(prefillTime ?: LocalTime.now()))
    }
    var km by rememberSaveable {
        mutableStateOf(prefill?.let { Fmt.n1(it.distanceKm) } ?: "")
    }
    var minutes by rememberSaveable {
        mutableStateOf(prefill?.let { it.durationMin.toString() } ?: "")
    }
    var energy by rememberSaveable { mutableStateOf("") }
    var note by rememberSaveable { mutableStateOf("") }
    var driveMode by rememberSaveable { mutableStateOf(suggestedDriveMode) }
    var regen by rememberSaveable { mutableStateOf(suggestedRegen) }
    var error by remember { mutableStateOf<String?>(null) }

    // Адреса подставляются в нетронутые поля: если владелец уже начал печатать,
    // его текст не перекрывается ответом геокодера.
    LaunchedEffect(prefill) {
        val p = prefill ?: return@LaunchedEffect
        val fromLat = p.fromLat ?: return@LaunchedEffect
        val fromLon = p.fromLon ?: return@LaunchedEffect
        val toLat = p.toLat ?: return@LaunchedEffect
        val toLon = p.toLon ?: return@LaunchedEffect
        val names = reverseGeocodeTrack(context, fromLat, fromLon, toLat, toLon)
        if (from == GPS_TRACK_PLACEHOLDER) {
            from = names.first ?: coordText(fromLat, fromLon)
        }
        if (to.isBlank()) {
            to = names.second ?: coordText(toLat, toLon)
        }
    }

    fun submit() {
        val parsedDate = Fmt.parseDate(date)
        val parsedTime = Fmt.parseTime(time)
        val kmValue = km.toDoubleRu()
        if (parsedDate == null) {
            error = "Дата должна быть в формате ДД.ММ.ГГГГ."
            return
        }
        if (parsedTime == null) {
            error = "Время должно быть в формате ЧЧ:ММ."
            return
        }
        if (kmValue == null || kmValue <= 0.0) {
            error = "Укажите расстояние больше нуля."
            return
        }
        if (kmValue > 2000.0) {
            error = "Расстояние выглядит слишком большим."
            return
        }
        val minValue = minutes.toIntRu()?.takeIf { it > 0 }
            ?: max(1, (kmValue / 37.0 * 60.0).roundToInt())
        val energyValue = energy.toDoubleRu()?.takeIf { it > 0.0 }
        if (energy.isNotBlank() && energyValue == null) {
            error = "Энергия должна быть числом."
            return
        }
        error = null
        val draft = TripDraft(
            from = from.ifBlank { "Старт" },
            to = to.ifBlank { "Финиш" },
            startedAt = Fmt.combine(parsedDate, parsedTime),
            distanceKm = kmValue,
            durationMin = minValue,
            energyKwh = energyValue,
            note = note,
            source = if (prefill != null) RecordSource.GPS else RecordSource.MANUAL,
            driveMode = driveMode,
            regen = regen,
            fromLat = prefill?.fromLat,
            fromLon = prefill?.fromLon,
            toLat = prefill?.toLat,
            toLon = prefill?.toLon
        )
        if (onSave(draft)) onDismiss()
    }

    HubDialog(onDismiss = onDismiss) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = "ЖУРНАЛ",
                    color = HubColors.Muted,
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontSize = 9.sp,
                        letterSpacing = 1.3.sp
                    )
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = if (prefill != null) "Поездка по GPS" else "Новая поездка",
                    color = HubColors.Text,
                    style = MaterialTheme.typography.headlineMedium
                )
            }
            if (prefill != null) {
                Badge(text = "GPS", color = HubColors.Cyan, dot = true)
                Spacer(Modifier.width(6.dp))
            }
            HubIconButton(
                icon = AppIcons.Close,
                contentDescription = "Закрыть",
                onClick = onDismiss,
                size = 34.dp
            )
        }
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HubTextField(
                value = from,
                onValueChange = { from = it },
                modifier = Modifier.weight(1f),
                label = "Откуда",
                placeholder = "Дом"
            )
            HubTextField(
                value = to,
                onValueChange = { to = it },
                modifier = Modifier.weight(1f),
                label = "Куда",
                placeholder = "Офис"
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HubTextField(
                value = date,
                onValueChange = { date = it },
                modifier = Modifier.weight(1f),
                label = "Дата",
                placeholder = "ДД.ММ.ГГГГ"
            )
            HubTextField(
                value = time,
                onValueChange = { time = it },
                modifier = Modifier.weight(1f),
                label = "Время начала",
                placeholder = "ЧЧ:ММ"
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HubTextField(
                value = km,
                onValueChange = { km = it },
                modifier = Modifier.weight(1f),
                label = "Расстояние, км",
                placeholder = "12,4",
                keyboardType = KeyboardType.Decimal
            )
            HubTextField(
                value = minutes,
                onValueChange = { minutes = it },
                modifier = Modifier.weight(1f),
                label = "Длительность, мин",
                placeholder = "рассчитается",
                keyboardType = KeyboardType.Number
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HubTextField(
                value = energy,
                onValueChange = { energy = it },
                modifier = Modifier.weight(1f),
                label = "Энергия, кВт·ч",
                placeholder = "рассчитается",
                keyboardType = KeyboardType.Decimal
            )
            HubTextField(
                value = note,
                onValueChange = { note = it },
                modifier = Modifier.weight(1f),
                label = "Заметка",
                placeholder = "необязательно"
            )
        }
        Spacer(Modifier.height(10.dp))
        SignalPicker(
            section = "РЕЖИМ ДВИЖЕНИЯ",
            options = DriveMode.entries,
            selected = driveMode,
            optionTitle = { it.title() },
            optionAccent = { it.color() },
            onSelect = { driveMode = it }
        )
        SignalPicker(
            section = "РЕКУПЕРАЦИЯ",
            options = RegenLevel.entries,
            selected = regen,
            optionTitle = { it.title() },
            optionAccent = { HubColors.Cyan },
            onSelect = { regen = it }
        )
        SectionNote(
            "Значения сообщил автомобиль при последнем чтении. Повторное касание снимает выбор — " +
                "тогда поездка сохранится без режима."
        )
        Spacer(Modifier.height(9.dp))
        error?.let {
            WarningBox(text = it, color = HubColors.Red)
            Spacer(Modifier.height(8.dp))
        }
        SectionNote(
            if (prefill != null) {
                "Маршрут записан по GPS. Проверьте данные; энергия и стоимость будут рассчитаны по текущему тарифу ${Fmt.n1(tariff)} р./кВт·ч."
            } else {
                "Поездка сохранится как ручная запись. Расход и стоимость рассчитываются по текущему тарифу ${Fmt.n1(tariff)} р./кВт·ч."
            }
        )
        Spacer(Modifier.height(14.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            HubButton(
                text = "Отмена",
                onClick = onDismiss,
                style = HubButtonStyle.Ghost,
                modifier = Modifier.weight(1f)
            )
            HubButton(
                text = if (prefill != null) "Сохранить поездку" else "Добавить поездку",
                onClick = ::submit,
                icon = AppIcons.Plus,
                style = HubButtonStyle.Primary,
                modifier = Modifier.weight(1.5f)
            )
        }
    }
}

@Composable
fun AddChargeDialog(
    tariff: Double,
    suggestedType: ChargeType?,
    onDismiss: () -> Unit,
    onSave: (ChargeDraft) -> Boolean
) {
    var type by rememberSaveable { mutableStateOf(suggestedType ?: ChargeType.AC) }
    var place by rememberSaveable { mutableStateOf("") }
    var date by rememberSaveable { mutableStateOf(Fmt.dateInput(LocalDate.now())) }
    var time by rememberSaveable { mutableStateOf(Fmt.timeInput(LocalTime.now())) }
    var added by rememberSaveable { mutableStateOf("") }
    var kwh by rememberSaveable { mutableStateOf("") }
    var minutes by rememberSaveable { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    val estimate = kwh.toDoubleRu()?.takeIf { it > 0.0 }

    fun submit() {
        val parsedDate = Fmt.parseDate(date)
        val parsedTime = Fmt.parseTime(time)
        val addedValue = added.toIntRu()
        val kwhValue = kwh.toDoubleRu()
        val minValue = minutes.toIntRu()
        if (place.isBlank()) {
            error = "Укажите место зарядки."
            return
        }
        if (parsedDate == null) {
            error = "Дата должна быть в формате ДД.ММ.ГГГГ."
            return
        }
        if (parsedTime == null) {
            error = "Время должно быть в формате ЧЧ:ММ."
            return
        }
        if (addedValue == null || addedValue !in 1..100) {
            error = "Добавленный заряд должен быть от 1 до 100%."
            return
        }
        if (kwhValue == null || kwhValue <= 0.0) {
            error = "Укажите количество энергии."
            return
        }
        if (minValue == null || minValue <= 0) {
            error = "Укажите длительность сессии."
            return
        }
        error = null
        val draft = ChargeDraft(
            place = place,
            startedAt = Fmt.combine(parsedDate, parsedTime),
            addedPercent = addedValue,
            energyKwh = kwhValue,
            durationMin = minValue,
            type = type
        )
        if (onSave(draft)) onDismiss()
    }

    HubDialog(width = 560.dp, onDismiss = onDismiss) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = "ЖУРНАЛ",
                    color = HubColors.Muted,
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontSize = 9.sp,
                        letterSpacing = 1.3.sp
                    )
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Новая зарядка",
                    color = HubColors.Text,
                    style = MaterialTheme.typography.headlineMedium
                )
            }
            HubIconButton(
                icon = AppIcons.Close,
                contentDescription = "Закрыть",
                onClick = onDismiss,
                size = 34.dp
            )
        }
        Spacer(Modifier.height(14.dp))
        SegmentedControl(
            options = listOf(
                ChargeType.AC to "Домашняя · AC",
                ChargeType.DC to "Быстрая · DC"
            ),
            selected = type,
            onSelect = { type = it },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(6.dp))
        if (suggestedType != null) {
            SectionNote(
                "Тип подставлен из телеметрии: автомобиль сообщает о " +
                    if (suggestedType == ChargeType.DC) "DC-зарядке." else "AC-зарядке."
            )
        } else {
            SectionNote("Автомобиль не сообщает о зарядке — выберите тип вручную.")
        }
        Spacer(Modifier.height(10.dp))
        HubTextField(
            value = place,
            onValueChange = { place = it },
            modifier = Modifier.fillMaxWidth(),
            label = "Место",
            placeholder = if (type == ChargeType.AC) "Дом" else "Зарядная станция"
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HubTextField(
                value = date,
                onValueChange = { date = it },
                modifier = Modifier.weight(1f),
                label = "Дата",
                placeholder = "ДД.ММ.ГГГГ"
            )
            HubTextField(
                value = time,
                onValueChange = { time = it },
                modifier = Modifier.weight(1f),
                label = "Время",
                placeholder = "ЧЧ:ММ"
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HubTextField(
                value = added,
                onValueChange = { added = it },
                modifier = Modifier.weight(1f),
                label = "Добавлено, %",
                placeholder = "30",
                keyboardType = KeyboardType.Number
            )
            HubTextField(
                value = kwh,
                onValueChange = { kwh = it },
                modifier = Modifier.weight(1f),
                label = "Энергия, кВт·ч",
                placeholder = "15,0",
                keyboardType = KeyboardType.Decimal
            )
        }
        Spacer(Modifier.height(10.dp))
        HubTextField(
            value = minutes,
            onValueChange = { minutes = it },
            modifier = Modifier.fillMaxWidth(),
            label = "Длительность, мин",
            placeholder = "35",
            keyboardType = KeyboardType.Number
        )
        Spacer(Modifier.height(9.dp))
        error?.let {
            WarningBox(text = it, color = HubColors.Red)
            Spacer(Modifier.height(8.dp))
        }
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(HubColors.SurfaceHigh.copy(alpha = 0.55f))
                .padding(horizontal = 11.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Стоимость по тарифу ${Fmt.n1(tariff)} р./кВт·ч",
                color = HubColors.Muted,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 9.5.sp),
                modifier = Modifier.weight(1f)
            )
            Text(
                text = estimate?.let { Fmt.money(it * tariff) } ?: "—",
                color = if (estimate != null) HubColors.Accent else HubColors.Muted,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            )
        }
        Spacer(Modifier.height(14.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            HubButton(
                text = "Отмена",
                onClick = onDismiss,
                style = HubButtonStyle.Ghost,
                modifier = Modifier.weight(1f)
            )
            HubButton(
                text = "Добавить зарядку",
                onClick = ::submit,
                icon = AppIcons.Plug,
                style = HubButtonStyle.Primary,
                modifier = Modifier.weight(1.5f)
            )
        }
    }
}

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirmText: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    danger: Boolean = false
) {
    HubDialog(width = 440.dp, onDismiss = onDismiss) {
        Text(
            text = "ПОДТВЕРЖДЕНИЕ",
            color = HubColors.Muted,
            style = MaterialTheme.typography.labelMedium.copy(
                fontSize = 9.sp,
                letterSpacing = 1.3.sp
            )
        )
        Spacer(Modifier.height(5.dp))
        Text(
            text = title,
            color = HubColors.Text,
            style = MaterialTheme.typography.headlineMedium.copy(fontSize = 20.sp)
        )
        Spacer(Modifier.height(9.dp))
        Text(
            text = message,
            color = HubColors.TextDim,
            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp, lineHeight = 18.sp)
        )
        Spacer(Modifier.height(16.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            HubButton(
                text = "Отмена",
                onClick = onDismiss,
                style = HubButtonStyle.Ghost,
                modifier = Modifier.weight(1f)
            )
            HubButton(
                text = confirmText,
                onClick = onConfirm,
                style = if (danger) HubButtonStyle.Danger else HubButtonStyle.Primary,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

/**
 * Выбор сигнала телеметрии, который автомобиль назвал сам. Повторное касание
 * выбранного варианта снимает значение — журнал не обязан его содержать.
 */
@Composable
private fun <T> SignalPicker(
    section: String,
    options: List<T>,
    selected: T?,
    optionTitle: (T) -> String,
    optionAccent: @Composable (T) -> Color,
    onSelect: (T?) -> Unit
) {
    Text(
        text = section,
        color = HubColors.Muted,
        style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp, letterSpacing = 1.3.sp)
    )
    Spacer(Modifier.height(5.dp))
    options.chunked(SIGNAL_CHIPS_PER_ROW).forEach { rowOptions ->
        Row(
            Modifier.fillMaxWidth().padding(bottom = 5.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            rowOptions.forEach { option ->
                val isSelected = option == selected
                val accent = optionAccent(option)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(9.dp))
                        .background(
                            if (isSelected) accent.copy(alpha = 0.16f)
                            else HubColors.SurfaceHigh.copy(alpha = 0.5f)
                        )
                        .border(
                            1.dp,
                            if (isSelected) accent.copy(alpha = 0.55f) else HubColors.BorderSoft,
                            RoundedCornerShape(9.dp)
                        )
                        .clickable { onSelect(if (isSelected) null else option) }
                        .padding(horizontal = 6.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = optionTitle(option),
                        color = if (isSelected) HubColors.Text else HubColors.TextDim,
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 9.5.sp),
                        maxLines = 1
                    )
                }
            }
            repeat(SIGNAL_CHIPS_PER_ROW - rowOptions.size) {
                Spacer(Modifier.weight(1f))
            }
        }
    }
}

private const val SIGNAL_CHIPS_PER_ROW = 5

private fun String.toDoubleRu(): Double? = trim()
    .replace(" ", "")
    .replace("\u00A0", "")
    .replace(',', '.')
    .toDoubleOrNull()

private fun String.toIntRu(): Int? = toDoubleRu()?.roundToInt()
