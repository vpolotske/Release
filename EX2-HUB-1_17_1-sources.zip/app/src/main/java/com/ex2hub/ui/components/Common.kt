package com.ex2hub.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ex2hub.ui.theme.HubColors

enum class HubButtonStyle { Primary, Ghost, Dashed, Danger, Text }

@Composable
fun HubCard(
    modifier: Modifier = Modifier,
    padding: Dp? = null,
    verticalArrangement: Arrangement.Vertical = Arrangement.Top,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(18.dp)
    val actualPadding = padding ?: LocalHubLayout.current.cardPadding
    Column(
        modifier = modifier
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    listOf(HubColors.CardTop, HubColors.CardBottom)
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(listOf(HubColors.Border, HubColors.BorderSoft)),
                shape = shape
            )
            .padding(actualPadding),
        verticalArrangement = verticalArrangement,
        content = content
    )
}

@Composable
fun Eyebrow(text: String, modifier: Modifier = Modifier, color: Color = HubColors.Muted) {
    val scale = LocalHubText.current
    Text(
        text = text.uppercase(),
        modifier = modifier,
        color = color,
        style = MaterialTheme.typography.labelMedium.copy(
            fontSize = scale.eyebrow,
            letterSpacing = scale.eyebrowSpacing,
            fontWeight = FontWeight.SemiBold
        ),
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
    )
}

@Composable
fun CardHead(
    title: String,
    modifier: Modifier = Modifier,
    eyebrow: String? = null,
    trailing: @Composable (() -> Unit)? = null
) {
    val scale = LocalHubText.current
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            if (eyebrow != null) {
                Eyebrow(eyebrow)
                Spacer(Modifier.height(4.dp))
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge.copy(fontSize = scale.cardTitle),
                color = HubColors.Text,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (trailing != null) {
            Spacer(Modifier.width(8.dp))
            trailing()
        }
    }
}

@Composable
fun ScreenHead(
    eyebrow: String,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    actions: @Composable RowScope.() -> Unit = {}
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Eyebrow(eyebrow)
            Spacer(Modifier.height(5.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.headlineLarge,
                color = HubColors.Text
            )
            Spacer(Modifier.height(3.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 21.sp, lineHeight = 28.sp),
                color = HubColors.TextDim,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            content = actions
        )
    }
}

@Composable
fun Badge(
    text: String,
    color: Color = HubColors.Accent,
    modifier: Modifier = Modifier,
    dot: Boolean = false,
    fontSize: TextUnit? = null
) {
    val size = fontSize ?: LocalHubText.current.badge
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.10f))
            .border(1.dp, color.copy(alpha = 0.22f), RoundedCornerShape(50))
            .padding(horizontal = 9.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (dot) {
            Box(
                Modifier
                    .size(5.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Spacer(Modifier.width(5.dp))
        }
        Text(
            text = text,
            color = color,
            style = MaterialTheme.typography.labelMedium.copy(
                fontSize = size,
                letterSpacing = 0.2.sp,
                fontWeight = FontWeight.SemiBold
            ),
            maxLines = 1
        )
    }
}

@Composable
fun StateDot(color: Color, size: Dp = 7.dp, glow: Boolean = false) {
    Box(
        Modifier
            .size(size + if (glow) 6.dp else 0.dp),
        contentAlignment = Alignment.Center
    ) {
        if (glow) {
            Box(
                Modifier
                    .size(size + 6.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.16f))
            )
        }
        Box(
            Modifier
                .size(size)
                .clip(CircleShape)
                .background(color)
        )
    }
}

@Composable
fun IconChip(
    icon: ImageVector,
    accent: Color = HubColors.Accent,
    modifier: Modifier = Modifier,
    size: Dp = 42.dp,
    iconSize: Dp = 21.dp
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(12.dp))
            .background(accent.copy(alpha = 0.08f))
            .border(1.dp, accent.copy(alpha = 0.17f), RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = accent,
            modifier = Modifier.size(iconSize)
        )
    }
}

@Composable
fun HubIconButton(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = HubColors.TextDim,
    size: Dp? = null,
    enabled: Boolean = true
) {
    val side = size ?: LocalHubText.current.iconButton
    Box(
        modifier = modifier
            .size(side)
            .alpha(if (enabled) 1f else 0.4f)
            .clip(RoundedCornerShape(11.dp))
            .background(HubColors.SurfaceHigh)
            .border(1.dp, HubColors.BorderSoft, RoundedCornerShape(11.dp))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (enabled) tint else HubColors.Muted,
            modifier = Modifier.size(side * 0.46f)
        )
    }
}

@Composable
fun HubButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    style: HubButtonStyle = HubButtonStyle.Primary,
    enabled: Boolean = true,
    accent: Color = HubColors.Accent,
    loading: Boolean = false
) {
    val shape = RoundedCornerShape(12.dp)
    val scale = LocalHubText.current
    val contentColor = when (style) {
        HubButtonStyle.Primary -> when {
            !enabled -> HubColors.Muted
            accent == HubColors.Accent -> HubColors.OnAccent
            else -> HubColors.Black
        }
        HubButtonStyle.Ghost, HubButtonStyle.Dashed -> if (enabled) accent else HubColors.Muted
        HubButtonStyle.Danger -> if (enabled) HubColors.Red else HubColors.Muted
        HubButtonStyle.Text -> if (enabled) HubColors.TextDim else HubColors.Muted
    }
    var background: Color = Color.Transparent
    var borderColor: Color = Color.Transparent
    when (style) {
        HubButtonStyle.Primary -> background = if (enabled) accent else HubColors.Track
        HubButtonStyle.Ghost -> {
            background = HubColors.SurfaceHigh
            borderColor = HubColors.Border
        }
        HubButtonStyle.Danger -> {
            background = HubColors.Red.copy(alpha = 0.08f)
            borderColor = HubColors.Red.copy(alpha = 0.22f)
        }
        else -> Unit
    }
    val base = modifier
        .heightIn(min = scale.buttonHeight)
        .clip(shape)
        .then(
            when (style) {
                HubButtonStyle.Dashed -> Modifier.dashedBorder(
                    color = if (enabled) accent.copy(alpha = 0.38f) else HubColors.BorderSoft,
                    radius = 12.dp
                )
                else -> Modifier.border(1.dp, borderColor, shape)
            }
        )
        .background(background)
        .clickable(
            enabled = enabled && !loading,
            interactionSource = remember { MutableInteractionSource() },
            indication = null,
            onClick = onClick
        )
        .padding(horizontal = scale.buttonPadH, vertical = scale.buttonPadV)

    Row(
        modifier = base,
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (loading) {
            CircularProgressIndicator(
                modifier = Modifier.size(15.dp),
                strokeWidth = 2.dp,
                color = contentColor
            )
            Spacer(Modifier.width(8.dp))
        } else if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = contentColor,
                modifier = Modifier.size(scale.buttonIcon)
            )
            Spacer(Modifier.width(8.dp))
        }
        Text(
            text = text,
            color = contentColor,
            style = MaterialTheme.typography.labelLarge.copy(
                fontSize = scale.button,
                fontWeight = FontWeight.SemiBold
            ),
            maxLines = 1
        )
    }
}

@Composable
fun HubTextButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    color: Color = HubColors.TextDim
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = text,
            color = color,
            style = MaterialTheme.typography.labelLarge.copy(fontSize = 18.sp)
        )
        if (icon != null) {
            Spacer(Modifier.width(3.dp))
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(13.dp)
            )
        }
    }
}

@Composable
fun HubTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    label: String? = null,
    placeholder: String = "",
    keyboardType: KeyboardType = KeyboardType.Text,
    enabled: Boolean = true,
    trailing: @Composable (() -> Unit)? = null
) {
    val scale = LocalHubText.current
    Column(modifier) {
        if (label != null) {
            Text(
                text = label,
                color = HubColors.Muted,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = scale.fieldLabel),
                maxLines = 1
            )
            Spacer(Modifier.height(6.dp))
        }
        val shape = RoundedCornerShape(11.dp)
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            enabled = enabled,
            singleLine = true,
            textStyle = MaterialTheme.typography.bodyLarge.copy(
                color = if (enabled) HubColors.Text else HubColors.Muted,
                fontSize = scale.fieldValue
            ),
            cursorBrush = SolidColor(HubColors.Accent),
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
            modifier = Modifier.fillMaxWidth(),
            decorationBox = { inner ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = scale.fieldHeight)
                        .clip(shape)
                        .background(HubColors.SurfaceHigh)
                        .border(1.dp, HubColors.BorderSoft, shape)
                        .padding(horizontal = scale.fieldPadH, vertical = scale.fieldPadV),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.weight(1f)) {
                        if (value.isEmpty() && placeholder.isNotEmpty()) {
                            Text(
                                text = placeholder,
                                color = HubColors.Muted,
                                style = MaterialTheme.typography.bodyLarge.copy(fontSize = scale.fieldValue),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        inner()
                    }
                    if (trailing != null) {
                        Spacer(Modifier.width(6.dp))
                        trailing()
                    }
                }
            }
        )
    }
}

@Composable
fun <T> SegmentedControl(
    options: List<Pair<T, String>>,
    selected: T,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(HubColors.Track)
            .padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        options.forEach { (value, label) ->
            val active = value == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(9.dp))
                    .background(if (active) HubColors.Accent else Color.Transparent)
                    .clickable { onSelect(value) }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = label,
                    color = if (active) HubColors.OnAccent else HubColors.TextDim,
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    ),
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun KpiCard(
    icon: ImageVector,
    label: String,
    value: String,
    unit: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    HubCard(modifier = modifier, padding = 15.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconChip(icon = icon, accent = accent, size = 46.dp, iconSize = 24.dp)
            Spacer(Modifier.width(11.dp))
            Column {
                Text(
                    text = label,
                    color = HubColors.Muted,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = value,
                        color = HubColors.Text,
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontSize = 21.sp,
                            fontWeight = FontWeight.Medium
                        ),
                        maxLines = 1
                    )
                    if (unit.isNotEmpty()) {
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = unit,
                            color = HubColors.Muted,
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp),
                            modifier = Modifier.padding(bottom = 3.dp),
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun InfoRow(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    valueColor: Color = HubColors.Text
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = label,
            color = HubColors.Muted,
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 21.sp),
            modifier = Modifier.weight(1f),
            maxLines = 1
        )
        Text(
            text = value,
            color = valueColor,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontSize = 21.sp,
                fontWeight = FontWeight.Medium
            ),
            maxLines = 1
        )
    }
}

@Composable
fun SectionNote(text: String, modifier: Modifier = Modifier) {
    val scale = LocalHubText.current
    Text(
        text = text,
        modifier = modifier,
        color = HubColors.Muted,
        style = MaterialTheme.typography.bodySmall.copy(fontSize = scale.note, lineHeight = scale.noteLine)
    )
}

@Composable
fun WarningBox(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = HubColors.Amber
) {
    val scale = LocalHubText.current
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(11.dp))
            .background(color.copy(alpha = 0.07f))
            .border(1.dp, color.copy(alpha = 0.18f), RoundedCornerShape(11.dp))
            .padding(11.dp),
        verticalAlignment = Alignment.Top
    ) {
        Icon(
            imageVector = AppIcons.Alert,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(scale.warningIcon)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = text,
            color = HubColors.TextDim,
            style = MaterialTheme.typography.bodySmall.copy(
                fontSize = scale.warning,
                lineHeight = scale.warningLine
            )
        )
    }
}

@Composable
fun EmptyState(
    icon: ImageVector,
    title: String,
    text: String,
    modifier: Modifier = Modifier,
    action: (@Composable () -> Unit)? = null
) {
    Column(
        modifier = modifier.fillMaxWidth().padding(vertical = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = HubColors.Muted,
            modifier = Modifier.size(28.dp)
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = title,
            color = HubColors.TextDim,
            style = MaterialTheme.typography.titleMedium.copy(fontSize = 24.sp)
        )
        Spacer(Modifier.height(3.dp))
        Text(
            text = text,
            color = HubColors.Muted,
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 21.sp, lineHeight = 30.sp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        if (action != null) {
            Spacer(Modifier.height(10.dp))
            action()
        }
    }
}

@Composable
fun SoftDivider(modifier: Modifier = Modifier, color: Color = HubColors.BorderSoft) {
    Box(
        modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(color)
    )
}

@Composable
fun VerticalSoftDivider(modifier: Modifier = Modifier, height: Dp = 34.dp) {
    Box(
        modifier
            .width(1.dp)
            .height(height)
            .background(HubColors.BorderSoft)
    )
}

@Composable
fun TerminalBlock(
    text: String,
    modifier: Modifier = Modifier,
    contentColor: Color = HubColors.Mint
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(11.dp))
            .background(HubColors.Black)
            .border(1.dp, HubColors.BorderSoft, RoundedCornerShape(11.dp))
            .padding(11.dp)
    ) {
        Text(
            text = text,
            color = contentColor,
            style = MaterialTheme.typography.bodySmall.copy(
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                lineHeight = 15.sp
            )
        )
    }
}

@Composable
fun HubSnackbarHost(
    hostState: SnackbarHostState,
    modifier: Modifier = Modifier
) {
    SnackbarHost(
        hostState = hostState,
        modifier = modifier.padding(horizontal = 18.dp, vertical = 12.dp)
    ) { data ->
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(13.dp))
                .background(HubColors.SurfaceHigh)
                .border(1.dp, HubColors.Border, RoundedCornerShape(13.dp))
                .padding(horizontal = 15.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            StateDot(HubColors.Accent, size = 6.dp)
            Spacer(Modifier.width(9.dp))
            Text(
                text = data.visuals.message,
                color = HubColors.Text,
                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp)
            )
        }
    }
}

@Composable
fun LabeledValue(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    labelColor: Color = HubColors.Muted,
    valueColor: Color = HubColors.Text,
    valueSize: Int = 10
) {
    Column(modifier) {
        Text(
            text = label,
            color = labelColor,
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 9.5.sp),
            maxLines = 1
        )
        Spacer(Modifier.height(3.dp))
        Text(
            text = value,
            color = valueColor,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontSize = valueSize.sp,
                fontWeight = FontWeight.Medium
            ),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun ProvideTextColor(color: Color, content: @Composable () -> Unit) {
    androidx.compose.runtime.CompositionLocalProvider(
        LocalContentColor provides color,
        content = content
    )
}

private fun Modifier.dashedBorder(color: Color, radius: Dp, width: Dp = 1.dp): Modifier =
    drawBehind {
        drawRoundRect(
            color = color,
            cornerRadius = CornerRadius(radius.toPx(), radius.toPx()),
            style = Stroke(
                width = width.toPx(),
                pathEffect = PathEffect.dashPathEffect(
                    floatArrayOf(7.dp.toPx(), 6.dp.toPx()),
                    0f
                )
            )
        )
    }
