package com.ex2hub.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.ex2hub.data.ChargeFlow
import com.ex2hub.data.ChargeType
import com.ex2hub.data.CheckStatus
import com.ex2hub.data.DriveMode
import com.ex2hub.data.Gear
import com.ex2hub.data.IgnitionState
import com.ex2hub.data.RegenLevel
import com.ex2hub.data.SourceMode
import com.ex2hub.ui.theme.HubColors

fun SourceMode.title(): String = when (this) {
    SourceMode.DEMO -> "Демо-данные"
    SourceMode.MANUAL -> "Ручной ввод"
    SourceMode.CAR_API -> "Car API"
    SourceMode.ROOT -> "Root-команды"
}

fun SourceMode.shortTitle(): String = when (this) {
    SourceMode.DEMO -> "Демо-данные"
    SourceMode.MANUAL -> "Вручную"
    SourceMode.CAR_API -> "Car API"
    SourceMode.ROOT -> "Root"
}

fun SourceMode.tag(): String = when (this) {
    SourceMode.DEMO -> "демо"
    SourceMode.MANUAL -> "вручную"
    SourceMode.CAR_API -> "car api"
    SourceMode.ROOT -> "root"
}

fun SourceMode.hint(): String = when (this) {
    SourceMode.DEMO -> "синтетические значения"
    SourceMode.MANUAL -> "значения из настроек"
    SourceMode.CAR_API -> "VHAL, ECARX, Flyme AutoFunc"
    SourceMode.ROOT -> "su и команды опроса"
}

fun SourceMode.description(): String = when (this) {
    SourceMode.DEMO ->
        "Подходит для первого запуска: все экраны заполнены, поездки и зарядки можно добавлять вручную. Реальные параметры авто появятся только после подключения доступного источника."
    SourceMode.MANUAL ->
        "Заряд и запас хода задаются вручную. Журнал поездок и зарядок ведётся локально, без доступа к автомобилю."
    SourceMode.CAR_API ->
        "Приложение прочитает заряд, запас хода, пробег, скорость, температуру, режим движения, рекуперацию, передачу и зажигание по идентификаторам свойств, проверенным на этой машине другими приложениями. Кроме CarPropertyManager пробуются два канала штатной прошивки: обёртка ECARX для состояния зарядки, зажигания и режима использования ключа, Flyme AutoFunc для режима и рекуперации. На этом ГУ источник отвечает с обычной debug-сборки: перечисленные свойства читаются, а записи климата принимаются. На другой прошивке часть каналов может молчать — причина видна в журнале проверки."
    SourceMode.ROOT ->
        "Приложение выполнит настроенные вами команды через su и возьмёт первое число из вывода. Режим движения и рекуперация принимаются кодом: 0x220101xx, 0x200205xx или короткий счёт 1/2/3. Если root недоступен, останутся ручные значения."
}

fun SourceMode.icon(): ImageVector = when (this) {
    SourceMode.DEMO -> AppIcons.Database
    SourceMode.MANUAL -> AppIcons.Edit
    SourceMode.CAR_API -> AppIcons.Car
    SourceMode.ROOT -> AppIcons.Terminal
}

@Composable
@ReadOnlyComposable
fun SourceMode.accent(): Color = when (this) {
    SourceMode.DEMO -> HubColors.Mint
    SourceMode.MANUAL -> HubColors.Amber
    SourceMode.CAR_API -> HubColors.Cyan
    SourceMode.ROOT -> HubColors.Amber
}

@Composable
@ReadOnlyComposable
fun CheckStatus.color(): Color = when (this) {
    CheckStatus.OK -> HubColors.Accent
    CheckStatus.ERROR -> HubColors.Red
    CheckStatus.UNKNOWN -> HubColors.Muted
}

/** Режим движения так, как его подписывает приборная панель. */
fun DriveMode.title(): String = when (this) {
    DriveMode.ECO -> "Эко"
    DriveMode.COMFORT -> "Комфорт"
    DriveMode.SPORT -> "Спорт"
    DriveMode.XC -> "XC"
    DriveMode.PURE -> "Pure"
    DriveMode.HYBRID -> "Hybrid"
    DriveMode.ADAPTIVE -> "Адаптивный"
}

@Composable
@ReadOnlyComposable
fun DriveMode.color(): Color = when (this) {
    DriveMode.ECO -> HubColors.Accent
    DriveMode.COMFORT -> HubColors.Cyan
    DriveMode.SPORT -> HubColors.Red
    DriveMode.XC, DriveMode.PURE, DriveMode.HYBRID -> HubColors.Mint
    DriveMode.ADAPTIVE -> HubColors.Amber
}

fun RegenLevel.title(): String = when (this) {
    RegenLevel.LOW -> "слабая"
    RegenLevel.MID -> "средняя"
    RegenLevel.HIGH -> "сильная"
    RegenLevel.AUTO -> "автоматическая"
}

/** Передача так, как её показывает приборная панель. */
fun Gear.title(): String = when (this) {
    Gear.P -> "P"
    Gear.R -> "R"
    Gear.N -> "N"
    Gear.D -> "D"
}

@Composable
@ReadOnlyComposable
fun Gear.color(): Color = when (this) {
    Gear.P -> HubColors.TextDim
    Gear.R -> HubColors.Red
    Gear.N -> HubColors.Amber
    Gear.D -> HubColors.Accent
}

/**
 * Зажигание по константам ISensorEvent. Подписи переводят код состояния, а не
 * додумывают: START — «стартер», DRIVING — «в пути».
 */
fun IgnitionState.title(): String = when (this) {
    IgnitionState.LOCK -> "заблокировано"
    IgnitionState.OFF -> "выключено"
    IgnitionState.ACC -> "ACC"
    IgnitionState.ON -> "включено"
    IgnitionState.START -> "стартер"
    IgnitionState.DRIVING -> "в пути"
}

@Composable
@ReadOnlyComposable
fun IgnitionState.color(): Color = when (this) {
    IgnitionState.LOCK, IgnitionState.OFF -> HubColors.TextDim
    IgnitionState.ACC -> HubColors.Amber
    IgnitionState.ON -> HubColors.Cyan
    IgnitionState.START -> HubColors.Red
    IgnitionState.DRIVING -> HubColors.Accent
}

/** Что автомобиль говорит о зарядном сеансе. Null-состояние подписывает вызывающий код. */
fun ChargeFlow.title(): String = when (this) {
    ChargeFlow.IDLE -> "зарядки нет"
    ChargeFlow.PLUGGED -> "кабель подключён"
    ChargeFlow.AC -> "идёт AC-зарядка"
    ChargeFlow.DC -> "идёт DC-зарядка"
    ChargeFlow.HEATING -> "подогрев батареи"
    ChargeFlow.BOOKING -> "зарядка по расписанию"
    ChargeFlow.FINISHED -> "зарядка завершена"
    ChargeFlow.SUSPENDED -> "зарядка приостановлена"
    ChargeFlow.DISCHARGING -> "отдача энергии"
}

@Composable
@ReadOnlyComposable
fun ChargeFlow.color(): Color = when (this) {
    ChargeFlow.AC, ChargeFlow.DC, ChargeFlow.HEATING -> HubColors.Accent
    ChargeFlow.PLUGGED, ChargeFlow.BOOKING, ChargeFlow.SUSPENDED -> HubColors.Amber
    ChargeFlow.DISCHARGING -> HubColors.Cyan
    ChargeFlow.IDLE, ChargeFlow.FINISHED -> HubColors.TextDim
}

fun ChargeType.title(): String = when (this) {
    ChargeType.AC -> "AC"
    ChargeType.DC -> "DC"
    ChargeType.UNKNOWN -> "Не определён"
}

fun ChargeType.placeLabel(): String = when (this) {
    ChargeType.AC -> "Домашняя · AC"
    ChargeType.DC -> "Быстрая · DC"
    ChargeType.UNKNOWN -> "Не определён"
}

/** Цвет статуса источника: зелёный — данные источника актуальны, янтарный — резерв, красный — ошибка. */
@Composable
@ReadOnlyComposable
fun sourceBadge(mode: SourceMode, check: CheckStatus, isFallback: Boolean): Pair<String, Color> {
    if (isFallback) return "резерв" to HubColors.Amber
    if (mode == SourceMode.DEMO) return "демо" to HubColors.Mint
    if (mode == SourceMode.MANUAL) {
        return if (check == CheckStatus.UNKNOWN) "не задано" to HubColors.Amber
        else "вручную" to HubColors.Amber
    }
    return when (check) {
        CheckStatus.OK -> "активен" to HubColors.Accent
        CheckStatus.ERROR -> "недоступен" to HubColors.Red
        CheckStatus.UNKNOWN -> "не проверен" to HubColors.Muted
    }
}

fun sourceReadingLabel(mode: SourceMode, isFallback: Boolean): String = when {
    isFallback -> "резерв"
    mode == SourceMode.DEMO -> "синтетика"
    mode == SourceMode.MANUAL -> "вручную"
    else -> "по API"
}

/** Почему панели климата ведут себя именно так на выбранном источнике. */
fun SourceMode.climateNote(): String = when (this) {
    SourceMode.DEMO ->
        "Демо-режим: панель меняет значения только в приложении, автомобиль не затронут."
    SourceMode.MANUAL ->
        "Ручной режим ничего не пишет в автомобиль: кнопки климата появятся вместе с ответом Car API."
    SourceMode.ROOT ->
        "Root-источник читает то, что вы задали командами, и климатом не управляет."
    SourceMode.CAR_API ->
        "Запись идёт в VHAL. На этом ГУ прошивка принимает её и с обычной debug-сборки: подтверждением служит следующее чтение автомобиля, а не ответ метода записи. На другой прошивке запись может быть отклонена — причина видна в журнале проверки."
}
