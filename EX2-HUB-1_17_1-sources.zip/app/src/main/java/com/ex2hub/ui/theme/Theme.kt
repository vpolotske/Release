package com.ex2hub.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Цвета прежнего API, но из единой синей палитры: экраны и компоненты
 * не знают о смене оформления.
 */
object HubColors {
    val Bg: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.tones.bg
    val Surface: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.tones.surface
    val SurfaceHigh: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.tones.surfaceHigh
    val CardTop: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.tones.cardTop
    val CardBottom: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.tones.cardBottom
    val Border: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.tones.border
    val BorderSoft: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.tones.borderSoft
    val Text: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.tones.text
    val TextDim: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.tones.textDim
    val Muted: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.tones.muted
    val Accent: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.tones.accent
    val AccentSoft: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.tones.accentSoft
    val AccentDark: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.tones.accentDark
    val Mint: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.tones.mint
    val Cyan: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.tones.cyan
    val Amber: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.tones.amber
    val Red: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.tones.red
    val Track: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.tones.track
    val Black: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.tones.black
    val OnAccent: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.tones.onAccent

    val RailBg: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.rail.bg
    val RailLine: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.rail.line
    val RailIdleText: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.rail.idleText
    val RailIdleIcon: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.rail.idleIcon
    val RailClock: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.rail.clock
    val RailClockDate: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.rail.clockDate
    val RailActiveBg: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.rail.activeBg
    val RailActiveBorder: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.rail.activeBorder
    val RailActiveText: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.rail.activeText
    val RailActiveIcon: Color
        @Composable @ReadOnlyComposable get() = LocalHubPalette.current.rail.activeIcon
}

val HubTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Light,
        fontSize = 60.sp,
        letterSpacing = (-2).sp
    ),
    displayMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Light,
        fontSize = 46.sp,
        letterSpacing = (-1.5).sp
    ),
    headlineLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 30.sp,
        letterSpacing = (-0.6).sp
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 22.sp,
        letterSpacing = (-0.2).sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 18.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 15.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 18.sp
    ),
    bodySmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 11.sp,
        lineHeight = 15.sp
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        letterSpacing = 0.2.sp
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 10.sp,
        letterSpacing = 0.6.sp
    )
)

@Composable
fun Ex2HubTheme(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalHubPalette provides HubPalettes.Blue) {
        MaterialTheme(
            colorScheme = HubPalettes.Blue.scheme,
            typography = HubTypography,
            content = content
        )
    }
}
