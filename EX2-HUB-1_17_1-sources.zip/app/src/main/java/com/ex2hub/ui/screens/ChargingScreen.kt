package com.ex2hub.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ex2hub.data.ChargeAnchor
import com.ex2hub.data.ChargeSession
import com.ex2hub.data.ChargeType
import com.ex2hub.data.Fmt
import com.ex2hub.data.RecordSource
import com.ex2hub.data.SourceMode
import com.ex2hub.data.Stats
import com.ex2hub.ui.AppIcons
import com.ex2hub.ui.Badge
import com.ex2hub.ui.BatteryBar
import com.ex2hub.ui.BatteryReadback
import com.ex2hub.ui.CardHead
import com.ex2hub.ui.ChargeWeekBarChart
import com.ex2hub.ui.ChargingPageState
import com.ex2hub.ui.EmptyState
import com.ex2hub.ui.HubButton
import com.ex2hub.ui.HubButtonStyle
import com.ex2hub.ui.HubCard
import com.ex2hub.ui.HubIconButton
import com.ex2hub.ui.KpiCard
import com.ex2hub.ui.LocalHubLayout
import com.ex2hub.ui.PeriodColumn
import com.ex2hub.ui.PeriodLine
import com.ex2hub.ui.PeriodSummaryCard
import com.ex2hub.ui.ScreenHead
import com.ex2hub.ui.SoftDivider
import com.ex2hub.ui.StateDot
import com.ex2hub.ui.theme.HubColors
import com.ex2hub.ui.color
import com.ex2hub.ui.title
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalDate

@Composable
fun ChargingScreen(
    state: ChargingPageState,
    onAddCharge: () -> Unit,
    onDeleteCharge: (String) -> Unit
) {
    val layout = LocalHubLayout.current
    val tariff = state.tariffPerKwh
    val sessions = state.sessions
    var weeksBack by rememberSaveable { mutableIntStateOf(0) }
    var pickedEpochDay by rememberSaveable(weeksBack) { mutableStateOf<Long?>(null) }
    val today = LocalDate.now()
    val week = rememberJournalCalculation(sessions, tariff, weeksBack, today) {
        Stats.chargeWeekStats(sessions, tariffPerKwh = tariff, weeksBack = weeksBack)
    }
    val month = rememberJournalCalculation(sessions, tariff, today) {
        Stats.chargeSummary(sessions, tariffPerKwh = tariff)
    }
    val history = rememberJournalCalculation(sessions) {
        ChargeHistoryUi(
            oldestDate = sessions.minOfOrNull { it.startedAt }?.let { Stats.dateOf(it) },
            carSessions = sessions.count { it.source == RecordSource.CAR }
        )
    }
    val canGoBack = week != null && history?.oldestDate?.isBefore(week.days.first().date) == true
    val selectedDay = week?.let { loaded ->
        pickedEpochDay?.let(LocalDate::ofEpochDay)
            ?.takeIf { date -> loaded.days.any { it.date == date } }
            ?: loaded.days.lastOrNull { it.sessions > 0 }?.date
            ?: loaded.days.last().date
    }
    val daySessions = if (selectedDay != null) rememberJournalCalculation(sessions, selectedDay) {
        sessions.filter { Stats.dateOf(it.startedAt) == selectedDay }.sortedByDescending { it.startedAt }
    } else null
    // A wrapper distinguishes a loaded, unknown range from a pending calculation.
    val range = rememberJournalCalculation(state.batteryKwh, state.trips) {
        ChargeRangeUi(Stats.potentialRangeKm(state.batteryKwh, state.trips))
    }
    val weekRange = week?.let { Fmt.weekRange(it.days.map { day -> day.date }) } ?: "Загрузка…"

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 900.dp
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(layout.pagePadding)
        ) {
            item(key = "charges:head", contentType = "section") {
                ScreenHead(
                    eyebrow = "Энергия",
                    title = "Зарядки",
                    subtitle = if (weeksBack == 0) "Последние 7 дней · $weekRange" else "Архив · $weekRange",
                    actions = {
                        HubButton(
                            text = "Добавить зарядку",
                            onClick = onAddCharge,
                            icon = AppIcons.Plus,
                            style = HubButtonStyle.Primary
                        )
                    }
                )
                Spacer(Modifier.height(layout.gap))
            }

            state.journalCharge?.let { anchor ->
                item(key = "charges:active", contentType = "section") {
                    CarChargeBanner(anchor = anchor)
                    Spacer(Modifier.height(layout.gap))
                }
            }

            if (week == null || selectedDay == null) {
                item(key = "charges:loading", contentType = "status") {
                    HubCard(Modifier.fillMaxWidth()) {
                        Text("Загрузка журнала зарядок…", color = HubColors.Muted)
                    }
                }
            } else {
            item(key = "charges:kpis", contentType = "section") {
                Column(verticalArrangement = Arrangement.spacedBy(layout.gap)) {
                    if (wide) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(layout.gap)
                        ) {
                            KpiCard(
                                icon = AppIcons.Plug,
                                label = "Получено за 7 дней",
                                value = Fmt.n1(week.kwh),
                                unit = "кВт·ч",
                                accent = HubColors.Accent,
                                modifier = Modifier.weight(1f).height(76.dp)
                            )
                            KpiCard(
                                icon = AppIcons.Coin,
                                label = "Стоимость",
                                value = Fmt.n2(week.cost),
                                unit = "р.",
                                accent = HubColors.Mint,
                                modifier = Modifier.weight(1f).height(76.dp)
                            )
                            KpiCard(
                                icon = AppIcons.Battery,
                                label = "Сессий",
                                value = week.sessions.toString(),
                                unit = Fmt.plural(week.sessions, "сессия", "сессии", "сессий"),
                                accent = HubColors.Cyan,
                                modifier = Modifier.weight(1f).height(76.dp)
                            )
                            KpiCard(
                                icon = AppIcons.Gauge,
                                label = "Текущий тариф",
                                value = Fmt.n2(tariff),
                                unit = "р./кВт·ч",
                                accent = HubColors.Accent,
                                modifier = Modifier.weight(1f).height(76.dp)
                            )
                        }
                    } else {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(layout.gap)
                        ) {
                            KpiCard(
                                icon = AppIcons.Plug,
                                label = "Получено за 7 дней",
                                value = Fmt.n1(week.kwh),
                                unit = "кВт·ч",
                                accent = HubColors.Accent,
                                modifier = Modifier.weight(1f).height(76.dp)
                            )
                            KpiCard(
                                icon = AppIcons.Coin,
                                label = "Стоимость",
                                value = Fmt.n2(week.cost),
                                unit = "р.",
                                accent = HubColors.Mint,
                                modifier = Modifier.weight(1f).height(76.dp)
                            )
                        }
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(layout.gap)
                        ) {
                            KpiCard(
                                icon = AppIcons.Battery,
                                label = "Сессий",
                                value = week.sessions.toString(),
                                unit = Fmt.plural(week.sessions, "сессия", "сессии", "сессий"),
                                accent = HubColors.Cyan,
                                modifier = Modifier.weight(1f).height(76.dp)
                            )
                            KpiCard(
                                icon = AppIcons.Gauge,
                                label = "Текущий тариф",
                                value = Fmt.n2(tariff),
                                unit = "р./кВт·ч",
                                accent = HubColors.Accent,
                                modifier = Modifier.weight(1f).height(76.dp)
                            )
                        }
                    }
                }
                Spacer(Modifier.height(layout.gap))
            }

            val chart: @Composable (Modifier) -> Unit = { modifier ->
                ChargeChartCard(
                    week = week,
                    selected = selectedDay,
                    onSelect = { pickedEpochDay = it.toEpochDay() },
                    canGoBack = canGoBack,
                    canGoForward = weeksBack > 0,
                    onBack = { weeksBack++ },
                    onForward = { weeksBack = (weeksBack - 1).coerceAtLeast(0) },
                    modifier = modifier
                )
            }
            if (wide) {
                item(key = "charges:chart-battery", contentType = "section") {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(layout.gap)
                    ) {
                        chart(Modifier.weight(1.62f).height(360.dp))
                        BatteryCard(
                            battery = state.battery,
                            batteryKwh = state.batteryKwh,
                            tariffPerKwh = tariff,
                            fullRange = range?.km,
                            rangeLoading = range == null,
                            modifier = Modifier.weight(0.82f).height(360.dp)
                        )
                    }
                    Spacer(Modifier.height(layout.gap))
                }
            } else {
                item(key = "charges:battery", contentType = "section") {
                    BatteryCard(
                        battery = state.battery,
                        batteryKwh = state.batteryKwh,
                        tariffPerKwh = tariff,
                        fullRange = range?.km,
                        rangeLoading = range == null,
                        modifier = Modifier.fillMaxWidth().height(360.dp)
                    )
                    Spacer(Modifier.height(layout.gap))
                }
                // На узком экране блок выбора дня должен стоять вплотную к списку.
                item(key = "charges:chart", contentType = "section") {
                    chart(Modifier.fillMaxWidth().height(330.dp))
                    Spacer(Modifier.height(layout.gap))
                }
            }

            month?.let { period ->
                item(key = "charges:period", contentType = "section") {
                    PeriodSummaryCard(
                        title = "Итоги",
                        eyebrow = "Неделя и месяц",
                        badge = "Тариф ${Fmt.n2(tariff)} р./кВт·ч",
                        columns = chargePeriodColumns,
                        lines = chargePeriodLines(week, period),
                        wide = wide,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(layout.gap))
                }
            }

            item(key = "charges:table-head", contentType = "table-header") {
                JournalTablePart(first = true, last = daySessions.isNullOrEmpty()) {
                    JournalListHeading(
                        title = "Зарядки · ${dayTitle(selectedDay)}",
                        count = daySessions?.let { "${Fmt.records(it.size)} · всего в журнале ${sessions.size}" }
                            ?: "Загрузка зарядок выбранного дня…"
                    )
                    Spacer(Modifier.height(10.dp))
                    if (state.source == SourceMode.CAR_API) {
                        CarChargeNote(carSessions = history?.carSessions, modifier = Modifier.padding(bottom = 8.dp))
                    }
                    when {
                        sessions.isEmpty() -> EmptyState(
                            icon = AppIcons.Plug,
                            title = "Зарядок пока нет",
                            text = if (state.source == SourceMode.CAR_API) {
                                "Сессия появится после завершения зарядки. Энергия по шагу SOC — оценка, " +
                                    "по измеренной мощности — расчёт; <1% — прирост ниже шага SOC."
                            } else {
                                "Добавьте домашнюю или быструю сессию — приложение посчитает энергию, мощность и стоимость."
                            },
                            action = {
                                HubButton(
                                    text = "Добавить зарядку",
                                    onClick = onAddCharge,
                                    icon = AppIcons.Plus,
                                    style = HubButtonStyle.Ghost
                                )
                            }
                        )
                        daySessions == null -> Text(
                            "Загрузка записей…", color = HubColors.Muted,
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 21.sp, lineHeight = 30.sp)
                        )
                        daySessions.isEmpty() -> Text(
                            text = "В этот день зарядок нет. Выберите другой столбик на графике выше " +
                                "или пролистайте недели стрелками.",
                            color = HubColors.Muted,
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 21.sp, lineHeight = 30.sp),
                            modifier = Modifier.padding(vertical = 10.dp)
                        )
                        else -> SessionsTableHeader()
                    }
                }
            }
            if (daySessions != null) {
                itemsIndexed(daySessions, key = { _, session -> session.id }, contentType = { _, _ -> "charge" }) { index, session ->
                    JournalTablePart(last = index == daySessions.lastIndex) {
                        SoftDivider()
                        SessionTableRow(
                            session = session,
                            tariff = tariff,
                            onDelete = { onDeleteCharge(session.id) }
                        )
                    }
                }
            }
            }
        }
    }
}

private data class ChargeHistoryUi(val oldestDate: LocalDate?, val carSessions: Int)
private data class ChargeRangeUi(val km: Double?)

/** Колонки сводки заряда: подписи таблицы и блоков периода на узком экране одинаковы. */
private val chargePeriodColumns = listOf(
    PeriodColumn("Получено, кВт·ч", 140.dp),
    PeriodColumn("Стоимость, р.", 130.dp),
    PeriodColumn("Сессий", 85.dp),
    PeriodColumn("Время", 120.dp),
    PeriodColumn("Средняя, кВт", 120.dp),
    PeriodColumn("AC / DC, кВт·ч", 150.dp)
)

private fun chargePeriodLines(
    week: com.ex2hub.data.ChargeWeekStats,
    month: com.ex2hub.data.ChargeSummary
): List<PeriodLine> = listOf(
    PeriodLine(
        label = "Неделя",
        values = listOf(
            Fmt.n1(week.kwh),
            Fmt.n2(week.cost),
            Fmt.int(week.sessions),
            Fmt.duration(week.minutes),
            Fmt.n1(week.averagePowerKw),
            "${Fmt.n1(week.acKwh)} / ${Fmt.n1(week.dcKwh)}"
        )
    ),
    PeriodLine(
        label = Fmt.monthTitle(month.month),
        values = listOf(
            Fmt.n1(month.kwh),
            Fmt.n2(month.cost),
            Fmt.int(month.count),
            Fmt.duration(month.minutes),
            Fmt.n1(month.averagePowerKw),
            "${Fmt.n1(month.acKwh)} / ${Fmt.n1(month.dcKwh)}"
        )
    )
)

@Composable
private fun ChargeChartCard(
    week: com.ex2hub.data.ChargeWeekStats,
    selected: LocalDate,
    onSelect: (LocalDate) -> Unit,
    canGoBack: Boolean,
    canGoForward: Boolean,
    onBack: () -> Unit,
    onForward: () -> Unit,
    modifier: Modifier = Modifier
) {
    HubCard(modifier) {
        CardHead(
            title = "Энергия по дням",
            eyebrow = "Нажмите на день — ниже его зарядки",
            trailing = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    WeekArrow(AppIcons.ChevronLeft, "Предыдущая неделя", canGoBack, onBack)
                    Text(
                        text = Fmt.weekRange(week.days.map { it.date }),
                        color = HubColors.TextDim,
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 21.sp, lineHeight = 28.sp),
                        maxLines = 1,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                    WeekArrow(AppIcons.Chevron, "Следующая неделя", canGoForward, onForward)
                }
            }
        )
        Spacer(Modifier.height(8.dp))
        ChargeWeekBarChart(
            days = week.days,
            modifier = Modifier.fillMaxWidth().weight(1f),
            selected = selected,
            onSelect = onSelect
        )
    }
}

@Composable
private fun WeekArrow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    enabled: Boolean,
    onClick: () -> Unit
) {
    HubIconButton(
        icon = icon,
        contentDescription = description,
        onClick = { if (enabled) onClick() },
        tint = if (enabled) HubColors.Text else HubColors.Muted.copy(alpha = 0.35f)
    )
}

private fun dayTitle(date: LocalDate): String {
    val today = LocalDate.now()
    return when (date) {
        today -> "сегодня"
        today.minusDays(1) -> "вчера"
        else -> "${Fmt.weekdayShort(date)}, ${Fmt.dayMonth(date)}"
    }
}

@Composable
private fun CarChargeNote(carSessions: Int?, modifier: Modifier = Modifier) {
    Row(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(HubColors.SurfaceHigh.copy(alpha = 0.5f))
            .padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        StateDot(HubColors.Accent, size = 5.dp)
        Spacer(Modifier.width(7.dp))
        Text(
            text = when (carSessions) {
                null -> "Подсчёт сессий автомобиля…"
                0 -> "Сессий автомобиля пока нет: запись появится после завершения зарядки"
                else -> "Сессий автомобиля: $carSessions · ≈ — оценка энергии; <1% — ниже шага SOC; тип —: не определён"
            },
            color = HubColors.Muted,
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 21.sp, lineHeight = 30.sp)
        )
    }
}

/**
 * Сессия, которую автомобиль уже начал. Запись появится в журнале только после
 * тишины в десять минут: ступенчатая зарядка по расписанию и подогрев батареи
 * на морозе не должны превращаться в две строки.
 */
@Composable
private fun CarChargeBanner(anchor: ChargeAnchor) {
    val now by produceState(initialValue = System.currentTimeMillis()) {
        while (true) {
            delay(5_000L)
            value = System.currentTimeMillis()
        }
    }
    val clockMinutes = ((now - anchor.startedAt).coerceAtLeast(0L) / 60_000L).toInt()
    val minutes = anchor.carMinutes ?: clockMinutes
    val added = anchor.endSoc?.let { end ->
        anchor.startSoc?.let { start -> (end - start).coerceAtLeast(0) }
    }
    val accent = if (anchor.type == ChargeType.DC) HubColors.Cyan else HubColors.Accent
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(13.dp))
            .background(accent.copy(alpha = 0.055f))
            .border(1.dp, accent.copy(alpha = 0.18f), RoundedCornerShape(13.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        StateDot(accent, size = 7.dp, glow = true)
        Spacer(Modifier.width(9.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = "Зарядка идёт по данным автомобиля",
                color = HubColors.Text,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Medium
                )
            )
            Text(
                text = if (anchor.stoppedSince != null) {
                    "Ждём тишину: запись появится, если зарядка не возобновится"
                } else {
                    "Запись появится сама, когда зарядка замолчит на десять минут"
                },
                color = HubColors.Muted,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp, lineHeight = 24.sp)
            )
        }
        Text(
            text = buildString {
                append(added?.let { "+$it%" } ?: "SOC не читается")
                append(" · ")
                append(Fmt.duration(minutes))
                if (anchor.carMinutes != null) append(" по часам машины")
            },
            color = accent,
            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 21.sp),
            maxLines = 1
        )
    }
}

@Composable
private fun BatteryCard(
    battery: BatteryReadback,
    batteryKwh: Double,
    tariffPerKwh: Double,
    fullRange: Double?,
    rangeLoading: Boolean,
    modifier: Modifier = Modifier
) {
    val available = battery.usableKwh
    HubCard(modifier) {
        CardHead(
            title = "Батарея",
            eyebrow = "Сейчас",
            trailing = {
                Badge(
                    text = when {
                        battery.charging == true -> "зарядка"
                        battery.soc == null -> "нет данных"
                        else -> "норма"
                    },
                    color = if (battery.charging == true) HubColors.Accent else HubColors.Mint
                )
            }
        )
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = battery.soc?.toString() ?: "—",
                    color = HubColors.Text,
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontSize = 38.sp,
                        fontWeight = FontWeight.Light,
                        letterSpacing = (-1.5).sp
                    )
                )
                Text(
                    text = "%",
                    color = HubColors.TextDim,
                    style = MaterialTheme.typography.titleMedium.copy(fontSize = 21.sp),
                    modifier = Modifier.padding(bottom = 6.dp, start = 1.dp)
                )
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                BatteryRow("Запас хода", battery.rangeKm?.let { "$it км" } ?: "—")
                BatteryRow("Доступно", available?.let { "${Fmt.n1(it)} кВт·ч" } ?: "—")
                BatteryRow("Ёмкость", Fmt.kwh(batteryKwh))
            }
        }
        Spacer(Modifier.height(8.dp))
        BatteryBar(percent = battery.soc)
        Spacer(Modifier.height(8.dp))
        ChargeFlowRow(battery)
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(HubColors.SurfaceHigh.copy(alpha = 0.55f))
                .padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            com.ex2hub.ui.IconChip(icon = AppIcons.Bolt, size = 30.dp, iconSize = 17.dp)
            Spacer(Modifier.width(7.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text = "Ожидаемый при 100%",
                    color = HubColors.Muted,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp, lineHeight = 24.sp)
                )
                Text(
                    text = if (rangeLoading) "Расчёт…" else fullRange?.let { "≈ ${it.toInt()} км" } ?: "мало данных",
                    color = HubColors.Text,
                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 21.sp),
                    maxLines = 1
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "Тариф",
                    color = HubColors.Muted,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp, lineHeight = 24.sp)
                )
                Text(
                    text = "${Fmt.n2(tariffPerKwh)} р.",
                    color = HubColors.Text,
                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 21.sp)
                )
            }
        }
    }
}

/**
 * Зарядный сеанс глазами автомобиля. Напряжение и ток — вход от станции, а не
 * высоковольтный пакет, поэтому подписаны «сеть»: 211 В / 6,8 А на машине
 * измерены именно на стороне несущей сети.
 *
 * «Сессия» берётся из CHARGING_WORK_TIME — это часы автомобиля, и они живут только
 * пока зарядка идёт: после остановки прошивка держит последнее число, поэтому
 * приложение показывает время сессии лишь вместе с активным состоянием зарядки.
 * «Разрешён» и «задан» — границы тока, которые объявил сам автомобиль
 * (CHARGING_ALTERNATING_CURRENT_MIN/MAX/VAL): Capy отмечает, что диапазон надо брать у
 * машины, а не придумывать — интерфейс, придумавший себе 48 A, обещал то, чего эта
 * машина никогда не сообщала.
 */
@Composable
private fun ChargeFlowRow(battery: BatteryReadback) {
    val volts = battery.inputV
    val amps = battery.inputA
    val allowed = if (battery.currentMinA != null && battery.currentMaxA != null) {
        "${battery.currentMinA}…${battery.currentMaxA} A"
    } else {
        null
    }
    val parts = buildList {
        battery.flow?.let { add(it.title()) }
        battery.workMin?.let { add("сессия ${Fmt.duration(it)} по часам машины") }
        battery.estimateMin?.let { add("до конца ${Fmt.duration(it)}") }
        allowed?.let { add("ток разрешён $it") }
        battery.currentSetA?.let { add("задан ${it} A") }
        if (volts != null || amps != null) {
            val supply = listOfNotNull(
                volts?.let { "${Fmt.n1(it)} В" },
                amps?.let { "${Fmt.n1(it)} А" }
            ).joinToString(" / ")
            add("сеть $supply")
        }
    }
    if (parts.isEmpty()) return
    val accent = battery.flow?.color() ?: HubColors.TextDim
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(accent.copy(alpha = 0.08f))
            .padding(horizontal = 9.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        StateDot(accent, size = 5.dp)
        Spacer(Modifier.width(6.dp))
        Text(
            text = parts.joinToString(" · "),
            color = HubColors.TextDim,
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp, lineHeight = 24.sp),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
    Spacer(Modifier.height(8.dp))
}

@Composable
private fun BatteryRow(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = label,
            color = HubColors.Muted,
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp),
            modifier = Modifier.weight(1f),
            maxLines = 1
        )
        Text(
            text = value,
            color = HubColors.TextDim,
            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 21.sp),
            maxLines = 1
        )
    }
}

@Composable
private fun SessionsTableHeader() {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TableLabel("Дата", Modifier.width(88.dp))
        TableLabel("Место", Modifier.weight(1f), align = TextAlign.Start)
        TableLabel("Тип", Modifier.width(146.dp), align = TextAlign.End)
        TableLabel("Добавлено", Modifier.width(106.dp), align = TextAlign.End)
        TableLabel("Энергия", Modifier.width(110.dp), align = TextAlign.End)
        TableLabel("Время", Modifier.width(122.dp), align = TextAlign.End)
        TableLabel("Стоимость", Modifier.width(126.dp), align = TextAlign.End)
        Spacer(Modifier.width(40.dp))
    }
}

@Composable
private fun TableLabel(text: String, modifier: Modifier, align: TextAlign = TextAlign.Start) {
    Text(
        text = text,
        modifier = modifier,
        color = HubColors.Muted,
        style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp, letterSpacing = 0.15.sp),
        textAlign = align,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
    )
}

@Composable
private fun SessionTableRow(
    session: ChargeSession,
    tariff: Double,
    onDelete: () -> Unit
) {
    val accent = if (session.type == ChargeType.AC) HubColors.Accent else HubColors.Cyan
    Row(
        Modifier.fillMaxWidth().padding(vertical = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.width(88.dp)) {
            Text(
                text = Fmt.dayMonth(Stats.dateOf(session.startedAt)),
                color = HubColors.Text,
                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 21.sp),
                maxLines = 1
            )
            Text(
                text = Fmt.time(session.startedAt),
                color = HubColors.Muted,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp)
            )
        }
        Column(Modifier.weight(1f).padding(end = 8.dp)) {
            Text(
                text = session.place,
                color = HubColors.Text,
                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 21.sp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "${Fmt.n1(session.averagePowerKw)} кВт средняя",
                color = HubColors.Muted,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp),
                maxLines = 1
            )
        }
        Box(Modifier.width(146.dp), contentAlignment = Alignment.CenterEnd) {
            Badge(text = session.type.title(), color = accent, fontSize = 19.sp)
        }
        TableCell(Fmt.signedPercent(session.addedPercent), Modifier.width(106.dp))
        TableCell("${Fmt.n1(session.energyKwh)} кВт·ч", Modifier.width(110.dp))
        TableCell(Fmt.duration(session.durationMin), Modifier.width(122.dp))
        TableCell(Fmt.money(session.energyKwh * tariff), Modifier.width(126.dp))
        Box(Modifier.width(40.dp), contentAlignment = Alignment.CenterEnd) {
            HubIconButton(
                icon = AppIcons.Trash,
                contentDescription = "Удалить зарядку",
                onClick = onDelete,
                tint = HubColors.Muted
            )
        }
    }
}

@Composable
private fun TableCell(text: String, modifier: Modifier) {
    Text(
        text = text,
        modifier = modifier,
        color = HubColors.TextDim,
        style = MaterialTheme.typography.bodyMedium.copy(fontSize = 21.sp),
        textAlign = TextAlign.End,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
    )
}
