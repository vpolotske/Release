package com.ex2hub.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ex2hub.ui.theme.HubColors

@Immutable
data class PeriodColumn(val caption: String, val width: Dp)

@Immutable
data class PeriodLine(val label: String, val values: List<String>)

/**
 * Неделя и месяц в одной карточке: строки читаются слева направо по одним и тем же
 * колонкам. Широкий экран — таблица, узкий — блоки периода, иначе цифры ушли бы за карточку.
 */
@Composable
fun PeriodSummaryCard(
    title: String,
    eyebrow: String,
    badge: String,
    columns: List<PeriodColumn>,
    lines: List<PeriodLine>,
    wide: Boolean,
    modifier: Modifier = Modifier
) {
    HubCard(modifier) {
        CardHead(
            title = title,
            eyebrow = eyebrow,
            trailing = { Badge(text = badge, color = HubColors.TextDim) }
        )
        Spacer(Modifier.height(10.dp))
        if (wide) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Период",
                    color = HubColors.Muted,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 18.sp,
                        letterSpacing = 0.15.sp
                    ),
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                columns.forEach { column ->
                    Text(
                        text = column.caption,
                        color = HubColors.Muted,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontSize = 18.sp,
                            letterSpacing = 0.15.sp
                        ),
                        textAlign = TextAlign.End,
                        modifier = Modifier.width(column.width),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            lines.forEach { line ->
                PeriodTableRow(line, columns)
            }
        } else {
            lines.forEachIndexed { index, line ->
                if (index > 0) Spacer(Modifier.height(8.dp))
                Text(
                    text = line.label,
                    color = HubColors.Text,
                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 21.sp),
                    maxLines = 1
                )
                columns.forEachIndexed { column, spec ->
                    Row(
                        Modifier.fillMaxWidth().padding(top = 2.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = spec.caption,
                            color = HubColors.Muted,
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp),
                            modifier = Modifier.weight(1f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = line.values.getOrElse(column) { "—" },
                            color = HubColors.Text,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontSize = 21.sp,
                                fontWeight = FontWeight.Medium
                            ),
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PeriodTableRow(line: PeriodLine, columns: List<PeriodColumn>) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = line.label,
            color = HubColors.TextDim,
            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 21.sp),
            modifier = Modifier.weight(1f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        columns.forEachIndexed { index, column ->
            Text(
                text = line.values.getOrElse(index) { "—" },
                color = HubColors.Text,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Medium
                ),
                textAlign = TextAlign.End,
                modifier = Modifier.width(column.width),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
