package com.ex2hub.ui.screens

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ex2hub.ui.AppIcons
import com.ex2hub.ui.HubButton
import com.ex2hub.ui.HubButtonStyle
import com.ex2hub.ui.InstalledApps
import com.ex2hub.ui.LaunchableApp
import com.ex2hub.ui.theme.HubColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Все приложения ГУ поверх рабочего стола: без него лаунчер оставил бы только ярлыки дока. */
@Composable
fun AllAppsScreen(onClose: () -> Unit) {
    val context = LocalContext.current
    val apps by produceState<List<LaunchableApp>?>(initialValue = null) {
        value = withContext(Dispatchers.IO) { InstalledApps.all(context) }
    }
    val isHome = remember { InstalledApps.isDefaultHome(context) }

    Column(
        Modifier
            .fillMaxSize()
            .background(HubColors.Bg)
            // Касания не должны проваливаться в рабочий стол под панелью.
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .padding(horizontal = 22.dp, vertical = 16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = "Все приложения",
                    color = HubColors.Text,
                    style = MaterialTheme.typography.titleLarge.copy(fontSize = 20.sp)
                )
                Text(
                    text = if (isHome) {
                        "EX2 HUB выбран рабочим столом. Вернуть штатный — кнопкой справа."
                    } else {
                        "Чтобы EX2 HUB открывался при включении ГУ, выберите его рабочим столом."
                    },
                    color = HubColors.Muted,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp)
                )
            }
            HubButton(
                text = if (isHome) "Сменить рабочий стол" else "Сделать рабочим столом",
                onClick = {
                    if (!InstalledApps.openHomeSettings(context)) {
                        Toast.makeText(context, "Настройки рабочего стола не открылись", Toast.LENGTH_SHORT).show()
                    }
                },
                icon = AppIcons.Home,
                style = HubButtonStyle.Ghost
            )
            Spacer(Modifier.width(10.dp))
            HubButton(text = "Закрыть", onClick = onClose, icon = AppIcons.Close, style = HubButtonStyle.Ghost)
        }
        Spacer(Modifier.height(14.dp))

        val list = apps
        if (list == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = HubColors.Accent, strokeWidth = 2.dp)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(204.dp),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp),
                horizontalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                items(list, key = { it.packageName }) { app ->
                    AppTile(app) {
                        if (InstalledApps.launch(context, app.packageName)) {
                            onClose()
                        } else {
                            Toast.makeText(context, "«${app.label}» не запускается", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AppTile(app: LaunchableApp, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val icon = app.icon
        if (icon != null) {
            Image(
                bitmap = icon,
                contentDescription = null,
                modifier = Modifier
                    .size(168.dp)
                    .clip(RoundedCornerShape(28.dp))
            )
        } else {
            Box(
                Modifier
                    .size(168.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(HubColors.SurfaceHigh),
                contentAlignment = Alignment.Center
            ) {
                Icon(AppIcons.Apps, contentDescription = null, tint = HubColors.TextDim, modifier = Modifier.size(72.dp))
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            text = app.label,
            color = HubColors.TextDim,
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 16.sp),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
