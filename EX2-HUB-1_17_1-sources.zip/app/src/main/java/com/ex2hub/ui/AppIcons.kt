package com.ex2hub.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.graphics.vector.group
import androidx.compose.ui.unit.dp

object AppIcons {
    private const val STROKE = 1.65f

    private inline fun vector(name: String, block: ImageVector.Builder.() -> Unit): ImageVector =
        ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f).apply(block).build()

    /** Один контур: обводка заданной толщины либо заливка. */
    private fun ImageVector.Builder.paint(
        d: String,
        width: Float? = STROKE,
        fill: Boolean = false
    ): ImageVector.Builder = addPath(
        pathData = PathParser().parsePathString(d).toNodes(),
        fill = if (fill) SolidColor(Color.White) else null,
        stroke = if (!fill) SolidColor(Color.White) else null,
        strokeLineWidth = width ?: 0f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round
    )

    private fun stroke(name: String, vararg paths: String): ImageVector = vector(name) {
        paths.forEach { paint(it) }
    }

    private fun filled(name: String, vararg paths: String): ImageVector = vector(name) {
        paths.forEach { paint(it, fill = true) }
    }

    val Bolt by lazy {
        filled("Bolt", "M13.2 2 4.5 14h6.1L9.8 22l8.7-12h-6.1l.8-8Z")
    }
    val BoltOutline by lazy {
        vector("BoltOutline") {
            paint("M13.4 2.6 5.4 13.8h5.5L10.3 21.4l8.3-11.6h-5.6l.4-7.2Z", 1.7f)
        }
    }
    val Home by lazy {
        vector("Home") {
            paint("M3.4 10.5 12 3.3l8.6 7.2", 1.7f)
            paint(
                "M5.3 9.5v8.6a2.1 2.1 0 0 0 2.1 2.1h9.2a2.1 2.1 0 0 0 2.1-2.1V9.5",
                1.7f
            )
        }
    }
    val Route by lazy {
        vector("Route") {
            paint("M5.2 18.6a2.4 2.4 0 1 0 0-4.8 2.4 2.4 0 0 0 0 4.8Z", 1.7f)
            paint("M18.8 8.2a2.4 2.4 0 1 0 0-4.8 2.4 2.4 0 0 0 0 4.8Z", 1.7f)
            paint("M5.2 13.8v-3a2.4 2.4 0 0 1 2.4-2.4h8.6", 1.7f)
        }
    }
    val Plug by lazy {
        vector("Plug") {
            paint("M9.2 2.8v5.4M14.8 2.8v5.4", 1.7f)
            paint("M6.8 8.2h10.4v3.4a5.2 5.2 0 0 1-10.4 0V8.2Z", 1.7f)
            paint("M12 16.8V21", 1.7f)
            paint("M10.3 21h3.4", 1.7f)
        }
    }
    val Settings by lazy {
        vector("Settings") {
            paint("M3.4 8.4h8.7M16.9 8.4h3.7", 1.7f)
            paint("M12.2 8.4a2.3 2.3 0 1 0 4.6 0a2.3 2.3 0 1 0-4.6 0Z", 1.7f)
            paint("M3.4 15.6h3.7M11.9 15.6h8.7", 1.7f)
            paint("M7.2 15.6a2.3 2.3 0 1 0 4.6 0a2.3 2.3 0 1 0-4.6 0Z", 1.7f)
        }
    }
    val Sliders by lazy {
        stroke(
            "Sliders",
            "M4 6h9M17 6h3M4 12h3M11 12h9M4 18h11M19 18h1",
            "M15 6a2 2 0 1 0 4 0 2 2 0 0 0-4 0Z",
            "M9 12a2 2 0 1 0 4 0 2 2 0 0 0-4 0Z",
            "M17 18a2 2 0 1 0 4 0 2 2 0 0 0-4 0Z"
        )
    }
    val Navigation by lazy {
        stroke("Navigation", "m3 11 19-8-8 19-2-9-9-2Z")
    }
    val NavigationFilled by lazy {
        filled("NavigationFilled", "M3.5 11.1 21.4 3.3l-7.8 18-2.5-7.6-7.6-2.6Z")
    }
    val Music by lazy {
        stroke("Music", "M9 18V5l12-2v13", "M6 18a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z", "M18 16a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z")
    }
    val Phone by lazy {
        stroke(
            "Phone",
            "M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.9a2 2 0 0 1-.5 2.1L8.1 10a16 16 0 0 0 6 6l1.3-1.2a2 2 0 0 1 2.1-.5c.9.3 1.9.6 2.9.7a2 2 0 0 1 1.6 1.9Z"
        )
    }
    val Camera by lazy {
        stroke(
            "Camera",
            "M14.5 5h-5L8 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-4l-1.5-2Z",
            "M12 17a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z"
        )
    }
    val Bluetooth by lazy {
        stroke("Bluetooth", "m7 7 10 10-5 4V3l5 4L7 17")
    }
    val Plus by lazy { stroke("Plus", "M12 5v14M5 12h14") }
    val Close by lazy { stroke("Close", "M18 6 6 18M6 6l12 12") }
    val Check by lazy { stroke("Check", "m5 12 4.5 4.5L19 7") }
    val Refresh by lazy {
        stroke(
            "Refresh",
            "M20 7v5h-5",
            "M4 17v-5h5",
            "M6.1 9a7 7 0 0 1 11.4-2L20 9M4 15l2.5 2a7 7 0 0 0 11.4-2"
        )
    }
    val Car by lazy {
        stroke(
            "Car",
            "m5 11 1.6-4.2A2 2 0 0 1 8.5 5h7a2 2 0 0 1 1.9 1.8L19 11",
            "M3 17v-3.2A2.8 2.8 0 0 1 5.8 11h12.4A2.8 2.8 0 0 1 21 13.8V17",
            "M3 17h18",
            "M7 19a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z",
            "M17 19a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"
        )
    }
    /** Силуэт спереди: шапка карточки «Режим движения». */
    val CarFront by lazy {
        vector("CarFront") {
            paint("M4.4 12.4 6 8.3a2.7 2.7 0 0 1 2.5-1.8h7a2.7 2.7 0 0 1 2.5 1.8l1.6 4.1", 1.6f)
            paint("M3.4 13.1h17.2v2.4a1.9 1.9 0 0 1-1.9 1.9H5.3a1.9 1.9 0 0 1-1.9-1.9z", 1.6f)
            paint("M6.7 17.4v1.5M17.3 17.4v1.5", 1.6f)
            paint("M7.1 10.3h2M14.9 10.3h2", 1.6f)
        }
    }
    val Database by lazy {
        stroke(
            "Database",
            "M12 9a8 3.5 0 1 0 0-7 8 3.5 0 0 0 0 7Z",
            "M4 5.5v6c0 1.9 3.6 3.5 8 3.5s8-1.6 8-3.5v-6",
            "M4 11.5v6c0 1.9 3.6 3.5 8 3.5s8-1.6 8-3.5v-6"
        )
    }
    val Terminal by lazy {
        stroke("Terminal", "M5 4h14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Z", "m7 9 3 3-3 3M13 15h4")
    }
    val Edit by lazy {
        stroke("Edit", "M12 20h9", "M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z")
    }
    val Chevron by lazy { stroke("Chevron", "m9 18 6-6-6-6") }
    val ChevronLeft by lazy { stroke("ChevronLeft", "m15 18-6-6 6-6") }
    val Lock by lazy {
        stroke("Lock", "M6 11h12v9H6Z", "M8.5 11V8a3.5 3.5 0 0 1 7 0v3")
    }
    val Headlight by lazy {
        stroke("Headlight", "M11 6h-1c-3.5 0-6 2.7-6 6s2.5 6 6 6h1Z", "M15 8h5M15 12h5M15 16h5")
    }
    val ChevronDown by lazy { stroke("ChevronDown", "m6 9 6 6 6-6") }
    val ArrowUpRight by lazy { stroke("ArrowUpRight", "M7 17 17 7", "M8 7h9v9") }
    val Battery by lazy {
        stroke(
            "Battery",
            "M5 7h14a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2Z",
            "M22 11v2",
            "M7 10v4M11 10v4"
        )
    }
    private const val BATTERY_SHELL =
        "M5 7.4h11.8a2.4 2.4 0 0 1 2.4 2.4v4.4a2.4 2.4 0 0 1-2.4 2.4H5a2.4 2.4 0 0 1-2.4-2.4V9.8A2.4 2.4 0 0 1 5 7.4Z"
    private const val BATTERY_NUB = "M21.4 10.3v3.4"

    val BatteryLow by lazy {
        vector("BatteryLow") {
            paint(BATTERY_SHELL, 1.6f)
            paint(BATTERY_NUB, 2.2f)
            paint("M13.9 15.3 15.3 8.7h1.4l-1.4 6.6z", fill = true)
        }
    }
    val BatteryMid by lazy {
        vector("BatteryMid") {
            paint(BATTERY_SHELL, 1.6f)
            paint(BATTERY_NUB, 2.2f)
            paint("M6 15.3 7.4 8.7h1.6L7.6 15.3zM10.2 15.3l1.4-6.6h1.6l-1.4 6.6z", fill = true)
        }
    }
    val BatteryHigh by lazy {
        vector("BatteryHigh") {
            paint(BATTERY_SHELL, 1.6f)
            paint(BATTERY_NUB, 2.2f)
            paint(
                "M5.4 15.3 6.8 8.7h1.4l-1.4 6.6zM9.2 15.3l1.4-6.6h1.4l-1.4 6.6zM13 15.3l1.4-6.6h1.4l-1.4 6.6z",
                fill = true
            )
        }
    }
    val Gauge by lazy {
        stroke(
            "Gauge",
            "m12 14 4.2-5.2",
            "M20.5 17a9 9 0 1 0-17 0",
            "M12 14a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z"
        )
    }
    val Clock by lazy {
        stroke("Clock", "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Z", "M12 7v5l3.5 2")
    }
    val Coin by lazy {
        stroke(
            "Coin",
            "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Z",
            "M15 9.2c-.6-.8-1.7-1.2-3-1.2-1.8 0-3 .9-3 2.2 0 1.4 1.3 1.8 3 2.2 1.9.4 3.2.9 3.2 2.4 0 1.4-1.3 2.4-3.2 2.4-1.4 0-2.6-.5-3.2-1.5",
            "M12 6v12"
        )
    }
    val Calendar by lazy {
        stroke(
            "Calendar",
            "M5 5h14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2Z",
            "M16 3v4M8 3v4M3 10h18"
        )
    }
    val Alert by lazy {
        stroke(
            "Alert",
            "M10.3 3.6 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.6a2 2 0 0 0-3.4 0Z",
            "M12 9v4M12 17h.01"
        )
    }
    val Info by lazy {
        stroke("Info", "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Z", "M12 11v5M12 8h.01")
    }
    val Shield by lazy {
        stroke("Shield", "M12 22s8-3.5 8-10V5l-8-3-8 3v7c0 6.5 8 10 8 10Z", "m8.5 11.5 2.5 2.5 4.5-5")
    }
    val Leaf by lazy {
        vector("Leaf") {
            paint(
                "M20.2 3.8C10.6 3.8 4.4 8.4 4.4 14.6a4.9 4.9 0 0 0 4.9 4.9c6.3 0 10.9-6.2 10.9-15.7Z",
                1.6f
            )
            paint("M4.2 21c2.1-5.9 5.9-9.3 11.4-11.4", 1.6f)
        }
    }
    /** Флажок с шахматной клеткой — спортивный режим. */
    val Flag by lazy {
        vector("Flag") {
            paint("M5.5 21V3.6", 1.5f)
            paint(
                "M5.5 4.6c2.4-1.3 4.2 1.4 6.6 0s4.2-1.3 6.6 0v6.1c-2.4 1.4-4.2-1.3-6.6 0s-4.2 1.3-6.6 0Z",
                1.5f
            )
            paint(
                "M6.1 5.4h2.5v2H6.1zM11 5.3h2.5v2H11zM14.5 5.4h2.4v2h-2.4zM8.6 7.4h2.5v2H8.6zM13.2 7.5h2.5v2h-2.5zM6.1 9.4h2.5v2H6.1zM11 9.3h2.5v2H11z",
                fill = true
            )
        }
    }
    val Trash by lazy {
        stroke("Trash", "M4 7h16M10 11v6M14 11v6", "M6 7l1 13h10l1-13M9 7V4h6v3")
    }
    /** Стрелка над лотком: вниз — выгрузить, вверх — взять файл обратно. */
    val Download by lazy {
        vector("Download") {
            paint("M12 3.8v10.8", 1.7f)
            paint("m7.4 10 4.6 4.6L16.6 10", 1.7f)
            paint("M4.4 17.4v1.4a2 2 0 0 0 2 2h11.2a2 2 0 0 0 2-2v-1.4", 1.7f)
        }
    }
    val Upload by lazy {
        vector("Upload") {
            paint("M12 14.6V3.8", 1.7f)
            paint("m7.4 8.2 4.6-4.6 4.6 4.6", 1.7f)
            paint("M4.4 17.4v1.4a2 2 0 0 0 2 2h11.2a2 2 0 0 0 2-2v-1.4", 1.7f)
        }
    }
    val Play by lazy { filled("Play", "M8 5v14l11-7Z") }
    val Stop by lazy {
        filled("Stop", "M8 6h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2Z")
    }
    val Location by lazy {
        stroke(
            "Location",
            "M12 21s7-6.1 7-11a7 7 0 1 0-14 0c0 4.9 7 11 7 11Z",
            "M12 12.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z"
        )
    }
    val Thermometer by lazy {
        stroke(
            "Thermometer",
            "M14 14.8V5a2 2 0 0 0-4 0v9.8a4 4 0 1 0 4 0Z",
            "M12 9v6"
        )
    }
    val Minus by lazy { stroke("Minus", "M5 12h14") }
    val Power by lazy {
        stroke("Power", "M12 3v8", "M7.8 6.3a7 7 0 1 0 8.4 0")
    }
    val Snowflake by lazy {
        vector("Snowflake") {
            paint("M12 2.9v18.2", 1.7f)
            paint("m4.3 7.4 15.4 9", 1.7f)
            paint("m19.7 7.4-15.4 9", 1.7f)
            paint("M9.5 4.7 12 7.2l2.5-2.5M9.5 19.3 12 16.8l2.5 2.5M4.9 10.6l3.3.9-.9-3.3M19.1 13.4l-3.3-.9.9 3.3", 1.7f)
        }
    }
    val Wind by lazy {
        stroke(
            "Wind",
            "M3 9h9.5A2.5 2.5 0 1 0 10 6.5",
            "M3 13.5h12a2.5 2.5 0 1 1-2.5 2.5",
            "M3 18h7"
        )
    }

    /** Три лопасти вентилятора; лопасти нарисованы заливкой, как в макете. */
    val Fan by lazy {
        vector("Fan") {
            val petal = "M8.35 6.7a3.65 5.3 0 1 0 7.3 0a3.65 5.3 0 1 0-7.3 0Z"
            listOf(0f, 120f, 240f).forEach { angle ->
                group(rotate = angle, pivotX = 12f, pivotY = 12f) { paint(petal, fill = true) }
            }
            paint("M10.7 12a1.3 1.3 0 1 0 2.6 0a1.3 1.3 0 1 0-2.6 0Z", fill = true)
        }
    }
    val HeatWaves by lazy {
        vector("HeatWaves") {
            paint("M7.4 17.9c1.9-1.6 1.9-3.4 0-5s-1.9-3.4 0-5", 1.15f)
            paint("M12 18.4c2.1-1.8 2.1-3.8 0-5.6s-2.1-3.8 0-5.6", 1.15f)
            paint("M16.6 17.9c1.9-1.6 1.9-3.4 0-5s-1.9-3.4 0-5", 1.15f)
        }
    }
    private const val WINDSCREEN =
        "M5.4 9.3C6.2 7.6 8.9 6.9 12 6.9s5.8.7 6.6 2.4l-2.7 4c-.3.6-.9 1-1.6 1-1.7.55-3.4.55-5.1 0-.7 0-1.3-.4-1.6-1Z"
    private const val WINDSCREEN_ROWS =
        "M9.9 9.7c.55.6.55 1.25 0 1.85s-.55 1.25 0 1.85M12 9.5c.55.6.55 1.25 0 1.85s-.55 1.25 0 1.85M14.1 9.7c.55.6.55 1.25 0 1.85s-.55 1.25 0 1.85"
    private const val WINDSCREEN_DRIPS =
        "M10.5 14.5c.6.45.6.9 0 1.35s-.6.9 0 1.35M13.5 14.5c.6.45.6.9 0 1.35s-.6.9 0 1.35"
    private const val FOOT =
        "M9.65 0C9.4.7 9 1.6 8.6 2.4 8.2 3.3 7.9 4 7.7 4.55L3.2 4.4C2.2 4.35 1.3 4.5.7 4.85.15 5.2 0 5.9.25 6.4.5 6.9 1.2 7.2 2.2 7.35 3.5 7.55 4.8 8 6 8.75 6.9 9.3 7.4 9.9 7.9 10.5 8.3 11 9 11.2 9.6 11 10.2 10.8 10.5 10.2 10.6 9.5 10.8 8.4 11 7.2 11.3 6.1 11.6 4.8 12 3.4 12.6 2.3 12.9 1.7 13.1 1.2 12.9.8 12.6.35 12 .15 11.4.25"

    val Defrost by lazy {
        vector("Defrost") {
            paint(WINDSCREEN, 0.62f)
            paint(WINDSCREEN_ROWS, 0.62f)
            paint(WINDSCREEN_DRIPS, 0.62f)
        }
    }
    val RearDefrost by lazy {
        vector("RearDefrost") {
            paint("M8.1 6.9h7.8a2.1 2.1 0 0 1 2.1 2.1v3.4a2.1 2.1 0 0 1-2.1 2.1H8.1A2.1 2.1 0 0 1 6 12.4V9a2.1 2.1 0 0 1 2.1-2.1Z", 0.62f)
            paint("M8.8 8.2c1.4.85 1.4 1.9 0 2.75s-1.4 1.9 0 2.75 1.4 1.9 0 2.75", 0.62f)
            paint("M12 8.6c1.4.85 1.4 1.9 0 2.75s-1.4 1.9 0 2.75 1.4 1.9 0 2.75", 0.62f)
            paint("M15.2 8.2c1.4.85 1.4 1.9 0 2.75s-1.4 1.9 0 2.75 1.4 1.9 0 2.75", 0.62f)
        }
    }
    val AirFlow by lazy {
        vector("AirFlow") {
            paint("M6.2 13.4a3.1 3.1 0 1 0 6.2 0a3.1 3.1 0 1 0-6.2 0Z", fill = true)
            paint("M14 8.2a2.2 2.2 0 1 0 4.4 0a2.2 2.2 0 1 0-4.4 0Z", fill = true)
            paint("M15.2 16.3a1.7 1.7 0 1 0 3.4 0a1.7 1.7 0 1 0-3.4 0Z", fill = true)
        }
    }
    val AirGlass by lazy {
        vector("AirGlass") {
            paint("M1.9 11.9h4.7m-1.4-1.4 1.4 1.4-1.4 1.4", 0.62f)
            group(translationX = 3.5f) {
                paint(WINDSCREEN, 0.62f)
                paint(WINDSCREEN_ROWS, 0.62f)
                paint(WINDSCREEN_DRIPS, 0.62f)
            }
        }
    }
    val AirFace by lazy {
        vector("AirFace") {
            paint("M3 9.2h4.6m-1.4-1.4 1.4 1.4-1.4 1.4", 0.62f)
            paint("M19.65 7.5a.95.95 0 1 0 1.9 0a.95.95 0 1 0-1.9 0Z", fill = true)
            paint("M19.9 9.6 18.4 13.8 13.2 13.8 11.1 16.6", 1.55f)
        }
    }
    val AirFeet by lazy {
        vector("AirFeet") {
            paint("M4.35 9.6v4.8M3.35 13.2l1 1.4 1-1.4", 0.62f)
            group(translationX = 7.4f, translationY = 6.2f, scaleX = 1.03f, scaleY = 1.03f) {
                paint(FOOT, 0.62f)
            }
        }
    }
    val AirGlassFeet by lazy {
        vector("AirGlassFeet") {
            group(
                translationX = -3.6f,
                translationY = 2.85f,
                scaleX = 0.8f,
                scaleY = 0.8f
            ) {
                paint(WINDSCREEN, 0.62f)
                paint(WINDSCREEN_ROWS, 0.62f)
                paint(WINDSCREEN_DRIPS, 0.62f)
            }
            paint("M11 6.6c1.6.6 2.9 1.9 3.6 3.6m-2.2-1 2.2 1-2.3.6", 0.7f)
            group(
                translationX = 12.4f,
                translationY = 10.4f,
                scaleX = 0.7f,
                scaleY = 0.7f,
                rotate = -14f
            ) {
                paint(FOOT, 0.62f)
            }
        }
    }
    val Seat by lazy {
        vector("Seat") {
            paint("M13.9 4.6a2.25 2.25 0 1 0 4.5 0a2.25 2.25 0 1 0-4.5 0Z", 0.9f)
            paint("M14.6 6.85c-.35 1.25-.35 2.5-.1 3.7l.55 3.2h4.5l-.95-4.5c-.3-1.4-1.25-2.4-2.55-2.4h-1.45Z", 0.9f)
            paint("M15.55 8.35c.8.85 1.3 1.95 1.45 3.1l.25 1.7", 0.9f)
            paint("M6.7 13.7h6.7a2 2 0 0 1 0 4H4.6", 0.9f)
            paint("M5.6 20.1h9.1", 0.9f)
        }
    }
    val SeatHeat by lazy {
        vector("SeatHeat") {
            paint(
                "M8.8 19.4V10a2.7 2.7 0 0 1 2.7-2.7h.4a2.7 2.7 0 0 1 2.7 2.7v5.6h3.2a2.1 2.1 0 0 1 2.1 2.1v1.7",
                1.55f
            )
            paint("M6.9 19.4h14.2", 1.55f)
            paint("M12.2 5.1c0-1.2 1.1-1.2 1.1-2.4", 1.55f)
        }
    }
    val Wheel by lazy {
        vector("Wheel") {
            paint("M3.4 11.8a8.6 8.6 0 1 0 17.2 0a8.6 8.6 0 1 0-17.2 0Z", 1.2f)
            paint("M3.4 10.4h5M15.6 10.4h5", 1.2f)
            paint("M9.7 10.4a2.3 1.7 0 1 0 4.6 0a2.3 1.7 0 1 0-4.6 0Z", 1.2f)
            paint("M11.2 12.2c-.2 2.3-1.2 4.4-2.9 5.9M12.8 12.2c.2 2.3 1.2 4.4 2.9 5.9", 1.2f)
        }
    }
    val Flame by lazy {
        stroke(
            "Flame",
            "M12 21c-3.5 0-6-2.4-6-5.6 0-3.6 3-5.4 3.5-9.4 2.6 1.6 4.2 4 4.5 6.3 1-.7 1.6-1.9 1.8-3.1 1.5 1.5 2.2 3.5 2.2 5.5 0 3.6-2.5 6.3-6 6.3Z"
        )
    }
    val Apps by lazy {
        vector("Apps") {
            paint("M5.5 3.9h3.4a1.6 1.6 0 0 1 1.6 1.6v3.4a1.6 1.6 0 0 1-1.6 1.6H5.5a1.6 1.6 0 0 1-1.6-1.6V5.5a1.6 1.6 0 0 1 1.6-1.6Z", 1.9f)
            paint("M15.1 3.9h3.4a1.6 1.6 0 0 1 1.6 1.6v3.4a1.6 1.6 0 0 1-1.6 1.6h-3.4a1.6 1.6 0 0 1-1.6-1.6V5.5a1.6 1.6 0 0 1 1.6-1.6Z", 1.9f)
            paint("M5.5 13.5h3.4a1.6 1.6 0 0 1 1.6 1.6v3.4a1.6 1.6 0 0 1-1.6 1.6H5.5a1.6 1.6 0 0 1-1.6-1.6v-3.4a1.6 1.6 0 0 1 1.6-1.6Z", 1.9f)
            paint("M15.1 13.5h3.4a1.6 1.6 0 0 1 1.6 1.6v3.4a1.6 1.6 0 0 1-1.6 1.6h-3.4a1.6 1.6 0 0 1-1.6-1.6v-3.4a1.6 1.6 0 0 1 1.6-1.6Z", 1.9f)
        }
    }

    /** Передний багажник: чемодан с ручкой, как на кнопке макета. */
    val Frunk by lazy {
        vector("Frunk") {
            paint("M5.8 8.4h12.4a2.2 2.2 0 0 1 2.2 2.2v5.6a2.2 2.2 0 0 1-2.2 2.2H5.8a2.2 2.2 0 0 1-2.2-2.2V10.6a2.2 2.2 0 0 1 2.2-2.2Z", 1.7f)
            paint("M9 8.4V6.6A1.6 1.6 0 0 1 10.6 5h2.8A1.6 1.6 0 0 1 15 6.6v1.8", 1.7f)
            paint("M9.6 13.4h4.8", 1.7f)
        }
    }
}
