package com.ex2hub.ui

import androidx.compose.runtime.Immutable
import com.ex2hub.data.ChargeAnchor
import com.ex2hub.data.ChargeFlow
import com.ex2hub.data.ChargeSession
import com.ex2hub.data.CheckStatus
import com.ex2hub.data.ClimateChange
import com.ex2hub.data.ClimatePreset
import com.ex2hub.data.ClimateWriteResult
import com.ex2hub.data.DriveMode
import com.ex2hub.data.Profile
import com.ex2hub.data.RegenLevel
import com.ex2hub.data.SourceCheck
import com.ex2hub.data.SourceMode
import com.ex2hub.data.TrackingInfo
import com.ex2hub.data.Trip
import com.ex2hub.data.TripAnchor
import com.ex2hub.data.VehicleSnapshot

@Immutable
data class HubUiState(
    val profile: Profile = Profile(),
    val vehicle: VehicleSnapshot = VehicleSnapshot(),
    val trips: List<Trip> = emptyList(),
    val sessions: List<ChargeSession> = emptyList(),
    val checks: Map<SourceMode, SourceCheck> = emptyMap(),
    val probeLog: String = "",
    val probeRunning: Boolean = false,
    /** Сериализация всей команды, включая чтение результата; не подсветка группы. */
    val climateBusy: Boolean = false,
    /** Только нажатая кнопка; null для сценария и когда команды нет. */
    val activeClimateChange: ClimateChange? = null,
    /** Только выполняемый сценарий; взаимоисключается с activeClimateChange. */
    val activeClimatePreset: ClimatePreset? = null,
    /** Сценарий, включённый приложением: подсвечивает кнопку, пока чтение ему не противоречит. */
    val climatePresetEngaged: ClimatePreset? = null,
    val climateWrite: ClimateWriteResult? = null,
    /** Идёт запись режима движения или рекуперации, включая всю сверку чтением. */
    val driveBusy: Boolean = false,
    /** Запрошенная кнопка режима, не подтверждение; null при ручном выборе рекуперации. */
    val activeDriveMode: DriveMode? = null,
    /** Запрошенная кнопка рекуперации; восстановление может отмечать обе кнопки. */
    val activeRegen: RegenLevel? = null,
    /** Идёт запись в кузов (открытие багажников). */
    val bodyBusy: Boolean = false,
    /** Заряд растёт по-настоящему и экран виден: только тогда пульсирует полоса заряда. */
    val socRising: Boolean = false,
    /** Выгрузка или восстановление журнала выполняется: кнопки блокируются на время записи файла. */
    val exportBusy: Boolean = false,
    /** Каталог, куда пишутся CSV и копия — показывается в настройках, чтобы файл можно было найти. */
    val exportPath: String = "",
    val tracking: TrackingInfo? = null,
    /** Поездка и зарядка, которые автомат уже начал по сигналам автомобиля. */
    val journalTrip: TripAnchor? = null,
    val journalCharge: ChargeAnchor? = null
) {
    fun check(mode: SourceMode): SourceCheck =
        checks[mode] ?: SourceCheck(status = CheckStatus.UNKNOWN, summary = "не проверен")

    val activeCheck: SourceCheck
        get() = check(profile.source)

    val isLiveFallback: Boolean
        get() = vehicle.isFallback && profile.source != SourceMode.DEMO
}

/**
 * Экран поездок видит только журнал и настройки расчёта. Телеметрия меняется
 * ежесекундно, и без этого снимка Compose перерисовывал таблицу на каждое
 * обновление скорости — отсюда были рывки при прокрутке.
 */
@Immutable
data class TripsPageState(
    val trips: List<Trip> = emptyList(),
    val tariffPerKwh: Double = 0.0,
    val batteryKwh: Double = 0.0,
    val source: SourceMode = SourceMode.DEMO,
    val tracking: TrackingInfo? = null,
    val journalTrip: TripAnchor? = null
)

/** Телеметрия батареи без полей, которые обновляются каждым опросом. */
@Immutable
data class BatteryReadback(
    val soc: Int? = null,
    val rangeKm: Int? = null,
    val usableKwh: Double? = null,
    val charging: Boolean? = null,
    val flow: ChargeFlow? = null,
    val workMin: Int? = null,
    val estimateMin: Int? = null,
    val inputV: Double? = null,
    val inputA: Double? = null,
    val currentSetA: Int? = null,
    val currentMinA: Int? = null,
    val currentMaxA: Int? = null
)

@Immutable
data class ChargingPageState(
    val sessions: List<ChargeSession> = emptyList(),
    val trips: List<Trip> = emptyList(),
    val tariffPerKwh: Double = 0.0,
    val batteryKwh: Double = 0.0,
    val source: SourceMode = SourceMode.DEMO,
    val journalCharge: ChargeAnchor? = null,
    val battery: BatteryReadback = BatteryReadback()
)

fun HubUiState.tripsPage(): TripsPageState = TripsPageState(
    trips = trips,
    tariffPerKwh = profile.tariffPerKwh,
    batteryKwh = profile.batteryKwh,
    source = profile.source,
    tracking = tracking,
    journalTrip = journalTrip
)

fun HubUiState.chargingPage(): ChargingPageState = ChargingPageState(
    sessions = sessions,
    trips = trips,
    tariffPerKwh = profile.tariffPerKwh,
    batteryKwh = profile.batteryKwh,
    source = profile.source,
    journalCharge = journalCharge,
    battery = vehicle.batteryReadback()
)

fun VehicleSnapshot.batteryReadback(): BatteryReadback = BatteryReadback(
    soc = soc,
    rangeKm = rangeKm,
    usableKwh = usableKwh,
    charging = isCharging,
    flow = chargeFlow,
    workMin = chargeWorkMin,
    estimateMin = chargeEstimateMin,
    inputV = chargeInputV,
    inputA = chargeInputA,
    currentSetA = acCurrentSetA,
    currentMinA = acCurrentMinA,
    currentMaxA = acCurrentMaxA
)
