package com.ex2hub.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ex2hub.data.Fmt
import com.ex2hub.data.RecordSource
import com.ex2hub.data.SourceMode
import com.ex2hub.data.Stats
import com.ex2hub.data.Trip
import com.ex2hub.data.TripAnchor
import com.ex2hub.ui.AppIcons
import com.ex2hub.ui.Badge
import com.ex2hub.ui.BatteryBar
import com.ex2hub.ui.CardHead
import com.ex2hub.ui.EmptyState
import com.ex2hub.ui.Eyebrow
import com.ex2hub.ui.HubButton
import com.ex2hub.ui.HubButtonStyle
import com.ex2hub.ui.HubCard
import com.ex2hub.ui.HubIconButton
import com.ex2hub.ui.HubTextButton
import com.ex2hub.ui.KpiCard
import com.ex2hub.ui.LocalHubLayout
import com.ex2hub.ui.MapRoute
import com.ex2hub.ui.PeriodColumn
import com.ex2hub.ui.PeriodLine
import com.ex2hub.ui.PeriodSummaryCard
import com.ex2hub.ui.ScreenHead
import com.ex2hub.ui.SoftDivider
import com.ex2hub.ui.StateDot
import com.ex2hub.ui.TripsPageState
import com.ex2hub.ui.WeekBarChart
import com.ex2hub.ui.color
import com.ex2hub.ui.theme.HubColors
import com.ex2hub.ui.title
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalDate

@Composable
fun TripsScreen(
    state: TripsPageState,
    gpsGranted: Boolean,
    onAddTrip: () -> Unit,
    onStartTracking: () -> Unit,
    onStopTracking: () -> Unit,
    onDeleteTrip: (String) -> Unit,
    onOpenRoute: (Trip) -> Unit,
    onOpenCharging: () -> Unit
) {
    val layout = LocalHubLayout.current
    val tariff = state.tariffPerKwh
    val trips = state.trips
    var weeksBack by rememberSaveable { mutableIntStateOf(0) }
    var pickedEpochDay by rememberSaveable(weeksBack) { mutableStateOf<Long?>(null) }
    val today = LocalDate.now()
    val week = rememberJournalCalculation(trips, tariff, weeksBack, today) {
        Stats.weekStats(trips, tariffPerKwh = tariff, weeksBack = weeksBack)
    }
    val month = rememberJournalCalculation(trips, tariff, today) {
        Stats.monthStats(trips, tariffPerKwh = tariff)
    }
    val history = rememberJournalCalculation(trips) {
        TripHistoryUi(
            oldestDate = trips.minOfOrNull { it.startedAt }?.let { Stats.dateOf(it) },
            carTrips = trips.count { it.source == RecordSource.CAR },
            modes = Stats.byDriveMode(trips.filter { !it.mixedDriveMode && it.driveMode != null })
        )
    }
    val canGoBack = week != null && history?.oldestDate?.isBefore(week.days.first().date) == true
    val selectedDay = week?.let { loaded ->
        pickedEpochDay?.let(LocalDate::ofEpochDay)
            ?.takeIf { date -> loaded.days.any { it.date == date } }
            ?: loaded.days.lastOrNull { it.trips > 0 }?.date
            ?: loaded.days.last().date
    }
    // Фильтр «весь журнал» по умолчанию не включён: null означает, что строки выбранного дня ещё грузятся.
    val dayTrips = if (selectedDay != null) rememberJournalCalculation(trips, selectedDay) {
        trips.filter { Stats.dateOf(it.startedAt) == selectedDay }.sortedByDescending { it.startedAt }
    } else null
    val tracking = state.tracking
    val weekRange = week?.let { Fmt.weekRange(it.days.map { day -> day.date }) } ?: "Загрузка…"
    val averageSpeed = if (week != null && week.minutes > 0) week.distanceKm / (week.minutes / 60.0) else null

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 900.dp
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(layout.pagePadding)
        ) {
            item(key = "trips:head", contentType = "section") {
                ScreenHead(
                    eyebrow = "Статистика",
                    title = "Поездки",
                    subtitle = if (weeksBack == 0) "Последние 7 дней · $weekRange" else "Архив · $weekRange",
                    actions = {
                        if (wide) {
                            Badge(
                                text = if (gpsGranted) "GPS доступен" else "GPS выключен",
                                color = if (gpsGranted) HubColors.Mint else HubColors.Muted,
                                dot = true
                            )
                        }
                        if (tracking != null) {
                            HubButton(
                                text = "Остановить",
                                onClick = onStopTracking,
                                icon = AppIcons.Stop,
                                style = HubButtonStyle.Danger
                            )
                        } else {
                            HubButton(
                                text = "GPS-запись",
                                onClick = onStartTracking,
                                icon = AppIcons.Location,
                                style = HubButtonStyle.Ghost
                            )
                        }
                        HubButton(
                            text = "Добавить поездку",
                            onClick = onAddTrip,
                            icon = AppIcons.Plus,
                            style = HubButtonStyle.Primary
                        )
                    }
                )
                Spacer(Modifier.height(layout.gap))
            }

            if (tracking != null) {
                item(key = "trips:tracking", contentType = "section") {
                    TrackingBanner(
                        startedAt = tracking.startedAt,
                        distanceKm = tracking.distanceKm,
                        points = tracking.points,
                        onStop = onStopTracking
                    )
                    Spacer(Modifier.height(layout.gap))
                }
            }

            state.journalTrip?.let { anchor ->
                item(key = "trips:active", contentType = "section") {
                    CarTripBanner(anchor = anchor)
                    Spacer(Modifier.height(layout.gap))
                }
            }

            if (week == null || selectedDay == null) {
                item(key = "trips:loading", contentType = "status") {
                    HubCard(Modifier.fillMaxWidth()) {
                        Text("Загрузка журнала поездок…", color = HubColors.Muted)
                    }
                }
            } else {
            item(key = "trips:kpis", contentType = "section") {
                Column(verticalArrangement = Arrangement.spacedBy(layout.gap)) {
                    if (wide) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(layout.gap)
                        ) {
                            KpiCard(
                                icon = AppIcons.Route,
                                label = "Пробег за 7 дней",
                                value = Fmt.n1(week.distanceKm),
                                unit = "км",
                                accent = HubColors.Accent,
                                modifier = Modifier.weight(1f).height(76.dp)
                            )
                            KpiCard(
                                icon = AppIcons.Bolt,
                                label = "Израсходовано",
                                value = Fmt.n1(week.energyKwh),
                                unit = "кВт·ч",
                                accent = HubColors.Cyan,
                                modifier = Modifier.weight(1f).height(76.dp)
                            )
                            KpiCard(
                                icon = AppIcons.Clock,
                                label = "За рулём",
                                value = Fmt.duration(week.minutes),
                                unit = "",
                                accent = HubColors.Mint,
                                modifier = Modifier.weight(1f).height(76.dp)
                            )
                            KpiCard(
                                icon = AppIcons.Leaf,
                                label = "Средний расход",
                                value = Fmt.n1(week.consumption),
                                unit = "кВт·ч/100",
                                accent = HubColors.Accent,
                                modifier = Modifier.weight(1f).height(76.dp)
                            )
                        }
                    } else {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(layout.gap)
                        ) {
                            KpiCard(
                                icon = AppIcons.Route,
                                label = "Пробег за 7 дней",
                                value = Fmt.n1(week.distanceKm),
                                unit = "км",
                                accent = HubColors.Accent,
                                modifier = Modifier.weight(1f).height(76.dp)
                            )
                            KpiCard(
                                icon = AppIcons.Bolt,
                                label = "Израсходовано",
                                value = Fmt.n1(week.energyKwh),
                                unit = "кВт·ч",
                                accent = HubColors.Cyan,
                                modifier = Modifier.weight(1f).height(76.dp)
                            )
                        }
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(layout.gap)
                        ) {
                            KpiCard(
                                icon = AppIcons.Clock,
                                label = "За рулём",
                                value = Fmt.duration(week.minutes),
                                unit = "",
                                accent = HubColors.Mint,
                                modifier = Modifier.weight(1f).height(76.dp)
                            )
                            KpiCard(
                                icon = AppIcons.Leaf,
                                label = "Средний расход",
                                value = Fmt.n1(week.consumption),
                                unit = "кВт·ч/100",
                                accent = HubColors.Accent,
                                modifier = Modifier.weight(1f).height(76.dp)
                            )
                        }
                    }
                }
                Spacer(Modifier.height(layout.gap))
            }

            val chart: @Composable (Modifier) -> Unit = { modifier ->
                TripsChartCard(
                    week = week,
                    selected = selectedDay,
                    onSelect = { pickedEpochDay = it.toEpochDay() },
                    canGoBack = canGoBack,
                    canGoForward = weeksBack > 0,
                    onBack = { weeksBack++ },
                    onForward = { weeksBack = (weeksBack - 1).coerceAtLeast(0) },
                    modifier = modifier
                )
            }
            // Выбор дня стоит вплотную к списку: сводка и режимы идут выше.
            item(key = "trips:modes", contentType = "section") {
                ModesCard(modes = history?.modes.orEmpty(), modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(layout.gap))
            }
            if (wide) {
                item(key = "trips:chart-summary", contentType = "section") {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(layout.gap)
                    ) {
                        chart(Modifier.weight(1.65f).height(330.dp))
                        WeekSummaryCard(
                            week = week,
                            averageSpeed = averageSpeed,
                            batteryKwh = state.batteryKwh,
                            modifier = Modifier.weight(0.85f).height(330.dp)
                        )
                    }
                    Spacer(Modifier.height(layout.gap))
                }
            } else {
                item(key = "trips:summary", contentType = "section") {
                    WeekSummaryCard(
                        week = week,
                        averageSpeed = averageSpeed,
                        batteryKwh = state.batteryKwh,
                        modifier = Modifier.fillMaxWidth().height(330.dp)
                    )
                    Spacer(Modifier.height(layout.gap))
                }
                item(key = "trips:chart", contentType = "section") {
                    chart(Modifier.fillMaxWidth().height(330.dp))
                    Spacer(Modifier.height(layout.gap))
                }
            }

            month?.let { period ->
                item(key = "trips:period", contentType = "section") {
                    PeriodSummaryCard(
                        title = "Итоги",
                        eyebrow = "Неделя и месяц",
                        badge = "Тариф ${Fmt.n2(tariff)} р./кВт·ч",
                        columns = tripsPeriodColumns,
                        lines = tripsPeriodLines(week, period),
                        wide = wide,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(layout.gap))
                }
            }

            item(key = "trips:table-head", contentType = "table-header") {
                JournalTablePart(first = true, last = dayTrips.isNullOrEmpty()) {
                    JournalListHeading(
                        title = "Поездки · ${dayTitle(selectedDay)}",
                        count = dayTrips?.let { "${Fmt.records(it.size)} · всего в журнале ${trips.size}" }
                            ?: "Загрузка поездок выбранного дня…"
                    )
                    Spacer(Modifier.height(10.dp))
                    if (state.source == SourceMode.CAR_API) {
                        CarJournalNote(
                            carTrips = history?.carTrips,
                            onOpenCharging = onOpenCharging,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }
                    when {
                        trips.isEmpty() -> EmptyState(
                            icon = AppIcons.Route,
                            title = "Журнал пуст",
                            text = if (state.source == SourceMode.CAR_API) {
                                "Поездка появится после завершения движения по данным автомобиля. " +
                                    "GPS-запись или ручной ввод добавляются сюда же."
                            } else {
                                "Запишите поездку по GPS или добавьте её вручную — расход и стоимость посчитаются автоматически."
                            },
                            action = {
                                HubButton(
                                    text = "Добавить поездку",
                                    onClick = onAddTrip,
                                    icon = AppIcons.Plus,
                                    style = HubButtonStyle.Ghost
                                )
                            }
                        )
                        dayTrips == null -> Text(
                            "Загрузка записей…", color = HubColors.Muted,
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 21.sp, lineHeight = 30.sp)
                        )
                        dayTrips.isEmpty() -> Text(
                            text = "В этот день поездок нет. Выберите другой столбик на графике выше " +
                                "или пролистайте недели стрелками.",
                            color = HubColors.Muted,
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 21.sp, lineHeight = 30.sp),
                            modifier = Modifier.padding(vertical = 10.dp)
                        )
                        else -> TripsTableHeader()
                    }
                }
            }
            if (dayTrips != null) {
                itemsIndexed(dayTrips, key = { _, trip -> trip.id }, contentType = { _, _ -> "trip" }) { index, trip ->
                    JournalTablePart(last = index == dayTrips.lastIndex) {
                        SoftDivider()
                        TripTableRow(
                            trip = trip,
                            tariff = tariff,
                            onDeleteTrip = onDeleteTrip,
                            onOpenRoute = onOpenRoute
                        )
                    }
                }
            }
            }
        }
    }
}

private data class TripHistoryUi(
    val oldestDate: LocalDate?,
    val carTrips: Int,
    val modes: List<com.ex2hub.data.ModeStat>
)

/** A generation token hides the previous result immediately, before the new effect starts. */
@Composable
internal fun <T> rememberJournalCalculation(vararg keys: Any?, calculate: () -> T): T? {
    val generation = remember(*keys) { Any() }
    val result by produceState<Pair<Any, T>?>(initialValue = null, key1 = generation) {
        value = withContext(Dispatchers.Default) { generation to calculate() }
    }
    return result?.takeIf { it.first === generation }?.second
}

/** Separate lazy items retain one card silhouette and the same bounded table viewport. */
@Composable
internal fun JournalTablePart(
    first: Boolean = false,
    last: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    val padding = LocalHubLayout.current.cardPadding
    val shape = RoundedCornerShape(
        topStart = if (first) 18.dp else 0.dp,
        topEnd = if (first) 18.dp else 0.dp,
        bottomStart = if (last) 18.dp else 0.dp,
        bottomEnd = if (last) 18.dp else 0.dp
    )
    Column(
        Modifier.fillMaxWidth().clip(shape).background(HubColors.CardBottom)
            .border(1.dp, HubColors.BorderSoft, shape)
            .padding(start = padding, end = padding, top = if (first) padding else 0.dp,
                bottom = if (last) padding else 0.dp),
        content = content
    )
}

@Composable
internal fun JournalListHeading(title: String, count: String) {
    Text(
        "ВЫБРАННЫЙ ДЕНЬ", color = HubColors.Muted,
        style = MaterialTheme.typography.labelMedium.copy(fontSize = 18.sp, letterSpacing = 1.4.sp)
    )
    Spacer(Modifier.height(4.dp))
    Text(title, color = HubColors.Text, style = MaterialTheme.typography.titleLarge.copy(fontSize = 24.sp))
    Text(
        count, color = HubColors.Muted,
        style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp, lineHeight = 24.sp)
    )
}

@Composable
private fun CarJournalNote(
    carTrips: Int?,
    onOpenCharging: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(HubColors.SurfaceHigh.copy(alpha = 0.5f))
            .padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        StateDot(HubColors.Cyan, size = 5.dp)
        Spacer(Modifier.width(7.dp))
        Text(
            text = when (carTrips) {
                null -> "Подсчёт поездок автомобиля…"
                0 -> "Поездок автомобиля пока нет: запись появится по пробегу и передаче"
                else -> "Поездок автомобиля: $carTrips · энергия зависит от доступных данных; ≈ — оценка"
            },
            color = HubColors.Muted,
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 21.sp, lineHeight = 30.sp),
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(10.dp))
        HubTextButton(text = "зарядки", onClick = onOpenCharging, color = HubColors.Cyan)
    }
}

/**
 * Поездка, которую автомобиль уже начал. Приложение пишет её по пробегу и передаче,
 * строка появляется в журнале, когда прошивка сообщит P или движение прекратится на
 * десять минут — до этого половина поездки неизвестна, и показывать её как запись нельзя.
 */
@Composable
private fun CarTripBanner(anchor: TripAnchor) {
    val now by produceState(initialValue = System.currentTimeMillis()) {
        while (true) {
            delay(5_000L)
            value = System.currentTimeMillis()
        }
    }
    val minutes = ((now - anchor.startedAt).coerceAtLeast(0L) / 60_000L).toInt()
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(13.dp))
            .background(HubColors.Cyan.copy(alpha = 0.055f))
            .border(1.dp, HubColors.Cyan.copy(alpha = 0.18f), RoundedCornerShape(13.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        StateDot(HubColors.Cyan, size = 7.dp, glow = true)
        Spacer(Modifier.width(9.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = "Поездка идёт по данным автомобиля",
                color = HubColors.Text,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Medium
                )
            )
            Text(
                text = "Запись появится в журнале сама: когда прошивка сообщит P или когда " +
                    "движение прекратится на десять минут",
                color = HubColors.Muted,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp, lineHeight = 24.sp)
            )
        }
        Text(
            text = "${Fmt.n1(anchor.distanceKm)} км · ${Fmt.duration(minutes)}",
            color = HubColors.Cyan,
            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 21.sp),
            maxLines = 1
        )
    }
}

@Composable
private fun TrackingBanner(
    startedAt: Long,
    distanceKm: Double,
    points: Int,
    onStop: () -> Unit
) {
    val now by produceState(initialValue = System.currentTimeMillis()) {
        while (true) {
            delay(5_000L)
            value = System.currentTimeMillis()
        }
    }
    val minutes = ((now - startedAt).coerceAtLeast(0L) / 60_000L).toInt()
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(13.dp))
            .background(HubColors.Accent.copy(alpha = 0.055f))
            .border(1.dp, HubColors.Accent.copy(alpha = 0.18f), RoundedCornerShape(13.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        StateDot(HubColors.Accent, size = 7.dp, glow = true)
        Spacer(Modifier.width(9.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = "Идёт запись маршрута",
                color = HubColors.Text,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Medium
                )
            )
            Text(
                text = "Определение по GPS · журнал пополнится после остановки",
                color = HubColors.Muted,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp, lineHeight = 24.sp)
            )
        }
        Text(
            text = "${Fmt.n1(distanceKm)} км · $minutes мин · $points ${Fmt.plural(points, "точка", "точки", "точек")}",
            color = HubColors.AccentSoft,
            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 21.sp),
            maxLines = 1
        )
        Spacer(Modifier.width(12.dp))
        HubTextButton(text = "Стоп", onClick = onStop, color = HubColors.Red)
    }
}

@Composable
private fun TripsChartCard(
    week: com.ex2hub.data.WeekStats,
    selected: LocalDate,
    onSelect: (LocalDate) -> Unit,
    canGoBack: Boolean,
    canGoForward: Boolean,
    onBack: () -> Unit,
    onForward: () -> Unit,
    modifier: Modifier = Modifier
) {
    HubCard(modifier) {
        CardHead(
            title = "Расход по дням",
            eyebrow = "Нажмите на день — ниже его поездки",
            trailing = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    WeekArrow(AppIcons.ChevronLeft, "Предыдущая неделя", canGoBack, onBack)
                    Text(
                        text = Fmt.weekRange(week.days.map { it.date }),
                        color = HubColors.TextDim,
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 21.sp, lineHeight = 28.sp),
                        maxLines = 1,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                    WeekArrow(AppIcons.Chevron, "Следующая неделя", canGoForward, onForward)
                }
            }
        )
        Spacer(Modifier.height(8.dp))
        WeekBarChart(
            days = week.days,
            modifier = Modifier.fillMaxWidth().weight(1f),
            selected = selected,
            onSelect = onSelect
        )
    }
}

@Composable
private fun WeekArrow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    enabled: Boolean,
    onClick: () -> Unit
) {
    HubIconButton(
        icon = icon,
        contentDescription = description,
        onClick = { if (enabled) onClick() },
        tint = if (enabled) HubColors.Text else HubColors.Muted.copy(alpha = 0.35f)
    )
}

private fun dayTitle(date: LocalDate): String {
    val today = LocalDate.now()
    return when (date) {
        today -> "сегодня"
        today.minusDays(1) -> "вчера"
        else -> "${Fmt.weekdayShort(date)}, ${Fmt.dayMonth(date)}"
    }
}

@Composable
private fun WeekSummaryCard(
    week: com.ex2hub.data.WeekStats,
    averageSpeed: Double?,
    batteryKwh: Double,
    modifier: Modifier = Modifier
) {
    val share = if (batteryKwh > 0.05) week.energyKwh / batteryKwh * 100.0 else 0.0
    val best = week.bestEfficiencyDay
    HubCard(modifier) {
        CardHead(
            title = "Энергия недели",
            eyebrow = "Итоги",
            trailing = { Badge(text = "7 дней", color = HubColors.TextDim) }
        )
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                text = Fmt.n1(week.energyKwh),
                color = HubColors.Text,
                style = MaterialTheme.typography.displayMedium.copy(
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Light,
                    letterSpacing = (-1).sp
                )
            )
            Spacer(Modifier.width(5.dp))
            Text(
                text = "кВт·ч",
                color = HubColors.TextDim,
                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 21.sp),
                modifier = Modifier.padding(bottom = 4.dp)
            )
        }
        Spacer(Modifier.height(5.dp))
        BatteryBar(
            percent = share.toInt().coerceIn(0, 100),
            height = 7.dp,
            color = HubColors.Accent
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = "≈ ${Fmt.n0(share)}% ёмкости батареи",
            color = HubColors.Muted,
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp, lineHeight = 24.sp)
        )
        Spacer(Modifier.height(7.dp))
        SummaryRow("Средняя скорость", averageSpeed?.let { "${Fmt.n0(it)} км/ч" } ?: "—")
        SummaryRow("Поездок", week.trips.toString())
        SummaryRow("Стоимость энергии", Fmt.money(week.cost))
        Spacer(Modifier.weight(1f))
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            StateDot(HubColors.Accent, size = 5.dp)
            Spacer(Modifier.width(5.dp))
            Text(
                text = "Лучший день",
                color = HubColors.Muted,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp, lineHeight = 24.sp),
                modifier = Modifier.weight(1f)
            )
            Text(
                text = best?.let {
                    "${Fmt.weekdayCapital(it.date)} · ${Fmt.n1(it.consumption)}"
                } ?: "—",
                color = HubColors.Text,
                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 21.sp),
                maxLines = 1
            )
        }
    }
}

/** Колонки сводки: фиксированные ширины держат таблицу и блоки периода на одних подписях. */
private val tripsPeriodColumns = listOf(
    PeriodColumn("Пробег, км", 110.dp),
    PeriodColumn("Энергия, кВт·ч", 140.dp),
    PeriodColumn("Расход/100, кВт·ч", 165.dp),
    PeriodColumn("Стоимость, р.", 130.dp),
    PeriodColumn("На 100 км, р.", 130.dp),
    PeriodColumn("Поездок", 85.dp)
)

private fun tripsPeriodLines(
    week: com.ex2hub.data.WeekStats,
    month: com.ex2hub.data.MonthStats
): List<PeriodLine> = listOf(
    PeriodLine(
        label = "Неделя",
        values = listOf(
            Fmt.n1(week.distanceKm),
            Fmt.n1(week.energyKwh),
            Fmt.n1(week.consumption),
            Fmt.n2(week.cost),
            Fmt.n2(week.costPer100Km),
            Fmt.int(week.trips)
        )
    ),
    PeriodLine(
        label = Fmt.monthTitle(month.month),
        values = listOf(
            Fmt.n1(month.distanceKm),
            Fmt.n1(month.energyKwh),
            Fmt.n1(month.consumption),
            Fmt.n2(month.cost),
            Fmt.n2(month.costPer100Km),
            Fmt.int(month.trips)
        )
    )
)

@Composable
private fun SummaryRow(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = label,
            color = HubColors.Muted,
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp),
            modifier = Modifier.weight(1f),
            maxLines = 1
        )
        Text(
            text = value,
            color = HubColors.Text,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontSize = 21.sp,
                fontWeight = FontWeight.Medium
            ),
            maxLines = 1
        )
    }
}

/** Колонки равны самой длинной подписи: таблица целиком помещается в карточку без прокрутки. */
@Composable
private fun TripsTableHeader() {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TableLabel("Дата", Modifier.width(88.dp))
        TableLabel("Маршрут", Modifier.weight(1f), align = TextAlign.Start)
        TableLabel("Расстояние", Modifier.width(103.dp), align = TextAlign.End)
        TableLabel("Время", Modifier.width(122.dp), align = TextAlign.End)
        TableLabel("Расход", Modifier.width(66.dp), align = TextAlign.End)
        TableLabel("Энергия", Modifier.width(110.dp), align = TextAlign.End)
        TableLabel("Стоимость", Modifier.width(100.dp), align = TextAlign.End)
        Spacer(Modifier.width(40.dp))
        Spacer(Modifier.width(40.dp))
    }
}

@Composable
private fun TableLabel(text: String, modifier: Modifier, align: TextAlign = TextAlign.Start) {
    Text(
        text = text,
        modifier = modifier,
        color = HubColors.Muted,
        style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp, letterSpacing = 0.15.sp),
        textAlign = align,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
    )
}

@Composable
private fun TripTableRow(
    trip: Trip,
    tariff: Double,
    onDeleteTrip: (String) -> Unit,
    onOpenRoute: (Trip) -> Unit
) {
    val date = Stats.dateOf(trip.startedAt)
    val today = LocalDate.now()
    val dateLabel = when (date) {
        today -> "Сегодня"
        today.minusDays(1) -> "Вчера"
        else -> Fmt.dayMonth(date)
    }
    Row(
        Modifier.fillMaxWidth().padding(vertical = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.width(88.dp)) {
            Text(
                text = dateLabel,
                color = HubColors.Text,
                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 21.sp),
                maxLines = 1
            )
            Text(
                text = Fmt.time(trip.startedAt),
                color = HubColors.Muted,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp),
                maxLines = 1
            )
        }
        Column(Modifier.weight(1f).padding(end = 8.dp)) {
            Text(
                text = "${trip.from} → ${trip.to}",
                color = HubColors.Text,
                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 21.sp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (trip.energyEstimated) {
                    Text(
                        text = "оценка",
                        color = HubColors.Amber.copy(alpha = 0.8f),
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp),
                        maxLines = 1
                    )
                }
                trip.driveMode?.let { mode ->
                    Text(
                        text = " · ${mode.title()}",
                        color = mode.color(),
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp),
                        maxLines = 1
                    )
                }
                trip.regen?.let { level ->
                    Text(
                        text = " · рекуп. ${level.title()}",
                        color = HubColors.Muted,
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp),
                        maxLines = 1
                    )
                }
            }
        }
        TableCell("${Fmt.n1(trip.distanceKm)} км", Modifier.width(103.dp))
        TableCell(Fmt.duration(trip.durationMin), Modifier.width(122.dp))
        TableCell(Fmt.n1(trip.consumption), Modifier.width(66.dp))
        TableCell("${Fmt.n1(trip.energyKwh)} кВт·ч", Modifier.width(110.dp))
        TableCell(Fmt.money(trip.energyKwh * tariff), Modifier.width(100.dp))
        Box(Modifier.width(40.dp), contentAlignment = Alignment.CenterEnd) {
            HubIconButton(
                icon = AppIcons.Location,
                contentDescription = "Маршрут в Яндекс.Картах",
                onClick = { onOpenRoute(trip) },
                tint = HubColors.Cyan,
                enabled = MapRoute.available(trip)
            )
        }
        Box(Modifier.width(40.dp), contentAlignment = Alignment.CenterEnd) {
            HubIconButton(
                icon = AppIcons.Trash,
                contentDescription = "Удалить поездку",
                onClick = { onDeleteTrip(trip.id) },
                tint = HubColors.Muted
            )
        }
    }
}

/**
 * Расход по режимам движения. Считается только по поездкам, где автомобиль
 * назвал режим, — остальных здесь нет намеренно.
 */
@Composable
private fun ModesCard(
    modes: List<com.ex2hub.data.ModeStat>,
    modifier: Modifier = Modifier
) {
    if (modes.isEmpty()) return
    HubCard(modifier) {
        CardHead(
            title = "Расход по режимам",
            eyebrow = "Режим движения",
            trailing = {
                Text(
                    text = "${Fmt.records(modes.sumOf { it.trips })} с кодом режима",
                    color = HubColors.Muted,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp, lineHeight = 24.sp),
                    maxLines = 1
                )
            }
        )
        Spacer(Modifier.height(8.dp))
        modes.chunked(4).forEach { rowModes ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                rowModes.forEach { stat ->
                    ModeTile(stat, Modifier.weight(1f))
                }
                repeat(4 - rowModes.size) {
                    Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun ModeTile(
    stat: com.ex2hub.data.ModeStat,
    modifier: Modifier = Modifier
) {
    val accent = stat.mode.color()
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(accent.copy(alpha = 0.07f))
            .border(1.dp, accent.copy(alpha = 0.2f), RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(
            text = stat.mode.title(),
            color = accent,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium
            ),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.height(2.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                text = Fmt.n1(stat.consumption),
                color = HubColors.Text,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Light
                ),
                maxLines = 1
            )
            Spacer(Modifier.width(3.dp))
            Text(
                text = "кВт·ч/100",
                color = HubColors.Muted,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp),
                modifier = Modifier.padding(bottom = 3.dp),
                maxLines = 1
            )
        }
        Text(
            text = "${Fmt.trips(stat.trips)} · ${Fmt.n1(stat.distanceKm)} км",
            color = HubColors.Muted,
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun TableCell(text: String, modifier: Modifier) {
    Text(
        text = text,
        modifier = modifier,
        color = HubColors.TextDim,
        style = MaterialTheme.typography.bodyMedium.copy(fontSize = 21.sp),
        textAlign = TextAlign.End,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
    )
}
