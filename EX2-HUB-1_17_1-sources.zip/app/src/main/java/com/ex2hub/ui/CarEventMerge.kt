package com.ex2hub.ui

import com.ex2hub.data.Climate
import com.ex2hub.data.VehicleSnapshot

internal fun VehicleSnapshot.withCarEvent(previous: VehicleSnapshot, event: VehicleSnapshot): VehicleSnapshot {
    val currentClimate = climate ?: Climate()
    val oldClimate = previous.climate ?: Climate()
    val newClimate = event.climate ?: Climate()
    val mergedClimate = currentClimate.copy(
        hvacOn = if (newClimate.hvacOn != oldClimate.hvacOn) newClimate.hvacOn else currentClimate.hvacOn,
        acOn = if (newClimate.acOn != oldClimate.acOn) newClimate.acOn else currentClimate.acOn,
        recircOn = if (newClimate.recircOn != oldClimate.recircOn) newClimate.recircOn else currentClimate.recircOn,
        frontDefrostOn = if (newClimate.frontDefrostOn != oldClimate.frontDefrostOn) newClimate.frontDefrostOn else currentClimate.frontDefrostOn,
        windshieldHeatOn = if (newClimate.windshieldHeatOn != oldClimate.windshieldHeatOn) newClimate.windshieldHeatOn else currentClimate.windshieldHeatOn,
        rearDefrostOn = if (newClimate.rearDefrostOn != oldClimate.rearDefrostOn) newClimate.rearDefrostOn else currentClimate.rearDefrostOn,
        fanSpeed = if (newClimate.fanSpeed != oldClimate.fanSpeed) newClimate.fanSpeed else currentClimate.fanSpeed,
        driverTempC = if (newClimate.driverTempC != oldClimate.driverTempC) newClimate.driverTempC else currentClimate.driverTempC,
        seatHeatDriver = if (newClimate.seatHeatDriver != oldClimate.seatHeatDriver) newClimate.seatHeatDriver else currentClimate.seatHeatDriver,
        seatHeatPassenger = if (newClimate.seatHeatPassenger != oldClimate.seatHeatPassenger) newClimate.seatHeatPassenger else currentClimate.seatHeatPassenger,
        wheelHeat = if (newClimate.wheelHeat != oldClimate.wheelHeat) newClimate.wheelHeat else currentClimate.wheelHeat,
        fanDirection = if (newClimate.fanDirection != oldClimate.fanDirection) newClimate.fanDirection else currentClimate.fanDirection
    )
    return copy(
        speedKmh = if (event.speedKmh != previous.speedKmh) event.speedKmh else speedKmh,
        soc = if (event.soc != previous.soc) event.soc else soc,
        odometerKm = if (event.odometerKm != previous.odometerKm) event.odometerKm else odometerKm,
        driveMode = if (event.driveMode != previous.driveMode) event.driveMode else driveMode,
        regen = if (event.regen != previous.regen) event.regen else regen,
        gear = if (event.gear != previous.gear) event.gear else gear,
        outsideTempC = if (event.outsideTempC != previous.outsideTempC) event.outsideTempC else outsideTempC,
        insideTempC = if (event.insideTempC != previous.insideTempC) event.insideTempC else insideTempC,
        climate = mergedClimate.takeUnless { it.isEmpty },
        body = if (event.body != previous.body) event.body else body
    )
}

/**
 * Страница зарядки показывает батарею и таблицу истории. Подписка приносит
 * только SOC и температуру за бортом, их и берём: история не перерисовывается
 * на каждый пакет VHAL, а процент меняется сразу, не дожидаясь опроса. Мощность,
 * разъём и токи подписка не передаёт — они приходят опросом.
 */
internal fun VehicleSnapshot.withBatteryCarEvent(merged: VehicleSnapshot): VehicleSnapshot = copy(
    soc = merged.soc,
    outsideTempC = merged.outsideTempC
)
