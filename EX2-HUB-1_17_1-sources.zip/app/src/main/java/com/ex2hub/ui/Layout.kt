package com.ex2hub.ui

import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class HubLayout(
    val pagePadding: Dp = 18.dp,
    val cardPadding: Dp = 20.dp,
    val gap: Dp = 14.dp,
    val compact: Boolean = false
)

val LocalHubLayout = staticCompositionLocalOf { HubLayout() }

/**
 * Два текстовых масштаба макета: базовый — как в `.card-title` и `.badge`,
 * и `.page-section` — 21 для содержимого, 18 для подписей. Всплывающие окна
 * рисуются вне раздела и остаются на базовом масштабе.
 */
data class HubText(
    val eyebrow: TextUnit = 10.5.sp,
    val eyebrowSpacing: TextUnit = 1.35.sp,
    val cardTitle: TextUnit = 18.sp,
    val badge: TextUnit = 9.5.sp,
    val button: TextUnit = 12.sp,
    val buttonHeight: Dp = 40.dp,
    val buttonPadH: Dp = 15.dp,
    val buttonPadV: Dp = 10.dp,
    val buttonIcon: Dp = 16.dp,
    val iconButton: Dp = 38.dp,
    val note: TextUnit = 11.sp,
    val noteLine: TextUnit = 16.sp,
    val warning: TextUnit = 10.5.sp,
    val warningLine: TextUnit = 15.sp,
    val warningIcon: Dp = 15.dp,
    val fieldLabel: TextUnit = 10.sp,
    val fieldValue: TextUnit = 13.sp,
    val fieldHeight: Dp = 41.dp,
    val fieldPadH: Dp = 12.dp,
    val fieldPadV: Dp = 9.dp,
    val controlLabel: TextUnit = 12.sp,
    val controlStatus: TextUnit = 11.sp,
    val controlIcon: Dp = 16.dp,
    val controlStatusWidth: Dp = 90.dp
) {
    companion object {
        val Base = HubText()
        val Page = HubText(
            eyebrow = 18.sp,
            eyebrowSpacing = 1.4.sp,
            cardTitle = 24.sp,
            badge = 18.sp,
            button = 18.sp,
            buttonHeight = 46.dp,
            buttonPadH = 17.dp,
            buttonPadV = 11.dp,
            buttonIcon = 20.dp,
            iconButton = 40.dp,
            note = 21.sp,
            noteLine = 28.sp,
            warning = 21.sp,
            warningLine = 30.sp,
            warningIcon = 24.dp,
            fieldLabel = 18.sp,
            fieldValue = 21.sp,
            fieldHeight = 56.dp,
            fieldPadH = 14.dp,
            fieldPadV = 12.dp,
            controlLabel = 21.sp,
            controlStatus = 18.sp,
            controlIcon = 22.dp,
            controlStatusWidth = 170.dp
        )
    }
}

val LocalHubText = staticCompositionLocalOf { HubText.Base }

enum class HubPage(val label: String) {
    HOME("Главная"),
    TRIPS("Поездки"),
    CHARGING("Зарядки"),
    SETTINGS("Настройки")
}
