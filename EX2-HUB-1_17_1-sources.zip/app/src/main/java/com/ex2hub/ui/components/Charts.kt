package com.ex2hub.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ex2hub.data.ChargeDayStat
import com.ex2hub.data.DayStat
import com.ex2hub.data.Fmt
import com.ex2hub.ui.theme.HubColors
import java.time.LocalDate

@Composable
fun RingGauge(
    progress: Float,
    modifier: Modifier = Modifier,
    stroke: Dp = 6.dp,
    color: Color = HubColors.Accent,
    trackColor: Color = HubColors.Track,
    center: @Composable () -> Unit = {}
) {
    val fraction = progress.coerceIn(0f, 1f)
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val width = stroke.toPx()
            drawArc(
                color = trackColor,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = Offset(width / 2f, width / 2f),
                size = Size(size.width - width, size.height - width),
                style = Stroke(width = width)
            )
            drawArc(
                color = color,
                startAngle = -90f,
                sweepAngle = 360f * fraction,
                useCenter = false,
                topLeft = Offset(width / 2f, width / 2f),
                size = Size(size.width - width, size.height - width),
                style = Stroke(width = width, cap = StrokeCap.Round)
            )
        }
        center()
    }
}

@Composable
fun BatteryBar(
    percent: Int?,
    modifier: Modifier = Modifier,
    height: Dp = 9.dp,
    color: Color = HubColors.Accent,
    showTrack: Boolean = true
) {
    val fraction = ((percent ?: 0).coerceIn(0, 100)) / 100f
    Box(
        modifier
            .fillMaxWidth()
            .height(height)
            .clip(RoundedCornerShape(50))
            .background(if (showTrack) HubColors.Track else Color.Transparent)
    ) {
        if (percent != null && percent > 0) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(fraction)
                    .clip(RoundedCornerShape(50))
                    .background(
                        Brush.horizontalGradient(
                            listOf(color.copy(alpha = 0.65f), color)
                        )
                    )
            )
        }
    }
}

@Composable
fun WeekBarChart(
    days: List<DayStat>,
    modifier: Modifier = Modifier,
    showValues: Boolean = true,
    selected: LocalDate? = null,
    onSelect: ((LocalDate) -> Unit)? = null
) {
    DailyBarChart(
        days = days.map { it.date to it.consumption },
        modifier = modifier,
        showValues = showValues,
        selected = selected,
        onSelect = onSelect
    )
}

@Composable
fun ChargeWeekBarChart(
    days: List<ChargeDayStat>,
    modifier: Modifier = Modifier,
    selected: LocalDate? = null,
    onSelect: ((LocalDate) -> Unit)? = null
) {
    DailyBarChart(
        days = days.map { it.date to it.kwh },
        modifier = modifier,
        showValues = true,
        selected = selected,
        onSelect = onSelect
    )
}

@Composable
private fun DailyBarChart(
    days: List<Pair<LocalDate, Double?>>,
    modifier: Modifier = Modifier,
    showValues: Boolean,
    selected: LocalDate?,
    onSelect: ((LocalDate) -> Unit)?
) {
    val today = LocalDate.now()
    // Цвет сетки читается в композиции: внутри Canvas обращение к палитре недоступно.
    val gridColor = HubColors.BorderSoft.copy(alpha = 0.65f)
    val max = days.maxOfOrNull { it.second ?: 0.0 }?.coerceAtLeast(1.0) ?: 1.0
    fun Modifier.pick(date: LocalDate): Modifier =
        if (onSelect == null) this else clickable { onSelect(date) }
    Column(modifier.fillMaxWidth()) {
        BoxWithConstraints(
            Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            val barAreaHeight = (maxHeight - if (showValues) 20.dp else 4.dp)
                .coerceAtLeast(8.dp)
            Canvas(Modifier.fillMaxSize()) {
                val inset = 6.dp.toPx()
                for (i in 0..3) {
                    val y = inset + (size.height - inset * 2f) * i / 3f
                    drawLine(
                        color = gridColor,
                        start = Offset(0f, y),
                        end = Offset(size.width, y),
                        strokeWidth = 1.dp.toPx()
                    )
                }
            }
            Row(
                Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                days.forEach { day ->
                    val value = day.second
                    val active = if (selected != null) day.first == selected else day.first == today
                    val fraction = ((value ?: 0.0) / max).toFloat().coerceIn(0f, 1f)
                    Column(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (active && selected != null) HubColors.Accent.copy(alpha = 0.07f) else Color.Transparent
                            )
                            .pick(day.first),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Bottom
                    ) {
                        if (showValues && value != null && value > 0.0) {
                            Text(
                                text = Fmt.n1(value),
                                color = if (active) HubColors.Accent else HubColors.TextDim,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Medium
                                ),
                                maxLines = 1
                            )
                            Spacer(Modifier.height(4.dp))
                        }
                        val barHeight = if (value == null || value <= 0.0) {
                            3.dp
                        } else {
                            (barAreaHeight * fraction).coerceAtLeast(5.dp)
                        }
                        Box(
                            Modifier
                                .fillMaxWidth(0.64f)
                                .height(barHeight)
                                .clip(RoundedCornerShape(topStart = 5.dp, topEnd = 5.dp))
                                .background(
                                    if (active) {
                                        Brush.verticalGradient(
                                            listOf(HubColors.Accent, HubColors.Accent.copy(alpha = 0.38f))
                                        )
                                    } else {
                                        Brush.verticalGradient(
                                            listOf(
                                                HubColors.AccentSoft.copy(alpha = 0.42f),
                                                HubColors.AccentSoft.copy(alpha = 0.08f)
                                            )
                                        )
                                    }
                                )
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(7.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            days.forEach { day ->
                val active = if (selected != null) day.first == selected else day.first == today
                Text(
                    text = "${Fmt.weekdayShort(day.first)} ${day.first.dayOfMonth}",
                    color = if (active) HubColors.Accent else HubColors.Muted,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 18.sp,
                        fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal
                    ),
                    modifier = Modifier.weight(1f).pick(day.first),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    maxLines = 1
                )
            }
        }
    }
}
