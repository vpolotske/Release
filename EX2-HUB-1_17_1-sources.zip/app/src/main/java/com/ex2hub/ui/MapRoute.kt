package com.ex2hub.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.ex2hub.data.Trip
import java.util.Locale

/**
 * Поездка открывается маршрутом в Яндекс.Картах. Точки берутся из GPS-трека;
 * без координат карта ищет место по названию. Строится дорога на автомобиле —
 * именно так поездка и была записана.
 */
object MapRoute {
    /** Названия-заполнители вместо адреса: по ним маршрут строить нечем. */
    private val placeholders = setOf("Старт", "Финиш", "GPS-трек")

    private fun point(lat: Double?, lon: Double?, name: String): String? =
        if (lat != null && lon != null) String.format(Locale.US, "%.6f,%.6f", lat, lon)
        else name.trim()
            .takeIf { it.isNotEmpty() && it !in placeholders }
            ?.let(Uri::encode)

    /** Маршрута нет, если хотя бы одна из точек неизвестна. */
    fun query(trip: Trip): String? {
        val from = point(trip.fromLat, trip.fromLon, trip.from) ?: return null
        val to = point(trip.toLat, trip.toLon, trip.to) ?: return null
        return "$from~$to"
    }

    fun available(trip: Trip): Boolean = query(trip) != null

    /** Сначала приложение карт, без него — то, что открывает ссылку. */
    fun open(context: Context, trip: Trip): Boolean {
        val rtext = query(trip) ?: return false
        val params = "rtext=$rtext&rtt=auto"
        return launch(context, "yandexmaps://maps.yandex.ru/?$params") ||
            launch(context, "https://yandex.ru/maps/?$params")
    }

    private fun launch(context: Context, url: String): Boolean = try {
        context.startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse(url))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        true
    } catch (_: ActivityNotFoundException) {
        false
    }
}
