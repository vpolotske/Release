package com.ex2hub.ui

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.ex2hub.BuildConfig
import com.ex2hub.data.CarJournal
import com.ex2hub.data.ChargeAlerts
import com.ex2hub.data.ChargeDraft
import com.ex2hub.data.ChargeSession
import com.ex2hub.data.CheckStatus
import com.ex2hub.data.Climate
import com.ex2hub.data.ClimateChange
import com.ex2hub.data.ClimatePreset
import com.ex2hub.data.ClimateWriteResult
import com.ex2hub.data.DemoData
import com.ex2hub.data.DriveMemory
import com.ex2hub.data.DriveMode
import com.ex2hub.data.Fmt
import com.ex2hub.data.JournalExport
import com.ex2hub.data.JournalFiles
import com.ex2hub.data.JournalUpdate
import com.ex2hub.data.PersistedState
import com.ex2hub.data.Profile
import com.ex2hub.data.ProbeOutcome
import com.ex2hub.data.RecordSource
import com.ex2hub.data.RegenLevel
import com.ex2hub.data.SocRising
import com.ex2hub.data.SourceCheck
import com.ex2hub.data.SourceMode
import com.ex2hub.data.Stats
import com.ex2hub.data.Store
import com.ex2hub.data.TrackResult
import com.ex2hub.data.TrackingInfo
import com.ex2hub.data.Trip
import com.ex2hub.data.TripDraft
import com.ex2hub.data.VehicleSnapshot
import com.ex2hub.data.nowMillis
import com.ex2hub.service.BackgroundStatus
import com.ex2hub.service.ChargeNotifier
import com.ex2hub.service.HubService
import com.ex2hub.source.GeelyVhal
import com.ex2hub.source.TelemetryReader
import com.ex2hub.tracker.TripTracker
import com.ex2hub.update.AppUpdater
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.UUID
import kotlin.math.exp
import kotlin.math.roundToInt
import kotlin.math.sin

// Один экземпляр на процесс не даёт экрану и сервису вести два журнала.
@Stable
class HubController private constructor(private val app: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val store = Store(app)
    private val files = JournalFiles(app)
    private val reader = TelemetryReader(app)
    val updater = AppUpdater(app)
    private val probeLogs = mutableMapOf<SourceMode, String>()
    private var pollJob: Job? = null
    private var tracker: TripTracker? = null
    private var uiVisible = false
    private var uiPage = HubPage.HOME
    private var serviceListener: ((BackgroundStatus) -> Unit)? = null
    private var lastStatus: BackgroundStatus? = null
    private var lastNote: String? = null
    private var serviceRequested = false
    private var serviceWantsLocation = false
    private var reading = false
    /** Когда снимок последний раз попал в состояние UI: см. [REPUBLISH_MS]. */
    private var lastTelemetryPublishAt = 0L
    /** Когда климат и кузов читались целиком: см. [FULL_READ_MS]. */
    private var lastFullReadAt = 0L
    /** Когда состояние в последний раз ушло в [Store]: см. [ANCHOR_PERSIST_MS]. */
    private var lastPersistAt = 0L
    private var retainedOutsideTempC: Int? = null
    private var retainedOutsideTempAt = 0L
    private var carEventBaseline: VehicleSnapshot? = null
    private var pendingCarEvent: VehicleSnapshot? = null
    private var lastCarEventUiAt = 0L
    private var pendingCarEventVehicle: VehicleSnapshot? = null
    private var pendingCarEventBase: VehicleSnapshot? = null
    private var carEventPublishJob: Job? = null
    private var controlGeneration = 0L
    private val driveMemory = DriveMemory()
    private val alerts = ChargeAlerts()
    private val socRise = SocRising()
    private val notifier = ChargeNotifier(app)
    private val ackMutex = Mutex()
    private var ackTrack: AudioTrack? = null
    /** Даже callback, совпавший с оптимистичным выбором, запрещает старый откат. */
    private var activeClimateObserved = false

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages = _messages.asSharedFlow()

    /** Якоря незакрытых поездки и зарядки переживают смерть процесса через [Store]. */
    private val journal: CarJournal

    var ui by mutableStateOf(HubUiState())
        private set

    init {
        val loaded = store.load()
        journal = CarJournal(
            restoredTrip = loaded.tripAnchor,
            restoredCharge = loaded.chargeAnchor
        )
        var trips = loaded.trips
        var sessions = loaded.sessions
        if (!loaded.demoSeeded) {
            if (trips.isEmpty() && sessions.isEmpty()) {
                trips = DemoData.seedTrips()
                sessions = DemoData.seedSessions()
            }
        }
        val profile = loaded.profile
        defaultProbeLogs(profile).forEach { (mode, text) -> probeLogs[mode] = text }

        val checks = defaultChecks() + loaded.checks
        ui = HubUiState(
            profile = profile,
            vehicle = initialVehicle(profile),
            trips = trips,
            sessions = sessions,
            checks = checks,
            probeLog = probeLogs[profile.source] ?: probeHint(profile.source),
            journalTrip = loaded.tripAnchor,
            journalCharge = loaded.chargeAnchor,
            exportPath = files.path
        )
        persist()
    }

    fun onUiStarted() {
        uiVisible = true
        syncService()
        restartPolling()
    }

    fun onUiStopped() {
        uiVisible = false
        // Пульсация живёт только на видимом экране: без этого она крутилась бы в фоне.
        if (ui.socRising) ui = ui.copy(socRising = false)
        restartPolling()
    }

    /**
     * Живой рабочий стол читается раз в секунду, списки поездок и зарядок — реже:
     * ежесекундная перерисовка всего экрана из-за телеметрии и была причиной
     * рывков при прокрутке.
     */
    fun onPageShown(page: HubPage) {
        uiPage = page
    }

    fun needsBackground(): Boolean = polls(ui.profile.source) || tracker != null

    fun wantsLocation(): Boolean = tracker != null

    suspend fun canInstallUpdate(): Boolean {
        val mode = ui.profile.source
        if (ui.climateBusy || ui.driveBusy || ui.bodyBusy || ui.probeRunning) return false
        val parked = when (mode) {
            SourceMode.CAR_API -> reader.isParkedForUpdate()
            SourceMode.ROOT -> false
            SourceMode.DEMO, SourceMode.MANUAL -> true
        }
        return parked && ui.profile.source == mode &&
            !ui.climateBusy && !ui.driveBusy && !ui.bodyBusy && !ui.probeRunning
    }

    fun attachService(listener: (BackgroundStatus) -> Unit) {
        serviceListener = listener
        serviceRequested = true
        serviceWantsLocation = wantsLocation()
        lastStatus = null
        restartPolling()
        publishStatus()
    }

    fun detachService() {
        serviceListener = null
        serviceRequested = false
        restartPolling()
    }

    fun status(): BackgroundStatus = BackgroundStatus.of(
        source = ui.profile.source,
        trackingKm = ui.tracking?.distanceKm,
        trip = journal.trip,
        charge = journal.charge,
        soc = ui.vehicle.soc?.takeIf { !ui.vehicle.isFallback },
        note = lastNote
    )

    fun syncService(): Boolean {
        val needed = needsBackground()
        val location = wantsLocation()
        if (needed && (!serviceRequested || location != serviceWantsLocation)) {
            serviceRequested = HubService.start(app)
            serviceWantsLocation = location
            if (!serviceRequested) serviceFailed()
        } else if (!needed && serviceRequested) {
            serviceRequested = false
            HubService.stop(app)
        }
        return !needed || serviceRequested
    }

    fun serviceFailed() {
        serviceRequested = false
        tracker?.stop()
        tracker = null
        ui = ui.copy(tracking = null)
        emit("Система запретила фоновую работу. Откройте EX2 HUB и проверьте ограничения фоновых приложений в настройках ГУ.")
    }

    private fun publishStatus() {
        val listener = serviceListener ?: return
        val status = status()
        if (status == lastStatus) return
        lastStatus = status
        listener(status)
    }

    fun setSource(mode: SourceMode) {
        if (ui.probeRunning || ui.climateBusy || ui.driveBusy || ui.bodyBusy || mode == ui.profile.source) return
        val previousMode = ui.profile.source
        var trips = ui.trips
        var sessions = ui.sessions
        var removed = 0
        if (previousMode == SourceMode.DEMO && mode != SourceMode.DEMO) {
            removed = trips.count { it.source == RecordSource.DEMO } +
                sessions.count { it.source == RecordSource.DEMO }
            trips = trips.filterNot { it.source == RecordSource.DEMO }
            sessions = sessions.filterNot { it.source == RecordSource.DEMO }
        }
        if (mode == SourceMode.DEMO &&
            trips.none { it.source == RecordSource.DEMO } &&
            sessions.none { it.source == RecordSource.DEMO }
        ) {
            trips = trips + DemoData.seedTrips()
            sessions = sessions + DemoData.seedSessions()
        }

        val profile = ui.profile.copy(source = mode)
        val vehicle = when (mode) {
            SourceMode.DEMO -> DemoData.snapshot(profile)
            SourceMode.MANUAL -> manualSnapshot(profile, asFallback = false)
            SourceMode.CAR_API, SourceMode.ROOT -> manualSnapshot(
                profile,
                asFallback = true,
                note = "Источник ожидает опроса"
            )
        }
        val checks = if (mode == SourceMode.DEMO) {
            ui.checks + (SourceMode.DEMO to DemoData.check())
        } else {
            ui.checks
        }
        // Якоря принадлежат Car API: на другом источнике они бессмысленны, и автомат
        // не должен дописать в журнал строку, начатую по сигналу другой природы.
        if (mode != SourceMode.CAR_API) journal.reset()
        driveMemory.reset()
        ui = ui.copy(
            profile = profile,
            trips = trips,
            sessions = sessions,
            vehicle = vehicle,
            checks = checks,
            climateWrite = null,
            activeClimateChange = null,
            activeClimatePreset = null,
            climatePresetEngaged = null,
            activeDriveMode = null,
            activeRegen = null,
            journalTrip = journal.trip,
            journalCharge = journal.charge,
            probeLog = probeLogs[mode] ?: probeHint(mode)
        )
        persist()
        if (removed > 0) {
            emit("Демо-записи убраны из журнала: $removed")
        }

        when (mode) {
            SourceMode.DEMO -> emit("Включён демонстрационный источник")
            SourceMode.MANUAL -> emit("Ручной режим: задайте заряд и запас хода")
            SourceMode.CAR_API -> emit("Car API выбран, проверяю доступ…")
            SourceMode.ROOT -> emit("Root-источник выбран, проверяю команды…")
        }
        lastNote = null
        syncService()
        restartPolling()
        publishStatus()
    }

    fun runProbe() {
        if (ui.probeRunning || ui.climateBusy || ui.driveBusy || ui.bodyBusy) return
        val mode = ui.profile.source
        val profile = ui.profile
        ui = ui.copy(
            probeRunning = true,
            probeLog = "$ ${sourceSlug(mode)} --probe\n… проверка выполняется"
        )
        scope.launch {
            val outcome = when (mode) {
                SourceMode.DEMO, SourceMode.MANUAL -> simulatedProbe(mode, profile)
                SourceMode.CAR_API, SourceMode.ROOT -> reader.probe(profile)
            }
            probeLogs[mode] = outcome.log.ifBlank { probeHint(mode) }
            val (checks, changed) = mergeCheck(ui.checks, mode, outcome.check)
            var nextVehicle = ui.vehicle
            val snapshot = usableSnapshot(outcome)
            if (snapshot != null) {
                nextVehicle = snapshot
            } else if (ui.profile.source == mode) {
                nextVehicle = manualSnapshot(
                    ui.profile,
                    asFallback = true,
                    note = outcome.check.summary.ifBlank { "Источник недоступен" }
                )
            }
            ui = ui.copy(
                probeRunning = false,
                probeLog = probeLogs[mode] ?: probeHint(mode),
                checks = checks,
                vehicle = nextVehicle
            )
            if (mode == SourceMode.CAR_API) seedCarEvents(snapshot)
            if (changed) persist()
            emit(
                when (outcome.check.status) {
                    CheckStatus.OK -> "Источник доступен"
                    CheckStatus.UNKNOWN -> if (mode == SourceMode.MANUAL) {
                        "Ручной режим: задайте значения"
                    } else {
                        "Источник ответил частично: ${outcome.check.summary}"
                    }
                    CheckStatus.ERROR -> "Источник недоступен. Подробности в журнале проверки."
                }
            )
        }
    }

    /**
     * Команда климат-панели. Демо меняет состояние только в приложении и прямо об
     * этом говорит; Car API отправляет запись в гу и показывает причину отказа, если
     * прошивка не выдала права. Root и ручной режим управлять климатом не обещают.
     */
    fun onClimateChange(change: ClimateChange) {
        if (ui.climateBusy || ui.probeRunning) return
        // Ручная правка любого органа снимает сценарий: кнопка больше не «включена».
        ui = ui.copy(climatePresetEngaged = null)
        val mode = ui.profile.source
        val current = ui.vehicle.climate
        if (current == null) {
            ui = ui.copy(
                climateWrite = ClimateWriteResult(
                    status = CheckStatus.ERROR,
                    summary = "климат не отвечает — управление недоступно"
                )
            )
            return
        }
        val next = GeelyVhal.climateNext(change, current)
            ?: if (change == ClimateChange.WINDSHIELD_HEAT) {
                // 0x10200C00 на этом ГУ не отвечает на чтение, поэтому кнопка
                // оставалась неактивной. Неизвестное состояние считаем выключенным:
                // первое нажатие включает обогрев, повторное — выключает по тому,
                // что запросила панель, а не по выдуманному ответу автомобиля.
                current.copy(windshieldHeatOn = !(current.windshieldHeatOn ?: false))
            } else {
                ui = ui.copy(
                    climateWrite = ClimateWriteResult(
                        status = CheckStatus.ERROR,
                        summary = "автомобиль не ответил этот сигнал, включать вслепую нельзя"
                    )
                )
                return
            }
        if (mode == SourceMode.DEMO) {
            ui = ui.copy(
                vehicle = ui.vehicle.copy(climate = next),
                climateWrite = ClimateWriteResult(
                    status = CheckStatus.OK,
                    summary = "демо: изменено только в приложении, автомобиль не затронут",
                    applied = next
                )
            )
            if (change == ClimateChange.WHEEL_HEAT) warnWheelHeat(next)
            playAck()
            return
        }

        controlGeneration++
        activeClimateObserved = false
        // Штатная панель показывает выбор сразу, не дожидаясь Binder-записи:
        // ответ автомобиля приходит подпиской, а следующее чтение поправит
        // значение, если прошивка команду не приняла.
        ui = ui.copy(
            climateBusy = true,
            activeClimateChange = change,
            activeClimatePreset = null,
            vehicle = ui.vehicle.copy(climate = next)
        )
        // Входим в try даже при уже отменённом scope: флаги не должны зависнуть.
        scope.launch(start = CoroutineStart.UNDISPATCHED) {
            try {
                val (result, log) = reader.writeClimate(mode, change, next.windshieldHeatOn)
                if (ui.profile.source != mode) return@launch
                applyClimateResult(mode, result, log, change, next, current)
                if (result.status == CheckStatus.OK && change == ClimateChange.WHEEL_HEAT) {
                    warnWheelHeat(next)
                }
            } catch (error: Exception) {
                val failure = commandFailure(error)
                applyClimateResult(mode, failure, "· ${failure.summary}", change, next, current)
                if (error is CancellationException) throw error
            } finally {
                activeClimateObserved = false
                ui = ui.copy(climateBusy = false, activeClimateChange = null, activeClimatePreset = null)
            }
        }
    }

    /** Быстрое охлаждение или обогрев: несколько обычных записей подряд. */
    fun onClimatePreset(preset: ClimatePreset) {
        if (ui.climateBusy || ui.probeRunning) return
        val mode = ui.profile.source
        val current = ui.vehicle.climate
        if (current == null) {
            ui = ui.copy(
                climateWrite = ClimateWriteResult(
                    status = CheckStatus.ERROR,
                    summary = "климат не отвечает — управление недоступно"
                )
            )
            return
        }
        // Повторное нажатие по активному пресету снимает его сразу, не дожидаясь,
        // пока владелец вручную тронет обогрев.
        val off = ui.climatePresetEngaged == preset && GeelyVhal.presetHeld(preset, current)
        val steps = GeelyVhal.presetSteps(preset, current, off)
        if (mode == SourceMode.DEMO) {
            val next = steps.fold(current) { state, step -> step.after(state) }
            ui = ui.copy(
                climatePresetEngaged = if (off) null else preset,
                vehicle = ui.vehicle.copy(climate = next),
                climateWrite = ClimateWriteResult(
                    status = CheckStatus.OK,
                    summary = "демо: изменено только в приложении, автомобиль не затронут",
                    applied = next
                )
            )
            warnWheelHeat(next)
            playAck()
            return
        }
        controlGeneration++
        activeClimateObserved = false
        ui = ui.copy(climateBusy = true, activeClimateChange = null, activeClimatePreset = preset)
        scope.launch(start = CoroutineStart.UNDISPATCHED) {
            try {
                val (result, log) = reader.writePreset(mode, preset, off)
                if (ui.profile.source != mode) return@launch
                if (result.status == CheckStatus.OK) {
                    ui = ui.copy(climatePresetEngaged = if (off) null else preset)
                }
                applyClimateResult(mode, result, log)
                result.applied?.let { warnWheelHeat(it) }
            } catch (error: Exception) {
                val failure = commandFailure(error)
                applyClimateResult(mode, failure, "· ${failure.summary}")
                if (error is CancellationException) throw error
            } finally {
                activeClimateObserved = false
                ui = ui.copy(climateBusy = false, activeClimateChange = null, activeClimatePreset = null)
            }
        }
    }

    private fun applyClimateResult(
        mode: SourceMode,
        result: ClimateWriteResult,
        log: String,
        change: ClimateChange? = null,
        requested: Climate? = null,
        previous: Climate? = null
    ) {
        appendLog(mode, log)
        if (ui.profile.source != mode) return
        val observed = mergeClimateCommandResult(
            current = ui.vehicle.climate,
            result = result,
            change = change,
            requested = requested,
            previous = previous,
            signalObservedSinceRequest = activeClimateObserved
        )
        val vehicle = ui.vehicle.copy(climate = observed)
        ui = ui.copy(climateWrite = result, vehicle = vehicle)
        if (result.confirmed) playAck()
        val heatWithoutReadback = change == ClimateChange.WINDSHIELD_HEAT &&
            result.status == CheckStatus.OK && result.observed?.windshieldHeatOn == null
        emit(
            when {
                heatWithoutReadback ->
                    "Команда обогрева лобового отправлена; подтверждения чтением нет"
                result.status == CheckStatus.OK ->
                    if (result.confirmed) "Изменение подтверждено чтением" else "Запрос принят, изменение пока не подтверждено"
                else -> "Не удалось подтвердить изменение климата: ${result.summary}"
            }
        )
    }

    /** Ошибка транспорта не доказывает ни применение, ни отказ автомобиля. */
    private fun commandFailure(error: Exception): ClimateWriteResult = ClimateWriteResult(
        status = CheckStatus.ERROR,
        summary = (if (error is CancellationException) "команда прервана" else
            "ошибка команды: ${error.message ?: error.javaClass.simpleName}") +
            "; результат на автомобиле неизвестен"
    )

    /**
     * Обогрев лобового 0x10200C00 на этом ГУ не отвечает на чтение, поэтому
     * последнее выбранное панелью состояние сохраняется между опросами. Как
     * только автомобиль начнёт отвечать, его значение заменяет сохранённое.
     */
    private fun keepWindshieldHeat(next: Climate?): Climate? {
        val carried = ui.vehicle.climate?.windshieldHeatOn ?: return next
        return when {
            next == null -> null
            next.windshieldHeatOn == null -> next.copy(windshieldHeatOn = carried)
            else -> next
        }
    }

    /**
     * Температура за бортом приходит только от проснувшегося климата: в журнале
     * 2026-10-28 AC_AMBIENT_TEMP и 0x11600703 во всех зонах ответили status=3 при
     * выключенном HVAC. Ноль подставлять нельзя, поэтому держим последнее настоящее
     * наблюдение так же, как это делает штатная панель, и лишь через полчаса
     * возвращаем прочерк — устаревшее значение за окном уже не подсказка.
     */
    private fun retainOutsideTemp(vehicle: VehicleSnapshot): VehicleSnapshot {
        val now = System.currentTimeMillis()
        vehicle.outsideTempC?.let {
            retainedOutsideTempC = it
            retainedOutsideTempAt = now
            return vehicle
        }
        val held = retainedOutsideTempC
        if (held == null || now - retainedOutsideTempAt > OUTSIDE_TEMP_HOLD_MS) return vehicle
        return vehicle.copy(outsideTempC = held)
    }

    /**
     * Режим и рекуперация на этом ГУ читаются не всегда: после записи HAL может
     * ответить status=1. Штатное приложение держит выбранное значение у себя,
     * поэтому и здесь молчание чтения не стирает уже известный выбор.
     */
    private fun keepDriveChoice(next: VehicleSnapshot): VehicleSnapshot {
        val previous = ui.vehicle
        if (previous.source != next.source || previous.isFallback) return next
        return next.copy(
            driveMode = next.driveMode ?: previous.driveMode,
            regen = next.regen ?: previous.regen
        )
    }

    /** Прошивка включает обогрев руля только после того, как была передача D или R. */
    private fun warnWheelHeat(state: Climate) {
        if ((state.wheelHeat ?: 0) > 0 && !driveMemory.seenDriveGear) {
            emit("Обогрев руля включится только после того, как будет включена передача D или R")
        }
    }

    fun onDriveMode(target: DriveMode) {
        if (target == ui.vehicle.driveMode || target !in GeelyVhal.SELECTABLE_DRIVE_MODES) return
        val regen = (ui.profile.preferredRegen ?: ui.vehicle.regen)
            ?.takeIf { it in GeelyVhal.SELECTABLE_REGEN }
        writeDrive(DriveMemory.Plan(target, regen), requestedRegen = null)
    }

    fun onRegen(target: RegenLevel) {
        if (target == ui.vehicle.regen || target !in GeelyVhal.SELECTABLE_REGEN) return
        val drive = (ui.profile.preferredDriveMode ?: ui.vehicle.driveMode)
            ?.takeIf { it in GeelyVhal.SELECTABLE_DRIVE_MODES }
        writeDrive(DriveMemory.Plan(drive, target), requestedMode = null)
    }

    fun setRestoreDrive(enabled: Boolean) {
        if (enabled == ui.profile.restoreDrive) return
        val profile = ui.profile.copy(
            restoreDrive = enabled,
            preferredDriveMode = ui.profile.preferredDriveMode ?: ui.vehicle.driveMode
                ?.takeIf { it in GeelyVhal.SELECTABLE_DRIVE_MODES },
            preferredRegen = ui.profile.preferredRegen ?: ui.vehicle.regen
                ?.takeIf { it in GeelyVhal.SELECTABLE_REGEN }
        )
        ui = ui.copy(profile = profile)
        persist()
        // Включение — явная просьба владельца: один возврат в этом включении
        // разрешён заново, даже если он уже был выполнен раньше.
        if (enabled) driveMemory.reset()
        emit(
            if (enabled) {
                "После включения будет отправлен запрос режима; применение зависит от автомобиля"
            } else {
                "Режим после включения выбирает автомобиль"
            }
        )
    }

    /** Уведомления о зарядке — только про то, что уже видно на экране: никаких команд автомобилю. */
    fun setChargeAlert(percent: Int) {
        val value = percent.coerceIn(0, 100)
        if (value == ui.profile.chargeAlertSoc) return
        ui = ui.copy(profile = ui.profile.copy(chargeAlertSoc = value))
        persist()
        emit(
            if (value == 0) "Уведомление о пороге заряда выключено"
            else "Уведомление о заряде $value% сработает один раз за сеанс зарядки"
        )
    }

    fun setChargeDoneAlert(enabled: Boolean) {
        if (enabled == ui.profile.chargeDoneAlert) return
        ui = ui.copy(profile = ui.profile.copy(chargeDoneAlert = enabled))
        persist()
        emit(if (enabled) "Будем сообщать об окончании зарядки" else "Об окончании зарядки не сообщаем")
    }

    private fun writeDrive(
        target: DriveMemory.Plan,
        restoring: Boolean = false,
        requestedMode: DriveMode? = target.mode,
        requestedRegen: RegenLevel? = target.regen
    ) {
        val first = target.mode?.let(GeelyVhal::driveModeWrites).orEmpty()
        val second = target.regen?.let(GeelyVhal::regenWrites).orEmpty()
        if (ui.driveBusy || ui.probeRunning || (first.isEmpty() && second.isEmpty())) return
        val mode = ui.profile.source
        if (mode == SourceMode.DEMO) {
            ui = ui.copy(
                vehicle = ui.vehicle.copy(
                    driveMode = target.mode ?: ui.vehicle.driveMode,
                    regen = target.regen ?: ui.vehicle.regen
                ),
                profile = target.remember(ui.profile)
            )
            persist()
            emit("Демо: изменено только в приложении")
            playAck()
            return
        }
        if (mode != SourceMode.CAR_API) {
            emit("Выбранный источник не управляет автомобилем")
            return
        }
        controlGeneration++
        driveMemory.settle()
        ui = ui.copy(
            driveBusy = true,
            activeDriveMode = requestedMode,
            activeRegen = requestedRegen,
            vehicle = ui.vehicle.copy(
                driveMode = target.mode ?: ui.vehicle.driveMode,
                regen = target.regen ?: ui.vehicle.regen
            )
        )
        scope.launch(start = CoroutineStart.UNDISPATCHED) {
            try {
                val prefix = if (restoring) "restore " else ""
                var accepted = true
                val failures = mutableListOf<String>()
                if (first.isNotEmpty()) {
                    val (result, log) = driveWriteAttempt {
                        reader.writeChain(
                            mode, "${prefix}drive_mode ${target.mode?.name?.lowercase()}", first,
                            stopOnFirst = false
                        )
                    }
                    appendLog(mode, log)
                    accepted = result.status == CheckStatus.OK
                    if (!accepted) failures += result.summary
                }
                if (ui.profile.source != mode) return@launch
                if (second.isNotEmpty()) {
                    if (first.isNotEmpty()) delay(DRIVE_REGEN_GAP_MS)
                    if (ui.profile.source != mode) return@launch
                    val (result, log) = driveWriteAttempt {
                        reader.writeChain(
                            mode, "${prefix}regen ${target.regen?.name?.lowercase()}", second,
                            stopOnFirst = false
                        )
                    }
                    appendLog(mode, log)
                    accepted = accepted && result.status == CheckStatus.OK
                    if (result.status != CheckStatus.OK) failures += result.summary
                }
                if (ui.profile.source != mode) return@launch
                if (accepted && !restoring) {
                    ui = ui.copy(profile = target.remember(ui.profile))
                    persist()
                }
                val confirmed = readDriveBack(mode, target)
                if (ui.profile.source != mode) return@launch
                val note = when {
                    !accepted -> "Не подтверждён приём всей пары настроек: ${failures.joinToString("; ")}"
                    confirmed && restoring -> "Режим и рекуперация после включения подтверждены чтением"
                    confirmed -> "Выбор сохранён в приложении; ответ автомобиля совпадает"
                    restoring -> "Запрос после включения отправлен; результат не подтверждён"
                    else -> "Выбор сохранён в приложении; результат на автомобиле не подтверждён"
                }
                appendLog(mode, "· $note")
                emit(note)
                if (!restoring && accepted && confirmed) playAck()
                if (restoring) {
                    lastNote = note
                    publishStatus()
                }
            } catch (error: Exception) {
                val note = "Режим и рекуперация: ${commandFailure(error).summary}"
                appendLog(mode, "· $note")
                if (ui.profile.source == mode) {
                    emit(note)
                    if (restoring) {
                        lastNote = note
                        publishStatus()
                    }
                }
                if (error is CancellationException) throw error
            } finally {
                ui = ui.copy(driveBusy = false, activeDriveMode = null, activeRegen = null)
            }
        }
    }

    /** Отказ первой половины пары не отменяет вторую; отмена корутины — отменяет. */
    private suspend fun driveWriteAttempt(
        write: suspend () -> Pair<ClimateWriteResult, String>
    ): Pair<ClimateWriteResult, String> = try {
        write()
    } catch (error: Exception) {
        if (error is CancellationException) throw error
        val failure = commandFailure(error)
        failure to "· ${failure.summary}"
    }

    private suspend fun readDriveBack(mode: SourceMode, target: DriveMemory.Plan): Boolean {
        var confirmed = false
        for (attempt in 0 until 2) {
            delay(if (attempt == 0) 250L else 450L)
            if (ui.profile.source != mode) return false
            val (drive, regen, log) = try {
                reader.readDrive()
            } catch (error: Exception) {
                if (error is CancellationException) throw error
                val note = "Ошибка сверки режима и рекуперации: ${error.message ?: error.javaClass.simpleName}"
                appendLog(mode, "· $note")
                if (ui.profile.source == mode) emit(note)
                // Не подставляем выбор панели вместо отсутствующего ответа.
                confirmed = false
                continue
            }
            appendLog(mode, log)
            if (ui.profile.source != mode) return false
            ui = ui.copy(
                vehicle = ui.vehicle.copy(
                    driveMode = drive,
                    regen = regen
                )
            )
            confirmed = target.matches(drive, regen)
        }
        return confirmed
    }

    /**
     * Открытие переднего багажника — единственная запись в кузов. Адрес-кандидат
     * ни разу не подтверждён записью на живой машине, поэтому состояние на экране
     * не меняем: правда придёт со следующим чтением BCM_HOOD_STATUS.
     * Задний багажник убран: в меню этого ГУ такой функции нет.
     */
    fun onFrunkOpen() = writeBodyActuator("открыть передний багажник", GeelyVhal.frunkOpenWrites())

    private fun writeBodyActuator(title: String, writes: List<GeelyVhal.VhalWrite>) {
        if (ui.bodyBusy || ui.probeRunning || writes.isEmpty()) return
        val mode = ui.profile.source
        if (mode == SourceMode.DEMO) {
            emit("Демо: команда не отправляется, автомобиль не затронут")
            return
        }
        controlGeneration++
        ui = ui.copy(bodyBusy = true)
        scope.launch {
            val (result, log) = reader.writeChain(mode, title, writes)
            appendLog(mode, log)
            ui = ui.copy(bodyBusy = false)
            if (result.status == CheckStatus.OK) {
                emit("Запрос отправлен автомобилю; открытие пока не подтверждено")
            } else {
                emit("Багажник не открыт: ${result.summary}")
            }
        }
    }

    private fun restoreDrive(snapshot: VehicleSnapshot) {
        if (ui.driveBusy || ui.climateBusy || ui.bodyBusy || ui.probeRunning) return
        val plan = driveMemory.observe(snapshot, ui.profile, System.currentTimeMillis())
        if (plan == null || ui.profile.source != SourceMode.CAR_API) return
        val target = DriveMemory.Plan(
            mode = (plan.mode ?: snapshot.driveMode)?.takeIf { it in GeelyVhal.SELECTABLE_DRIVE_MODES },
            regen = (plan.regen ?: snapshot.regen)?.takeIf { it in GeelyVhal.SELECTABLE_REGEN }
        )
        writeDrive(target, restoring = true)
    }

    private fun appendLog(mode: SourceMode, log: String) {
        probeLogs[mode] = ((probeLogs[mode] ?: probeHint(mode)) + "\n" + log).takeLast(LOG_MAX_CHARS)
        if (ui.profile.source == mode) ui = ui.copy(probeLog = probeLogs[mode]!!)
    }

    private fun playAck() {
        scope.launch(Dispatchers.Default) {
            ackMutex.withLock {
                runCatching {
                    val track = ackTrack ?: run {
                        val rate = 22_050
                        val count = rate * 72 / 1_000
                        var phase = 0.0
                        var overtonePhase = 0.0
                        val samples = ShortArray(count) { index ->
                            val seconds = index.toDouble() / rate
                            val progress = index.toDouble() / count
                            // Восходящий чирп: стеклянный тон с обертоном и коротким затуханием.
                            val tone = 740.0 + 880.0 * progress * progress
                            phase += 2.0 * Math.PI * tone / rate
                            overtonePhase += 2.0 * Math.PI * tone * 2.0 / rate
                            val attack = (seconds / 0.004).coerceAtMost(1.0)
                            val body = sin(phase) * exp(-seconds / 0.024)
                            val shimmer = sin(overtonePhase) * 0.28 * exp(-seconds / 0.012)
                            ((body + shimmer) * attack * 13_000.0).roundToInt().toShort()
                        }
                        val created = AudioTrack.Builder()
                            .setAudioAttributes(
                                AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_MEDIA)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                    .build()
                            )
                            .setAudioFormat(
                                AudioFormat.Builder()
                                    .setSampleRate(rate)
                                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                    .build()
                            )
                            .setBufferSizeInBytes(samples.size * 2)
                            .setTransferMode(AudioTrack.MODE_STATIC)
                            .build()
                        ackTrack = created
                        check(created.write(samples, 0, samples.size) == samples.size)
                        created.setVolume(0.65f)
                        created
                    }
                    track.stop()
                    check(track.reloadStaticData() == AudioTrack.SUCCESS)
                    track.play()
                }.onFailure {
                    runCatching { ackTrack?.release() }
                    ackTrack = null
                }
            }
        }
    }

    fun applyManualValues(socText: String, rangeText: String): Boolean {
        val soc = parseInt(socText)
        val range = parseInt(rangeText)
        if (soc == null || soc !in 0..100) {
            emit("Заряд должен быть числом от 0 до 100%")
            return false
        }
        if (range == null || range !in 0..1200) {
            emit("Запас хода должен быть числом от 0 до 1200 км")
            return false
        }
        val profile = ui.profile.copy(
            manualSoc = soc,
            manualRangeKm = range,
            manualUpdatedAt = nowMillis()
        )
        var vehicle = ui.vehicle
        if (ui.profile.source == SourceMode.MANUAL ||
            (ui.profile.source != SourceMode.DEMO && vehicle.isFallback)
        ) {
            vehicle = manualSnapshot(profile, asFallback = false)
        }
        ui = ui.copy(profile = profile, vehicle = vehicle)
        persist()
        emit("Ручные значения обновлены")
        return true
    }

    fun saveTariff(tariffText: String): Boolean {
        val tariff = parseDouble(tariffText)
        if (tariff == null || tariff !in 0.0..100.0) {
            emit("Проверьте тариф: допустимо от 0 до 100 р./кВт·ч")
            return false
        }
        ui = ui.copy(profile = ui.profile.copy(tariffPerKwh = tariff))
        persist()
        emit("Тариф сохранён")
        return true
    }

    fun setDockApps(packages: List<String>) {
        val cleaned = packages.filter { it.isNotBlank() }.distinct().take(Store.MAX_DOCK_APPS)
        if (cleaned == ui.profile.dockApps) return
        ui = ui.copy(profile = ui.profile.copy(dockApps = cleaned))
        persist()
    }

    fun saveRootCommands(
        soc: String,
        range: String,
        power: String,
        temp: String,
        driveMode: String,
        regen: String
    ): Boolean {
        val profile = ui.profile.copy(
            rootSocCommand = soc.trim(),
            rootRangeCommand = range.trim(),
            rootPowerCommand = power.trim(),
            rootTempCommand = temp.trim(),
            rootDriveModeCommand = driveMode.trim(),
            rootRegenCommand = regen.trim()
        )
        val check = SourceCheck(
            status = CheckStatus.UNKNOWN,
            summary = "команды обновлены, нужна проверка",
            checkedAt = nowMillis()
        )
        probeLogs[SourceMode.ROOT] =
            "$ su -c <команда>\n· команды сохранены\nℹ нажмите «Проверить доступ», чтобы выполнить их"
        ui = ui.copy(
            profile = profile,
            checks = ui.checks + (SourceMode.ROOT to check),
            probeLog = if (ui.profile.source == SourceMode.ROOT) probeLogs[SourceMode.ROOT]!! else ui.probeLog
        )
        persist()
        emit("Root-команды сохранены")
        if (ui.profile.source == SourceMode.ROOT) {
            restartPolling()
        }
        return true
    }

    fun addTrip(draft: TripDraft): Boolean {
        if (draft.distanceKm <= 0.0 || draft.distanceKm > 2000.0) {
            emit("Проверьте расстояние поездки")
            return false
        }
        if (draft.startedAt <= 0L) {
            emit("Проверьте дату и время")
            return false
        }
        if (draft.durationMin <= 0) {
            emit("Длительность должна быть больше нуля")
            return false
        }
        val estimated = draft.energyKwh == null || draft.energyKwh <= 0.0
        val energy = if (estimated) {
            Stats.estimateEnergy(draft.distanceKm, ui.trips).coerceAtLeast(0.1)
        } else {
            draft.energyKwh ?: 0.0
        }
        val trip = Trip(
            id = UUID.randomUUID().toString(),
            startedAt = draft.startedAt,
            from = draft.from.trim().ifBlank { "Старт" }.take(40),
            to = draft.to.trim().ifBlank { "Финиш" }.take(40),
            distanceKm = (draft.distanceKm * 10).roundToInt() / 10.0,
            durationMin = draft.durationMin.coerceIn(1, 24 * 60),
            energyKwh = (energy * 10).roundToInt() / 10.0,
            note = draft.note.trim().take(80),
            source = draft.source,
            energyEstimated = estimated,
            driveMode = draft.driveMode,
            regen = draft.regen,
            fromLat = draft.fromLat,
            fromLon = draft.fromLon,
            toLat = draft.toLat,
            toLon = draft.toLon
        )
        ui = ui.copy(trips = listOf(trip) + ui.trips)
        persist()
        emit(if (estimated) "Поездка добавлена, энергия оценена по среднему расходу" else "Поездка добавлена в журнал")
        return true
    }

    fun addCharge(draft: ChargeDraft): Boolean {
        if (draft.energyKwh <= 0.0 || draft.energyKwh > 500.0) {
            emit("Проверьте количество энергии")
            return false
        }
        if (draft.addedPercent !in 1..100) {
            emit("Добавленный заряд должен быть от 1 до 100%")
            return false
        }
        if (draft.durationMin <= 0) {
            emit("Длительность должна быть больше нуля")
            return false
        }
        if (draft.startedAt <= 0L) {
            emit("Проверьте дату зарядки")
            return false
        }
        val session = ChargeSession(
            id = UUID.randomUUID().toString(),
            startedAt = draft.startedAt,
            place = draft.place.trim().ifBlank { "Зарядка" }.take(40),
            addedPercent = draft.addedPercent.coerceIn(1, 100),
            energyKwh = (draft.energyKwh * 10).roundToInt() / 10.0,
            durationMin = draft.durationMin.coerceIn(1, 24 * 60),
            type = draft.type,
            source = draft.source
        )
        ui = ui.copy(sessions = listOf(session) + ui.sessions)
        persist()
        emit("Зарядка добавлена в журнал")
        return true
    }

    fun deleteTrip(id: String) {
        ui = ui.copy(trips = ui.trips.filterNot { it.id == id })
        persist()
        emit("Поездка удалена")
    }

    fun deleteCharge(id: String) {
        ui = ui.copy(sessions = ui.sessions.filterNot { it.id == id })
        persist()
        emit("Зарядка удалена")
    }

    fun clearJournal() {
        journal.reset()
        ui = ui.copy(
            trips = emptyList(),
            sessions = emptyList(),
            journalTrip = null,
            journalCharge = null
        )
        persist()
        emit("Журнал очищен")
    }

    /**
     * Выгрузка журнала: два CSV и копия JSON в каталог приложения. Расчёт текста и
     * запись уходят с главного потока — журнал растёт годами.
     */
    fun exportJournal() {
        if (ui.exportBusy) return
        val trips = ui.trips
        val sessions = ui.sessions
        val profile = ui.profile
        val checks = ui.checks
        ui = ui.copy(exportBusy = true)
        scope.launch {
            val result = try {
                Result.success(
                    withContext(Dispatchers.IO) {
                        files.export(
                            JournalExport.tripsCsv(trips, profile.tariffPerKwh),
                            JournalExport.chargesCsv(sessions, profile.tariffPerKwh),
                            store.backupJson(
                                PersistedState(
                                    profile = profile,
                                    trips = trips,
                                    sessions = sessions,
                                    checks = checks,
                                    demoSeeded = true
                                ),
                                BuildConfig.VERSION_NAME
                            )
                        )
                    }
                )
            } catch (cancellation: CancellationException) {
                throw cancellation
            } catch (failure: Throwable) {
                Result.failure(failure)
            }
            ui = ui.copy(exportBusy = false)
            emit(
                result.fold(
                    onSuccess = {
                        "Выгружено ${Fmt.trips(trips.size)} и ${Fmt.sessions(sessions.size)}: ${files.path}"
                    },
                    onFailure = { "Выгрузка не удалась: ${failureReason(it)}" }
                )
            )
        }
    }

    /**
     * Восстановление из копии возвращает журнал и тариф. Источник данных, root-команды
     * и ручные значения остаются текущие: копия могла прийти с другой машины. Файл без
     * записей ничего не стирает.
     */
    fun restoreJournal() {
        if (ui.exportBusy) return
        ui = ui.copy(exportBusy = true)
        scope.launch {
            val restored = try {
                Result.success(
                    withContext(Dispatchers.IO) {
                        val text = files.backupText()
                            ?: error("нет файла ${JournalFiles.BACKUP_FILE} в ${files.path}")
                        store.parseBackup(text) ?: error("файл не похож на копию журнала")
                    }
                )
            } catch (cancellation: CancellationException) {
                throw cancellation
            } catch (failure: Throwable) {
                Result.failure(failure)
            }
            val state = restored.getOrNull()
            if (state == null) {
                ui = ui.copy(exportBusy = false)
                emit("Восстановление не удалось: ${failureReason(restored.exceptionOrNull())}")
                return@launch
            }
            if (state.trips.isEmpty() && state.sessions.isEmpty()) {
                ui = ui.copy(exportBusy = false)
                emit("В копии нет записей — журнал оставлен без изменений")
                return@launch
            }
            ui = ui.copy(
                exportBusy = false,
                profile = ui.profile.copy(tariffPerKwh = state.profile.tariffPerKwh),
                trips = state.trips,
                sessions = state.sessions
            )
            persist()
            publishStatus()
            emit("Восстановлено: ${Fmt.trips(state.trips.size)} и ${Fmt.sessions(state.sessions.size)}")
        }
    }

    fun resetDemoData() {
        if (ui.probeRunning || ui.climateBusy || ui.driveBusy) return
        journal.reset()
        driveMemory.reset()
        val profile = ui.profile.copy(source = SourceMode.DEMO)
        probeLogs[SourceMode.DEMO] = DemoData.probeLog()
        probeLogs[SourceMode.MANUAL] = defaultManualProbeLog(profile)
        ui = ui.copy(
            profile = profile,
            trips = DemoData.seedTrips(),
            sessions = DemoData.seedSessions(),
            vehicle = DemoData.snapshot(profile),
            checks = ui.checks + (SourceMode.DEMO to DemoData.check()),
            climateWrite = null,
            activeClimateChange = null,
            activeClimatePreset = null,
            climatePresetEngaged = null,
            activeDriveMode = null,
            activeRegen = null,
            journalTrip = null,
            journalCharge = null,
            probeLog = DemoData.probeLog()
        )
        persist()
        lastNote = null
        syncService()
        restartPolling()
        publishStatus()
        emit("Демонстрационные данные восстановлены")
    }

    fun startTracking(): Boolean {
        if (ui.tracking != null) return true
        val newTracker = TripTracker(
            context = app,
            onUpdate = { distanceKm, points ->
                val current = ui.tracking
                if (current != null) {
                    ui = ui.copy(
                        tracking = current.copy(distanceKm = distanceKm, points = points)
                    )
                    publishStatus()
                }
            },
            onError = { message -> emit(message) }
        )
        if (!newTracker.start()) {
            emit(newTracker.lastError ?: "Не удалось начать GPS-запись")
            return false
        }
        tracker = newTracker
        ui = ui.copy(
            tracking = TrackingInfo(
                startedAt = System.currentTimeMillis(),
                distanceKm = 0.0
            )
        )
        if (!syncService()) return false
        publishStatus()
        emit("Запись поездки началась")
        return true
    }

    fun stopTracking(): TrackResult? {
        val result = tracker?.stop()
        tracker = null
        ui = ui.copy(tracking = null)
        syncService()
        publishStatus()
        if (result == null || result.distanceKm < 0.15) {
            emit("Маршрут слишком короткий — запись отброшена")
            return null
        }
        emit("Проверьте данные записанной поездки")
        return result
    }

    fun hasTracking(): Boolean = ui.tracking != null

    private fun receiveCarEvent(event: VehicleSnapshot) {
        if (ui.profile.source != SourceMode.CAR_API || event.source != SourceMode.CAR_API) return
        // Живые пакеты рисует рабочий стол. На зарядке обновляем только SOC и
        // температуру за бортом: они меняются сразу, а таблица истории не
        // перерисовывается на каждый пакет VHAL. Мощность, разъём и токи приходят
        // опросом. Списки поездок и настройки тоже остаются на опросе.
        // В фоне события продолжают обновлять снимок для сервиса и журнала —
        // подписка живёт, пока жив цикл опроса, а не только пока виден экран.
        val charging = uiVisible && uiPage == HubPage.CHARGING
        if (uiVisible && uiPage != HubPage.HOME && !charging) return
        val previous = carEventBaseline
        if (ui.probeRunning || previous == null || event.updatedAt > previous.updatedAt) {
            pendingCarEvent = event
            return
        }
        if (event.updatedAt < previous.updatedAt) return
        carEventBaseline = event
        if (ui.vehicle.source != SourceMode.CAR_API || ui.vehicle.isFallback) return
        val merged = retainOutsideTemp(ui.vehicle.withCarEvent(previous, event))
        val vehicle = if (charging) ui.vehicle.withBatteryCarEvent(merged) else merged
        if (!charging) ui.activeClimateChange?.let { change ->
            // Сравниваем с baseline подписки, а не оптимистичным UI: callback
            // может подтвердить тот же выбор и не изменить отображаемое значение.
            if (Climate().withSignalObservation(change, previous.climate) !=
                Climate().withSignalObservation(change, event.climate)
            ) activeClimateObserved = true
        }
        if (vehicle != ui.vehicle) publishCarEvent(vehicle)
    }

    /**
     * VHAL присылает снимок на каждое изменение скорости или передачи — это несколько
     * кадров перерисовки в секунду. Показываем не чаще [CAR_EVENT_UI_MS], а последнее
     * значение досылаем по таймеру, если новых пакетов не было.
     */
    private fun publishCarEvent(vehicle: VehicleSnapshot) {
        val now = android.os.SystemClock.uptimeMillis()
        val wait = CAR_EVENT_UI_MS - (now - lastCarEventUiAt)
        if (wait <= 0L) {
            carEventPublishJob?.cancel()
            carEventPublishJob = null
            pendingCarEventVehicle = null
            pendingCarEventBase = null
            applyCarEvent(vehicle)
            return
        }
        pendingCarEventVehicle = vehicle
        pendingCarEventBase = ui.vehicle
        if (carEventPublishJob != null) return
        carEventPublishJob = scope.launch {
            delay(wait)
            carEventPublishJob = null
            val next = pendingCarEventVehicle
            val base = pendingCarEventBase
            pendingCarEventVehicle = null
            pendingCarEventBase = null
            // Пока ждали, опрос или команда могли обновить снимок: их данные свежее.
            if (next != null && base != null && ui.vehicle == base) applyCarEvent(next)
        }
    }

    private fun applyCarEvent(vehicle: VehicleSnapshot) {
        lastCarEventUiAt = android.os.SystemClock.uptimeMillis()
        if (vehicle == ui.vehicle) return
        ui = ui.copy(vehicle = vehicle)
        publishStatus()
    }

    private fun seedCarEvents(snapshot: VehicleSnapshot?) {
        if (snapshot?.source != SourceMode.CAR_API) return
        carEventBaseline = snapshot
        val pending = pendingCarEvent
        pendingCarEvent = null
        if (pending != null) receiveCarEvent(pending)
    }

    private suspend fun refreshTelemetry(silent: Boolean) {
        val mode = ui.profile.source
        if (mode != SourceMode.CAR_API && mode != SourceMode.ROOT) return
        if (reading || ui.probeRunning || ui.climateBusy || ui.driveBusy || ui.bodyBusy) return
        val profile = ui.profile
        // Климат и кузов нужны только рабочему столу: на остальных страницах это
        // полсотни лишних Binder-чтений на каждый цикл опроса. На самом рабочем
        // столе их изменения приходят подпиской, поэтому полное чтение идёт
        // страховкой раз в FULL_READ_MS, а не каждый цикл.
        val now = System.currentTimeMillis()
        val home = uiVisible && uiPage == HubPage.HOME
        val full = home && (lastFullReadAt == 0L || now - lastFullReadAt >= FULL_READ_MS)
        val generation = controlGeneration
        reading = true
        val outcome = try {
            reader.read(profile, full)
        } finally {
            reading = false
        }
        if (full && outcome.snapshot != null) lastFullReadAt = now
        if (ui.profile.source != mode) return
        val snapshot = usableSnapshot(outcome)
        if (generation != controlGeneration) {
            seedCarEvents(snapshot)
            return
        }
        val (checks, changed) = mergeCheck(ui.checks, mode, outcome.check)
        val nextVehicle = if (snapshot != null) {
            val fresh = if (full) {
                // Обогрев лобового не читается: пока автомобиль молчит, опрос не
                // должен затирать выбор панели, иначе второе нажатие снова включит.
                snapshot.copy(climate = keepWindshieldHeat(snapshot.climate))
            } else {
                // Укороченное чтение не спрашивает климат и кузов: не стираем
                // последнее известное состояние, иначе рабочий стол мигал бы «нет данных».
                val previous = ui.vehicle
                if (previous.source == mode && !previous.isFallback) {
                    snapshot.copy(
                        climate = previous.climate,
                        body = previous.body
                    )
                } else {
                    snapshot
                }
            }
            retainOutsideTemp(keepDriveChoice(fresh))
        } else {
            val previous = ui.vehicle
            if (previous.source == mode && !previous.isFallback && previous.hasCoreData) {
                previous.copy(
                    stale = true,
                    note = outcome.check.summary.ifBlank { "Нет связи с источником" }
                )
            } else {
                manualSnapshot(
                    profile,
                    asFallback = true,
                    note = outcome.check.summary.ifBlank { "Источник недоступен" }
                )
            }
        }
        val previousTrip = journal.trip
        val previousCharge = journal.charge
        val update = if (snapshot != null) {
            journal.observe(snapshot, profile, ui.trips)
        } else {
            JournalUpdate()
        }
        val socRising = socRise.update(
            soc = nextVehicle.soc.takeIf { !nextVehicle.isFallback },
            charging = nextVehicle.isCharging == true,
            visible = uiVisible,
            now = now
        )
        val next = ui.copy(
            vehicle = nextVehicle,
            checks = checks,
            trips = if (update.trips.isEmpty()) ui.trips else update.trips + ui.trips,
            sessions = if (update.sessions.isEmpty()) ui.sessions else update.sessions + ui.sessions,
            journalTrip = journal.trip,
            journalCharge = journal.charge,
            socRising = socRising,
            // Чтение с климатом подтверждает или опровергает прошлый запрос: держать
            // старую плашку нет смысла, на экране должно быть состояние автомобиля.
            climateWrite = if (snapshot?.climate != null) null else ui.climateWrite
        )
        // От каждого чтения в снимке меняется только метка времени, поэтому на
        // стоянке дерево перерисовывалось каждый цикл, хотя числа те же. Неизменное
        // состояние публикуем не чаще REPUBLISH_MS: метка остаётся в пределах
        // пяти секунд, которые требует гейт установки обновления.
        val telemetryChanged = next.copy(
            vehicle = next.vehicle.copy(updatedAt = ui.vehicle.updatedAt)
        ) != ui
        if (telemetryChanged || now - lastTelemetryPublishAt >= REPUBLISH_MS) {
            ui = next
            lastTelemetryPublishAt = now
        }
        seedCarEvents(snapshot)
        // Начало и конец поездки или зарядки пишем сразу, а сдвиг прогресса внутри идущей —
        // не чаще раза в ANCHOR_PERSIST_MS: раньше каждый цикл опроса переписывал весь
        // журнал в SharedPreferences. Пробег берётся из одометра, поэтому потеря
        // последних секунд прогресса при смерти процесса ничего не искажает.
        val journalChanged = changed || update.trips.isNotEmpty() || update.sessions.isNotEmpty()
        val anchorBoundary = (previousTrip == null) != (journal.trip == null) ||
            (previousCharge == null) != (journal.charge == null)
        val anchorProgress = previousTrip != journal.trip || previousCharge != journal.charge
        if (journalChanged || anchorBoundary ||
            (anchorProgress && now - lastPersistAt >= ANCHOR_PERSIST_MS)
        ) persist()
        notifyCharge(nextVehicle, profile, update.sessions)
        update.notes.forEach { emit(it) }
        update.notes.lastOrNull()?.let { lastNote = it }
        snapshot?.let { restoreDrive(it) }
        if (!silent && snapshot != null) emit("Данные источника обновлены")
        publishStatus()
    }

    /**
     * Уведомления о зарядке. Порог берётся только из заряда автомобиля: на ручных
     * значениях молчим, иначе приложение хвасталось бы цифрой, которую ввело само.
     * Завершение — ровно одна сводка на самую позднюю закрытую сессию.
     */
    private fun notifyCharge(vehicle: VehicleSnapshot, profile: Profile, closed: List<ChargeSession>) {
        if (!vehicle.isFallback && profile.chargeAlertSoc > 0) {
            val reached = alerts.thresholdReached(
                soc = vehicle.soc,
                charging = vehicle.isCharging == true,
                limitPercent = profile.chargeAlertSoc
            )
            if (reached != null) {
                notifier.show(ChargeAlerts.threshold(profile.chargeAlertSoc, reached, vehicle.rangeKm))
            }
        }
        if (profile.chargeDoneAlert) {
            closed.maxByOrNull { it.startedAt }?.let { session ->
                notifier.show(ChargeAlerts.finished(session, profile.tariffPerKwh))
            }
        }
    }

    private fun polls(mode: SourceMode): Boolean = mode == SourceMode.CAR_API || mode == SourceMode.ROOT

    private fun restartPolling() {
        val previous = pollJob
        previous?.cancel()
        pollJob = scope.launch {
            // Binder-чтение не прерывается cancel: дождаться его нужно вне UI-потока.
            withContext(NonCancellable) { previous?.cancelAndJoin() }
            ensureActive()
            carEventBaseline = null
            pendingCarEvent = null
            val mode = ui.profile.source
            if (!polls(mode) || (!uiVisible && serviceListener == null)) {
                withContext(Dispatchers.IO) { reader.close() }
                return@launch
            }
            if (mode == SourceMode.CAR_API) {
                launch { reader.carUpdates.collect { receiveCarEvent(it) } }
            }
            while (isActive) {
                refreshTelemetry(silent = true)
                // Интервал пересчитывается каждые полсекунды: после возврата на
                // рабочий стол секундный темп возобновляется, не дожидаясь конца
                // длинной паузы списка.
                val interval = pollInterval(mode)
                var waited = 0L
                while (isActive && waited < interval) {
                    delay(POLL_TICK_MS)
                    waited += POLL_TICK_MS
                    if (pollInterval(mode) < interval) break
                }
            }
        }
    }

    /**
     * Опрос — сверка, а не источник живых чисел: при работающей подписке скорость,
     * заряд, режим и климат приходят callback'ами, а чтение лишь чинит пропущенное
     * и забирает свойства без событий. Поэтому рабочий стол сверяется раз в
     * [SUBSCRIPTION_POLL_MS], а не каждую секунду. Если подписка не зарегистрировалась,
     * остаётся прежний быстрый опрос — иначе спидометр дёргался бы раз в пять секунд.
     */
    private fun pollInterval(mode: SourceMode): Long = when {
        mode != SourceMode.CAR_API -> if (uiVisible) 15_000L else 30_000L
        !reader.eventsActive -> when {
            uiVisible && uiPage == HubPage.HOME -> 1_000L
            uiVisible -> 3_000L
            else -> 10_000L
        }
        uiVisible && uiPage == HubPage.HOME -> SUBSCRIPTION_POLL_MS
        uiVisible -> 10_000L
        else -> 20_000L
    }

    private suspend fun simulatedProbe(mode: SourceMode, profile: Profile): ProbeOutcome {
        delay(350)
        return when (mode) {
            SourceMode.DEMO -> ProbeOutcome(
                log = DemoData.probeLog(),
                check = DemoData.check(),
                snapshot = DemoData.snapshot(profile)
            )
            SourceMode.MANUAL -> {
                val hasValues = profile.manualSoc != null || profile.manualRangeKm != null
                val log = buildString {
                    appendLine("$ manual-provider --probe")
                    appendLine("✓ ручной ввод доступен без разрешений")
                    if (hasValues) {
                        appendLine("· SOC ${profile.manualSoc ?: "—"}%, запас ${profile.manualRangeKm ?: "—"} км")
                    } else {
                        appendLine("· значения ещё не заданы")
                    }
                    append("ℹ запас и заряд задаются в настройках источника")
                }
                ProbeOutcome(
                    log = log,
                    check = SourceCheck(
                        status = if (hasValues) CheckStatus.OK else CheckStatus.UNKNOWN,
                        summary = if (hasValues) {
                            "ручные значения: ${profile.manualSoc ?: "—"}% · ${profile.manualRangeKm ?: "—"} км"
                        } else {
                            "значения не заданы"
                        },
                        checkedAt = nowMillis()
                    ),
                    snapshot = if (hasValues) manualSnapshot(profile, asFallback = false) else null
                )
            }
            else -> ProbeOutcome(
                log = probeHint(mode),
                check = SourceCheck(
                    status = CheckStatus.UNKNOWN,
                    summary = "нет проверки",
                    checkedAt = nowMillis()
                )
            )
        }
    }

    private fun initialVehicle(profile: Profile): VehicleSnapshot = when (profile.source) {
        SourceMode.DEMO -> DemoData.snapshot(profile)
        SourceMode.MANUAL -> manualSnapshot(profile, asFallback = false)
        SourceMode.CAR_API, SourceMode.ROOT -> manualSnapshot(
            profile,
            asFallback = true,
            note = "Источник ожидает опроса"
        )
    }

    private fun manualSnapshot(
        profile: Profile,
        asFallback: Boolean,
        note: String = ""
    ): VehicleSnapshot = VehicleSnapshot(
        source = profile.source,
        soc = profile.manualSoc,
        rangeKm = profile.manualRangeKm,
        batteryKwh = profile.batteryKwh,
        updatedAt = profile.manualUpdatedAt,
        isFallback = asFallback,
        note = note.ifBlank { if (asFallback) "Показаны ручные значения" else "Ручной ввод" }
    )

    private fun usableSnapshot(outcome: ProbeOutcome): VehicleSnapshot? {
        val snapshot = outcome.snapshot ?: return null
        // Снимок показывает, даже если автомобиль ответил только температурой или
        // режимом: это честнее, чем подменять ответ ручными значениями.
        return snapshot.takeIf {
            it.hasCoreData || it.chargePowerKw != null || it.speedKmh != null ||
                it.outsideTempC != null || it.driveMode != null || it.regen != null ||
                it.gear != null || it.ignition != null ||
                it.climate?.controllable == true || it.body != null
        }
    }

    private fun defaultChecks(): Map<SourceMode, SourceCheck> {
        val base = SourceMode.values().associateWith {
            SourceCheck(CheckStatus.UNKNOWN, "не проверен")
        }
        return base +
            mapOf(
                SourceMode.DEMO to DemoData.check(),
                SourceMode.MANUAL to SourceCheck(CheckStatus.OK, "ручной ввод", nowMillis())
            )
    }

    private fun defaultProbeLogs(profile: Profile): Map<SourceMode, String> = mapOf(
        SourceMode.DEMO to DemoData.probeLog(),
        SourceMode.MANUAL to defaultManualProbeLog(profile),
        SourceMode.CAR_API to
            "$ android.car probe\n· проверка выполняется на головном устройстве\nℹ нажмите «Проверить доступ»: проба прочитает свойства и запишет, что из них ответило",
        SourceMode.ROOT to
            "$ su -c id\n· проверка выполняется на головном устройстве\nℹ задайте команды чтения и нажмите «Проверить доступ»"
    )

    private fun defaultManualProbeLog(profile: Profile): String = buildString {
        appendLine("$ manual-provider --probe")
        appendLine("✓ ручной ввод доступен без разрешений")
        if (profile.manualSoc != null || profile.manualRangeKm != null) {
            appendLine("· SOC ${profile.manualSoc ?: "—"}%, запас ${profile.manualRangeKm ?: "—"} км")
        } else {
            appendLine("· значения ещё не заданы")
        }
        append("ℹ при недоступности Car API/root используются как резерв")
    }

    private fun probeHint(mode: SourceMode): String = when (mode) {
        SourceMode.DEMO -> DemoData.probeLog()
        SourceMode.MANUAL -> defaultManualProbeLog(ui.profile)
        SourceMode.CAR_API ->
            "$ android.car probe\n· проверка выполняется на головном устройстве\nℹ нажмите «Проверить доступ»: проба прочитает свойства и запишет, что из них ответило"
        SourceMode.ROOT ->
            "$ su -c id\n· проверка выполняется на головном устройстве\nℹ задайте команды чтения и нажмите «Проверить доступ»"
    }

    private fun sourceSlug(mode: SourceMode): String = when (mode) {
        SourceMode.DEMO -> "demo-provider"
        SourceMode.MANUAL -> "manual-provider"
        SourceMode.CAR_API -> "android.car"
        SourceMode.ROOT -> "su"
    }

    private fun mergeCheck(
        checks: Map<SourceMode, SourceCheck>,
        mode: SourceMode,
        newCheck: SourceCheck
    ): Pair<Map<SourceMode, SourceCheck>, Boolean> {
        val old = checks[mode]
        val changed = old == null ||
            old.status != newCheck.status ||
            old.summary != newCheck.summary
        val merged = if (changed) newCheck else old!!
        return (checks + (mode to merged)) to changed
    }

    private fun persist() {
        lastPersistAt = System.currentTimeMillis()
        store.save(
            PersistedState(
                profile = ui.profile,
                trips = ui.trips,
                sessions = ui.sessions,
                checks = ui.checks,
                demoSeeded = true,
                tripAnchor = ui.journalTrip,
                chargeAnchor = ui.journalCharge
            )
        )
    }

    private fun emit(message: String) {
        _messages.tryEmit(message)
    }

    /** Сообщение исключения вместо имени класса: у IO-ошибок оно говорит, что не так. */
    private fun failureReason(error: Throwable?): String =
        error?.message?.takeIf { it.isNotBlank() } ?: error?.javaClass?.simpleName ?: "неизвестная ошибка"

    private fun parseInt(text: String): Int? =
        text.trim().replace(" ", "").replace(',', '.').toDoubleOrNull()?.roundToInt()

    private fun parseDouble(text: String): Double? =
        text.trim().replace(" ", "").replace(',', '.').toDoubleOrNull()

    companion object {
        private var instance: HubController? = null

        /** Хвост журнала проверки: около десятка полных проб или вся сессия управления. */
        private const val LOG_MAX_CHARS = 60_000

        /** Шаг пересчёта паузы опроса при смене экрана. */
        private const val POLL_TICK_MS = 500L

        /** Central EX Auto пишет рекуперацию через 450 мс после режима. */
        private const val DRIVE_REGEN_GAP_MS = 450L

        /** Неизменная телеметрия попадает в UI не чаще раза в 2 с (гейт установки — 5 с). */
        private const val REPUBLISH_MS = 2_000L

        /** События VHAL показываются не чаще пяти раз в секунду: цифры не мигают, кадры не копятся. */
        private const val CAR_EVENT_UI_MS = 190L

        /** Прогресс идущей поездки или зарядки сохраняется не чаще раза в полминуты. */
        private const val ANCHOR_PERSIST_MS = 30_000L

        /**
         * Климат и кузов читаются целиком не чаще раза в 10 с: их изменения приходят
         * подпиской, а полное чтение остаётся страховкой от пропущенного события.
         */
        private const val FULL_READ_MS = 10_000L

        /**
         * Сверка рабочего стола при живой подписке: события дают реакцию сразу,
         * а чтение раз в 5 секунд только восполняет то, что callback не принёс.
         */
        private const val SUBSCRIPTION_POLL_MS = 5_000L

        /**
         * Сколько показывать последнюю известную температуру за бортом. Климат
         * отдаёт её только проснувшимся: в журнале 2026-10-28 AC_AMBIENT_TEMP и
         * 0x11600703 во всех зонах ответили status=3 при выключенном HVAC, и без
         * удержания панель каждый раз показывала прочерк.
         */
        private const val OUTSIDE_TEMP_HOLD_MS = 30 * 60_000L

        /** Вызывается только с главного потока: экран, сервис и приёмник загрузки. */
        fun get(context: Context): HubController =
            instance ?: HubController(context.applicationContext).also { instance = it }
    }
}

/** Результат одиночной команды не является снимком остальных сигналов климата. */
internal fun mergeClimateCommandResult(
    current: Climate?,
    result: ClimateWriteResult,
    change: ClimateChange? = null,
    requested: Climate? = null,
    previous: Climate? = null,
    signalObservedSinceRequest: Boolean = false
): Climate? {
    // Сценарий не оптимистичен: без чтения ему нечего откатывать.
    if (change == null) return result.observed ?: current
    val latest = current ?: Climate()
    return when {
        result.status != CheckStatus.OK -> when {
            result.observed != null -> latest.withSignalObservation(change, result.observed)
            // Callback важнее старого снимка, даже если совпал с запросом или
            // успел изменить сигнал и вернуть его обратно. Проверка значения
            // дополнительно защищает обновления UI не из подписки.
            signalObservedSinceRequest || requested == null ||
                latest.withSignalObservation(change, requested) != latest -> current
            else -> latest.withSignalObservation(change, previous)
        }
        result.confirmed -> latest.withSignalObservation(change, result.observed)
        signalObservedSinceRequest -> current
        // Принятая, но не подтверждённая запись оставляет выбор панели; это
        // не readback. Следующий callback/опрос заменит его настоящим ответом.
        else -> latest.withSignalObservation(change, requested ?: result.observed)
    }
}
