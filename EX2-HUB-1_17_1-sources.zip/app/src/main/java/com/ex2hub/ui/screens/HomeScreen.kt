package com.ex2hub.ui.screens

import android.content.res.Resources
import android.graphics.BitmapFactory
import android.widget.Toast
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.requiredWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ex2hub.R
import com.ex2hub.data.BodyPart
import com.ex2hub.data.Climate
import com.ex2hub.data.ClimateChange
import com.ex2hub.data.ClimatePreset
import com.ex2hub.data.DriveMode
import com.ex2hub.data.Fmt
import com.ex2hub.data.Gear
import com.ex2hub.data.RegenLevel
import com.ex2hub.source.GeelyVhal
import com.ex2hub.ui.AppIcons
import com.ex2hub.ui.DepthIcons
import com.ex2hub.ui.HubPage
import com.ex2hub.ui.HubUiState
import com.ex2hub.ui.InstalledApps
import com.ex2hub.ui.theme.HomeColors
import com.ex2hub.ui.title
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Рабочий стол по макету. Масштаб подбирается по высоте, а логическая ширина
 * холста растягивается на весь рабочий стол: пропорции значков и строк остаются
 * макетными, но блоки заполняют ширину. Все размеры ниже — пиксели макета, умноженные
 * на 1920/1366 ≈ 1,4056 (плотность ГУ — 1,0). 1768 — это 1920 без левой панели
 * навигации 152 dp, то есть минимальная ширина холста.
 */
private val DesignWidth = 1768.dp
private val DesignHeight = 1080.dp

private val CanvasStart = 19.7.dp
private val CanvasTop = 30.9.dp
private val CanvasEnd = 33.7.dp
private val CanvasBottom = 47.8.dp
private val CanvasGap = 23.9.dp
private val PanelRadius = 21.1.dp

private val HeroRowHeight = 185.5.dp
private val HeroRowTop = 35.1.dp
private val HeroRowGap = 19.7.dp

private val DockHeight = 119.5.dp
private val DockTop = 21.1.dp
private val DockTileWidth = 195.65.dp
private val DockGap = 14.06.dp

@Composable
fun HomeScreen(
    ui: HubUiState,
    onNavigate: (HubPage) -> Unit,
    onClimate: (ClimateChange) -> Unit,
    onPreset: (ClimatePreset) -> Unit,
    onDriveMode: (DriveMode) -> Unit,
    onRegen: (RegenLevel) -> Unit,
    onFrunkOpen: () -> Unit,
    onAllApps: () -> Unit
) {
    val vehicle = ui.vehicle
    val c = HomeColors.current
    // Фон рисуется дальше своих границ: без обрезки он закрашивает рейл навигации.
    BoxWithConstraints(
        Modifier.fillMaxSize().clipToBounds().workspaceGradient(c.workspace)
    ) {
        val scale = minOf(
            maxWidth.value / DesignWidth.value,
            maxHeight.value / DesignHeight.value
        )
        val canvasWidth = maxWidth / scale
        val shellWidth = maxWidth
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Box(
                Modifier.size(shellWidth, DesignHeight * scale),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    Modifier
                        .requiredSize(canvasWidth, DesignHeight)
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            // requiredSize центрирует холст; масштаб должен сохранять тот же центр.
                            transformOrigin = TransformOrigin.Center
                        }
                ) {
                    HomeCanvas(
                        rangeKm = vehicle.rangeKm,
                        soc = vehicle.soc,
                        socRising = ui.socRising,
                        usableKwh = vehicle.usableKwh,
                        outsideTempC = vehicle.outsideTempC,
                        gear = vehicle.gear,
                        hoodOpen = vehicle.body?.openParts?.contains(BodyPart.HOOD) == true,
                        driveMode = vehicle.driveMode,
                        regen = vehicle.regen,
                        climate = vehicle.climate,
                        dockApps = ui.profile.dockApps,
                        driveBusy = ui.driveBusy,
                        climateBusy = ui.climateBusy,
                        bodyBusy = ui.bodyBusy,
                        pendingChange = ui.activeClimateChange,
                        pendingPreset = ui.activeClimatePreset,
                        engagedPreset = ui.climatePresetEngaged,
                        pendingDriveMode = ui.activeDriveMode,
                        pendingRegen = ui.activeRegen,
                        onDriveMode = onDriveMode,
                        onRegen = onRegen,
                        onFrunkOpen = onFrunkOpen,
                        onClimate = onClimate,
                        onPreset = onPreset,
                        onConfigureDock = { onNavigate(HubPage.SETTINGS) },
                        onAllApps = onAllApps
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeCanvas(
    rangeKm: Int?,
    soc: Int?,
    socRising: Boolean,
    usableKwh: Double?,
    outsideTempC: Int?,
    gear: Gear?,
    hoodOpen: Boolean,
    driveMode: DriveMode?,
    regen: RegenLevel?,
    climate: Climate?,
    dockApps: List<String>,
    driveBusy: Boolean,
    climateBusy: Boolean,
    bodyBusy: Boolean,
    pendingChange: ClimateChange?,
    pendingPreset: ClimatePreset?,
    engagedPreset: ClimatePreset?,
    pendingDriveMode: DriveMode?,
    pendingRegen: RegenLevel?,
    onDriveMode: (DriveMode) -> Unit,
    onRegen: (RegenLevel) -> Unit,
    onFrunkOpen: () -> Unit,
    onClimate: (ClimateChange) -> Unit,
    onPreset: (ClimatePreset) -> Unit,
    onConfigureDock: () -> Unit,
    onAllApps: () -> Unit
) {
    // Режим, которого нет в списке записи, всё равно показываем: скрыть
    // фактическое состояние автомобиля хуже, чем показать его невыбираемым.
    val driveOptions = remember(driveMode) {
        val base = GeelyVhal.SELECTABLE_DRIVE_MODES
        if (driveMode != null && driveMode !in base) base + driveMode else base
    }
    val regenOptions = remember(regen) {
        val base = GeelyVhal.SELECTABLE_REGEN
        if (regen != null && regen !in base) base + regen else base
    }
    // Занятость читается в момент нажатия, а не принимается параметром кнопки:
    // иначе смена флага перерисовывала бы весь блок, а не одну кнопку.
    val busyClimate = rememberUpdatedState(climateBusy)
    val busyDrive = rememberUpdatedState(driveBusy)
    val runClimate: (ClimateChange) -> Unit = remember(onClimate) {
        { change -> if (!busyClimate.value) onClimate(change) }
    }
    val runPreset: (ClimatePreset) -> Unit = remember(onPreset) {
        { preset -> if (!busyClimate.value) onPreset(preset) }
    }
    val runDriveMode: (DriveMode) -> Unit = remember(onDriveMode) {
        { mode -> if (!busyDrive.value && mode in GeelyVhal.SELECTABLE_DRIVE_MODES) onDriveMode(mode) }
    }
    val runRegen: (RegenLevel) -> Unit = remember(onRegen) {
        { level -> if (!busyDrive.value && level in GeelyVhal.SELECTABLE_REGEN) onRegen(level) }
    }
    Row(
        Modifier
            .fillMaxSize()
            .padding(start = CanvasStart, top = CanvasTop, end = CanvasEnd, bottom = CanvasBottom),
        horizontalArrangement = Arrangement.spacedBy(CanvasGap)
    ) {
        Column(Modifier.weight(736f).fillMaxHeight()) {
            HeroCard(
                rangeKm = rangeKm,
                soc = soc,
                usableKwh = usableKwh,
                outsideTempC = outsideTempC,
                gear = gear,
                hoodOpen = hoodOpen,
                busy = bodyBusy,
                pulse = socRising,
                onFrunkOpen = onFrunkOpen,
                modifier = Modifier.fillMaxWidth().weight(1f)
            )
            Spacer(Modifier.height(HeroRowTop))
            Row(
                Modifier.fillMaxWidth().height(HeroRowHeight),
                horizontalArrangement = Arrangement.spacedBy(HeroRowGap)
            ) {
                SegmentCard(
                    title = "Режим движения",
                    headIcon = DepthIcons.Car,
                    options = driveOptions,
                    selectable = GeelyVhal.SELECTABLE_DRIVE_MODES,
                    selected = driveMode,
                    pending = pendingDriveMode,
                    label = { it.title() },
                    iconFor = { modeIcon(it) },
                    onSelect = runDriveMode,
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
                SegmentCard(
                    title = "Рекуперация",
                    headIcon = DepthIcons.Bolt,
                    options = regenOptions,
                    selectable = GeelyVhal.SELECTABLE_REGEN,
                    selected = regen,
                    pending = pendingRegen,
                    label = { it.title().capitalized() },
                    iconFor = { regenIcon(it) },
                    onSelect = runRegen,
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
            }
            Spacer(Modifier.height(DockTop))
            AppDock(
                packages = dockApps,
                onAllApps = onAllApps,
                onConfigure = onConfigureDock,
                modifier = Modifier.fillMaxWidth()
            )
        }
        ClimatePanel(
            climate = climate,
            pendingChange = pendingChange,
            pendingPreset = pendingPreset,
            engagedPreset = engagedPreset,
            onClimate = runClimate,
            onPreset = runPreset,
            modifier = Modifier.weight(467f).fillMaxHeight()
        )
    }
}

// ---------------------------------------------------------------------------------------
// Запас хода
// ---------------------------------------------------------------------------------------

/** Единственный статичный кадр декодируется вне UI и повторно используется. */
private object CarFrameCache {
    @Volatile
    private var image: ImageBitmap? = null

    fun peek(): ImageBitmap? = image

    @Synchronized
    fun load(resources: Resources): ImageBitmap? {
        image?.let { return it }
        return BitmapFactory.decodeResource(resources, R.drawable.car_base)
            ?.asImageBitmap()?.also { image = it }
    }
}

@Composable
private fun HeroCard(
    rangeKm: Int?,
    soc: Int?,
    usableKwh: Double?,
    outsideTempC: Int?,
    gear: Gear?,
    hoodOpen: Boolean,
    busy: Boolean,
    pulse: Boolean,
    onFrunkOpen: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(PanelRadius)
    val c = HomeColors.current
    val resources = LocalContext.current.resources
    val car by produceState(CarFrameCache.peek(), resources) {
        value = withContext(Dispatchers.Default) { CarFrameCache.load(resources) }
    }
    /**
     * Дыхание полосы заряда. Альфа читается в graphicsLayer, поэтому анимация
     * перерисовывает слой, а не перегенерирует карточку с кадром автомобиля.
     */
    val fillAlpha = remember { Animatable(1f) }
    LaunchedEffect(pulse) {
        if (pulse) {
            while (true) {
                fillAlpha.animateTo(0.55f, tween(1200, easing = FastOutSlowInEasing))
                fillAlpha.animateTo(1f, tween(1200, easing = FastOutSlowInEasing))
            }
        } else {
            fillAlpha.animateTo(1f, tween(300))
        }
    }
    Box(
        modifier
            .clip(shape)
            .cssGradient(
                118f,
                0f to c.heroGradient[0],
                0.52f to c.heroGradient[1],
                1f to c.heroGradient[2]
            )
            .radialGlow(c.heroGlow, 0.70f, 0.62f, 0.58f, 0.72f)
            .border(1.dp, c.heroBorder, shape)
    ) {
        val bitmap = car
        if (bitmap != null) {
            Box(
                Modifier
                    .fillMaxSize()
                    .drawBehind {
                        val carHeight = size.height * 2f
                        val carWidth = carHeight * bitmap.width / bitmap.height
                        drawImage(
                            image = bitmap,
                            dstOffset = IntOffset(
                                (size.width - carWidth * 0.8f).roundToInt(),
                                (-size.height * 0.5f).roundToInt()
                            ),
                            dstSize = IntSize(carWidth.roundToInt(), carHeight.roundToInt()),
                            filterQuality = FilterQuality.Medium,
                            colorFilter = c.carFilter
                        )
                    }
            )
        }
        // Затемнение под текстом: кадр автомобиля занимает почти всю карточку.
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        0f to c.heroScrim[0],
                        0.22f to c.heroScrim[1],
                        0.38f to c.heroScrim[2],
                        0.54f to c.heroScrim[3]
                    )
                )
        )
        Column(Modifier.fillMaxSize().padding(47.8.dp)) {
            Text(
                text = "ЗАПАС ХОДА",
                color = c.heroLabel,
                fontSize = 23.9.sp,
                lineHeight = 23.9.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 3.09.sp,
                maxLines = 1
            )
            Row(Modifier.padding(top = 16.9.dp)) {
                Text(
                    text = Fmt.int(rangeKm),
                    color = c.heroValue,
                    fontSize = 177.1.sp,
                    lineHeight = 148.8.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = (-1.12).sp,
                    maxLines = 1,
                    modifier = Modifier.alignByBaseline()
                )
                Text(
                    text = "км",
                    color = c.heroUnit,
                    fontSize = 42.2.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    modifier = Modifier.padding(start = 16.9.dp).alignByBaseline()
                )
            }
            Box(
                Modifier
                    .padding(top = 12.6.dp)
                    .fillMaxWidth(0.49f)
                    .height(19.7.dp)
                    .clip(CircleShape)
                    .background(c.heroTrack)
            ) {
                if (soc != null && soc > 0) {
                    Box(
                        Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(soc / 100f)
                            .clip(CircleShape)
                            .background(
                                Brush.horizontalGradient(c.heroFill)
                            )
                            .graphicsLayer { alpha = fillAlpha.value }
                    )
                }
            }
            Row(Modifier.padding(top = 11.2.dp)) {
                Text(
                    text = Fmt.percent(soc),
                    color = c.heroPercent,
                    fontSize = 38.0.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    modifier = Modifier.alignByBaseline()
                )
                Text(
                    text = "· ${Fmt.kwh(usableKwh)}",
                    color = c.heroCharge,
                    fontSize = 38.0.sp,
                    maxLines = 1,
                    modifier = Modifier.padding(start = 9.8.dp).alignByBaseline()
                )
            }
            Text(
                text = outsideText(outsideTempC),
                color = c.heroOutside,
                fontSize = 35.1.sp,
                maxLines = 1,
                modifier = Modifier.padding(top = 9.8.dp)
            )
        }
        FrunkPill(
            open = hoodOpen,
            ready = gear == Gear.P,
            busy = busy,
            onClick = onFrunkOpen,
            modifier = Modifier.align(Alignment.BottomStart).padding(start = 47.8.dp, bottom = 19.7.dp)
        )
    }
}

private fun outsideText(tempC: Int?): String =
    if (tempC == null) "Наружный воздух: —" else "Наружный воздух: ${Fmt.temp(tempC)}C"

/** Открытие переднего багажника: доступно только в P и только пока автомобиль отвечает. */
@Composable
private fun FrunkPill(
    open: Boolean,
    ready: Boolean,
    busy: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(12.dp)
    val c = HomeColors.current
    val enabled = ready && !busy
    Row(
        modifier
            .height(52.dp)
            .clip(shape)
            .background(c.frunkBg)
            .border(
                1.dp,
                when {
                    open -> c.frunkBorderOpen
                    ready -> c.frunkBorderReady
                    else -> c.frunkBorderIdle
                },
                shape
            )
            .clickable(
                enabled = enabled,
                onClickLabel = if (ready) "Открыть передний багажник" else "Доступно только в P",
                onClick = onClick
            )
            .padding(horizontal = 19.7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = AppIcons.Frunk,
            contentDescription = null,
            tint = if (ready) c.frunkIconReady else c.frunkIconIdle,
            modifier = Modifier.size(30.9.dp)
        )
        Spacer(Modifier.width(14.1.dp))
        Text(
            text = if (open) "Передний багажник открыт" else "Открыть передний багажник",
            color = if (ready) c.frunkTextReady else c.frunkTextIdle,
            fontSize = 25.3.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1
        )
        Spacer(Modifier.width(21.1.dp))
        if (busy) {
            CircularProgressIndicator(
                modifier = Modifier.size(24.dp),
                strokeWidth = 2.dp,
                color = c.frunkSpinner
            )
        } else {
            Icon(
                imageVector = AppIcons.Chevron,
                contentDescription = null,
                tint = c.frunkChevron,
                modifier = Modifier.size(23.9.dp)
            )
        }
    }
}

// ---------------------------------------------------------------------------------------
// Режим движения и рекуперация
// ---------------------------------------------------------------------------------------

private fun modeIcon(mode: DriveMode): ImageVector = when (mode) {
    DriveMode.ECO -> DepthIcons.Leaf
    DriveMode.COMFORT -> DepthIcons.Comfort
    DriveMode.SPORT -> DepthIcons.Sport
    else -> DepthIcons.Car
}

private fun regenIcon(level: RegenLevel): ImageVector = when (level) {
    RegenLevel.LOW -> DepthIcons.RegenLow
    RegenLevel.MID -> DepthIcons.RegenMid
    RegenLevel.HIGH -> DepthIcons.RegenHigh
    RegenLevel.AUTO -> DepthIcons.Bolt
}

private fun String.capitalized(): String = replaceFirstChar { it.titlecase(Fmt.RU) }

@Composable
private fun <T> SegmentCard(
    title: String,
    headIcon: ImageVector,
    options: List<T>,
    selectable: List<T>,
    selected: T?,
    pending: T?,
    label: (T) -> String,
    iconFor: (T) -> ImageVector,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(15.5.dp)
    val c = HomeColors.current
    Column(
        modifier
            .clip(shape)
            .background(c.cardBg)
            .border(1.dp, c.cardBorder, shape)
            .padding(start = 19.7.dp, end = 19.7.dp, top = 21.1.dp, bottom = 16.9.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            DepthIcon(headIcon, 28.1.dp, colorFilter = c.iconDim)
            Spacer(Modifier.width(11.2.dp))
            Text(
                text = title.uppercase(Fmt.RU),
                color = c.cardLabel,
                fontSize = 19.7.sp,
                lineHeight = 19.7.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 2.25.sp,
                maxLines = 1,
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.weight(1f))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.4.dp)
        ) {
            options.forEach { option ->
                SegmentButton(
                    label = label(option),
                    icon = iconFor(option),
                    active = option == selected,
                    selectable = option in selectable,
                    waiting = option == pending,
                    onClick = { onSelect(option) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun SegmentButton(
    label: String,
    icon: ImageVector,
    active: Boolean,
    selectable: Boolean,
    waiting: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(12.dp)
    val c = HomeColors.current
    Column(
        modifier
            .height(87.1.dp)
            .clip(shape)
            .background(if (active) c.controlOnBg else c.controlBg)
            .border(1.dp, if (active) c.controlOnBorder else c.controlBorder, shape)
            // Занятость проверяется в момент нажатия: кнопка не гаснет целиком,
            // когда команду выполняет её сосед.
            .clickable(enabled = selectable, onClick = onClick),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(contentAlignment = Alignment.Center) {
            DepthIcon(
                icon,
                39.4.dp,
                alpha = if (selectable) 1f else 0.45f,
                colorFilter = if (active) c.iconOnAccent else c.iconDim
            )
            if (waiting) {
                CircularProgressIndicator(
                    modifier = Modifier.size(50.dp),
                    strokeWidth = 2.5.dp,
                    color = if (active) c.controlOnText else c.accent
                )
            }
        }
        Spacer(Modifier.height(7.03.dp))
        Text(
            text = label,
            color = when {
                active -> c.controlOnText
                selectable -> c.controlText
                else -> c.controlText.copy(alpha = 0.55f)
            },
            fontSize = 22.5.sp,
            lineHeight = 22.5.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1
        )
    }
}

// ---------------------------------------------------------------------------------------
// Ярлыки приложений
// ---------------------------------------------------------------------------------------

@Composable
private fun AppDock(
    packages: List<String>,
    onAllApps: () -> Unit,
    onConfigure: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val c = HomeColors.current
    val apps by produceState(initialValue = InstalledApps.cached(packages), packages) {
        value = withContext(Dispatchers.IO) { InstalledApps.resolve(context, packages) }
    }
    BoxWithConstraints(modifier.fillMaxWidth().height(DockHeight)) {
        // Ярлыки держат ширину макета; пока их меньше пяти, ряд центрируется,
        // а при переполнении прокручивается.
        val count = apps.size + 1 + if (apps.isEmpty()) 1 else 0
        val total = DockTileWidth * count + DockGap * (count - 1)
        val side = ((maxWidth - total) / 2).coerceAtLeast(0.dp)
        Row(
            Modifier
                .fillMaxWidth()
                .height(DockHeight)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = side),
            horizontalArrangement = Arrangement.spacedBy(DockGap)
        ) {
            apps.forEach { app ->
                DockTile(
                    label = app.label,
                    onClick = {
                        if (!InstalledApps.launch(context, app.packageName)) {
                            Toast.makeText(context, "«${app.label}» не запускается", Toast.LENGTH_SHORT)
                                .show()
                        }
                    }
                ) {
                    val icon = app.icon
                    if (icon != null) {
                        Image(
                            bitmap = icon,
                            contentDescription = app.label,
                            modifier = Modifier.size(46.4.dp)
                        )
                    } else {
                        Icon(
                            imageVector = dockGlyph(app.packageName, app.label),
                            contentDescription = app.label,
                            tint = c.controlIcon,
                            modifier = Modifier.size(46.4.dp)
                        )
                    }
                }
            }
            DockTile(label = "Все приложения", onClick = onAllApps) {
                Icon(
                    imageVector = AppIcons.Apps,
                    contentDescription = "Все приложения",
                    tint = c.controlIcon,
                    modifier = Modifier.size(46.4.dp)
                )
            }
            if (apps.isEmpty()) {
                DockTile(label = "Добавить ярлыки", onClick = onConfigure) {
                    Icon(
                        imageVector = AppIcons.Plus,
                        contentDescription = "Добавить ярлыки",
                        tint = c.controlIcon,
                        modifier = Modifier.size(46.4.dp)
                    )
                }
            }
        }
    }
}

/** Ярлык получает контурный знак по назначению приложения, а не цветную иконку. */
private fun dockGlyph(packageName: String, label: String): ImageVector {
    val key = "$packageName $label".lowercase()
    return when {
        listOf("maps", "navi", "navigation", "gps", "2gis", "location").any { key.contains(it) } ->
            AppIcons.Navigation
        listOf("music", "audio", "sound", "radio", "player", "spotify").any { key.contains(it) } ->
            AppIcons.Music
        listOf("phone", "dial", "telecom", "contacts").any { key.contains(it) } ->
            AppIcons.Phone
        listOf("camera", "dvr", "video", "record").any { key.contains(it) } ->
            AppIcons.Camera
        else -> AppIcons.Apps
    }
}

@Composable
private fun DockTile(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: @Composable () -> Unit
) {
    val shape = RoundedCornerShape(12.dp)
    val c = HomeColors.current
    Column(
        modifier
            .width(DockTileWidth)
            .height(DockHeight)
            .clip(shape)
            .background(c.controlBg)
            .border(1.dp, c.controlBorder, shape)
            .clickable(onClick = onClick),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        icon()
        Spacer(Modifier.height(9.8.dp))
        Text(
            text = label,
            color = c.controlText,
            fontSize = 23.9.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 10.dp)
        )
    }
}

// ---------------------------------------------------------------------------------------
// Климат
// ---------------------------------------------------------------------------------------

@Composable
private fun ClimatePanel(
    climate: Climate?,
    pendingChange: ClimateChange?,
    pendingPreset: ClimatePreset?,
    engagedPreset: ClimatePreset?,
    onClimate: (ClimateChange) -> Unit,
    onPreset: (ClimatePreset) -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(PanelRadius)
    val c = HomeColors.current
    val direction = climate?.fanDirection
    // Быстрый режим красится, только если приложение его включало и чтение ему не
    // противоречит: 17 °C с кондиционером «в лицо» — обычная летняя настройка.
    val coolActive = engagedPreset == ClimatePreset.QUICK_COOL &&
        climate != null && GeelyVhal.presetHeld(ClimatePreset.QUICK_COOL, climate)
    val heatActive = engagedPreset == ClimatePreset.QUICK_HEAT &&
        climate != null && GeelyVhal.presetHeld(ClimatePreset.QUICK_HEAT, climate)

    Column(
        modifier
            .clip(shape)
            .background(c.cardBg)
            .border(1.dp, c.cardBorder, shape)
            .padding(horizontal = 28.1.dp, vertical = 25.3.dp)
    ) {
        // Каждый блок принимает только свои значения: шаг температуры не перерисовывает
        // вентилятор, направления, пресеты и обогревы.
        ClimateHead(
            power = climate?.hvacOn,
            waiting = pendingChange == ClimateChange.POWER,
            onPower = { onClimate(ClimateChange.POWER) }
        )

        Spacer(Modifier.height(43.6.dp))
        TempRow(
            setpoint = climate?.driverTempC,
            lowering = pendingChange == ClimateChange.DRIVER_DOWN,
            raising = pendingChange == ClimateChange.DRIVER_UP,
            onLower = { onClimate(ClimateChange.DRIVER_DOWN) },
            onRaise = { onClimate(ClimateChange.DRIVER_UP) }
        )

        Spacer(Modifier.height(19.7.dp))
        FanRow(
            level = climate?.fanSpeed,
            lowering = pendingChange == ClimateChange.FAN_DOWN,
            raising = pendingChange == ClimateChange.FAN_UP,
            onLower = { onClimate(ClimateChange.FAN_DOWN) },
            onRaise = { onClimate(ClimateChange.FAN_UP) }
        )

        Spacer(Modifier.height(25.3.dp))
        DirectionRow(
            direction = direction,
            waiting = pendingChange?.isDirection(),
            onClimate = onClimate
        )

        Spacer(Modifier.height(23.9.dp))
        PresetsRow(
            reachable = climate != null,
            acOn = climate?.acOn,
            coolActive = coolActive,
            heatActive = heatActive,
            waitingCool = pendingPreset == ClimatePreset.QUICK_COOL,
            waitingHeat = pendingPreset == ClimatePreset.QUICK_HEAT,
            acWaiting = pendingChange == ClimateChange.AC,
            onCool = { onPreset(ClimatePreset.QUICK_COOL) },
            onHeat = { onPreset(ClimatePreset.QUICK_HEAT) },
            onAc = { onClimate(ClimateChange.AC) }
        )

        Spacer(Modifier.height(35.1.dp))
        Text(
            text = "ОБОГРЕВ",
            color = c.climateLabel,
            fontSize = 20.4.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = 2.81.sp,
            maxLines = 1
        )
        Spacer(Modifier.height(9.8.dp))
        SeatsRow(
            driver = climate?.seatHeatDriver,
            wheel = climate?.wheelHeat,
            passenger = climate?.seatHeatPassenger,
            waiting = when (pendingChange) {
                ClimateChange.SEAT_DRIVER -> SeatSlot.DRIVER
                ClimateChange.SEAT_PASSENGER -> SeatSlot.PASSENGER
                ClimateChange.WHEEL_HEAT -> SeatSlot.WHEEL
                else -> SeatSlot.NONE
            },
            onClimate = onClimate
        )

        Spacer(Modifier.height(23.9.dp))
        GlassRow(
            windshield = climate?.windshieldHeatOn == true,
            rear = climate?.rearDefrostOn,
            waiting = when (pendingChange) {
                ClimateChange.WINDSHIELD_HEAT -> SeatSlot.DRIVER
                ClimateChange.REAR_DEFROST -> SeatSlot.PASSENGER
                else -> SeatSlot.NONE
            },
            onClimate = onClimate
        )
    }
}

private fun ClimateChange.isDirection(): Boolean =
    this == ClimateChange.DIRECTION_FACE || this == ClimateChange.DIRECTION_FEET ||
        this == ClimateChange.DIRECTION_GLASS || this == ClimateChange.DIRECTION_GLASS_FEET

/** Какой из трёх обогревов сейчас ждёт ответа автомобиля. */
private enum class SeatSlot { NONE, DRIVER, WHEEL, PASSENGER }

@Composable
private fun ClimateHead(power: Boolean?, waiting: Boolean, onPower: () -> Unit) {
    val c = HomeColors.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        DepthIcon(DepthIcons.Fan, 49.2.dp, colorFilter = c.iconDim)
        Spacer(Modifier.width(14.1.dp))
        Text(
            text = "Климат",
            color = c.climateTitle,
            fontSize = 37.3.sp,
            lineHeight = 37.3.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = (-0.3).sp,
            maxLines = 1
        )
        Spacer(Modifier.weight(1f))
        PowerPill(power, waiting, onPower)
    }
}

@Composable
private fun TempRow(
    setpoint: Double?,
    lowering: Boolean,
    raising: Boolean,
    onLower: () -> Unit,
    onRaise: () -> Unit
) {
    val c = HomeColors.current
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        RoundButton(
            icon = DepthIcons.Minus,
            description = "Холоднее",
            enabled = setpoint != null,
            waiting = lowering
        ) { onLower() }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = setpoint?.let { "${setpointText(it)}°" } ?: "—",
                color = if (setpoint == null) c.climateDim else c.climateValue,
                fontSize = 151.8.sp,
                lineHeight = 130.5.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = (-1.41).sp,
                maxLines = 1
            )
            Text(
                text = "САЛОН",
                color = c.climateLabel,
                fontSize = 21.1.sp,
                letterSpacing = 3.09.sp,
                maxLines = 1
            )
        }
        RoundButton(
            icon = DepthIcons.Plus,
            description = "Теплее",
            enabled = setpoint != null,
            waiting = raising
        ) { onRaise() }
    }
}

@Composable
private fun FanRow(
    level: Int?,
    lowering: Boolean,
    raising: Boolean,
    onLower: () -> Unit,
    onRaise: () -> Unit
) {
    val c = HomeColors.current
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        // Стрелка макета: маленькая кнопка — маленький вентилятор, большая — большой.
        RoundButton(
            icon = DepthIcons.Fan,
            description = "Меньше обдув",
            enabled = level != null,
            waiting = lowering,
            iconSize = 31.dp
        ) { onLower() }
        Spacer(Modifier.width(19.7.dp))
        Column(Modifier.weight(1f)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
                Text(
                    text = "ВЕНТИЛЯТОР",
                    color = c.climateLabel,
                    fontSize = 20.4.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 2.81.sp,
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )
                if (level == null) {
                    Text(
                        text = "—",
                        color = c.climateValue,
                        fontSize = 22.5.sp,
                        maxLines = 1
                    )
                } else {
                    Row {
                        Text(
                            text = level.toString(),
                            color = c.climateValue,
                            fontSize = 22.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1
                        )
                        Text(
                            text = " / ${GeelyVhal.FAN_MAX}",
                            color = c.climateValue,
                            fontSize = 22.5.sp,
                            maxLines = 1
                        )
                    }
                }
            }
            Spacer(Modifier.height(5.6.dp))
            FanBars(level, Modifier.fillMaxWidth())
        }
        Spacer(Modifier.width(19.7.dp))
        RoundButton(
            icon = DepthIcons.Fan,
            description = "Больше обдув",
            enabled = level != null,
            waiting = raising,
            iconSize = 47.8.dp
        ) { onRaise() }
    }
}

@Composable
private fun DirectionRow(
    direction: Int?,
    waiting: Boolean?,
    onClimate: (ClimateChange) -> Unit
) {
    val c = HomeColors.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        DepthIcon(DepthIcons.AirFlow, 21.1.dp, colorFilter = c.iconDim)
        Spacer(Modifier.width(9.8.dp))
        Text(
            text = "НАПРАВЛЕНИЕ ВОЗДУХА",
            color = c.climateLabel,
            fontSize = 19.0.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = 2.25.sp,
            maxLines = 1
        )
    }
    Spacer(Modifier.height(14.1.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.6.dp)) {
        DirectionData.entries.forEach { entry ->
            DirectionTile(
                icon = entry.icon,
                description = entry.description,
                active = direction == entry.mask,
                reachable = direction != null,
                waiting = waiting == true && direction != entry.mask,
                onClick = { onClimate(entry.change) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

/** Направление обдува: маска автомобиля, её значок, подпись и команда кнопки. */
private enum class DirectionData(
    val mask: Int,
    val change: ClimateChange,
    val description: String,
    val icon: ImageVector
) {
    GLASS(GeelyVhal.DIRECTION_GLASS, ClimateChange.DIRECTION_GLASS, "Лобовое стекло", DepthIcons.AirGlass),
    FACE(GeelyVhal.DIRECTION_FACE, ClimateChange.DIRECTION_FACE, "В лицо", DepthIcons.AirFace),
    FEET(GeelyVhal.DIRECTION_FEET, ClimateChange.DIRECTION_FEET, "В ноги", DepthIcons.AirFeet),
    GLASS_FEET(
        GeelyVhal.DIRECTION_GLASS_FEET,
        ClimateChange.DIRECTION_GLASS_FEET,
        "Стекло и ноги",
        DepthIcons.AirGlassFeet
    )
}

@Composable
private fun PresetsRow(
    reachable: Boolean,
    acOn: Boolean?,
    coolActive: Boolean,
    heatActive: Boolean,
    waitingCool: Boolean,
    waitingHeat: Boolean,
    acWaiting: Boolean,
    onCool: () -> Unit,
    onHeat: () -> Unit,
    onAc: () -> Unit
) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.1.dp)) {
        PresetTile(
            icon = DepthIcons.Snowflake,
            label = "Быстрое охлаждение",
            active = coolActive,
            reachable = reachable,
            waiting = waitingCool,
            onClick = onCool,
            modifier = Modifier.weight(1f)
        )
        AcTile(acOn, acWaiting, onAc)
        PresetTile(
            icon = DepthIcons.Heat,
            label = "Быстрый обогрев",
            active = heatActive,
            reachable = reachable,
            waiting = waitingHeat,
            onClick = onHeat,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun SeatsRow(
    driver: Int?,
    wheel: Int?,
    passenger: Int?,
    waiting: SeatSlot,
    onClimate: (ClimateChange) -> Unit
) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.9.dp)) {
        HeatTile(
            icon = DepthIcons.Seat,
            label = "Водитель",
            level = driver,
            levels = GeelyVhal.HEAT_MAX_LEVEL,
            waiting = waiting == SeatSlot.DRIVER,
            onClick = { onClimate(ClimateChange.SEAT_DRIVER) },
            modifier = Modifier.weight(1f)
        )
        HeatTile(
            icon = DepthIcons.Wheel,
            label = "Руль",
            level = wheel,
            levels = 1,
            waiting = waiting == SeatSlot.WHEEL,
            onClick = { onClimate(ClimateChange.WHEEL_HEAT) },
            modifier = Modifier.weight(1f)
        )
        HeatTile(
            icon = DepthIcons.SeatPassenger,
            label = "Пассажир",
            level = passenger,
            levels = GeelyVhal.HEAT_MAX_LEVEL,
            waiting = waiting == SeatSlot.PASSENGER,
            onClick = { onClimate(ClimateChange.SEAT_PASSENGER) },
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun GlassRow(
    windshield: Boolean,
    rear: Boolean?,
    waiting: SeatSlot,
    onClimate: (ClimateChange) -> Unit
) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.1.dp)) {
        GlassTile(
            icon = DepthIcons.Defrost,
            label = "Лобовое стекло",
            on = windshield,
            // 0x10200C00 на этом ГУ не отвечает на чтение: кнопка остаётся
            // нажимаемой, пока автомобиль отвечает хоть на что-то в климате.
            reachable = true,
            waiting = waiting == SeatSlot.DRIVER,
            onClick = { onClimate(ClimateChange.WINDSHIELD_HEAT) },
            modifier = Modifier.weight(1f)
        )
        GlassTile(
            icon = DepthIcons.RearDefrost,
            label = "Заднее стекло",
            on = rear == true,
            reachable = rear != null,
            waiting = waiting == SeatSlot.PASSENGER,
            onClick = { onClimate(ClimateChange.REAR_DEFROST) },
            modifier = Modifier.weight(1f)
        )
    }
}

/** 22.0 → «22», 22.5 → «22,5»: уставка ставится шагом в градус, дробь бывает только у прочитанной. */
private fun setpointText(value: Double): String =
    if (value % 1.0 == 0.0) value.toInt().toString() else Fmt.n1(value)

@Composable
private fun PowerPill(state: Boolean?, waiting: Boolean, onPower: () -> Unit) {
    val on = state == true
    val shape = RoundedCornerShape(12.dp)
    val c = HomeColors.current
    Box(
        Modifier
            .height(64.7.dp)
            .widthIn(min = 182.7.dp)
            .clip(shape)
            .background(if (on) c.controlOnBg else c.controlBg)
            .border(1.dp, if (on) c.controlOnBorder else c.controlBorder, shape)
            .clickable(enabled = state != null, onClickLabel = "Питание климата", onClick = onPower)
            .padding(horizontal = 28.1.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (waiting) {
                CircularProgressIndicator(
                    modifier = Modifier.size(22.dp),
                    strokeWidth = 2.dp,
                    color = if (on) c.controlOnText else c.accent
                )
                Spacer(Modifier.width(12.dp))
            }
            Text(
                text = when (state) {
                    true -> "Вкл"
                    false -> "Выкл"
                    null -> "—"
                },
                color = if (on) {
                    c.controlOnText
                } else if (state == null) {
                    c.controlText.copy(alpha = 0.55f)
                } else {
                    c.controlText
                },
                fontSize = 26.7.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun RoundButton(
    icon: ImageVector,
    description: String,
    enabled: Boolean,
    waiting: Boolean,
    iconSize: Dp = 38.65.dp,
    onClick: () -> Unit
) {
    val c = HomeColors.current
    Box(
        Modifier
            .size(84.3.dp)
            .clip(CircleShape)
            .background(c.controlBg)
            .border(1.dp, c.controlBorder, CircleShape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        DepthIcon(
            icon,
            iconSize,
            alpha = if (enabled) 1f else 0.45f,
            contentDescription = description,
            colorFilter = c.iconDim
        )
        if (waiting) {
            CircularProgressIndicator(
                modifier = Modifier.size(64.dp),
                strokeWidth = 2.5.dp,
                color = c.accent
            )
        }
    }
}

/** Кнопка A/C между пресетами: короткий переключатель кондиционера. */
@Composable
private fun AcTile(on: Boolean?, waiting: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    val active = on == true
    val c = HomeColors.current
    Box(
        Modifier
            .size(width = 90.dp, height = 70.3.dp)
            .clip(shape)
            .background(if (active) c.controlOnBg else c.controlBg)
            .border(1.dp, if (active) c.controlOnBorder else c.controlBorder, shape)
            .clickable(enabled = on != null, onClickLabel = "Кондиционер", onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (waiting) {
            CircularProgressIndicator(
                modifier = Modifier.size(46.dp),
                strokeWidth = 2.5.dp,
                color = if (active) c.controlOnText else c.accent
            )
        }
        Text(
            text = if (on == null) "—" else "A/C",
            color = if (active) {
                c.controlOnText
            } else if (on == null) {
                c.controlText.copy(alpha = 0.55f)
            } else {
                c.controlText
            },
            fontSize = 23.9.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )
    }
}

@Composable
private fun FanBars(level: Int?, modifier: Modifier = Modifier) {
    val c = HomeColors.current
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(9.8.dp)) {
        (1..GeelyVhal.FAN_MAX).forEach { index ->
            val shape = RoundedCornerShape(7.03.dp)
            Box(
                Modifier
                    .weight(1f)
                    .height(28.1.dp)
                    .clip(shape)
                    .background(
                        when {
                            level == null -> c.track
                            index <= level -> c.accent
                            else -> c.track
                        }
                    )
            )
        }
    }
}

@Composable
private fun DirectionTile(
    icon: ImageVector,
    description: String,
    active: Boolean,
    reachable: Boolean,
    waiting: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(12.dp)
    val c = HomeColors.current
    Box(
        modifier
            .height(70.3.dp)
            .clip(shape)
            .background(if (active) c.controlOnBg else c.controlBg)
            .border(1.dp, if (active) c.controlOnBorder else c.controlBorder, shape)
            .clickable(enabled = reachable && !active, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        DepthIcon(
            icon,
            53.4.dp,
            alpha = if (reachable) 1f else 0.4f,
            contentDescription = description,
            colorFilter = if (active) c.iconOnAccent else c.iconDim
        )
        if (waiting) {
            CircularProgressIndicator(
                modifier = Modifier.size(62.dp),
                strokeWidth = 2.5.dp,
                color = c.accent
            )
        }
    }
}

@Composable
private fun PresetTile(
    icon: ImageVector,
    label: String,
    active: Boolean,
    reachable: Boolean,
    waiting: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(12.dp)
    val c = HomeColors.current
    Row(
        modifier
            .height(70.3.dp)
            .clip(shape)
            .background(if (active) c.controlOnBg else c.controlBg)
            .border(1.dp, if (active) c.controlOnBorder else c.controlBorder, shape)
            .clickable(enabled = reachable, onClick = onClick)
            .padding(horizontal = 14.1.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        DepthIcon(
            icon,
            38.0.dp,
            alpha = if (reachable) 1f else 0.4f,
            colorFilter = if (active) c.iconOnAccent else c.iconDim
        )
        Spacer(Modifier.width(12.6.dp))
        Text(
            text = label,
            color = when {
                active -> c.controlOnText
                reachable -> c.controlText
                else -> c.controlText.copy(alpha = 0.55f)
            },
            fontSize = 19.0.sp,
            maxLines = 1,
            softWrap = false
        )
        if (waiting) {
            Spacer(Modifier.width(10.dp))
            CircularProgressIndicator(
                modifier = Modifier.size(22.dp),
                strokeWidth = 2.dp,
                color = if (active) c.controlOnText else c.accent
            )
        }
    }
}

/**
 * Плитка обогрева: значок плюс столько волн, сколько ступней supportует сигнал.
 * Активных волн ровно `level`, поэтому режим виден без чтения числа.
 */
@Composable
private fun HeatTile(
    icon: ImageVector,
    label: String,
    level: Int?,
    levels: Int,
    waiting: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val active = level != null && level > 0
    val shape = RoundedCornerShape(12.dp)
    val c = HomeColors.current
    val iconFilter = if (active) c.iconOnAccent else c.iconDim
    Column(
        modifier
            .height(118.1.dp)
            .clip(shape)
            .background(if (active) c.controlOnBg else c.controlBg)
            .border(1.dp, if (active) c.controlOnBorder else c.controlBorder, shape)
            .clickable(enabled = level != null, onClick = onClick),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            DepthIcon(
                icon,
                64.7.dp,
                alpha = if (level == null) 0.5f else 1f,
                colorFilter = iconFilter
            )
            // Ступень нагрева видна числом волн; у руля одна ступень — волн нет.
            if (levels > 1) {
                val lit = if (level == null) 0 else level.coerceIn(0, levels)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    (1..levels).forEach { index ->
                        DepthIcon(
                            DepthIcons.HeatWave,
                            size = 60.9.dp,
                            width = 15.4.dp,
                            colorFilter = iconFilter,
                            alpha = when {
                                index <= lit -> 1f
                                level == null -> 0.12f
                                else -> 0.28f
                            }
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(9.8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (waiting) {
                CircularProgressIndicator(
                    modifier = Modifier.size(17.dp),
                    strokeWidth = 2.dp,
                    color = if (active) c.controlOnText else c.accent
                )
                Spacer(Modifier.width(7.dp))
            }
            Text(
                text = label,
                color = when {
                    active -> c.controlOnText
                    level == null -> c.controlText.copy(alpha = 0.55f)
                    else -> c.controlText
                },
                fontSize = 20.4.sp,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun GlassTile(
    icon: ImageVector,
    label: String,
    on: Boolean,
    reachable: Boolean,
    waiting: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(12.dp)
    val c = HomeColors.current
    Row(
        modifier
            .height(75.9.dp)
            .clip(shape)
            .background(if (on) c.controlOnBg else c.controlBg)
            .border(1.dp, if (on) c.controlOnBorder else c.controlBorder, shape)
            .clickable(enabled = reachable, onClick = onClick)
            .padding(horizontal = 14.1.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        DepthIcon(
            icon,
            50.6.dp,
            alpha = if (reachable) 1f else 0.4f,
            colorFilter = if (on) c.iconOnAccent else c.iconDim
        )
        Spacer(Modifier.width(12.6.dp))
        Text(
            text = label,
            color = when {
                on -> c.controlOnText
                reachable -> c.controlText
                else -> c.controlText.copy(alpha = 0.55f)
            },
            fontSize = 23.9.sp,
            maxLines = 1,
            softWrap = false
        )
        if (waiting) {
            Spacer(Modifier.width(10.dp))
            CircularProgressIndicator(
                modifier = Modifier.size(22.dp),
                strokeWidth = 2.dp,
                color = if (on) c.controlOnText else c.accent
            )
        }
    }
}

/**
 * Объёмный значок из DepthIcons: рисуется своими градиентами. Темы подмешивают
 * оттенок фильтром, не пересобирая сами значки.
 */
@Composable
private fun DepthIcon(
    icon: ImageVector,
    size: Dp,
    alpha: Float = 1f,
    contentDescription: String? = null,
    width: Dp? = null,
    modifier: Modifier = Modifier,
    colorFilter: ColorFilter? = null
) {
    val box = modifier.requiredSize(size)
    Image(
        imageVector = icon,
        contentDescription = contentDescription,
        alignment = Alignment.Center,
        alpha = alpha,
        colorFilter = colorFilter,
        // Волна обогрева узкая: ширина задана отдельно и не сохраняет пропорций значка.
        contentScale = if (width != null) ContentScale.FillBounds else ContentScale.Fit,
        modifier = if (width != null) box.requiredWidth(width) else box
    )
}

// ---------------------------------------------------------------------------------------
// Градиенты макета
// ---------------------------------------------------------------------------------------

/**
 * CSS-градиент по углу из макета: 118° — из левого верха в правый низ, 165° — почти вниз.
 * Кисти строятся один раз на размер: фон панели не пересобирается на каждый кадр.
 */
private fun Modifier.cssGradient(angleDeg: Float, vararg stops: Pair<Float, Color>): Modifier =
    drawWithCache {
        val radians = Math.toRadians(angleDeg.toDouble())
        val dx = sin(radians).toFloat()
        val dy = -cos(radians).toFloat()
        val half = (abs(dx) * size.width + abs(dy) * size.height) / 2f
        val center = Offset(size.width / 2f, size.height / 2f)
        val brush = Brush.linearGradient(
            *stops,
            start = center - Offset(dx * half, dy * half),
            end = center + Offset(dx * half, dy * half)
        )
        onDrawBehind { drawRect(brush = brush) }
    }

/** Фон рабочего стола из макета: эллипс 95%×90% в точке 64%/48%. */
private fun Modifier.workspaceGradient(colors: List<Color>): Modifier = drawWithCache {
    val radius = 0.95f * size.width
    if (radius <= 0f || colors.isEmpty()) return@drawWithCache onDrawBehind { }
    val brush = Brush.radialGradient(
        *arrayOf(
            0f to colors.first(),
            0.46f to colors.getOrElse(1) { colors.first() },
            1f to colors.last()
        ),
        center = Offset.Zero,
        radius = radius
    )
    val offsetX = 0.64f * size.width
    val offsetY = 0.48f * size.height
    val scaleY = 0.90f * size.height / radius
    onDrawBehind {
        withTransform({
            translate(offsetX, offsetY)
            scale(1f, scaleY, Offset.Zero)
        }) {
            drawRect(brush, topLeft = Offset(-radius, -radius), size = Size(radius * 2f, radius * 2f))
        }
    }
}

/** Эллиптическое свечение из макета: центр и радиусы в долях размера. */
private fun Modifier.radialGlow(
    color: Color,
    cx: Float,
    cy: Float,
    rx: Float,
    ry: Float
): Modifier = drawWithCache {
    val radius = rx * size.width
    if (radius <= 0f) return@drawWithCache onDrawBehind { }
    val clear = color.copy(alpha = 0f)
    val brush = Brush.radialGradient(
        *arrayOf(0f to color, 0.72f to clear, 1f to clear),
        center = Offset.Zero,
        radius = radius
    )
    val offsetX = cx * size.width
    val scaleY = ry * size.height / radius
    onDrawBehind {
        withTransform({
            translate(offsetX, cy * size.height)
            scale(1f, scaleY, Offset.Zero)
        }) {
            drawCircle(brush = brush, radius = radius, center = Offset.Zero)
        }
    }
}
