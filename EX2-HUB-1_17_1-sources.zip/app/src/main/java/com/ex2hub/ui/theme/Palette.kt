package com.ex2hub.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter

/** Базовые поверхности разделов: поездки, зарядки, настройки, док. */
@Immutable
data class HubTones(
    val bg: Color,
    val surface: Color,
    val surfaceHigh: Color,
    val cardTop: Color,
    val cardBottom: Color,
    val border: Color,
    val borderSoft: Color,
    val text: Color,
    val textDim: Color,
    val muted: Color,
    val accent: Color,
    val accentSoft: Color,
    val accentDark: Color,
    val mint: Color,
    val cyan: Color,
    val amber: Color,
    val red: Color,
    val track: Color,
    val black: Color,
    /** Текст иконок и подписей на акцентной заливке. */
    val onAccent: Color
)

@Immutable
data class RailTones(
    val bg: Color,
    val line: Color,
    val idleText: Color,
    val idleIcon: Color,
    val clock: Color,
    val clockDate: Color,
    val activeBg: Color,
    val activeBorder: Color,
    val activeText: Color,
    val activeIcon: Color
)

/**
 * Рабочий стол держит собственный набор поверхностей макета. Управление
 * собрано из одной нейтральной палитры: включённое состояние отличается
 * только акцентной рамкой, текстом и значком.
 */
@Immutable
data class HomeTones(
    val workspace: List<Color>,
    val heroGradient: List<Color>,
    val heroGlow: Color,
    val heroBorder: Color,
    val heroScrim: List<Color>,
    val heroLabel: Color,
    val heroValue: Color,
    val heroUnit: Color,
    val heroTrack: Color,
    val heroFill: List<Color>,
    val heroPercent: Color,
    val heroCharge: Color,
    val heroOutside: Color,
    val carFilter: ColorFilter?,
    val frunkBg: Color,
    val frunkBorderOpen: Color,
    val frunkBorderReady: Color,
    val frunkBorderIdle: Color,
    val frunkTextReady: Color,
    val frunkTextIdle: Color,
    val frunkIconReady: Color,
    val frunkIconIdle: Color,
    val frunkSpinner: Color,
    val frunkChevron: Color,
    val cardBg: Color,
    val cardBorder: Color,
    val cardLabel: Color,
    /** Нейтральная поверхность кнопки: одна на весь рабочий стол. */
    val controlBg: Color,
    val controlBorder: Color,
    val controlText: Color,
    val controlIcon: Color,
    /** Включённое состояние: та же поверхность с акцентной рамкой. */
    val controlOnBg: Color,
    val controlOnBorder: Color,
    val controlOnText: Color,
    val controlOnIcon: Color,
    val climateTitle: Color,
    val climateLabel: Color,
    val climateValue: Color,
    val climateDim: Color,
    val accent: Color,
    val track: Color,
    /** Линейные значки: нейтральный и акцентный цвета одной кистью. */
    val iconDim: ColorFilter,
    val iconOnAccent: ColorFilter
)

@Immutable
data class HubPalette(
    val tones: HubTones,
    val rail: RailTones,
    val home: HomeTones,
    val scheme: ColorScheme
)

val LocalHubPalette = staticCompositionLocalOf { HubPalettes.Blue }

private fun grad(vararg values: Long): List<Color> = values.map { Color(it) }

private fun scheme(tones: HubTones): ColorScheme = darkColorScheme(
    primary = tones.accent,
    onPrimary = tones.onAccent,
    secondary = tones.mint,
    onSecondary = tones.black,
    tertiary = tones.cyan,
    onTertiary = tones.black,
    background = tones.bg,
    onBackground = tones.text,
    surface = tones.surface,
    onSurface = tones.text,
    surfaceVariant = tones.surfaceHigh,
    onSurfaceVariant = tones.textDim,
    outline = tones.border,
    error = tones.red,
    onError = tones.black
)

object HubPalettes {

    val Blue: HubPalette = run {
        val tones = HubTones(
            bg = Color(0xFF040C1A),
            surface = Color(0xFF071628),
            surfaceHigh = Color(0xFF0B2040),
            cardTop = Color(0xFF091B34),
            cardBottom = Color(0xFF051327),
            border = Color(0xFF17365C),
            borderSoft = Color(0xFF102946),
            text = Color(0xFFEAF3FF),
            textDim = Color(0xFF9DB6DA),
            muted = Color(0xFF6B87AE),
            accent = Color(0xFF3D8BFF),
            accentSoft = Color(0xFF7FB6FF),
            accentDark = Color(0xFF0D2B54),
            mint = Color(0xFF6FE0BE),
            cyan = Color(0xFF58D3F2),
            amber = Color(0xFFFFC46B),
            red = Color(0xFFFF7E7E),
            track = Color(0xFF0E2542),
            black = Color(0xFF02070F),
            onAccent = Color(0xFFFFFFFF)
        )
        val rail = RailTones(
            bg = Color(0xFF05101F),
            line = Color(0xFF123055),
            idleText = Color(0xFFC7DBF5),
            idleIcon = Color(0xFF8DAEDB),
            clock = Color(0xFFEAF3FF),
            clockDate = Color(0xFF6B87AE),
            activeBg = Color(0xFF2E7DFF),
            activeBorder = Color(0xFF7FB6FF),
            activeText = Color(0xFFFFFFFF),
            activeIcon = Color(0xFFFFFFFF)
        )
        val home = HomeTones(
            workspace = grad(0xFF0A2B5C, 0xFF04142E, 0xFF010813),
            heroGradient = grad(0xFF03152F, 0xFF04204A, 0xFF06295C),
            heroGlow = Color(0x4D2C70F5),
            heroBorder = Color(0x6B407ED6),
            heroScrim = grad(0xF709162C, 0xE609162C, 0x7309162C, 0x0009162C),
            heroLabel = Color(0xFF9DB6DC),
            heroValue = Color(0xFFF2F7FF),
            heroUnit = Color(0xFFDCE8FF),
            heroTrack = Color(0x4D4882DC),
            heroFill = grad(0xFF2F7DF6, 0xFF3CBDDA),
            heroPercent = Color(0xFFF6FAFF),
            heroCharge = Color(0xFF9DB8DD),
            heroOutside = Color(0xFF8EA9CC),
            carFilter = null,
            frunkBg = Color(0xB806142A),
            frunkBorderOpen = Color(0xFF7FB6FF),
            frunkBorderReady = Color(0x2EFFFFFF),
            frunkBorderIdle = Color(0x1AFFFFFF),
            frunkTextReady = Color(0xFFEDF4FF),
            frunkTextIdle = Color(0xFF9AA8BE),
            frunkIconReady = Color(0xFFC9D9F2),
            frunkIconIdle = Color(0xFF7B8CA4),
            frunkSpinner = Color(0xFF8CC3FF),
            frunkChevron = Color(0xFFC9D9F2),
            cardBg = Color(0xFF071B36),
            cardBorder = Color(0xFF153760),
            cardLabel = Color(0xFF8DAEDB),
            controlBg = Color(0xFF0A2447),
            controlBorder = Color(0xFF1C4374),
            controlText = Color(0xFFC7DBF5),
            controlIcon = Color(0xFF8DAEDB),
            controlOnBg = Color(0xFF103E7C),
            controlOnBorder = Color(0xFF3F8CFF),
            controlOnText = Color(0xFFF2F8FF),
            controlOnIcon = Color(0xFF8CC3FF),
            climateTitle = Color(0xFFEAF3FF),
            climateLabel = Color(0xFF9DB6DA),
            climateValue = Color(0xFFF2F7FF),
            climateDim = Color(0xFF6B87AE),
            accent = Color(0xFF3D8BFF),
            track = Color(0xFF0E2542),
            iconDim = ColorFilter.tint(Color(0xFF8DAEDB)),
            iconOnAccent = ColorFilter.tint(Color(0xFF8CC3FF))
        )
        HubPalette(tones = tones, rail = rail, home = home, scheme = scheme(tones))
    }
}

object HomeColors {
    val current: HomeTones
        @Composable
        @ReadOnlyComposable
        get() = LocalHubPalette.current.home
}
