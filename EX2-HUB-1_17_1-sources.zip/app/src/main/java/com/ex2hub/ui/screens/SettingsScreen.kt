package com.ex2hub.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ex2hub.BuildConfig
import com.ex2hub.data.CheckStatus
import com.ex2hub.data.Fmt
import com.ex2hub.data.SourceMode
import com.ex2hub.ui.AppIcons
import com.ex2hub.ui.Badge
import com.ex2hub.ui.CardHead
import com.ex2hub.ui.Eyebrow
import com.ex2hub.ui.HubButton
import com.ex2hub.ui.HubButtonStyle
import com.ex2hub.ui.HubCard
import com.ex2hub.ui.HubIconButton
import com.ex2hub.ui.HubTextField
import com.ex2hub.ui.HubTextButton
import com.ex2hub.ui.HubUiState
import com.ex2hub.ui.InfoRow
import com.ex2hub.ui.LocalHubLayout
import com.ex2hub.ui.ScreenHead
import com.ex2hub.ui.SectionNote
import com.ex2hub.ui.SoftDivider
import com.ex2hub.ui.StateDot
import com.ex2hub.ui.WarningBox
import com.ex2hub.ui.accent
import com.ex2hub.ui.color
import com.ex2hub.ui.description
import com.ex2hub.ui.dialogs.ConfirmDialog
import com.ex2hub.ui.hint
import com.ex2hub.ui.icon
import com.ex2hub.ui.shortTitle
import com.ex2hub.ui.theme.HubColors
import com.ex2hub.ui.title
import com.ex2hub.update.UpdatePhase
import com.ex2hub.update.UpdateState

@Composable
fun SettingsScreen(
    ui: HubUiState,
    gpsGranted: Boolean,
    onSelectSource: (SourceMode) -> Unit,
    onProbe: () -> Unit,
    onApplyManual: (String, String) -> Unit,
    onSaveTariff: (String) -> Unit,
    onSaveRootCommands: (String, String, String, String, String, String) -> Unit,
    onResetDemo: () -> Unit,
    onClearJournal: () -> Unit,
    onExportJournal: () -> Unit,
    onRestoreJournal: () -> Unit,
    onNavigateHome: () -> Unit,
    onDockAppsChange: (List<String>) -> Unit,
    onRestoreDrive: (Boolean) -> Unit,
    onChargeAlertChange: (Int) -> Unit,
    onChargeDoneChange: (Boolean) -> Unit,
    update: UpdateState,
    onCheckUpdate: () -> Unit,
    onDownloadUpdate: () -> Unit,
    onInstallUpdate: () -> Unit
) {
    val layout = LocalHubLayout.current
    val profile = ui.profile

    var tariff by rememberSaveable(profile.tariffPerKwh) {
        mutableStateOf(Fmt.n2(profile.tariffPerKwh))
    }
    var manualSoc by rememberSaveable(profile.manualSoc, profile.manualUpdatedAt) {
        mutableStateOf((profile.manualSoc ?: ui.vehicle.soc)?.toString() ?: "")
    }
    var manualRange by rememberSaveable(profile.manualRangeKm, profile.manualUpdatedAt) {
        mutableStateOf((profile.manualRangeKm ?: ui.vehicle.rangeKm)?.toString() ?: "")
    }
    var rootSoc by rememberSaveable(profile.rootSocCommand) {
        mutableStateOf(profile.rootSocCommand)
    }
    var rootRange by rememberSaveable(profile.rootRangeCommand) {
        mutableStateOf(profile.rootRangeCommand)
    }
    var rootPower by rememberSaveable(profile.rootPowerCommand) {
        mutableStateOf(profile.rootPowerCommand)
    }
    var rootTemp by rememberSaveable(profile.rootTempCommand) {
        mutableStateOf(profile.rootTempCommand)
    }
    var rootDriveMode by rememberSaveable(profile.rootDriveModeCommand) {
        mutableStateOf(profile.rootDriveModeCommand)
    }
    var rootRegen by rememberSaveable(profile.rootRegenCommand) {
        mutableStateOf(profile.rootRegenCommand)
    }
    val rootForm = RootCommandsForm(rootSoc, rootRange, rootPower, rootTemp, rootDriveMode, rootRegen)
    val updateRootForm: (RootCommandsForm) -> Unit = { next ->
        rootSoc = next.soc
        rootRange = next.range
        rootPower = next.power
        rootTemp = next.temp
        rootDriveMode = next.driveMode
        rootRegen = next.regen
    }
    val saveRootForm: () -> Unit = {
        onSaveRootCommands(rootSoc, rootRange, rootPower, rootTemp, rootDriveMode, rootRegen)
    }

    var confirm by remember { mutableStateOf<SettingsConfirmation?>(null) }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 1000.dp
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(layout.pagePadding),
            verticalArrangement = Arrangement.spacedBy(layout.gap)
        ) {
            ScreenHead(
                eyebrow = "Конфигурация",
                title = "Настройки",
                subtitle = "Данные, тариф, экран и звук",
                actions = {
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(50))
                            .background(HubColors.Accent.copy(alpha = 0.07f))
                            .border(1.dp, HubColors.Accent.copy(alpha = 0.18f), RoundedCornerShape(50))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = AppIcons.Check,
                            contentDescription = null,
                            tint = HubColors.Accent,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = "Сохранено локально",
                            color = HubColors.AccentSoft,
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp)
                        )
                    }
                }
            )

            UpdateCard(update, onCheckUpdate, onDownloadUpdate, onInstallUpdate)

            if (wide) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(layout.gap),
                    verticalAlignment = Alignment.Top
                ) {
                    Column(
                        Modifier.weight(1.28f),
                        verticalArrangement = Arrangement.spacedBy(layout.gap)
                    ) {
                        SourceSettingsCard(
                            ui = ui,
                            manualSoc = manualSoc,
                            manualRange = manualRange,
                            onManualSocChange = { manualSoc = it },
                            onManualRangeChange = { manualRange = it },
                            onSelectSource = onSelectSource,
                            onProbe = onProbe,
                            onApplyManual = { onApplyManual(manualSoc, manualRange) }
                        )
                        if (profile.source == SourceMode.ROOT) {
                            RootCommandsCard(
                                form = rootForm,
                                onChange = updateRootForm,
                                onSave = saveRootForm
                            )
                        }
                        AboutCard()
                    }
                    Column(
                        Modifier.weight(0.72f),
                        verticalArrangement = Arrangement.spacedBy(layout.gap)
                    ) {
                        ProfileCard(
                            tariff = tariff,
                            onTariffChange = { tariff = it },
                            onSave = { onSaveTariff(tariff) }
                        )
                        com.ex2hub.ui.SystemSettingsCard()
                        DockAppsCard(profile.dockApps, onDockAppsChange)
                        DriveMemoryCard(profile.restoreDrive, onRestoreDrive)
                        ChargeAlertCard(
                            percent = profile.chargeAlertSoc,
                            done = profile.chargeDoneAlert,
                            onPercentChange = onChargeAlertChange,
                            onDoneChange = onChargeDoneChange
                        )
                        CurrentSourceCard(
                            ui = ui,
                            gpsGranted = gpsGranted,
                            onNavigateHome = onNavigateHome
                        )
                        HelpCard()
                        DataCard(
                            records = ui.trips.size + ui.sessions.size,
                            busy = ui.exportBusy,
                            path = ui.exportPath,
                            onResetDemo = {
                                confirm = SettingsConfirmation(
                                    title = "Восстановить демо-данные?",
                                    message = "Журнал будет заменён демонстрационными поездками и зарядками, источник переключится на демо.",
                                    confirmText = "Восстановить",
                                    danger = false,
                                    action = onResetDemo
                                )
                            },
                            onClearJournal = {
                                confirm = SettingsConfirmation(
                                    title = "Очистить журнал?",
                                    message = "Все поездки и зарядки будут удалены без возможности отменить действие.",
                                    confirmText = "Очистить",
                                    danger = true,
                                    action = onClearJournal
                                )
                            },
                            onExport = onExportJournal,
                            onRestore = {
                                confirm = SettingsConfirmation(
                                    title = "Восстановить журнал из копии?",
                                    message = "Текущие поездки и зарядки будут заменены записями из файла. Источник данных и настройки останутся как сейчас.",
                                    confirmText = "Восстановить",
                                    danger = false,
                                    action = onRestoreJournal
                                )
                            }
                        )
                    }
                }
            } else {
                SourceSettingsCard(
                    ui = ui,
                    manualSoc = manualSoc,
                    manualRange = manualRange,
                    onManualSocChange = { manualSoc = it },
                    onManualRangeChange = { manualRange = it },
                    onSelectSource = onSelectSource,
                    onProbe = onProbe,
                    onApplyManual = { onApplyManual(manualSoc, manualRange) }
                )
                if (profile.source == SourceMode.ROOT) {
                    RootCommandsCard(
                        form = rootForm,
                        onChange = updateRootForm,
                        onSave = saveRootForm
                    )
                }
                ProfileCard(
                    tariff = tariff,
                    onTariffChange = { tariff = it },
                    onSave = { onSaveTariff(tariff) }
                )
                com.ex2hub.ui.SystemSettingsCard()
                DockAppsCard(profile.dockApps, onDockAppsChange)
                DriveMemoryCard(profile.restoreDrive, onRestoreDrive)
                ChargeAlertCard(
                    percent = profile.chargeAlertSoc,
                    done = profile.chargeDoneAlert,
                    onPercentChange = onChargeAlertChange,
                    onDoneChange = onChargeDoneChange
                )
                CurrentSourceCard(
                    ui = ui,
                    gpsGranted = gpsGranted,
                    onNavigateHome = onNavigateHome
                )
                HelpCard()
                AboutCard()
                DataCard(
                    records = ui.trips.size + ui.sessions.size,
                    busy = ui.exportBusy,
                    path = ui.exportPath,
                    onResetDemo = {
                        confirm = SettingsConfirmation(
                            title = "Восстановить демо-данные?",
                            message = "Журнал будет заменён демонстрационными поездками и зарядками, источник переключится на демо.",
                            confirmText = "Восстановить",
                            danger = false,
                            action = onResetDemo
                        )
                    },
                    onClearJournal = {
                        confirm = SettingsConfirmation(
                            title = "Очистить журнал?",
                            message = "Все поездки и зарядки будут удалены без возможности отменить действие.",
                            confirmText = "Очистить",
                            danger = true,
                            action = onClearJournal
                        )
                    },
                    onExport = onExportJournal,
                    onRestore = {
                        confirm = SettingsConfirmation(
                            title = "Восстановить журнал из копии?",
                            message = "Текущие поездки и зарядки будут заменены записями из файла. Источник данных и настройки останутся как сейчас.",
                            confirmText = "Восстановить",
                            danger = false,
                            action = onRestoreJournal
                        )
                    }
                )
            }
        }
    }

    confirm?.let { pending ->
        ConfirmDialog(
            title = pending.title,
            message = pending.message,
            confirmText = pending.confirmText,
            danger = pending.danger,
            onConfirm = {
                pending.action()
                confirm = null
            },
            onDismiss = { confirm = null }
        )
    }
}

@Composable
private fun UpdateCard(
    state: UpdateState,
    onCheck: () -> Unit,
    onDownload: () -> Unit,
    onInstall: () -> Unit
) {
    val busy = state.phase == UpdatePhase.CHECKING || state.phase == UpdatePhase.DOWNLOADING
    HubCard(Modifier.fillMaxWidth()) {
        CardHead(title = "Обновление EX2 HUB")
        SectionNote("Установлено ${BuildConfig.VERSION_NAME} · GitHub: vpolotske/Release")
        Spacer(Modifier.height(8.dp))
        Text(
            text = when (state.phase) {
                UpdatePhase.IDLE -> "Проверка запускается только по нажатию."
                UpdatePhase.CHECKING -> "Проверяем последнюю версию…"
                UpdatePhase.UP_TO_DATE -> "Установлена актуальная версия."
                UpdatePhase.AVAILABLE -> "Доступна версия ${state.release?.versionName}."
                UpdatePhase.DOWNLOADING -> "Загрузка APK: ${state.progress ?: 0}%"
                UpdatePhase.READY -> "Версия ${state.release?.versionName} проверена и готова к установке."
                UpdatePhase.ERROR -> state.message ?: "Не удалось получить обновление."
            },
            color = if (state.phase == UpdatePhase.ERROR) HubColors.Red else HubColors.Text,
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(Modifier.height(10.dp))
        HubButton(
            text = "Проверить обновление",
            onClick = onCheck,
            modifier = Modifier.fillMaxWidth(),
            enabled = !busy,
            loading = state.phase == UpdatePhase.CHECKING,
            style = HubButtonStyle.Ghost
        )
        if (state.phase == UpdatePhase.AVAILABLE || state.phase == UpdatePhase.DOWNLOADING ||
            (state.phase == UpdatePhase.ERROR && state.release != null)) {
            Spacer(Modifier.height(8.dp))
            HubButton(
                text = "Скачать APK",
                onClick = onDownload,
                modifier = Modifier.fillMaxWidth(),
                enabled = !busy,
                loading = state.phase == UpdatePhase.DOWNLOADING
            )
        }
        if (state.phase == UpdatePhase.READY) {
            Spacer(Modifier.height(8.dp))
            HubButton("Установить", onInstall, modifier = Modifier.fillMaxWidth())
        }
        Spacer(Modifier.height(8.dp))
        SectionNote("APK проверяется по SHA-256 и подписи. Установка — только с подтверждением Android, на стоянке; автоматической установки нет.")
    }
}

/** Выбор режима движения и рекуперации после выключения: раньше стоял на рабочем столе. */
@Composable
private fun DriveMemoryCard(restore: Boolean, onChange: (Boolean) -> Unit) {
    HubCard(Modifier.fillMaxWidth()) {
        CardHead(title = "Режим после включения", eyebrow = "Движение")
        Spacer(Modifier.height(6.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 48.dp)
                .clip(RoundedCornerShape(9.dp))
                .clickable { onChange(!restore) },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = "Запоминать выбор после выключения",
                    color = HubColors.Text,
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(2.dp))
                SectionNote(
                    "Режим движения и рекуперация восстанавливаются при запуске, когда автомобиль подтвердил передачу P."
                )
            }
            Spacer(Modifier.width(10.dp))
            SwitchPill(restore)
        }
    }
}

/**
 * Уведомления о зарядке: приложение только докладывает о том, что уже показывает
 * экран, и ничего не пишет автомобилю.
 */
@Composable
private fun ChargeAlertCard(
    percent: Int,
    done: Boolean,
    onPercentChange: (Int) -> Unit,
    onDoneChange: (Boolean) -> Unit
) {
    HubCard(Modifier.fillMaxWidth()) {
        CardHead(title = "Уведомления о зарядке", eyebrow = "Зарядка")
        Spacer(Modifier.height(6.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 48.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = if (percent == 0) "Порог заряда не задан" else "Порог заряда $percent%",
                    color = HubColors.Text,
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(2.dp))
                SectionNote("Одно уведомление за сеанс зарядки, только по заряду автомобиля.")
            }
            HubIconButton(
                icon = AppIcons.Minus,
                contentDescription = "Снизить порог заряда",
                onClick = { onPercentChange((percent - CHARGE_STEP).coerceAtLeast(0)) },
                enabled = percent > 0
            )
            Spacer(Modifier.width(6.dp))
            HubIconButton(
                icon = AppIcons.Plus,
                contentDescription = "Поднять порог заряда",
                onClick = {
                    onPercentChange(
                        if (percent == 0) CHARGE_FIRST_STEP
                        else (percent + CHARGE_STEP).coerceAtMost(100)
                    )
                }
            )
        }
        SoftDivider()
        Spacer(Modifier.height(6.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 48.dp)
                .clip(RoundedCornerShape(9.dp))
                .clickable { onDoneChange(!done) },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = "Сообщать об окончании зарядки",
                    color = HubColors.Text,
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(2.dp))
                SectionNote("Сводка сеанса: место, прибавка заряда, энергия, время и стоимость.")
            }
            Spacer(Modifier.width(10.dp))
            SwitchPill(done)
        }
        Spacer(Modifier.height(8.dp))
        SectionNote(
            "События идут в отдельный канал «Зарядка». Если показ уведомлений запрещён, они не придут: " +
                "разрешение запрашивается при первом запуске."
        )
    }
}

private const val CHARGE_STEP = 5
private const val CHARGE_FIRST_STEP = 50

@Composable
private fun SwitchPill(on: Boolean) {
    Box(
        Modifier
            .size(width = 42.dp, height = 24.dp)
            .clip(RoundedCornerShape(50))
            .background(if (on) HubColors.Accent else HubColors.Track)
            .padding(2.dp),
        contentAlignment = if (on) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Box(
            Modifier
                .size(20.dp)
                .clip(CircleShape)
                .background(if (on) Color.White else HubColors.Muted)
        )
    }
}

private data class SettingsConfirmation(
    val title: String,
    val message: String,
    val confirmText: String,
    val danger: Boolean,
    val action: () -> Unit
)

@Composable
private fun SourceSettingsCard(
    ui: HubUiState,
    manualSoc: String,
    manualRange: String,
    onManualSocChange: (String) -> Unit,
    onManualRangeChange: (String) -> Unit,
    onSelectSource: (SourceMode) -> Unit,
    onProbe: () -> Unit,
    onApplyManual: () -> Unit
) {
    val profile = ui.profile
    val check = ui.activeCheck
    val showManual = profile.source == SourceMode.MANUAL ||
        (profile.source != SourceMode.DEMO && ui.vehicle.isFallback)
    HubCard(Modifier.fillMaxWidth()) {
        CardHead(
            title = "Источник данных автомобиля",
            eyebrow = "Телеметрия",
            trailing = { Badge(text = "v1", color = HubColors.TextDim) }
        )
        Spacer(Modifier.height(6.dp))
        SectionNote(
            "Приложение не получает CAN напрямую. Выберите способ, который доступен на вашем головном устройстве."
        )
        Spacer(Modifier.height(10.dp))

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SourceMode.entries.forEach { mode ->
                SourceOption(
                    mode = mode,
                    selected = profile.source == mode,
                    checkStatus = ui.check(mode).status,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { onSelectSource(mode) }
                )
            }
        }

        Spacer(Modifier.height(10.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(
                    if (ui.vehicle.isFallback) HubColors.Amber.copy(alpha = 0.05f)
                    else HubColors.SurfaceHigh.copy(alpha = 0.5f)
                )
                .border(
                    1.dp,
                    if (ui.vehicle.isFallback) HubColors.Amber.copy(alpha = 0.18f)
                    else HubColors.BorderSoft,
                    RoundedCornerShape(12.dp)
                )
                .padding(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StateDot(
                        color = if (ui.vehicle.isFallback) HubColors.Amber else check.status.color(),
                        size = 6.dp
                    )
                    Spacer(Modifier.width(7.dp))
                    Text(
                        text = when {
                            ui.vehicle.isFallback -> "Источник недоступен, используется резерв"
                            check.status == CheckStatus.OK -> "${profile.source.title()}: доступен"
                            check.status == CheckStatus.ERROR -> "${profile.source.title()}: ошибка"
                            else -> "${profile.source.title()}: не проверен"
                        },
                        color = HubColors.Text,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontSize = 21.sp,
                            fontWeight = FontWeight.Medium
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text = profile.source.description(),
                    color = HubColors.Muted,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 21.sp, lineHeight = 30.sp)
                )
                if (check.checkedAt > 0L) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "Проверка: ${Fmt.relativeUpdated(check.checkedAt)} · ${check.summary}",
                        color = HubColors.Muted,
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        if (profile.source == SourceMode.CAR_API) {
            Spacer(Modifier.height(8.dp))
            WarningBox(
                text = "Строка «права Car API» в журнале — это взгляд приложения на манифест: на этом ГУ 8 из 12 разрешений помечены не выданными, а чтение и запись климата работают. Отказ возможен на другой прошивке — тогда остаются root-команды или ручной ввод."
            )
            Spacer(Modifier.height(6.dp))
            WarningBox(
                text = "Журнал автомобиля работает сам: поездка пишется по пробегу и передаче, " +
                    "зарядка — по состоянию зарядки. Строка появляется, когда событие закончится. " +
                    "На root и в ручном режиме автомат молчит: там нет пробега и состояния зарядки.",
                color = HubColors.Mint
            )
        }

        if (showManual) {
            Spacer(Modifier.height(10.dp))
            SoftDivider()
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Eyebrow("Ручные значения")
                Spacer(Modifier.weight(1f))
                Text(
                    text = if (ui.vehicle.isFallback) "резерв при недоступном источнике" else "текущие значения",
                    color = HubColors.Muted,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp)
                )
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HubTextField(
                    value = manualSoc,
                    onValueChange = onManualSocChange,
                    modifier = Modifier.weight(1f),
                    label = "Текущий заряд, %",
                    placeholder = "0–100",
                    keyboardType = KeyboardType.Number
                )
                HubTextField(
                    value = manualRange,
                    onValueChange = onManualRangeChange,
                    modifier = Modifier.weight(1f),
                    label = "Запас хода, км",
                    placeholder = "0–1200",
                    keyboardType = KeyboardType.Number
                )
            }
            Spacer(Modifier.height(8.dp))
            HubButton(
                text = "Применить значения",
                onClick = onApplyManual,
                icon = AppIcons.Check,
                style = HubButtonStyle.Ghost
            )
        }

        Spacer(Modifier.height(10.dp))
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            HubButton(
                text = "Проверить доступ",
                onClick = onProbe,
                icon = AppIcons.Refresh,
                style = HubButtonStyle.Ghost,
                loading = ui.probeRunning,
                enabled = !ui.probeRunning
            )
            Spacer(Modifier.width(10.dp))
            Text(
                text = if (profile.source == SourceMode.DEMO || profile.source == SourceMode.MANUAL) {
                    "В демо и ручном режиме проверка выполняется локально."
                } else {
                    "В APK проверка выполняется на устройстве и пишет журнал ниже."
                },
                color = HubColors.Muted,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 21.sp, lineHeight = 30.sp),
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(8.dp))
        ProbeTerminal(text = ui.probeLog)

        Spacer(Modifier.height(8.dp))
        SectionNote(
            text = "При переходе с демо-данных синтетические записи журнала будут удалены. Ручные поездки и зарядки сохранятся."
        )
    }
}

@Composable
private fun SourceOption(
    mode: SourceMode,
    selected: Boolean,
    checkStatus: CheckStatus,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val accent = mode.accent()
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) accent.copy(alpha = 0.07f) else HubColors.SurfaceHigh.copy(alpha = 0.42f))
            .border(
                1.dp,
                if (selected) accent.copy(alpha = 0.42f) else HubColors.BorderSoft,
                RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(accent.copy(alpha = if (selected) 0.14f else 0.07f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = mode.icon(),
                contentDescription = null,
                tint = if (selected) accent else HubColors.TextDim,
                modifier = Modifier.size(19.dp)
            )
        }
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = mode.shortTitle(),
                color = if (selected) HubColors.Text else HubColors.TextDim,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Medium
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = mode.hint(),
                color = HubColors.Muted,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Box(
                Modifier
                    .size(20.dp)
                    .clip(CircleShape)
                    .border(
                        1.dp,
                        if (selected) accent else HubColors.Border,
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (selected) {
                    Box(
                        Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(accent)
                    )
                }
            }
            Text(
                text = when (checkStatus) {
                    CheckStatus.OK -> "доступен"
                    CheckStatus.ERROR -> "ошибка"
                    CheckStatus.UNKNOWN -> if (mode == SourceMode.DEMO) "активен" else "не проверен"
                },
                color = checkStatus.color(),
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp),
                maxLines = 1
            )
        }
    }
}

@Composable
private fun ProbeTerminal(text: String) {
    val clipboard = LocalClipboardManager.current
    // Терминал хранит до 60 000 символов. Один Text на такой строке пересобирался
    // при каждом обновлении пробы и подвешивал настройки, поэтому строки ленивые.
    val lines = remember(text) { text.split('\n') }
    val list = rememberLazyListState()
    LaunchedEffect(lines) {
        if (lines.isNotEmpty()) list.scrollToItem(lines.lastIndex)
    }
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(11.dp))
            .background(HubColors.Black)
            .border(1.dp, HubColors.BorderSoft, RoundedCornerShape(11.dp))
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 12.dp, end = 6.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "ТЕРМИНАЛ",
                color = HubColors.Muted,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontSize = 18.sp,
                    letterSpacing = 1.6.sp,
                    fontWeight = FontWeight.Medium
                )
            )
            Spacer(Modifier.weight(1f))
            HubTextButton(
                text = "Скопировать",
                onClick = { clipboard.setText(AnnotatedString(text)) },
                color = HubColors.Mint
            )
        }
        SelectionContainer {
            LazyColumn(
                Modifier.heightIn(min = 150.dp, max = 380.dp),
                state = list,
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 12.dp)
            ) {
                items(lines.size) { index ->
                    Text(
                        text = lines[index],
                        color = HubColors.Mint,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 18.sp,
                            lineHeight = 26.sp
                        )
                    )
                }
            }
        }
    }
}

/** Команды чтения root-источника. Каждая должна выводить одно число. */
private data class RootCommandsForm(
    val soc: String,
    val range: String,
    val power: String,
    val temp: String,
    val driveMode: String,
    val regen: String
)

@Composable
private fun RootCommandsCard(
    form: RootCommandsForm,
    onChange: (RootCommandsForm) -> Unit,
    onSave: () -> Unit
) {
    HubCard(Modifier.fillMaxWidth()) {
        CardHead(
            title = "Команды root",
            eyebrow = "Продвинутый режим",
            trailing = { Badge(text = "осторожно", color = HubColors.Amber, dot = true) }
        )
        Spacer(Modifier.height(8.dp))
        WarningBox(
            text = "Команды выполняются от суперпользователя. Ошибка в команде может изменить систему. Не используйте чужие скрипты без проверки."
        )
        Spacer(Modifier.height(9.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            HubTextField(
                value = form.soc,
                onValueChange = { onChange(form.copy(soc = it)) },
                label = "SOC, %",
                placeholder = "команда, выводящая число 0–100"
            )
            HubTextField(
                value = form.range,
                onValueChange = { onChange(form.copy(range = it)) },
                label = "Запас хода, км",
                placeholder = "команда, выводящая число километров"
            )
            HubTextField(
                value = form.power,
                onValueChange = { onChange(form.copy(power = it)) },
                label = "Мощность зарядки, кВт",
                placeholder = "0, если заряд не идёт"
            )
            HubTextField(
                value = form.temp,
                onValueChange = { onChange(form.copy(temp = it)) },
                label = "Температура за бортом, °C",
                placeholder = "число от −50 до 85"
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HubTextField(
                    value = form.driveMode,
                    onValueChange = { onChange(form.copy(driveMode = it)) },
                    modifier = Modifier.weight(1f),
                    label = "Режим движения",
                    placeholder = "код 0x220101xx или 1/2/3"
                )
                HubTextField(
                    value = form.regen,
                    onValueChange = { onChange(form.copy(regen = it)) },
                    modifier = Modifier.weight(1f),
                    label = "Рекуперация",
                    placeholder = "код 0x200205xx или 1/2/3"
                )
            }
        }
        Spacer(Modifier.height(7.dp))
        SectionNote(
            "Из вывода команды берётся первое число. Режим и рекуперация принимаются и полным " +
                "кодом свойства, и коротким счётом 1/2/3. Опрос выполняется не чаще одного раза " +
                "в 15 секунд. Готовые команды зависят от прошивки."
        )
        Spacer(Modifier.height(8.dp))
        HubButton(
            text = "Сохранить команды",
            onClick = onSave,
            icon = AppIcons.Check,
            style = HubButtonStyle.Ghost
        )
    }
}

@Composable
private fun ProfileCard(
    tariff: String,
    onTariffChange: (String) -> Unit,
    onSave: () -> Unit
) {
    HubCard(Modifier.fillMaxWidth()) {
        CardHead(title = "Тариф зарядки")
        Spacer(Modifier.height(9.dp))
        HubTextField(
            value = tariff,
            onValueChange = onTariffChange,
            modifier = Modifier.fillMaxWidth(),
            label = "Тариф, р./кВт·ч",
            placeholder = "0,28",
            keyboardType = KeyboardType.Decimal
        )
        Spacer(Modifier.height(7.dp))
        SectionNote(
            "Тариф используется для расчёта стоимости поездок и зарядок. Все данные хранятся локально на устройстве."
        )
        Spacer(Modifier.height(8.dp))
        HubButton(
            text = "Сохранить тариф",
            onClick = onSave,
            icon = AppIcons.Check,
            style = HubButtonStyle.Primary,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun CurrentSourceCard(
    ui: HubUiState,
    gpsGranted: Boolean,
    onNavigateHome: () -> Unit
) {
    val profile = ui.profile
    val interval = when (profile.source) {
        SourceMode.CAR_API -> "каждые 5 секунд"
        SourceMode.ROOT -> "каждые 15 секунд"
        SourceMode.MANUAL -> "по кнопке"
        SourceMode.DEMO -> "синтетика"
    }
    HubCard(Modifier.fillMaxWidth()) {
        CardHead(
            title = "Сейчас используется",
            eyebrow = "Состояние",
            trailing = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StateDot(HubColors.Accent, size = 6.dp, glow = true)
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = "локально",
                        color = HubColors.Muted,
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp)
                    )
                }
            }
        )
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            com.ex2hub.ui.IconChip(
                icon = profile.source.icon(),
                accent = profile.source.accent(),
                size = 48.dp,
                iconSize = 24.dp
            )
            Spacer(Modifier.width(10.dp))
            Column {
                Text(
                    text = profile.source.title(),
                    color = HubColors.Text,
                    style = MaterialTheme.typography.titleMedium.copy(fontSize = 21.sp),
                    maxLines = 1
                )
                Text(
                    text = profile.source.hint(),
                    color = HubColors.Muted,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp),
                    maxLines = 1
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        InfoRow(
            label = "Последнее чтение",
            value = if (ui.vehicle.updatedAt > 0L) Fmt.relativeUpdated(ui.vehicle.updatedAt) else "—"
        )
        Spacer(Modifier.height(8.dp))
        InfoRow(
            label = "GPS-поездки",
            value = if (gpsGranted) "доступны" else "нет разрешения",
            valueColor = if (gpsGranted) HubColors.Text else HubColors.Amber
        )
        Spacer(Modifier.height(8.dp))
        InfoRow(label = "Обновление", value = interval)
        Spacer(Modifier.height(10.dp))
        HubButton(
            text = "На рабочий стол",
            onClick = onNavigateHome,
            icon = AppIcons.Home,
            style = HubButtonStyle.Ghost,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun HelpCard() {
    HubCard(Modifier.fillMaxWidth()) {
        CardHead(
            title = "Как подключить авто",
            eyebrow = "Если данных нет",
            trailing = { com.ex2hub.ui.IconChip(icon = AppIcons.Info, size = 38.dp, iconSize = 19.dp) }
        )
        Spacer(Modifier.height(8.dp))
        StepRow(1, "Откройте «Проверить доступ» и сохраните вывод диагностики.")
        Spacer(Modifier.height(6.dp))
        StepRow(2, "Если не ответило ни одно свойство — остаются root-команды или ручной ввод. На этом ГУ Car API отвечает и без них.")
        Spacer(Modifier.height(6.dp))
        StepRow(3, "Для root найдите команду, которая печатает SOC, и вставьте её в настройки.")
        Spacer(Modifier.height(7.dp))
        SectionNote(
            "На Flyme Auto и Geely OS доступ зависит от прошивки. Приложение не обещает доступ к параметрам, которых нет в системе."
        )
    }
}

@Composable
private fun StepRow(number: Int, text: String) {
    Row(verticalAlignment = Alignment.Top) {
        Box(
            Modifier
                .size(30.dp)
                .clip(CircleShape)
                .background(HubColors.Accent.copy(alpha = 0.1f))
                .border(1.dp, HubColors.Accent.copy(alpha = 0.22f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = number.toString(),
                color = HubColors.Accent,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold
                )
            )
        }
        Spacer(Modifier.width(7.dp))
        Text(
            text = text,
            color = HubColors.TextDim,
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 21.sp, lineHeight = 30.sp),
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun AboutCard() {
    HubCard(Modifier.fillMaxWidth()) {
        CardHead(
            title = "EX2 HUB ${BuildConfig.VERSION_NAME}",
            eyebrow = "О приложении",
            trailing = { Badge(text = "Android 8+", color = HubColors.TextDim) }
        )
        Spacer(Modifier.height(8.dp))
        InfoRow("Назначение", "Бортовой рабочий стол и учёт поездок")
        Spacer(Modifier.height(6.dp))
        InfoRow("Хранение", "Локально, без облака")
        Spacer(Modifier.height(6.dp))
        InfoRow("Интернет", "Не требуется")
        Spacer(Modifier.height(6.dp))
        InfoRow("Ограничение", "Нет прямого доступа к CAN без прав ГУ")
        Spacer(Modifier.height(7.dp))
        SectionNote(
            "Приложение не заменяет штатный лаунчер и не трогает двери. Климат пишется только штатными VHAL-свойствами и только там, где автомобиль ответил по этому сигналу."
        )
    }
}

@Composable
private fun DataCard(
    records: Int,
    busy: Boolean,
    path: String,
    onResetDemo: () -> Unit,
    onClearJournal: () -> Unit,
    onExport: () -> Unit,
    onRestore: () -> Unit
) {
    HubCard(Modifier.fillMaxWidth()) {
        CardHead(
            title = "Данные приложения",
            eyebrow = "Локально",
            trailing = {
                Text(
                    text = Fmt.records(records),
                    color = HubColors.Muted,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp)
                )
            }
        )
        Spacer(Modifier.height(8.dp))
        SectionNote(
            "Журнал и настройки удаляются только по вашему действию. Демо-режим можно вернуть в любой момент."
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HubButton(
                text = "Выгрузить CSV и копию",
                onClick = onExport,
                icon = AppIcons.Download,
                style = HubButtonStyle.Ghost,
                enabled = records > 0 && !busy,
                loading = busy,
                modifier = Modifier.weight(1f)
            )
            HubButton(
                text = "Восстановить из копии",
                onClick = onRestore,
                icon = AppIcons.Upload,
                style = HubButtonStyle.Ghost,
                enabled = !busy,
                modifier = Modifier.weight(1f)
            )
        }
        if (path.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            SectionNote("Файлы лежат в $path")
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HubButton(
                text = "Демо-данные",
                onClick = onResetDemo,
                icon = AppIcons.Refresh,
                style = HubButtonStyle.Ghost,
                enabled = !busy,
                modifier = Modifier.weight(1f)
            )
            HubButton(
                text = "Очистить журнал",
                onClick = onClearJournal,
                icon = AppIcons.Trash,
                style = HubButtonStyle.Danger,
                enabled = records > 0 && !busy,
                modifier = Modifier.weight(1f)
            )
        }
    }
}
