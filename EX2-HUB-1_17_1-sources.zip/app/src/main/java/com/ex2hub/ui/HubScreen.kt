package com.ex2hub.ui

import android.Manifest
import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import com.ex2hub.data.Gear
import com.ex2hub.data.SourceMode
import com.ex2hub.data.TrackedTripPrefill
import com.ex2hub.data.Trip
import com.ex2hub.tracker.TripTracker
import com.ex2hub.ui.dialogs.AddChargeDialog
import com.ex2hub.ui.dialogs.AddTripDialog
import com.ex2hub.ui.screens.AllAppsScreen
import com.ex2hub.ui.screens.ChargingScreen
import com.ex2hub.ui.screens.HomeScreen
import com.ex2hub.ui.screens.SettingsScreen
import com.ex2hub.ui.screens.TripsScreen
import com.ex2hub.ui.theme.HubColors
import kotlinx.coroutines.launch

@Composable
fun HubScreen(vm: HubController, homePresses: Int) {
    val ui = vm.ui
    val context = LocalContext.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val updater = vm.updater
    val update by updater.state.collectAsState()
    // Ссылка на метод контроллера — каждый раз новый объект. Из-за него Compose считал
    // параметры рабочего стола изменившимися на любое обновление телеметрии и
    // перерисовывал весь блок климата. Одна ссылка на контроллер решает это.
    val onClimate = remember(vm) { vm::onClimateChange }
    val onPreset = remember(vm) { vm::onClimatePreset }
    val onDriveMode = remember(vm) { vm::onDriveMode }
    val onRegen = remember(vm) { vm::onRegen }
    val onFrunkOpen = remember(vm) { vm::onFrunkOpen }
    // Макет собран в фиксированных dp и sp. Крупный шрифт из настроек ГУ раздвигал бы
    // подписи за края кнопок и карточек, поэтому масштаб шрифта закреплён на единице.
    val fixedDensity = remember(density.density) { Density(density.density, 1f) }
    val journalDensity = remember(density.density) { Density(density.density * 1.5f, 1f) }
    val installPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        scope.launch {
            val allowed = runCatching { updater.canRequestPackageInstalls() }.getOrDefault(false)
            snackbar.showSnackbar(
                if (allowed) "Доступ разрешён. Нажмите «Установить» ещё раз." else
                    "Android не разрешил установку. APK можно установить вручную."
            )
        }
    }

    fun installUpdate() {
        val vehicle = ui.vehicle
        val liveSource = ui.profile.source == SourceMode.CAR_API || ui.profile.source == SourceMode.ROOT
        if (liveSource && (vehicle.stale || vehicle.isFallback || vehicle.updatedAt <= 0L ||
                System.currentTimeMillis() - vehicle.updatedAt !in 0L..5_000L || vehicle.gear != Gear.P ||
                vehicle.speedKmh != 0 || ui.climateBusy || ui.driveBusy || ui.bodyBusy || ui.probeRunning)) {
            scope.launch { snackbar.showSnackbar("Установка доступна на стоянке, при подтверждённых P и 0 км/ч.") }
            return
        }
        scope.launch {
            if (!runCatching { vm.canInstallUpdate() }.getOrDefault(false)) {
                snackbar.showSnackbar("Не подтверждена безопасная стоянка: нужны свежая скорость 0 и передача P.")
                return@launch
            }
            runCatching {
                if (!updater.canRequestPackageInstalls()) {
                    installPermissionLauncher.launch(updater.permissionIntent())
                } else {
                    updater.installerIntent()?.let(context::startActivity)
                }
            }.onFailure {
                snackbar.showSnackbar("Установщик недоступен в этой прошивке. Установите APK вручную.")
            }
        }
    }

    var page by rememberSaveable { mutableStateOf(HubPage.HOME) }
    var showAllApps by rememberSaveable { mutableStateOf(false) }
    var showTripDialog by remember { mutableStateOf(false) }
    var showChargeDialog by remember { mutableStateOf(false) }
    var tripPrefill by remember { mutableStateOf<TrackedTripPrefill?>(null) }
    var gpsGranted by remember {
        mutableStateOf(TripTracker.hasAnyLocationPermission(context))
    }

    LaunchedEffect(homePresses) {
        if (homePresses > 0) {
            page = HubPage.HOME
            showAllApps = false
        }
    }

    LaunchedEffect(page) { vm.onPageShown(page) }

    // Рабочему столу некуда возвращаться: «Назад» на главной ничего не закрывает,
    // а в роли обычного приложения просто уводит его на фон, сохраняя состояние.
    BackHandler {
        when {
            showAllApps -> showAllApps = false
            page != HubPage.HOME -> page = HubPage.HOME
            !InstalledApps.isDefaultHome(context) -> (context as? Activity)?.moveTaskToBack(true)
        }
    }

    LaunchedEffect(vm) {
        vm.messages.collect { message ->
            snackbar.currentSnackbarData?.dismiss()
            snackbar.showSnackbar(message)
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val granted = result.values.any { it } ||
            TripTracker.hasAnyLocationPermission(context)
        gpsGranted = granted
        if (granted) {
            if (vm.startTracking()) {
                page = HubPage.TRIPS
            }
        } else {
            scope.launch {
                snackbar.showSnackbar(
                    "Без доступа к геолокации GPS-запись недоступна. Разрешение можно выдать в настройках ГУ."
                )
            }
        }
    }

    fun requestTracking() {
        if (TripTracker.hasAnyLocationPermission(context)) {
            gpsGranted = true
            if (vm.startTracking()) {
                page = HubPage.TRIPS
            }
        } else {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    fun stopTracking() {
        val result = vm.stopTracking() ?: return
        tripPrefill = TrackedTripPrefill(
            distanceKm = result.distanceKm,
            durationMin = result.durationMin,
            startedAt = result.startedAt,
            fromLat = result.fromLat,
            fromLon = result.fromLon,
            toLat = result.toLat,
            toLon = result.toLon
        )
        showTripDialog = true
    }

    fun openTripDialog(prefill: TrackedTripPrefill? = null) {
        tripPrefill = prefill
        showTripDialog = true
    }

    fun openTripRoute(trip: Trip) {
        if (!MapRoute.open(context, trip)) {
            scope.launch {
                snackbar.showSnackbar("Карты не открылись: на ГУ нет приложения, которое строит маршрут.")
            }
        }
    }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .background(HubColors.Bg)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        val compact = maxWidth < 1000.dp
        val layout = HubLayout(
            pagePadding = if (compact) 13.dp else 18.dp,
            cardPadding = if (compact) 16.dp else 20.dp,
            gap = if (compact) 10.dp else 14.dp,
            compact = compact
        )
        CompositionLocalProvider(LocalHubLayout provides layout) {
            Row(Modifier.fillMaxSize()) {
                CompositionLocalProvider(LocalDensity provides fixedDensity) {
                    HubNavRail(
                        page = page,
                        onNavigate = { page = it }
                    )
                }
                Column(Modifier.fillMaxSize().weight(1f)) {
                    Box(Modifier.fillMaxSize().weight(1f)) {
                        // Рабочий стол собран по макету 1768×1080 и масштабируется целиком,
                        // остальные разделы — в 1,5 раза.
                        val sectionDensity = if (page == HubPage.HOME) {
                            fixedDensity
                        } else {
                            journalDensity
                        }
                        val sectionText = if (page == HubPage.HOME) HubText.Base else HubText.Page
                        CompositionLocalProvider(
                            LocalDensity provides sectionDensity,
                            LocalHubText provides sectionText
                        ) {
                            when (page) {
                                HubPage.HOME -> HomeScreen(
                                    ui = ui,
                                    onNavigate = { page = it },
                                    onClimate = onClimate,
                                    onPreset = onPreset,
                                    onDriveMode = onDriveMode,
                                    onRegen = onRegen,
                                    onFrunkOpen = onFrunkOpen,
                                    onAllApps = { showAllApps = true }
                                )
                                HubPage.TRIPS -> TripsScreen(
                                    state = ui.tripsPage(),
                                    gpsGranted = gpsGranted,
                                    onAddTrip = { openTripDialog() },
                                    onStartTracking = ::requestTracking,
                                    onStopTracking = ::stopTracking,
                                    onDeleteTrip = vm::deleteTrip,
                                    onOpenRoute = ::openTripRoute,
                                    onOpenCharging = { page = HubPage.CHARGING }
                                )
                                HubPage.CHARGING -> ChargingScreen(
                                    state = ui.chargingPage(),
                                    onAddCharge = { showChargeDialog = true },
                                    onDeleteCharge = vm::deleteCharge
                                )
                                HubPage.SETTINGS -> SettingsScreen(
                                    ui = ui,
                                    gpsGranted = gpsGranted,
                                    onSelectSource = vm::setSource,
                                    onProbe = vm::runProbe,
                                    onApplyManual = { soc, range ->
                                        vm.applyManualValues(soc, range)
                                        Unit
                                    },
                                    onSaveTariff = { tariff ->
                                        vm.saveTariff(tariff)
                                        Unit
                                    },
                                    onSaveRootCommands = { soc, range, power, temp, driveMode, regen ->
                                        vm.saveRootCommands(soc, range, power, temp, driveMode, regen)
                                        Unit
                                    },
                                    onResetDemo = vm::resetDemoData,
                                    onClearJournal = vm::clearJournal,
                                    onExportJournal = vm::exportJournal,
                                    onRestoreJournal = vm::restoreJournal,
                                    onNavigateHome = { page = HubPage.HOME },
                                    onDockAppsChange = vm::setDockApps,
                                    onRestoreDrive = vm::setRestoreDrive,
                                    onChargeAlertChange = vm::setChargeAlert,
                                    onChargeDoneChange = vm::setChargeDoneAlert,
                                    update = update,
                                    onCheckUpdate = { scope.launch { updater.checkLatest() } },
                                    onDownloadUpdate = { scope.launch { updater.download() } },
                                    onInstallUpdate = ::installUpdate
                                )
                            }
                        }
                    }
                }
            }
            if (showAllApps) {
                AllAppsScreen(onClose = { showAllApps = false })
            }
            HubSnackbarHost(
                hostState = snackbar,
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
    }

    if (showTripDialog) {
        AddTripDialog(
            tariff = ui.profile.tariffPerKwh,
            prefill = tripPrefill,
            suggestedDriveMode = ui.vehicle.driveMode,
            suggestedRegen = ui.vehicle.regen,
            onDismiss = {
                showTripDialog = false
                tripPrefill = null
            },
            onSave = { draft -> vm.addTrip(draft) }
        )
    }

    if (showChargeDialog) {
        AddChargeDialog(
            tariff = ui.profile.tariffPerKwh,
            suggestedType = ui.vehicle.chargeType,
            onDismiss = { showChargeDialog = false },
            onSave = { draft -> vm.addCharge(draft) }
        )
    }
}
