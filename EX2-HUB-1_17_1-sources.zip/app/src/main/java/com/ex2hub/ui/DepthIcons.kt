package com.ex2hub.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.dp

/**
 * Линейные значки 24×24 с теми же контурами, что в mockup/index.html.
 * Заливок и градиентов нет: цвет задаётся тонированием при отрисовке.
 */
object DepthIcons {
    private const val STROKE = 1.7f

    private fun vector(
        name: String,
        width: Float = 24f,
        height: Float = 24f,
        block: ImageVector.Builder.() -> Unit
    ): ImageVector =
        ImageVector.Builder(name, width.dp, height.dp, width, height, tintColor = Color.Unspecified)
            .apply(block).build()

    private fun ImageVector.Builder.line(d: String, width: Float = STROKE) {
        addPath(
            pathData = PathParser().parsePathString(d).toNodes(),
            stroke = SolidColor(Color.White),
            strokeLineWidth = width,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round
        )
    }

    val Bolt: ImageVector by lazy {
        vector("Bolt") {
            line(
                "M13.2 2.4 4.6 13.6a.7.7 0 0 0 .55 1.15h4.6l-1.1 6.35a.55.55 0 0 0 .95.45" +
                    "l8.8-11.2a.7.7 0 0 0-.55-1.15h-4.6l1.05-6.35a.55.55 0 0 0-.95-.45Z"
            )
        }
    }

    val Leaf: ImageVector by lazy {
        vector("Leaf") {
            line(
                "M20.7 3.4C10.6 3 4.4 8.3 4.4 15.2c0 3.5 1.9 5.8 4.9 6.4" +
                    " 1-7.7 5.4-13.2 11.4-18.2Z"
            )
            line("M9.3 21.6c1.1-6.3 4.6-11.6 9.6-15.2")
        }
    }

    val Comfort: ImageVector by lazy {
        vector("Comfort") {
            line("M7.1 10.4V6.6a2.7 2.7 0 0 1 2.7-2.7h4.4a2.7 2.7 0 0 1 2.7 2.7v3.8")
            line(
                "M5.7 10.4h12.6a2.5 2.5 0 0 1 2.5 2.5v2.8a2.6 2.6 0 0 1-2.6 2.6" +
                    "H5.8a2.6 2.6 0 0 1-2.6-2.6v-2.8a2.5 2.5 0 0 1 2.5-2.5Z"
            )
            line("M7 18.3v2.2M17 18.3v2.2")
        }
    }

    val Sport: ImageVector by lazy {
        vector("Sport") {
            line("M3.8 17.8a8.5 8.5 0 0 1 16.4 0")
            line("M12 17.6l4.2-6.5")
            line("M13.2 17.6A1.2 1.2 0 1 1 10.8 17.6A1.2 1.2 0 1 1 13.2 17.6Z")
            line("M5.9 14.3l.9.8M18.1 14.3l-.9.8M12 10.9v1.2")
        }
    }

    val Car: ImageVector by lazy {
        vector("Car") {
            line(
                "M5.1 12.2 6.9 7.9a2.8 2.8 0 0 1 2.6-1.8h5a2.8 2.8 0 0 1 2.6 1.8l1.8 4.3",
                1.6f
            )
            line(
                "M3.8 12.2h16.4a1.6 1.6 0 0 1 1.6 1.6v2.7a1.6 1.6 0 0 1-1.6 1.6" +
                    "H3.8a1.6 1.6 0 0 1-1.6-1.6v-2.7a1.6 1.6 0 0 1 1.6-1.6Z",
                1.6f
            )
            line("M6.4 15.3h2.2M15.4 15.3h2.2", 1.6f)
            line("M6.1 18.1v1.1M17.9 18.1v1.1", 1.6f)
        }
    }

    /** Рекуперация: кольцо со стрелкой и одна-три ступени по уровню. */
    private const val REGEN_RING = "M20.4 12a8.4 8.4 0 1 1-2.5-5.97"
    private const val REGEN_ARROW = "M20.4 3.4v5h-5"

    private fun regen(name: String, bars: String): ImageVector = vector(name) {
        line(REGEN_RING, 1.5f)
        line(REGEN_ARROW, 1.5f)
        line(bars, 2.2f)
    }

    val RegenLow: ImageVector by lazy {
        regen("RegenLow", "M12 10.7v5.6")
    }
    val RegenMid: ImageVector by lazy {
        regen("RegenMid", "M10.4 12.3v4M13.6 10.7v5.6")
    }
    val RegenHigh: ImageVector by lazy {
        regen("RegenHigh", "M9.7 13.9v2.4M12 12.3v4M14.3 10.7v5.6")
    }

    val Fan: ImageVector by lazy {
        vector("Fan") {
            line(
                "M10.9 15.9a5.9 5.9 0 0 1-8.35-6.79l5.25 1.41a5.9 5.9 0 0 1 6.79-8.36" +
                    "l-1.41 5.25a5.9 5.9 0 0 1 8.36 6.79l-5.25-1.41a5.9 5.9 0 0 1-6.79 8.36l1.4-5.25Z",
                1.6f
            )
            line("M13.1 12A1.1 1.1 0 1 1 10.9 12A1.1 1.1 0 1 1 13.1 12Z", 1.6f)
        }
    }

    val Snowflake: ImageVector by lazy {
        vector("Snowflake") {
            line("M12 8.9 15 10.6v3.4L12 15.7l-3-1.7v-3.4Z")
            line(
                "M12 3.6v5.3M12 15.7v5.3M4.7 7.6l4.5 2.6M14.8 13.8l4.5 2.6" +
                    "M4.7 16.4l4.5-2.6M14.8 10.2l4.5-2.6"
            )
        }
    }

    val Heat: ImageVector by lazy {
        vector("Heat") {
            line(
                "M12 2.7c.6 3.2 2.9 4.5 4.4 6.9 1.1 1.7 1.6 3.6 1.2 5.6" +
                    "-.6 3.2-3 5.5-6 5.5-3.1 0-5.5-2.4-5.9-5.5-.3-2.5.9-4.6 2.6-6.3" +
                    ".4-.4.8-.8 1-1.3.3 1.3.7 2 1.5 2.5-.2-2.6.5-5 1.2-7.4Z"
            )
            line(
                "M12 20c-1.4 0-2.5-1-2.5-2.3 0-1.5 1.3-2.2 1.9-3.8" +
                    " 1.1.9 1.7 2 1.7 3.1 0 1.7-.5 3-1.1 3Z"
            )
        }
    }

    /** Силуэт сиденья: спинка слева у водителя и справа у пассажира. */
    private const val SEAT_DRIVER =
        "M9.8 3.3H7.9a2.8 2.8 0 0 0-2.8 2.8v6.6h4.7a2.2 2.2 0 0 0 2.2-2.2" +
            "V5.5a2.2 2.2 0 0 0-2.2-2.2Z"
    private const val SEAT_DRIVER_BASE =
        "M5.1 12.7h6.6a4.7 4.7 0 0 1 4.7 4.7v1.2H8.7a3.6 3.6 0 0 1-3.6-3.6v-2.3Z"
    private const val SEAT_PASSENGER =
        "M14.2 3.3h1.9a2.8 2.8 0 0 1 2.8 2.8v6.6h-4.7a2.2 2.2 0 0 1-2.2-2.2" +
            "V5.5a2.2 2.2 0 0 1 2.2-2.2Z"
    private const val SEAT_PASSENGER_BASE =
        "M18.9 12.7h-6.6a4.7 4.7 0 0 0-4.7 4.7v1.2h7.7a3.6 3.6 0 0 0 3.6-3.6v-2.3Z"

    val Seat: ImageVector by lazy {
        vector("Seat") {
            line(SEAT_DRIVER)
            line(SEAT_DRIVER_BASE)
            line("M5.2 19.8h12.6M7.6 19.8v1.6M15.4 19.8v1.6")
        }
    }

    val SeatPassenger: ImageVector by lazy {
        vector("SeatPassenger") {
            line(SEAT_PASSENGER)
            line(SEAT_PASSENGER_BASE)
            line("M18.8 19.8H6.2M16.4 19.8v1.6M8.6 19.8v1.6")
        }
    }

    val Wheel: ImageVector by lazy {
        vector("Wheel") {
            line("M20.5 12A8.5 8.5 0 1 1 3.5 12A8.5 8.5 0 1 1 20.5 12Z")
            line("M14.2 12A2.2 2.2 0 1 1 9.8 12A2.2 2.2 0 1 1 14.2 12Z")
            line("M3.5 12h6.3M14.2 12h6.3M12 14.2v6.3")
        }
    }

    /** Обогрев лобового: трапеция стекла с закруглёнными углами и зигзаги накала. */
    val Defrost: ImageVector by lazy {
        vector("Defrost") {
            line("M7.6 4.3h8.8c.84 0 1.48.75 1.38 1.58l-.62 5.2c-.09.72-.7 1.26-1.42 1.26H8.26c-.72 0-1.33-.54-1.42-1.26l-.62-5.2C6.12 5.05 6.76 4.3 7.6 4.3Z")
            line("M9.8 10.7c-.45-.7-.45-1.4 0-2.1s.45-1.4 0-2.1")
            line("M12 11c-.5-.75-.5-1.5 0-2.25s.5-1.5 0-2.25")
            line("M14.2 10.7c-.45-.7-.45-1.4 0-2.1s.45-1.4 0-2.1")
        }
    }

    /** Обогрев заднего стекла: прямоугольник с закруглёнными углами и горизонтальные нити. */
    val RearDefrost: ImageVector by lazy {
        vector("RearDefrost") {
            line("M5.6 3.9h12.8c.85 0 1.5.74 1.4 1.58l-1 8.2c-.08.7-.68 1.22-1.38 1.22H6.58c-.7 0-1.3-.52-1.38-1.22l-1-8.2C4.1 4.64 4.75 3.9 5.6 3.9Z")
            line("M6.4 7q1.9-1 3.8 0t3.8 0 3.8 0")
            line("M6.2 9.9q1.9-1 3.8 0t3.8 0 3.8 0")
            line("M6 12.8q1.9-1 3.8 0t3.8 0 3.8 0")
        }
    }

    val AirFlow: ImageVector by lazy {
        vector("AirFlow") {
            line(
                "M3 7.4h10.1c1.8 0 3.1-1.3 3.1-2.9 0-1.5-1.2-2.6-2.6-2.6" +
                    "-1.1 0-2 .6-2.4 1.5"
            )
            line(
                "M3 12.2h13.4c1.9 0 3.3 1.4 3.3 3.1 0 1.7-1.4 3-3 3" +
                    "-1.1 0-2.1-.6-2.5-1.6"
            )
            line("M3 17h6.4")
        }
    }

    val AirGlass: ImageVector by lazy {
        vector("AirGlass") {
            line("M7.6 4.3h8.8c.84 0 1.48.75 1.38 1.58l-.62 5.2c-.09.72-.7 1.26-1.42 1.26H8.26c-.72 0-1.33-.54-1.42-1.26l-.62-5.2C6.12 5.05 6.76 4.3 7.6 4.3Z")
            line("M8 20.8v-5.3M6.9 16.6l1.1-1.1 1.1 1.1")
            line("M12 21v-5.3M10.9 16.8l1.1-1.1 1.1 1.1")
            line("M16 20.8v-5.3M14.9 16.6l1.1-1.1 1.1 1.1")
        }
    }

    val AirFace: ImageVector by lazy {
        vector("AirFace") {
            line("M17.8 6.6A2.8 2.8 0 1 1 12.2 6.6A2.8 2.8 0 1 1 17.8 6.6Z")
            line("M10.4 20.8c0-3.2 2.1-5.8 4.6-5.8s4.6 2.6 4.6 5.8")
            line("M2.4 5.8h5.6M6.4 4.6l1.2 1.2-1.2 1.2")
            line("M2.4 9.8h5.6M6.4 8.6l1.2 1.2-1.2 1.2")
            line("M2.4 13.8h5.6M6.4 12.6l1.2 1.2-1.2 1.2")
        }
    }

    val AirFeet: ImageVector by lazy {
        vector("AirFeet") {
            line(
                "M16.4 3.8h1.7a1.7 1.7 0 0 1 1.7 1.7v11.4a2.8 2.8 0 0 1-2.8 2.8H9.2" +
                    "a2.3 2.3 0 0 1-2.3-2.3v-.8a3.4 3.4 0 0 1 1-2.4l5.4-5.2a2.2 2.2 0 0 0 .7-1.6" +
                    "V5.5a1.7 1.7 0 0 1 1.7-1.7Z"
            )
            line("M2.2 7.8h5.3M6.1 6.5l1.2 1.3-1.2 1.3")
            line("M2.2 11.3h4.6M5.4 10l1.2 1.3-1.2 1.3")
            line("M2.2 14.8h3.9M4.7 13.5l1.2 1.3-1.2 1.3")
        }
    }

    val AirGlassFeet: ImageVector by lazy {
        vector("AirGlassFeet") {
            line(
                "M3.51 3H10.11C10.74 3 11.22 3.562 11.145 4.185L10.68 8.085" +
                    "C10.612 8.625 10.155 9.03 9.615 9.03H4.005C3.465 9.03 3.007 8.625 2.94 8.085" +
                    "L2.475 4.185C2.4 3.562 2.88 3 3.51 3Z",
                1.6f
            )
            line(
                "M19.025 10.8H20.3A1.275 1.275 0 0 1 21.575 12.075V20.625" +
                    "A2.1 2.1 0 0 1 19.475 22.725H13.625A1.725 1.725 0 0 1 11.9 21V20.4" +
                    "A2.55 2.55 0 0 1 12.65 18.6L16.7 14.7A1.65 1.65 0 0 0 17.225 13.5V12.075" +
                    "A1.275 1.275 0 0 1 18.5 10.8Z",
                1.6f
            )
        }
    }

    /**
     * Полоса обогрева. В макете у неё свой узкий viewBox 6.4×36 с preserveAspectRatio="none",
     * поэтому HomeScreen растягивает её той же парой ширина/высота.
     */
    val HeatWave: ImageVector by lazy {
        vector("HeatWave", 6.4f, 36f) {
            line("M3.2 3C0.9 8.2 0.9 12.8 3.2 18C5.5 23.2 5.5 27.8 3.2 33", 2.8f)
        }
    }

    val Minus: ImageVector by lazy {
        vector("Minus") { line("M5 12H19", 1.65f) }
    }

    val Plus: ImageVector by lazy {
        vector("Plus") { line("M12 5V19M5 12H19", 1.65f) }
    }
}
