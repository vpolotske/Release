package com.ex2hub.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ex2hub.data.Store
import com.ex2hub.ui.AppIcons
import com.ex2hub.ui.CardHead
import com.ex2hub.ui.Eyebrow
import com.ex2hub.ui.HubCard
import com.ex2hub.ui.HubTextButton
import com.ex2hub.ui.InstalledApps
import com.ex2hub.ui.LaunchableApp
import com.ex2hub.ui.SectionNote
import com.ex2hub.ui.theme.HubColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private const val COLLAPSED_COUNT = 8

/** Выбор и порядок ярлыков нижней строки главной. Список — приложения ГУ с иконкой в лаунчере. */
@Composable
internal fun DockAppsCard(selected: List<String>, onChange: (List<String>) -> Unit) {
    val context = LocalContext.current
    val installed by produceState<List<LaunchableApp>?>(initialValue = null) {
        value = withContext(Dispatchers.IO) { InstalledApps.all(context) }
    }
    var expanded by rememberSaveable { mutableStateOf(false) }
    val full = selected.size >= Store.MAX_DOCK_APPS

    HubCard(Modifier.fillMaxWidth()) {
        CardHead(
            title = "Ярлыки на главной",
            eyebrow = "выбрано ${selected.size} из ${Store.MAX_DOCK_APPS}",
            trailing = {
                Icon(
                    imageVector = AppIcons.Home,
                    contentDescription = null,
                    tint = HubColors.Accent,
                    modifier = Modifier.size(18.dp)
                )
            }
        )
        Spacer(Modifier.height(12.dp))

        val apps = installed
        if (apps == null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(
                    modifier = Modifier.size(15.dp),
                    strokeWidth = 2.dp,
                    color = HubColors.Accent
                )
                Spacer(Modifier.width(8.dp))
                SectionNote("Собираю список приложений…")
            }
            return@HubCard
        }

        val byPackage = apps.associateBy { it.packageName }
        if (selected.isNotEmpty()) {
            Eyebrow("в нижней строке, по порядку")
            Spacer(Modifier.height(6.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                selected.forEachIndexed { index, pkg ->
                    val app = byPackage[pkg]
                    AppRow(
                        app = app,
                        fallbackLabel = pkg,
                        note = if (app == null) "не найдено на ГУ" else null
                    ) {
                        RowAction(AppIcons.ChevronLeft, "Раньше", enabled = index > 0) {
                            onChange(selected.toMutableList().apply { add(index - 1, removeAt(index)) })
                        }
                        RowAction(AppIcons.Chevron, "Позже", enabled = index < selected.lastIndex) {
                            onChange(selected.toMutableList().apply { add(index + 1, removeAt(index)) })
                        }
                        RowAction(AppIcons.Close, "Убрать", enabled = true, danger = true) {
                            onChange(selected - pkg)
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        val available = apps.filter { it.packageName !in selected }
        Eyebrow(if (full) "строка заполнена — уберите ярлык, чтобы добавить другой" else "добавить")
        Spacer(Modifier.height(6.dp))
        if (available.isEmpty()) {
            SectionNote("Других приложений с ярлыком в лаунчере нет.")
        } else {
            val shown = if (expanded) available else available.take(COLLAPSED_COUNT)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                shown.forEach { app ->
                    AppRow(app = app, fallbackLabel = app.packageName, note = null) {
                        RowAction(AppIcons.Plus, "Добавить", enabled = !full) {
                            onChange(selected + app.packageName)
                        }
                    }
                }
            }
            if (available.size > COLLAPSED_COUNT) {
                Spacer(Modifier.height(4.dp))
                HubTextButton(
                    text = if (expanded) "Свернуть" else "Показать все (${available.size})",
                    onClick = { expanded = !expanded },
                    icon = AppIcons.ChevronDown
                )
            }
        }
    }
}

@Composable
private fun AppRow(
    app: LaunchableApp?,
    fallbackLabel: String,
    note: String?,
    actions: @Composable () -> Unit
) {
    val shape = RoundedCornerShape(10.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(HubColors.SurfaceHigh.copy(alpha = 0.45f))
            .border(1.dp, HubColors.BorderSoft, shape)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val icon = app?.icon
        Box(
            Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(HubColors.SurfaceHigh),
            contentAlignment = Alignment.Center
        ) {
            if (icon != null) {
                Image(
                    bitmap = icon,
                    contentDescription = null,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                )
            } else {
                Icon(
                    imageVector = AppIcons.Info,
                    contentDescription = null,
                    tint = HubColors.Muted,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = app?.label ?: fallbackLabel,
                color = if (app == null) HubColors.Muted else HubColors.Text,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Medium
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = note ?: (app?.packageName ?: ""),
                color = if (note != null) HubColors.Amber else HubColors.Muted,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 18.sp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            actions()
        }
    }
}

@Composable
private fun RowAction(
    icon: ImageVector,
    description: String,
    enabled: Boolean,
    danger: Boolean = false,
    onClick: () -> Unit
) {
    val tint = when {
        !enabled -> HubColors.Track
        danger -> HubColors.Red
        else -> HubColors.Accent
    }
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(HubColors.SurfaceHigh)
            .border(1.dp, HubColors.BorderSoft, RoundedCornerShape(10.dp))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = description,
            tint = tint,
            modifier = Modifier.size(19.dp)
        )
    }
}
