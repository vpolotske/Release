package com.ex2hub.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.database.ContentObserver
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.setProgress
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.ex2hub.data.Fmt
import com.ex2hub.ui.theme.HubColors
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import kotlin.math.roundToInt

@Composable
fun SystemSettingsCard() {
    val controls = rememberHomeControls()
    HubCard(Modifier.fillMaxWidth()) {
        CardHead(title = "Экран и звук")
        Spacer(Modifier.height(8.dp))
        HomeSystemControls(controls, Modifier.fillMaxWidth())
    }
}

private data class MusicVolume(val current: Int, val maximum: Int, val fixed: Boolean)
private data class ScreenBrightness(val current: Int, val automatic: Boolean)

/** Unwrap only real ContextWrappers; guard against cycles and a destroyed Activity. */
private fun Context.findActivity(): Activity? {
    var current = this
    val visited = mutableSetOf<Context>()
    while (visited.add(current)) {
        if (current is Activity) return current.takeUnless { it.isFinishing || it.isDestroyed }
        current = (current as? ContextWrapper)?.baseContext ?: return null
    }
    return null
}

/** Reads never write; a released draft remains visible until its commit completes. */
private class HomeControls(private val context: Context, private val scope: CoroutineScope) {
    private data class Snapshot(
        val volume: MusicVolume?,
        val brightness: ScreenBrightness?,
        val canWriteBrightness: Boolean,
        val canOfferBrightnessAccess: Boolean
    )
    private data class VolumeCommit(val volume: MusicVolume?, val confirmed: Boolean)
    private data class BrightnessCommit(
        val systemMode: Boolean,
        val brightness: ScreenBrightness?,
        val confirmed: Boolean
    )

    var active by mutableStateOf(false)
        private set
    var volume by mutableStateOf<MusicVolume?>(null)
        private set
    var brightness by mutableStateOf<ScreenBrightness?>(null)
        private set
    var canWriteBrightness by mutableStateOf(false)
        private set
    var canOfferBrightnessAccess by mutableStateOf(false)
        private set
    var windowBrightnessInherited by mutableStateOf(true)
        private set
    var volumeDraft by mutableStateOf<Float?>(null)
        private set
    var brightnessDraft by mutableStateOf<Float?>(null)
        private set
    var volumeNotice by mutableStateOf<String?>(null)
        private set
    var brightnessNotice by mutableStateOf<String?>(null)
        private set
    private var volumeCommitting by mutableStateOf(false)
    private var brightnessCommitting by mutableStateOf(false)
    private var lifecycleVersion = 0L
    private var writeVersion = 0L
    private var refreshRunning = false
    private var refreshDirty = false
    private var accessRequestPending = false

    val volumeEnabled: Boolean
        get() = active && !volumeCommitting && volume?.let { !it.fixed && it.maximum > 0 } == true
    val brightnessEnabled: Boolean
        get() = active && !brightnessCommitting && brightness != null &&
            (canWriteBrightness || context.findActivity() != null)
    private val committing: Boolean
        get() = volumeCommitting || brightnessCommitting

    private fun isCurrent(version: Long) = active && lifecycleVersion == version

    private fun brightnessAccessIntent() =
        Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    private fun brightnessAccessResolvable(): Boolean = try {
        brightnessAccessIntent().resolveActivity(context.packageManager) != null
    } catch (_: Exception) {
        false
    }

    private fun readVolume(): MusicVolume? = try {
        val audio = context.getSystemService(AudioManager::class.java)
            ?: error("AudioManager недоступен")
        MusicVolume(
            current = audio.getStreamVolume(AudioManager.STREAM_MUSIC),
            maximum = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
            fixed = audio.isVolumeFixed
        )
    } catch (_: Exception) {
        null
    }

    private fun readBrightnessAccess(): Boolean = try {
        Settings.System.canWrite(context)
    } catch (_: Exception) {
        false
    }

    private fun readSystemBrightness(): ScreenBrightness? = try {
        val resolver = context.contentResolver
        val mode = Settings.System.getInt(resolver, Settings.System.SCREEN_BRIGHTNESS_MODE)
        check(mode == Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL ||
            mode == Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC)
        ScreenBrightness(
            current = Settings.System.getInt(resolver, Settings.System.SCREEN_BRIGHTNESS),
            automatic = mode == Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
        )
    } catch (_: Exception) {
        null
    }

    private fun readSnapshot(): Snapshot {
        val systemMode = readBrightnessAccess()
        return Snapshot(
            volume = readVolume(),
            brightness = readSystemBrightness(),
            canWriteBrightness = systemMode,
            canOfferBrightnessAccess = !systemMode && brightnessAccessResolvable()
        )
    }

    private fun applyBrightness(systemBrightness: ScreenBrightness?, systemMode: Boolean) {
        brightness = if (systemMode) {
            systemBrightness
        } else {
            try {
                context.findActivity()?.let { activity ->
                    val override = activity.window.attributes.screenBrightness
                    windowBrightnessInherited = !override.isFinite() || override < 0f
                    ScreenBrightness(
                        current = if (windowBrightnessInherited) systemBrightness?.current ?: 128
                            else (override * 255f).roundToInt().coerceIn(1, 255),
                        automatic = false
                    )
                }
            } catch (_: Exception) {
                null
            }
        }
    }

    fun updateActiveState(value: Boolean) {
        if (active == value) return
        active = value
        lifecycleVersion++
        volumeDraft = null
        brightnessDraft = null
        if (value) {
            volumeNotice = null
            brightnessNotice = null
        } else {
            refreshDirty = false
        }
    }

    fun refresh() {
        if (!active) return
        refreshDirty = true
        if (refreshRunning || committing) return
        refreshRunning = true
        scope.launch {
            try {
                // A single dirty bit bounds bursts; versions reject reads crossing a pause or write.
                while (active && refreshDirty && !committing) {
                    refreshDirty = false
                    val lifecycle = lifecycleVersion
                    val writes = writeVersion
                    val snapshot = withContext(Dispatchers.IO) { readSnapshot() }
                    if (isCurrent(lifecycle) && writes == writeVersion && !committing) {
                        volume = snapshot.volume
                        canWriteBrightness = snapshot.canWriteBrightness
                        canOfferBrightnessAccess = snapshot.canOfferBrightnessAccess
                        applyBrightness(snapshot.brightness, snapshot.canWriteBrightness)
                        if (!volumeEnabled) volumeDraft = null
                        if (!brightnessEnabled) brightnessDraft = null
                    } else if (active) {
                        refreshDirty = true
                    }
                }
            } finally {
                refreshRunning = false
                if (active && refreshDirty && !committing) refresh()
            }
        }
    }

    fun previewVolume(value: Float) {
        if (volumeEnabled) {
            volumeDraft = value
            volumeNotice = null
        }
    }

    fun cancelVolumePreview() {
        if (!volumeCommitting) volumeDraft = null
    }

    fun finishVolume() {
        val draft = volumeDraft ?: return
        if (!active || volumeCommitting) return
        val lifecycle = lifecycleVersion
        volumeCommitting = true
        writeVersion++
        scope.launch {
            try {
                if (!isCurrent(lifecycle)) return@launch
                val result = withContext(Dispatchers.IO) {
                    try {
                        val audio = context.getSystemService(AudioManager::class.java)
                            ?: error("AudioManager недоступен")
                        val maximum = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        check(!audio.isVolumeFixed && maximum > 0)
                        val requested = draft.roundToInt().coerceIn(0, maximum)
                        audio.setStreamVolume(AudioManager.STREAM_MUSIC, requested, 0)
                        val updated = readVolume()
                        VolumeCommit(updated, updated?.current == requested)
                    } catch (_: Exception) {
                        VolumeCommit(readVolume(), false)
                    }
                }
                if (!isCurrent(lifecycle)) return@launch
                volume = result.volume
                if (!result.confirmed) {
                    volumeNotice = "Система не подтвердила изменение громкости"
                    report("Система не подтвердила изменение громкости.")
                }
            } finally {
                volumeDraft = null
                volumeCommitting = false
                writeVersion++
                refresh()
            }
        }
    }

    fun previewBrightness(value: Float) {
        if (brightnessEnabled) {
            brightnessDraft = value
            brightnessNotice = null
        }
    }

    fun cancelBrightnessPreview() {
        if (!brightnessCommitting) brightnessDraft = null
    }

    private fun commitSystemBrightness(requested: Int): BrightnessCommit {
        val systemMode = readBrightnessAccess()
        if (!systemMode) return BrightnessCommit(false, readSystemBrightness(), true)
        return try {
            val resolver = context.contentResolver
            val mode = Settings.System.getInt(resolver, Settings.System.SCREEN_BRIGHTNESS_MODE)
            check(mode == Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL ||
                mode == Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC)
            // Only an explicit slider release may turn off system automatic brightness.
            if (mode == Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC) {
                check(Settings.System.putInt(
                    resolver,
                    Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
                ))
            }
            check(Settings.System.putInt(resolver, Settings.System.SCREEN_BRIGHTNESS, requested))
            val updated = readSystemBrightness()
            BrightnessCommit(true, updated, updated?.let { it.current == requested && !it.automatic } == true)
        } catch (_: Exception) {
            BrightnessCommit(true, readSystemBrightness(), false)
        }
    }

    fun finishBrightness() {
        val draft = brightnessDraft ?: return
        if (!active || brightnessCommitting) return
        val lifecycle = lifecycleVersion
        val requested = draft.roundToInt().coerceIn(1, 255)
        brightnessCommitting = true
        writeVersion++
        scope.launch {
            try {
                if (!isCurrent(lifecycle)) return@launch
                val result = withContext(Dispatchers.IO) { commitSystemBrightness(requested) }
                if (!isCurrent(lifecycle)) return@launch
                canWriteBrightness = result.systemMode
                if (result.systemMode) canOfferBrightnessAccess = false
                applyBrightness(result.brightness, result.systemMode)
                try {
                    check(result.confirmed)
                    if (result.systemMode) {
                        context.findActivity()?.window?.let { window ->
                            val attributes = window.attributes
                            if (attributes.screenBrightness >= 0f) {
                                // Drop an earlier app-only override only after this explicit system adjustment.
                                attributes.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                                window.attributes = attributes
                            }
                        }
                    } else {
                        val activity = context.findActivity() ?: error("Окно EX2 HUB недоступно")
                        val window = activity.window
                        val attributes = window.attributes
                        attributes.screenBrightness = requested / 255f
                        // Never set a window override during startup, observation or slider preview.
                        window.attributes = attributes
                        check((window.attributes.screenBrightness * 255f).roundToInt() == requested)
                        applyBrightness(result.brightness, false)
                    }
                } catch (_: Exception) {
                    brightnessNotice = if (result.systemMode) "Система не подтвердила изменение яркости"
                        else "Окно EX2 HUB не подтвердило изменение яркости"
                    report(brightnessNotice ?: "Яркость недоступна")
                }
            } finally {
                brightnessDraft = null
                brightnessCommitting = false
                writeVersion++
                refresh()
            }
        }
    }

    fun requestBrightnessAccess() {
        if (!active || accessRequestPending) return
        val lifecycle = lifecycleVersion
        accessRequestPending = true
        scope.launch {
            try {
                val resolvable = withContext(Dispatchers.IO) { brightnessAccessResolvable() }
                if (!isCurrent(lifecycle)) return@launch
                if (!resolvable) {
                    canOfferBrightnessAccess = false
                    return@launch
                }
                try {
                    context.startActivity(brightnessAccessIntent())
                } catch (_: Exception) {
                    canOfferBrightnessAccess = false
                    brightnessNotice = "Системный доступ недоступен; используйте яркость EX2 HUB"
                    report("Системный доступ недоступен. Яркость EX2 HUB не требует разрешения.")
                }
            } finally {
                accessRequestPending = false
            }
        }
    }

    fun observationUnavailable() {
        if (!active) return
        volumeNotice = "Нет обновлений"
        brightnessNotice = "Нет обновлений"
    }

    private fun report(message: String) {
        // The inline notice remains available even if the OEM blocks Toasts.
        try {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            // No further platform operation can safely report this failure.
        }
    }
}

private fun isHomeControlsSettingsUri(uri: Uri?): Boolean {
    if (uri == null) return true
    val base = Settings.System.CONTENT_URI
    if (uri.scheme != base.scheme || uri.authority != base.authority) return false
    val path = uri.pathSegments
    val basePath = base.pathSegments
    if (path.isEmpty()) return true
    if (path.take(basePath.size) != basePath) return false
    val key = path.getOrNull(basePath.size) ?: return true
    return key == Settings.System.SCREEN_BRIGHTNESS ||
        key == Settings.System.SCREEN_BRIGHTNESS_MODE ||
        key.startsWith("${Settings.System.SCREEN_BRIGHTNESS}_") ||
        key == "volume_music" || key.startsWith("volume_music_")
}

@Composable
private fun rememberHomeControls(): HomeControls {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val scope = rememberCoroutineScope()
    val controls = remember(context, scope) { HomeControls(context, scope) }
    DisposableEffect(controls, lifecycle) {
        val resolver = context.contentResolver
        var observationJob: Job? = null
        var observationVersion = 0L
        fun startObserving() {
            if (controls.active) return
            controls.updateActiveState(true)
            val version = ++observationVersion
            val handler = Handler(Looper.getMainLooper())
            val observer = object : ContentObserver(handler) {
                override fun onChange(selfChange: Boolean) {
                    if (controls.active && version == observationVersion) controls.refresh()
                }

                override fun onChange(selfChange: Boolean, uri: Uri?) {
                    if (isHomeControlsSettingsUri(uri)) onChange(selfChange)
                }
            }
            observationJob = scope.launch {
                try {
                    val registered = withContext(Dispatchers.IO) {
                        try {
                            resolver.registerContentObserver(Settings.System.CONTENT_URI, true, observer)
                            true
                        } catch (_: Exception) {
                            false
                        }
                    }
                    if (controls.active && version == observationVersion) {
                        if (!registered) controls.observationUnavailable()
                        controls.refresh()
                    }
                    if (registered) awaitCancellation()
                } finally {
                    handler.removeCallbacksAndMessages(null)
                    // Each resume owns its observer; even partial or late registration must be undone.
                    withContext(NonCancellable + Dispatchers.IO) {
                        try {
                            resolver.unregisterContentObserver(observer)
                        } catch (_: Exception) {
                            // A dead settings provider must not crash the process.
                        }
                        handler.removeCallbacksAndMessages(null)
                    }
                }
            }
            controls.refresh()
        }
        fun stopObserving() {
            observationVersion++
            controls.updateActiveState(false)
            observationJob?.cancel()
            observationJob = null
        }
        val lifecycleObserver = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> startObserving()
                Lifecycle.Event.ON_PAUSE, Lifecycle.Event.ON_STOP,
                Lifecycle.Event.ON_DESTROY -> stopObserving()
                else -> Unit
            }
        }
        lifecycle.addObserver(lifecycleObserver)
        if (lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) startObserving()
        onDispose {
            lifecycle.removeObserver(lifecycleObserver)
            stopObserving()
        }
    }
    return controls
}

@Composable
private fun HomeSystemControls(controls: HomeControls, modifier: Modifier = Modifier) {
    BoxWithConstraints(modifier) {
        // Keep each horizontal track usable even on very narrow displays.
        if (maxWidth < 480.dp) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                VolumeControl(controls, Modifier.fillMaxWidth())
                BrightnessControl(controls, Modifier.fillMaxWidth())
            }
        } else {
            Row(
                horizontalArrangement = Arrangement.spacedBy(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                VolumeControl(controls, Modifier.weight(1f))
                BrightnessControl(controls, Modifier.weight(1f))
            }
        }
    }
}

private fun Modifier.sliderTapRelease(onStart: () -> Unit, onRelease: () -> Unit): Modifier =
    pointerInput(onStart, onRelease) {
        awaitEachGesture {
            awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            onStart()
            if (waitForUpOrCancellation(PointerEventPass.Initial) != null) {
                // Slider stages a track tap in Main; read its draft only after that pass.
                awaitPointerEvent(PointerEventPass.Final)
                onRelease()
            }
        }
    }

private fun Modifier.sliderKeyRelease(onRelease: () -> Unit): Modifier = onPreviewKeyEvent { event ->
    if (event.type == KeyEventType.KeyUp) {
        when (event.key) {
            Key.DirectionLeft, Key.DirectionRight, Key.DirectionUp, Key.DirectionDown,
            Key.MoveHome, Key.MoveEnd, Key.PageUp, Key.PageDown -> onRelease()
            else -> Unit
        }
    }
    false
}

@Composable
private fun VolumeControl(controls: HomeControls, modifier: Modifier) {
    val interactions = remember { MutableInteractionSource() }
    LaunchedEffect(controls, interactions) {
        var drag: DragInteraction.Start? = null
        interactions.interactions.collect { interaction ->
            when (interaction) {
                is DragInteraction.Start -> drag = interaction
                is DragInteraction.Stop -> if (interaction.start === drag) {
                    drag = null
                    controls.finishVolume()
                }
                is DragInteraction.Cancel -> if (interaction.start === drag) {
                    drag = null
                    controls.cancelVolumePreview()
                }
                else -> Unit
            }
        }
    }
    val volume = controls.volume
    val maximum = (volume?.maximum ?: 0).coerceAtLeast(1)
    val status = when {
        volume == null -> "Недоступно"
        volume.fixed -> "${volume.current}/${volume.maximum} · фикс."
        else -> "${volume.current}/${volume.maximum}"
    }
    Column(modifier) {
        ControlLabel(AppIcons.Music, "Громкость", status, notice = controls.volumeNotice)
        Slider(
            value = (controls.volumeDraft ?: volume?.current?.toFloat() ?: 0f)
                .coerceIn(0f, maximum.toFloat()),
            onValueChange = controls::previewVolume,
            onValueChangeFinished = {},
            interactionSource = interactions,
            enabled = controls.volumeEnabled,
            valueRange = 0f..maximum.toFloat(),
            steps = if (maximum > 1) maximum - 1 else 0,
            colors = homeSliderColors(),
            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                .sliderTapRelease(controls::cancelVolumePreview, controls::finishVolume)
                .sliderKeyRelease(controls::finishVolume)
                .semantics {
                    contentDescription = "Громкость мультимедиа"
                    setProgress { requested ->
                        if (!controls.volumeEnabled || !requested.isFinite()) false else {
                            controls.previewVolume(requested.coerceIn(0f, maximum.toFloat()))
                            controls.finishVolume()
                            true
                        }
                    }
                }
        )
    }
}

@Composable
private fun BrightnessControl(controls: HomeControls, modifier: Modifier) {
    val interactions = remember { MutableInteractionSource() }
    LaunchedEffect(controls, interactions) {
        var drag: DragInteraction.Start? = null
        interactions.interactions.collect { interaction ->
            when (interaction) {
                is DragInteraction.Start -> drag = interaction
                is DragInteraction.Stop -> if (interaction.start === drag) {
                    drag = null
                    controls.finishBrightness()
                }
                is DragInteraction.Cancel -> if (interaction.start === drag) {
                    drag = null
                    controls.cancelBrightnessPreview()
                }
                else -> Unit
            }
        }
    }
    val brightness = controls.brightness
    val percent = brightness?.let { (it.current.coerceIn(0, 255) * 100f / 255f).roundToInt() }
    val label = if (controls.canWriteBrightness) "Яркость экрана" else "Яркость EX2 HUB"
    val status = when {
        brightness == null -> "Недоступно"
        !controls.canWriteBrightness && controls.windowBrightnessInherited -> "По системе"
        brightness.automatic -> "Авто · $percent%"
        else -> "$percent%"
    }
    Column(modifier) {
        ControlLabel(AppIcons.Headlight, label, status, notice = controls.brightnessNotice) {
            if (controls.canOfferBrightnessAccess) {
                TextButton(
                    onClick = controls::requestBrightnessAccess,
                    enabled = controls.active,
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                    modifier = Modifier.heightIn(min = 48.dp).widthIn(min = 48.dp)
                ) {
                    Text(
                        "Системный доступ",
                        color = HubColors.Accent,
                        fontSize = LocalHubText.current.controlStatus,
                        maxLines = 1
                    )
                }
            }
        }
        Slider(
            value = (controls.brightnessDraft ?: brightness?.current?.toFloat() ?: 1f)
                .coerceIn(1f, 255f),
            onValueChange = controls::previewBrightness,
            onValueChangeFinished = {},
            interactionSource = interactions,
            enabled = controls.brightnessEnabled,
            valueRange = 1f..255f,
            colors = homeSliderColors(),
            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                .sliderTapRelease(controls::cancelBrightnessPreview, controls::finishBrightness)
                .sliderKeyRelease(controls::finishBrightness)
                .semantics {
                    contentDescription = label
                    setProgress { requested ->
                        if (!controls.brightnessEnabled || !requested.isFinite()) false else {
                            controls.previewBrightness(requested.coerceIn(1f, 255f))
                            controls.finishBrightness()
                            true
                        }
                    }
                }
        )
    }
}

@Composable
private fun ControlLabel(
    icon: ImageVector,
    label: String,
    status: String,
    notice: String? = null,
    action: @Composable () -> Unit = {}
) {
    val scale = LocalHubText.current
    Row(
        modifier = Modifier.fillMaxWidth().heightIn(min = 24.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(icon, contentDescription = null, tint = HubColors.TextDim, modifier = Modifier.size(scale.controlIcon))
        Text(
            label, color = HubColors.TextDim, fontSize = scale.controlLabel,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
        )
        Text(
            status, color = HubColors.Muted, fontSize = scale.controlStatus,
            maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.widthIn(max = scale.controlStatusWidth)
        )
        if (notice != null) {
            Icon(
                AppIcons.Alert, contentDescription = notice, tint = HubColors.Accent,
                modifier = Modifier.size(scale.controlIcon)
            )
        }
        action()
    }
}

@Composable
private fun homeSliderColors() = SliderDefaults.colors(
    thumbColor = HubColors.Accent,
    activeTrackColor = HubColors.Accent,
    inactiveTrackColor = HubColors.BorderSoft
)

/** Часы и разделы: подписанные плитки, активная — с синей заливкой, как в макете. */
@Composable
fun HubNavRail(
    page: HubPage,
    onNavigate: (HubPage) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(modifier.fillMaxHeight()) {
        Column(
            Modifier
                .width(152.dp)
                .fillMaxHeight()
                .background(HubColors.RailBg)
                .padding(start = 12.dp, end = 12.dp, top = 30.dp, bottom = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Clock(Modifier.fillMaxWidth().padding(horizontal = 8.dp))
            Column(
                Modifier.fillMaxWidth().padding(top = 40.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                HubPage.entries.forEach { item ->
                    RailItem(
                        page = item,
                        selected = page == item,
                        onClick = { onNavigate(item) }
                    )
                }
            }
        }
        Box(
            Modifier
                .fillMaxHeight()
                .width(1.dp)
                .background(HubColors.RailLine)
        )
    }
}

@Composable
private fun RailItem(
    page: HubPage,
    selected: Boolean,
    onClick: () -> Unit
) {
    val icon: ImageVector = when (page) {
        HubPage.HOME -> AppIcons.Home
        HubPage.TRIPS -> AppIcons.Route
        HubPage.CHARGING -> AppIcons.Plug
        HubPage.SETTINGS -> AppIcons.Settings
    }
    val shape = RoundedCornerShape(12.dp)
    val iconColor = if (selected) HubColors.RailActiveIcon else HubColors.RailIdleIcon
    val textColor = if (selected) HubColors.RailActiveText else HubColors.RailIdleText
    Column(
        modifier = Modifier
            .width(if (selected) 107.8.dp else 98.dp)
            .height(132.dp)
            .clip(shape)
            .background(if (selected) HubColors.RailActiveBg else Color.Transparent)
            .border(1.dp, if (selected) HubColors.RailActiveBorder else Color.Transparent, shape)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = page.label,
            tint = iconColor,
            modifier = Modifier.size(42.dp)
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = page.label,
            color = textColor,
            fontSize = 19.sp,
            lineHeight = 19.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1
        )
    }
}

@Composable
private fun Clock(modifier: Modifier = Modifier) {
    val now by produceState(initialValue = LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(20_000L)
        }
    }
    Column(modifier) {
        Text(
            text = Fmt.timeInput(now.toLocalTime()),
            color = HubColors.RailClock,
            fontSize = 40.sp,
            lineHeight = 46.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = 0.3.sp,
            maxLines = 1
        )
        Spacer(Modifier.height(3.dp))
        Text(
            text = "${Fmt.weekdayCapital(now.toLocalDate())}, ${Fmt.dayMonth(now.toLocalDate())}",
            color = HubColors.RailClockDate,
            fontSize = 17.sp,
            lineHeight = 22.sp,
            maxLines = 1
        )
    }
}
